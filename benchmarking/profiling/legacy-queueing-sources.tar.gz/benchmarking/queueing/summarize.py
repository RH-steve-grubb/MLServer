"""Print per-configuration averages from one or more queueing sweep JSON files."""

import argparse
import csv
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


def report(path: Path) -> None:
    document = json.loads(path.read_text())
    groups: dict[tuple[str, int, int], list[dict[str, Any]]] = defaultdict(list)
    for row in document["results"]:
        groups[(row["config"], row["batch"], row["concurrency"])].append(row)
    print(f"\n{path}")
    writer = csv.writer(sys.stdout)
    writer.writerow(
        [
            "config",
            "batch",
            "concurrency",
            "repeats",
            "mean_rps",
            "mean_latency_ms",
            "mean_frontend_cpu_cores",
        ]
    )
    for (config, batch, concurrency), rows in groups.items():
        writer.writerow(
            [
                config,
                batch,
                concurrency,
                len(rows),
                round(statistics.mean(row["rps"] for row in rows), 2),
                round(
                    statistics.mean(
                        row["timings"]["client_ms"]["mean"] for row in rows
                    ),
                    2,
                ),
                round(statistics.mean(row["server_main_cpu_cores"] for row in rows), 2),
            ]
        )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path, nargs="+")
    for path in parser.parse_args().results:
        report(path)


if __name__ == "__main__":
    main()
