"""Strict GIL-on controls and no-GIL trace interpretation."""

import json

import pytest

from . import free_threaded_profile as profile


def test_empty_trace_is_allowed_only_for_no_gil(tmp_path):
    trace = tmp_path / "events.txt"
    trace.write_text("# empty trace\n")
    window = profile.original.Window(0, 1000)
    with pytest.raises(RuntimeError, match="no complete GIL acquisitions"):
        profile.analyze_trace(trace, {}, window, "on")
    result = profile.analyze_trace(trace, {}, window, "off")
    assert result["valid"]
    assert result["condition_wait_thread_ms"] == 0
    assert result["count_semantics"] == "calls, not acquisitions"


def test_no_gil_trace_still_rejects_lost_events(tmp_path):
    trace = tmp_path / "events.txt"
    trace.write_text("LOST 17 events!\n")
    with pytest.raises(RuntimeError, match="lost events"):
        profile.analyze_trace(trace, {}, profile.original.Window(0, 1000), "off")


def test_no_gil_fast_take_gil_call_is_not_a_lock_acquisition(tmp_path):
    trace = tmp_path / "events.txt"
    trace.write_text(" 10 0.000000100: g:in:\n 10 0.000000200: g:out:\n")
    result = profile.analyze_trace(
        trace,
        {"g:in": "take_in", "g:out": "take_out"},
        profile.original.Window(0, 1000),
        "off",
    )
    assert result["acquisition"]["count"] == 1
    assert result["acquisitions_with_condition_wait"] == 0
    assert result["count_semantics"] == "calls, not acquisitions"


def test_no_gil_trace_rejects_actual_gil_wait(tmp_path):
    trace = tmp_path / "events.txt"
    trace.write_text(
        " 10 0.000000100: g:take_in:\n"
        " 10 0.000000200: g:cond_in:\n"
        " 10 0.000000300: g:cond_out:\n"
        " 10 0.000000400: g:take_out:\n"
    )
    events = {
        f"g:{role}": role for role in ("take_in", "cond_in", "cond_out", "take_out")
    }
    with pytest.raises(RuntimeError, match="unexpectedly waited"):
        profile.analyze_trace(trace, events, profile.original.Window(0, 1000), "off")
    assert profile.analyze_trace(trace, events, profile.original.Window(0, 1000), "on")[
        "condition_wait_thread_ms"
    ] == pytest.approx(0.0001)


def test_no_gil_trace_rejects_incomplete_call(tmp_path):
    trace = tmp_path / "events.txt"
    trace.write_text(" 10 0.000000100: g:in:\n")
    with pytest.raises(RuntimeError, match="unfinished GIL calls"):
        profile.analyze_trace(
            trace, {"g:in": "take_in"}, profile.original.Window(0, 1000), "off"
        )


@pytest.mark.parametrize(
    "build,enabled,mode", [(0, False, "off"), (1, True, "off"), (1, False, "on")]
)
def test_interpreter_preflight_rejects_incorrect_build_or_mode(
    monkeypatch, build, enabled, mode
):
    monkeypatch.setattr(
        profile.original,
        "command",
        lambda args, env: json.dumps(
            dict(
                implementation="cpython",
                minor=[3, 14],
                gil_disabled=build,
                gil_enabled=enabled,
            )
        ),
    )
    with pytest.raises(RuntimeError, match="build or actual GIL mode"):
        profile.python_info(profile.Path("python"), mode)
