"""Compare worker-side JSON and two frontends, retaining Queue/pickle and ONNX.

Run as the ordinary user with the study's MLServer Python-3.12 environment.
Results, logs and source snapshots go into a NEW durable --output directory.
No packages, privilege changes, aiohttp server or ZeroMQ adapter are installed.
"""

import argparse
import importlib
import json
import math
import os
import shutil
import statistics
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

_cleanup = importlib.import_module(
    f"{__package__}.run_zmq_experiment" if __package__ else "run_zmq_experiment"
)

BENCH = Path(__file__).with_name("bench.py")
VARIANTS = {
    "stock-1x6": ("frontend", "pool6-tuned", 1),
    "worker-input-1x6": ("input", "pool6-tuned", 1),
    "worker-json-1x6": ("full", "pool6-tuned", 1),
    "stock-2x3": ("frontend", "replica2-pool3", 2),
}


def validate(document: dict[str, Any], variant: str) -> None:
    mode, config, frontends = VARIANTS[variant]
    meta = document["metadata"]
    if meta["queue_json"] != mode or meta["queue_transport"] != "queue":
        raise ValueError("Requested JSON/transport mode was not selected")
    if not document["results"] or meta["probed"]:
        raise ValueError("Empty or instrumented benchmark")
    for row in document["results"]:
        if row["errors"] or row["total_drained"] <= 0:
            raise ValueError("Prediction failure or empty measurement")
        if not math.isfinite(row["rps"]) or row["rps"] <= 0:
            raise ValueError("Invalid completion rate")
        if any(
            row[key] != value
            for key, value in (
                ("config", config),
                ("frontends", frontends),
                ("total_workers", 6),
                ("threads", 1),
                ("queue_codec", "pickle"),
                ("queue_tensors", "list"),
                ("queue_transport", "queue"),
                ("queue_json", mode),
            )
        ) or any(
            row[key] for key in ("codec_counts", "tensor_counts", "transport_counts")
        ):
            raise ValueError("Confounded configuration or codec/transport counters")
        counts = row["raw_counts"]
        if mode == "frontend":
            if counts:
                raise ValueError("Stock control unexpectedly used raw worker JSON")
        elif any(
            counts[key] != expected
            for key, expected in (
                ("raw_requests", row["total_drained"]),
                ("raw_worker_replies", row["total_drained"]),
                ("raw_input_bytes", row["total_drained"] * row["request_bytes"]),
                ("raw_byte_replies", row["total_drained"] if mode == "full" else 0),
            )
        ):
            raise ValueError("Raw request/reply count or byte validation failed")


def run_block(args: argparse.Namespace, variant: str, index: int) -> dict[str, Any]:
    mode, config, _ = VARIANTS[variant]
    result = args.output / f"{index:02d}-{variant}.json"
    env = dict(os.environ)
    env.update(
        MLSERVER_QUEUE_JSON=mode,
        MLSERVER_QUEUE_TRANSPORT="queue",
        MLSERVER_QUEUE_CODEC="pickle",
        MLSERVER_QUEUE_TENSORS="list",
        MLSERVER_QUEUE_PROBE="0",
        PYTHONDONTWRITEBYTECODE="1",
    )
    reverse = (index // len(VARIANTS)) % 2 == 1
    batches = args.batches[::-1] if reverse else args.batches
    concurrency = args.concurrencies[::-1] if reverse else args.concurrencies
    command = [
        sys.executable,
        str(BENCH),
        "sweep",
        str(args.model),
        "--configs",
        config,
        "--unprobed",
        "--batches",
        *map(str, batches),
        "--concurrencies",
        *map(str, concurrency),
        "--seconds",
        str(args.seconds),
        "--repeats",
        "1",
        "--output",
        str(result),
    ]
    print(f"Block {index + 1}: {variant}; {result}", flush=True)
    with result.with_suffix(".log").open("w") as log:
        process = subprocess.Popen(
            command,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            code = process.wait(
                timeout=300 + args.seconds * len(batches) * len(concurrency)
            )
            if code:
                raise RuntimeError(f"Benchmark exited {code}; inspect {log.name}")
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Benchmark left a live process in its owned group")
        except BaseException:
            _cleanup.stop_owned_group(process)
            raise
    document = json.loads(result.read_text())
    validate(document, variant)
    expected = {(b, c) for b in args.batches for c in args.concurrencies}
    actual = {(r["batch"], r["concurrency"]) for r in document["results"]}
    if actual != expected or len(document["results"]) != len(expected):
        raise ValueError("Incomplete or duplicate workload matrix")
    for row in document["results"]:
        row.update(
            variant=variant, independent_trial=index // len(VARIANTS), block=index
        )
    return document


def summarize(output: Path, documents: list[dict[str, Any]]) -> None:
    groups: dict[tuple[int, int, str], list[dict[str, Any]]] = defaultdict(list)
    for doc in documents:
        for row in doc["results"]:
            groups[(row["batch"], row["concurrency"], row["variant"])].append(row)
    lines = [
        "Worker JSON placement / two-frontends ONNX experiments",
        "====================================================",
        "",
        f"Completed validated blocks: {len(documents)}.",
        "All variants retain Uvicorn, Queue/pickle, round robin and six workers.",
        "One ORT thread/worker, spinning off, no adaptive batching/gzip/REST metrics.",
        "stock-1x6: one frontend, six workers, original typed JSON request/reply.",
        "worker-input-1x6: request bytes -> worker parse/validation/DataPlane.",
        "worker-json-1x6: additionally return worker-encoded JSON response bytes.",
        "stock-2x3: two complete frontends with three workers each, original JSON.",
        "Worker CPU is summed Linux /proc process CPU, including their threads.",
        "Loop lag: max frontend statistic per window, not pooled percentiles.",
        "Numerical warm-ups and exact raw-mode counters checked in completed blocks.",
        "",
        "Rows C Variant Repeats MeanRPS SD MeanLatencyMs FrontCPU WorkerCPU "
        "ClientCPU LoopP95/MaxMs GainVsStock1x6",
    ]
    for (batch, c, variant), rows in sorted(groups.items()):
        rates = [r["rps"] for r in rows]
        avg = statistics.mean(rates)
        sd = statistics.stdev(rates) if len(rates) > 1 else 0
        latency = statistics.mean(r["timings"]["client_ms"]["mean"] for r in rows)
        cpu = [
            statistics.mean(r[key] for r in rows)
            for key in ("server_main_cpu_cores", "worker_cpu_cores", "client_cpu_cores")
        ]
        p95 = statistics.mean(r["server_loop_lag_ms"]["p95"] for r in rows)
        worst = max(r["server_loop_lag_ms"]["max"] for r in rows)
        control = groups.get((batch, c, "stock-1x6"))
        gain = (
            f"{100*(avg/statistics.mean(r['rps'] for r in control)-1):+.2f}%"
            if control
            else "N/A"
        )
        lines.append(
            f"{batch:4} {c:2} {variant:17} {len(rows):7} {avg:8.2f} {sd:7.2f} "
            f"{latency:10.2f} {cpu[0]:8.2f} {cpu[1]:9.2f} {cpu[2]:9.2f} "
            f"{p95:7.2f}/{worst:.2f} {gain}"
        )
    lines += [
        "",
        "Synthetic CPU-only localhost closed-loop windows, not production SLOs.",
        "Core inference metrics/middleware move into workers in raw modes.",
        "Replica clients alternate directly between ports; no load balancer measured.",
        "No GIL tracing, shared worker pool, zero copy, aiohttp or ZeroMQ comparison.",
        "Startup/shutdown controls are not production lifecycle/cancellation coverage.",
    ]
    (output / "SUMMARY.txt").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[2, 64])
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        parser.error("Use the study's MLServer Python-3.12 Poetry environment")
    if (
        not math.isfinite(args.seconds)
        or args.seconds <= 0
        or args.repeats <= 0
        or min(args.batches + args.concurrencies) <= 0
    ):
        parser.error("Duration, repeats and workload values must be positive/finite")
    args.output, args.model = args.output.absolute(), args.model.absolute()
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    source = args.output / "source"
    source.mkdir()
    for name in (
        "bench.py",
        "probe.py",
        "raw_worker.py",
        "test_raw_worker.py",
        "run_pending_experiments.py",
        "test_pending_experiments.py",
        "run_zmq_experiment.py",
    ):
        shutil.copy2(BENCH.with_name(name), source / name)
    project = BENCH.parents[2]
    for name in ("pyproject.toml", "poetry.lock"):
        shutil.copy2(project / name, source / name)
    documents: list[dict[str, Any]] = []
    try:
        for trial in range(args.repeats):
            order = list(VARIANTS)
            if trial % 2:
                order.reverse()
            for variant in order:
                documents.append(run_block(args, variant, len(documents)))
                (args.output / "results.json").write_text(
                    json.dumps(documents, indent=2)
                )
                summarize(args.output, documents)
    finally:
        summarize(args.output, documents)
    print(f"Finished. Read {args.output / 'SUMMARY.txt'}", flush=True)


if __name__ == "__main__":
    main()
