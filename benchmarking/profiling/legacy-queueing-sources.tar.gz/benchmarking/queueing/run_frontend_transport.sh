#!/usr/bin/env bash
# Keep all source, locks, logs and measurements in this durable study bundle.
set -euo pipefail

TRANSPORT_STORE=${MLSERVER_FRONTEND_TRANSPORT_STORE:-/home/codex/mlserver-durable-store/frontend-transport-20261008}
TRANSPORT_CLIENT=/home/codex/tmp/mlserver-perf-venvs/mlserver-bnlygABv-py3.12/bin/python
TRANSPORT_SERVER="$TRANSPORT_STORE/poetry-project/.venv/bin/python"

export MLSERVER_STUDY_REPO="$TRANSPORT_STORE/source-original"
exec "$TRANSPORT_CLIENT" "$TRANSPORT_STORE/harness/run_frontend_transport.py" \
    --server-python "$TRANSPORT_SERVER" \
    --client-python "$TRANSPORT_CLIENT" \
    --source "$TRANSPORT_STORE/source" \
    --model "$TRANSPORT_STORE/mlserver-queue-mlp.onnx" \
    --output "$TRANSPORT_STORE/run-$(date -u +%Y%m%dT%H%M%SZ)-$$" \
    "$@"
