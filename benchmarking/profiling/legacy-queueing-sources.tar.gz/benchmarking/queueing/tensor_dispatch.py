"""Opt-in input-buffer experiment for the synthetic ONNX benchmark model.

Conversion runs on every frontend prediction, before the existing Queue.put().
It is not cached or moved outside the measurement window. Worker decoding,
ONNX, response representation and transport are unchanged. This narrow FP32
diagnostic is not a general request conversion policy for arbitrary runtimes.
"""

import time

import numpy as np

from mlserver.codecs import NumpyCodec
from mlserver.parallel.model import ParallelModel
from mlserver.types import InferenceRequest, InferenceResponse

_ORIGINAL = ParallelModel.predict
COUNTS = {"requests": 0.0, "inputs": 0.0, "seconds": 0.0, "bytes": 0.0}


def compact_request(payload: InferenceRequest) -> InferenceRequest:
    """Copy FP32 inputs to typed buffers without mutating the caller's request."""
    started = time.perf_counter()
    inputs = []
    converted = 0
    tensor_bytes = 0
    for tensor in payload.inputs:
        if tensor.datatype != "FP32" or isinstance(tensor.data.root, np.ndarray):
            inputs.append(tensor)
            continue
        # Use exactly the ordinary worker's dtype/reshape conversion. Moving
        # it earlier has a cost, and the worker still performs its normal copy.
        buffer = np.ascontiguousarray(NumpyCodec.decode_input(tensor))
        data = tensor.data.model_copy(update={"root": buffer})
        inputs.append(tensor.model_copy(update={"data": data}))
        converted += 1
        tensor_bytes += buffer.nbytes
    if not converted:
        return payload
    result = payload.model_copy(update={"inputs": inputs})
    COUNTS["requests"] += 1
    COUNTS["inputs"] += converted
    COUNTS["bytes"] += tensor_bytes
    COUNTS["seconds"] += time.perf_counter() - started
    return result


async def buffered_predict(
    self: ParallelModel, payload: InferenceRequest
) -> InferenceResponse:
    # Other models and non-predict operations retain their original behavior.
    # The synthetic benchmark's inputs are FP32; BYTES/FP64 policies are outside
    # this experiment, rather than silently forcing every input into FP32.
    if self.name == "queue-mlp":
        payload = compact_request(payload)
    return await _ORIGINAL(self, payload)


def install() -> None:
    """Install only in this benchmark process; spawn repeats the opt-in hook."""
    setattr(ParallelModel, "predict", buffered_predict)
