"""Root-only frontend GIL/native tracing for the matched REST/JSON study.

Reuses the validated perf control, ELF-offset probes and interval accounting,
but not the old collector's Python 3.12 assumptions. Every run must validate a
known-contention GIL-on workload and a no-GIL negative control on this binary.
GIL-off take_gil entries, if present, are calls, not lock acquisitions.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import json
import os
import select
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, TYPE_CHECKING

study = importlib.import_module(
    f"{__package__}.free_threaded" if __package__ else "free_threaded"
)
original = importlib.import_module(
    f"{__package__}.gil_profile" if __package__ else "gil_profile"
)

if TYPE_CHECKING:
    from .gil_profile import Probes, Window


def mapped_images(pid: int) -> list[Path]:
    images = {Path(f"/proc/{pid}/exe").resolve()}
    for line in Path(f"/proc/{pid}/maps").read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith("/"):
            path = Path(fields[5])
            if "libpython3.14t" in path.name or path.name == "libc.so.6":
                images.add(path.resolve())
    return sorted(images)


def python_info(python: Path, mode: str) -> dict[str, Any]:
    code = (
        "import json,sys,sysconfig; "
        "print(json.dumps(dict(version=sys.version,minor=sys.version_info[:2],"
        "implementation=sys.implementation.name,executable=sys._base_executable,"
        "gil_disabled=sysconfig.get_config_var('Py_GIL_DISABLED'),"
        "gil_enabled=sys._is_gil_enabled())))"
    )
    info = json.loads(
        original.command(
            [str(python), "-c", code], env=study.environment(Path("/unused"), mode)
        )
    )
    if info["implementation"] != "cpython" or info["minor"] != [3, 14]:
        raise RuntimeError("This collector requires CPython 3.14")
    if info["gil_disabled"] != 1 or info["gil_enabled"] != (mode == "on"):
        raise RuntimeError("Interpreter build or actual GIL mode is incorrect")
    return info


def analyze_trace(
    path: Path, events: dict, window: Window, mode: str
) -> dict[str, Any]:
    analysis = original.TraceAnalysis(window)
    parsed = 0
    lost = False
    for line in path.read_text().splitlines():
        lost |= "LOST" in line.upper()
        match = original.EVENT_LINE.match(line)
        if match is None:
            continue
        tid, seconds, fraction, event = match.groups()
        if event not in events:
            continue
        stamp = int(seconds) * 10**9 + int(fraction.ljust(9, "0"))
        analysis.feed(int(tid), stamp, events[event])
        parsed += 1
    result = analysis.finish()
    result.update(parsed_events=parsed, lost_events_reported=lost)
    reasons = []
    if lost:
        reasons.append("perf reported lost events")
    if (
        result["unmatched_events"]
        or result["open_acquisitions"]
        or result["open_condition_waits"]
    ):
        reasons.append("unpaired or unfinished GIL calls")
    if mode == "on" and not result["acquisition"]["count"]:
        reasons.append("no complete GIL acquisitions in GIL-on control")
    if mode == "off" and result["acquisitions_with_condition_wait"]:
        reasons.append("GIL-off process unexpectedly waited inside take_gil")
    result.update(
        valid=not reasons,
        invalid_reasons=reasons,
        mode=mode,
        count_semantics="acquisitions" if mode == "on" else "calls, not acquisitions",
    )
    if reasons:
        result["condition_wait_thread_ms"] = None
    original.require_valid_trace(result)
    return result


def read_trace(
    directory: Path, probes: Probes, window: Window, mode: str
) -> dict[str, Any]:
    trace = directory / "events.txt"
    with trace.open("w") as output:
        process = subprocess.run(
            [
                "perf",
                "script",
                "--ns",
                "--show-lost-events",
                "-i",
                str(directory / "perf.data"),
                "-F",
                "tid,time,event",
            ],
            stdout=output,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60,
        )
    directory.joinpath("decode.log").write_text(process.stderr)
    if process.returncode:
        raise RuntimeError(process.stderr[-4000:])
    result = analyze_trace(trace, probes.events, window, mode)
    directory.joinpath("analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def self_test_worker() -> None:
    ready = threading.Barrier(3)
    start = threading.Event()
    until = 0.0

    def busy() -> None:
        ready.wait()
        start.wait()
        value = 0
        while time.perf_counter() < until:
            for _ in range(10000):
                value += 1

    threads = [threading.Thread(target=busy) for _ in range(2)]
    for thread in threads:
        thread.start()
    ready.wait()
    enabled = getattr(sys, "_is_gil_enabled")()
    print(json.dumps({"ready": True, "gil_enabled": enabled}), flush=True)
    for command in ("quiet", "contended"):
        if sys.stdin.readline().strip() != command:
            raise RuntimeError("Unexpected self-test command")
        began = time.perf_counter_ns()
        if command == "quiet":
            for _ in range(100):
                time.sleep(0.01)
        else:
            sys.setswitchinterval(0.002)
            until = time.perf_counter() + 2
            start.set()
            for thread in threads:
                thread.join()
        print(
            json.dumps(
                {
                    "start": began,
                    "end": time.perf_counter_ns(),
                    "gil_enabled": getattr(sys, "_is_gil_enabled")(),
                }
            ),
            flush=True,
        )
    sys.stdin.readline()


def self_test(args: argparse.Namespace, mode: str) -> None:
    directory = args.output / f"self-test-{mode}"
    directory.mkdir()
    with contextlib.ExitStack() as cleanup:
        log = cleanup.enter_context(directory.joinpath("worker.log").open("w"))
        worker = subprocess.Popen(
            [
                str(args.server_python),
                str(Path(__file__).resolve()),
                "--self-test-worker",
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=log,
            text=True,
            env=study.environment(args.source, mode),
        )
        cleanup.callback(original.stop_process, worker)
        assert worker.stdin is not None and worker.stdout is not None
        cleanup.callback(worker.stdin.close)
        cleanup.callback(worker.stdout.close)

        def receive() -> dict:
            assert worker.stdout is not None
            readable, _, _ = select.select([worker.stdout], [], [], 15)
            if not readable:
                raise RuntimeError("Self-test timed out")
            row = json.loads(worker.stdout.readline())
            if row["gil_enabled"] != (mode == "on"):
                raise RuntimeError("Self-test ran in incorrect GIL mode")
            return row

        if not receive()["ready"]:
            raise RuntimeError("Self-test was not ready")
        probes = original.Probes(mapped_images(worker.pid))
        with original.recording(worker.pid, directory, probes):
            windows = {}
            for name in ("quiet", "contended"):
                worker.stdin.write(name + "\n")
                worker.stdin.flush()
                windows[name] = receive()
        worker.stdin.close()
        worker.wait(timeout=10)
        if worker.returncode:
            raise RuntimeError("Self-test worker failed")
        results = {
            name: read_trace(
                directory, probes, original.Window(row["start"], row["end"]), mode
            )
            for name, row in windows.items()
        }
        directory.joinpath("windows.json").write_text(json.dumps(windows, indent=2))
        directory.joinpath("results.json").write_text(json.dumps(results, indent=2))
        if mode == "on":
            original.validate_self_test(results["quiet"], results["contended"])
        directory.joinpath("PASSED").write_text(
            "Validated actual GIL mode and paired trace accounting.\n"
        )
        print(f"Self-test {mode}: PASSED", flush=True)


def load(args: argparse.Namespace, port: int, directory: Path) -> dict:
    env = study.environment(study.REPO, "on")
    env["PYTHONPATH"] += os.pathsep + str(study.REPO / "runtimes/onnx")
    with directory.joinpath("client.log").open("w") as log:
        subprocess.run(
            [
                str(args.client_python),
                str(study.HERE / "bench.py"),
                "load",
                str(args.model),
                "--port",
                str(port),
                "--batch",
                str(args.batch),
                "--concurrency",
                str(args.concurrency),
                "--seconds",
                str(args.seconds),
            ],
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=True,
            timeout=args.seconds + 240,
        )
    row = json.loads(directory.joinpath("client.log").read_text().splitlines()[-1])
    if row["errors"]:
        raise RuntimeError("Prediction errors; inspect client.log")
    directory.joinpath("load.json").write_text(json.dumps(row, indent=2))
    return row


def collect(args: argparse.Namespace, directory: Path, mode: str) -> list[dict]:
    directory.mkdir()
    port = study.free_port()
    env = study.environment(args.source, mode)
    env.update(MLSERVER_FT_EXPECT=mode, MLSERVER_FT_SOURCE=str(args.source))
    env["MLSERVER_FT_WORKER_GIL"] = args.worker_gil
    rows = []
    with directory.joinpath("server.log").open("w") as log:
        server = subprocess.Popen(
            [
                str(args.server_python),
                str(study.HERE / "free_threaded.py"),
                "serve",
                str(args.model),
                "--port",
                str(port),
                "--workers",
                str(args.workers),
                "--threads",
                "1",
                "--no-spin",
                "--unprobed",
            ],
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            study.wait_ready(server, port)
            for phase in ("baseline-before", "gil", "cpu", "baseline-after"):
                target = directory / phase
                target.mkdir()
                state_before = study.read_json(port, "/free-threaded/state")
                print(f"{directory.name}: {phase}", flush=True)
                probes = (
                    original.Probes(mapped_images(server.pid))
                    if phase == "gil"
                    else None
                )
                # baseline-before also creates all six Queue feeder threads
                # before perf attaches. No tracing is active in either baseline.
                if phase.startswith("baseline"):
                    row = load(args, port, target)
                else:
                    with original.recording(server.pid, target, probes):
                        row = load(args, port, target)
                    window = original.Window(
                        row["measurement_started_ns"], row["measurement_drained_ns"]
                    )
                    if probes:
                        row["gil"] = read_trace(target, probes, window, mode)
                    else:
                        report = original.command(
                            [
                                "perf",
                                "report",
                                "--stdio",
                                "--no-children",
                                "-i",
                                str(target / "perf.data"),
                                "--sort",
                                "comm,tgid,pid,dso,symbol",
                                "--time",
                                f"{window.start / 1e9:.9f},{window.end / 1e9:.9f}",
                            ]
                        )
                        target.joinpath("cpu-report.txt").write_text(report)
                row.update(
                    mode=mode,
                    phase=phase,
                    frontend_pid=server.pid,
                    state_before=state_before,
                    state_after=study.read_json(port, "/free-threaded/state"),
                )
                rows.append(row)
                target.joinpath("result.json").write_text(json.dumps(row, indent=2))
        finally:
            study.close_server(server, port)
    return rows


def write_summary(output: Path, rows: list[dict]) -> None:
    lines = [
        "Matched CPython 3.14 frontend profiling: REST/HTTP JSON only.",
        "Queue/pickle and existing threads unchanged; one frontend, six workers.",
        "GIL-on and no-GIL self-tests must both pass before serving traces.",
        "Compare profiled RPS with surrounding unprofiled baselines.",
        "",
    ]
    for mode in ("on", "off"):
        passed = output.joinpath(f"self-test-{mode}/PASSED").is_file()
        lines.append(f"Self-test {mode}: {'PASSED' if passed else 'NOT PASSED'}")
    for row in rows:
        lines.append(
            f"batch={row['batch']} C={row['concurrency']} GIL={row['mode']} "
            f"{row['phase']}: {row['rps']:.1f} RPS"
        )
        if "gil" in row:
            trace = row["gil"]
            lines.append(
                f"  take_gil {trace['count_semantics']}: "
                f"{trace['acquisition']['count']}; contended: "
                f"{trace['acquisitions_with_condition_wait']}; "
                f"condition wait: {trace['condition_wait_thread_ms']:.2f} thread-ms"
            )
            for thread in trace["threads"]:
                lines.append(
                    f"    TID {thread['tid']}: "
                    f"{thread['condition_wait_ms']:.2f} thread-ms"
                )
    lines.extend(
        [
            "",
            "Condition wait is counted only within paired take_gil calls.",
            "It includes wakeup/scheduling and mutex reacquisition, not just sleep.",
            "No GIL-held-time percentage is estimated; "
            "thread totals may exceed wall time.",
            "No-GIL does not eliminate other object/application locks or queue costs.",
            "Only the frontend is traced. "
            "Worker processes have independent interpreters.",
        ]
    )
    output.joinpath("SUMMARY.txt").write_text("\n".join(lines) + "\n")


def main() -> None:
    if "--self-test-worker" in sys.argv:
        self_test_worker()
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--server-python", type=Path, required=True)
    parser.add_argument("--client-python", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[64])
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--worker-gil", choices=["on", "matched"], default="on")
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--self-test-only", action="store_true")
    args = parser.parse_args()
    for tool in ("perf", "nm", "objdump"):
        if not shutil.which(tool):
            parser.error(f"Required tool missing: {tool}")
    info = {mode: python_info(args.server_python, mode) for mode in ("on", "off")}
    print(json.dumps(info, indent=2), flush=True)
    study.source_manifest(args.source)
    if args.check:
        print(
            "Read-only interpreter/source preflight passed. "
            "Root self-tests are still required."
        )
        return
    if os.geteuid() != 0:
        parser.error("Run from a root shell; this harness never invokes sudo")
    if (
        args.seconds <= 0
        or args.workers <= 0
        or min(args.batches + args.concurrencies) <= 0
    ):
        parser.error("Duration, workers and workload sizes must be positive")
    args.output.mkdir(parents=True, exist_ok=False)
    args.output.chmod(0o755)

    def interrupted(signum: int, frame: Any) -> None:
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, interrupted)
    rows = []
    try:
        self_test(args, "on")
        self_test(args, "off")
        args.output.joinpath("metadata.json").write_text(
            json.dumps(
                dict(
                    scope="REST/HTTP JSON only",
                    worker_gil=args.worker_gil,
                    workers=args.workers,
                    seconds=args.seconds,
                    batches=args.batches,
                    concurrencies=args.concurrencies,
                    model_sha256=hashlib.sha256(args.model.read_bytes()).hexdigest(),
                    git_commit=os.environ.get("MLSERVER_STUDY_COMMIT"),
                    cpu_affinity=sorted(os.sched_getaffinity(0)),
                    python=info,
                    audit=original.audit_status(),
                    source_manifest=study.source_manifest(args.source),
                ),
                indent=2,
            )
        )
        if not args.self_test_only:
            for batch in args.batches:
                for concurrency in args.concurrencies:
                    args.batch, args.concurrency = batch, concurrency
                    for mode in ("on", "off"):
                        rows.extend(
                            collect(
                                args,
                                args.output / f"b{batch}-c{concurrency}-{mode}",
                                mode,
                            )
                        )
                        args.output.joinpath("results.json").write_text(
                            json.dumps(rows, indent=2)
                        )
                        write_summary(args.output, rows)
    finally:
        write_summary(args.output, rows)
        # Preserve readable diagnostics even when a self-test/trace aborts.
        for path in args.output.rglob("*"):
            if not path.is_symlink():
                path.chmod(0o755 if path.is_dir() else 0o644)
    print(f"Finished. Artifacts: {args.output}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(
            "Interrupted; owned perf probes/processes were cleaned up.", file=sys.stderr
        )
        sys.exit(130)
