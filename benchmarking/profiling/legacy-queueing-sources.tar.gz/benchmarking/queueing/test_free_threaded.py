"""Test the matched comparison's safeguards without starting a server."""

import sys
from pathlib import Path

import pytest

from . import free_threaded as study


def test_environment_removes_experiment_and_forced_gil_settings(monkeypatch):
    monkeypatch.setenv("PYTHON_GIL", "0")
    monkeypatch.setenv("PYTHONPATH", "/incorrect/source")
    monkeypatch.setenv("MLSERVER_QUEUE_PROBE", "1")
    monkeypatch.setenv("MLSERVER_QUEUE_HTTP", "aiohttp")
    monkeypatch.setenv("MLSERVER_QUEUE_TRANSPORT", "zmq")
    monkeypatch.setenv("MLSERVER_QUEUE_NEW_EXPERIMENT", "1")
    monkeypatch.setenv("MLSERVER_FT_EXPECT", "incorrect")
    env = study.environment(Path("/diagnostic"), "off")
    assert "PYTHON_GIL" not in env
    assert env["PYTHONPATH"].split(":")[0] == "/diagnostic"
    assert env["MLSERVER_QUEUE_PROBE"] == "0"
    assert env["MLSERVER_QUEUE_HTTP"] == "fastapi"
    assert env["MLSERVER_QUEUE_TRANSPORT"] == "queue"
    assert "MLSERVER_QUEUE_NEW_EXPERIMENT" not in env
    assert "MLSERVER_FT_EXPECT" not in env


def test_environment_gil_on_propagates_to_spawned_workers():
    assert study.environment(Path("/diagnostic"), "on")["PYTHON_GIL"] == "1"
    with pytest.raises(ValueError):
        study.environment(Path("/diagnostic"), "force-off")


def test_state_rejects_ordinary_python(monkeypatch):
    monkeypatch.setenv("MLSERVER_FT_EXPECT", "off")
    monkeypatch.setattr(study.sysconfig, "get_config_var", lambda name: 0)
    with pytest.raises(RuntimeError, match="free-threaded Python build"):
        study.check_state("test")


def test_state_rejects_extension_gil_fallback(monkeypatch):
    monkeypatch.setenv("MLSERVER_FT_EXPECT", "off")
    monkeypatch.setattr(study.sysconfig, "get_config_var", lambda name: 1)
    monkeypatch.setattr(sys, "_is_gil_enabled", lambda: True, raising=False)
    with pytest.raises(RuntimeError, match="Unexpected GIL state"):
        study.check_state("test")


def test_thread_deltas_ignore_reused_thread_ids():
    before = {
        "monotonic_ns": 1_000_000_000,
        "threads": {
            "1": dict(
                name="MainThread",
                start_ticks=1,
                cpu_ns=0,
                runqueue_wait_ns=0,
                timeslices=0,
            ),
            "2": dict(
                name="reader", start_ticks=1, cpu_ns=0, runqueue_wait_ns=0, timeslices=0
            ),
        },
    }
    after = {
        "monotonic_ns": 2_000_000_000,
        "threads": {
            "1": dict(
                name="MainThread",
                start_ticks=1,
                cpu_ns=300_000_000,
                runqueue_wait_ns=1_000_000,
                timeslices=20,
            ),
            "2": dict(
                name="new thread",
                start_ticks=2,
                cpu_ns=20_000_000,
                runqueue_wait_ns=0,
                timeslices=1,
            ),
        },
    }
    result = study.thread_deltas(before, after)
    assert len(result["threads"]) == 1
    assert result["threads"][0]["cpu_cores"] == pytest.approx(0.3)
    assert result["threads"][0]["runqueue_wait_ms"] == 1
    assert "not GIL/lock wait" in result["caution"]


def test_summary_reports_means_without_confusing_percentiles():
    rows = [
        dict(
            batch=1,
            concurrency=64,
            mode=mode,
            rps=rps,
            timings={"client_ms": {"p95": p95}},
        )
        for mode, rps, p95 in (
            ("on", 100, 20),
            ("on", 200, 10),
            ("off", 300, 5),
            ("off", 300, 7),
        )
    ]
    result = study.summarize(rows)
    assert "REST/HTTP JSON" in result
    assert "2.000" in result
    assert "15.00" in result
    assert "6.00" in result


def test_source_manifest_allows_only_startup_compatibility_changes(tmp_path):
    repo, source = tmp_path / "repo", tmp_path / "copy"
    names = (
        "mlserver/__init__.py",
        "mlserver/tracing.py",
        "mlserver/rest/openapi/schema.py",
    )
    for name in names:
        baseline, diagnostic = repo / name, source / name
        baseline.parent.mkdir(parents=True, exist_ok=True)
        diagnostic.parent.mkdir(parents=True, exist_ok=True)
        baseline.write_text("original")
        diagnostic.write_text("startup compatibility")
    (repo / "runtimes/onnx/mlserver_onnx").mkdir(parents=True)
    assert len(study.source_manifest(source, repo)["changed_files"]) == 3
    baseline, diagnostic = (
        repo / "mlserver/registry.py",
        source / "mlserver/registry.py",
    )
    baseline.write_text("original")
    diagnostic.write_text("changed dispatch")
    with pytest.raises(RuntimeError, match="Unexpected diagnostic source changes"):
        study.source_manifest(source, repo)
