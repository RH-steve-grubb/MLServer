"""Reproduce ONNX serving saturation without changing production runtime code.

Run with the project's Poetry environment:
  poetry run python benchmarking/queueing/bench.py generate /tmp/queue-mlp.onnx
  poetry run python benchmarking/queueing/bench.py micro /tmp/queue-mlp.onnx
  poetry run python benchmarking/queueing/bench.py sweep /tmp/queue-mlp.onnx \
      --output /tmp/queue-results.json --seconds 5

The generated untrained FP32 MLP uses the report's large layer widths:
54 -> 1024 -> 512 -> 256 -> 128 -> 7. It reproduces computation shapes, NOT the
original model, its accuracy, its deployment, or the reported OVMS speed ratio.
All timings are CPU-only. Server and client execute in separate processes.
"""

import argparse
import asyncio
import contextlib
import cProfile
import hashlib
import importlib.metadata
import itertools
import random
import json
import os
import platform
import resource
import signal
import socket
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Iterator

import aiohttp
import numpy as np
import onnx
import onnxruntime as ort
from onnx import TensorProto, helper, numpy_helper

from mlserver.handlers import DataPlane, ModelRepositoryHandlers
from mlserver.parallel.registry import InferencePoolRegistry
from mlserver.registry import MultiModelRegistry, model_initialiser
from mlserver.repository import SchemalessModelRepository
from mlserver.rest import RESTServer
from mlserver.settings import ModelParameters, ModelSettings, Settings
from mlserver.types import InferenceRequest
from mlserver.utils import install_uvloop_event_loop
from mlserver_onnx import OnnxModel

from probe import HTTPProbe, PREFIX, install


# multiprocessing spawn re-imports this module as __mp_main__. Installing here
# lets stock Worker processes exercise the same instrumentation as the parent.
if os.environ.get("MLSERVER_QUEUE_PROBE") == "1":
    install()

if os.environ.get("MLSERVER_QUEUE_CODEC") == "msgpack":
    # Spawn re-imports this module. Install the same diagnostic Queue codec in
    # parent and workers, leaving pipe framing, scheduling and ONNX unchanged.
    from msgpack_codec import install as install_msgpack

    install_msgpack()

if os.environ.get("MLSERVER_QUEUE_TENSORS") == "numpy":
    from tensor_dispatch import install as install_tensors

    install_tensors()

if os.environ.get("MLSERVER_QUEUE_TRANSPORT") == "zmq":
    from zmq_transport import install as install_zmq

    install_zmq()

if os.environ.get("MLSERVER_QUEUE_JSON", "frontend") != "frontend":
    from raw_worker import install as install_raw_worker

    install_raw_worker()

if os.environ.get("MLSERVER_QUEUE_SCHEDULER") == "least-outstanding":
    from balance_scheduler import install as install_scheduler

    install_scheduler()

if os.environ.get("MLSERVER_QUEUE_BALANCE") == "1":
    from worker_balance import install as install_balance

    install_balance()

if os.environ.get("MLSERVER_QUEUE_HTTP_PARSER") in ("h11", "httptools"):
    from http_parser import install as install_http_parser

    install_http_parser()


def generate(path: Path) -> None:
    random = np.random.default_rng(42)
    sizes = [54, 1024, 512, 256, 128, 7]
    nodes = []
    initializers = []
    previous = "input"
    for index, (inputs, outputs) in enumerate(zip(sizes, sizes[1:])):
        weights = random.normal(0, inputs**-0.5, (inputs, outputs)).astype(np.float32)
        bias = np.zeros(outputs, dtype=np.float32)
        initializers += [
            numpy_helper.from_array(weights, f"weight{index}"),
            numpy_helper.from_array(bias, f"bias{index}"),
        ]
        linear = f"linear{index}"
        nodes.append(
            helper.make_node(
                "Gemm", [previous, f"weight{index}", f"bias{index}"], [linear]
            )
        )
        previous = f"hidden{index}"
        last = index == len(sizes) - 2
        activation = (
            helper.make_node("Softmax", [linear], ["probabilities"], axis=1)
            if last
            else helper.make_node("Relu", [linear], [previous])
        )
        nodes.append(activation)
    graph = helper.make_graph(
        nodes,
        "queueing-mlp",
        [helper.make_tensor_value_info("input", TensorProto.FLOAT, ["N", 54])],
        [helper.make_tensor_value_info("probabilities", TensorProto.FLOAT, ["N", 7])],
        initializers,
    )
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
    model.ir_version = 9
    onnx.checker.check_model(model)
    onnx.save(model, path)
    print(
        json.dumps(
            {
                "model": str(path),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
        )
    )


def model_settings(args: argparse.Namespace) -> ModelSettings:
    extra: dict[str, Any] = {
        "providers": ["CPUExecutionProvider"],
        "session_options": {"intra_op_num_threads": args.threads},
    }
    if args.no_spin:
        extra["session_config_entries"] = {"session.intra_op.allow_spinning": "0"}
    return ModelSettings(
        name="queue-mlp",
        implementation="mlserver_onnx.OnnxModel",
        parameters=ModelParameters(uri=str(args.model.resolve()), extra=extra),
    )


def payload(batch: int) -> dict[str, Any]:
    data = np.random.default_rng(7).normal(size=(batch, 54)).astype(np.float32)
    return {
        "inputs": [
            {
                "name": "input",
                "shape": [batch, 54],
                "datatype": "FP32",
                "data": data.ravel().tolist(),
            }
        ],
        "outputs": [{"name": "probabilities"}],
    }


def summary(values: list[float]) -> dict[str, float]:
    if not values:
        return {}
    array = np.asarray(values)
    return {
        "mean": float(array.mean()),
        "p50": float(np.percentile(array, 50)),
        "p95": float(np.percentile(array, 95)),
        "p99": float(np.percentile(array, 99)),
        "max": float(array.max()),
    }


async def heartbeat(samples: list[float]) -> None:
    period = 0.005
    loop = asyncio.get_running_loop()
    expected = loop.time() + period
    while True:
        await asyncio.sleep(max(0, expected - loop.time()))
        samples.append(max(0, loop.time() - expected) * 1000)
        # Reschedule from now: do not turn one long stall into many samples.
        expected = loop.time() + period


async def micro(args: argparse.Namespace) -> None:
    model = OnnxModel(model_settings(args))
    await model.load()
    data = np.random.default_rng(7).normal(size=(args.batch, 54)).astype(np.float32)
    expected = model._model.run(["probabilities"], {"input": data})[0]
    request_bytes = json.dumps(payload(args.batch)).encode()
    for _ in range(20):
        await model.predict(InferenceRequest.model_validate_json(request_bytes))
    rows = []
    with ThreadPoolExecutor(max_workers=32) as executor:
        for mode in ("raw-inline", "raw-thread", "runtime-inline", "runtime-thread"):
            for concurrency, trial in itertools.product(
                args.concurrencies, range(args.repeats)
            ):
                queue = []
                service = []
                results = []
                lag: list[float] = []
                slots = asyncio.Semaphore(args.lanes)
                monitor = asyncio.create_task(heartbeat(lag))
                await asyncio.sleep(0.006)
                started = time.perf_counter()

                async def one(submitted):
                    async with slots if "thread" in mode else contextlib.nullcontext():
                        queue.append((time.perf_counter() - submitted) * 1000)
                        begin = time.perf_counter()
                        loop = asyncio.get_running_loop()
                        if mode == "raw-inline":
                            result = model._model.run(
                                ["probabilities"], {"input": data}
                            )[0]
                        elif mode == "raw-thread":
                            outputs = await loop.run_in_executor(
                                executor,
                                model._model.run,
                                ["probabilities"],
                                {"input": data},
                            )
                            result = outputs[0]
                        elif mode == "runtime-inline":
                            response = await model.predict(
                                InferenceRequest.model_validate_json(request_bytes)
                            )
                            result = np.asarray(response.outputs[0].data.root).reshape(
                                args.batch, 7
                            )
                        else:
                            request = InferenceRequest.model_validate_json(
                                request_bytes
                            )
                            request = model._check_request(request)
                            outputs = await loop.run_in_executor(
                                executor, model._get_model_outputs, request
                            )
                            result = np.asarray(outputs[0].data.root).reshape(
                                args.batch, 7
                            )
                        service.append((time.perf_counter() - begin) * 1000)
                        results.append(result)

                tasks = [asyncio.create_task(one(started)) for _ in range(concurrency)]
                await asyncio.gather(*tasks)
                elapsed = time.perf_counter() - started
                await asyncio.sleep(0.006)
                monitor.cancel()
                await asyncio.gather(monitor, return_exceptions=True)
                # Numerical assertions are outside BOTH the throughput window
                # and the loop-lag observation interval.
                for result in results:
                    np.testing.assert_allclose(result, expected, rtol=1e-5, atol=1e-6)
                row = {
                    "mode": mode,
                    "concurrency": concurrency,
                    "batch": args.batch,
                    "threads": args.threads,
                    "lanes": args.lanes,
                    "trial": trial,
                    "rps": concurrency / elapsed,
                    "queue_ms": summary(queue),
                    "service_ms": summary(service),
                    "loop_lag_ms": summary(lag),
                }
                rows.append(row)
                print(json.dumps(row), flush=True)
    if args.output:
        args.output.write_text(json.dumps(rows, indent=2) + "\n")
    await model.unload()


async def serve(args: argparse.Namespace) -> None:
    http = os.environ.get("MLSERVER_QUEUE_HTTP", "fastapi")
    if http not in ("fastapi", "aiohttp"):
        raise ValueError("Unknown diagnostic HTTP framework")
    if http == "aiohttp" and (
        os.environ.get("MLSERVER_QUEUE_JSON") != "full"
        or os.environ.get("MLSERVER_QUEUE_PROBE") == "1"
        or args.stock
        or args.profile_dir
        or not args.workers
    ):
        raise ValueError("aiohttp requires unprobed full worker JSON and a fixed pool")
    loop_lag: list[float] = []
    loop_monitor = asyncio.create_task(heartbeat(loop_lag))
    settings = Settings(
        host="127.0.0.1",
        http_port=args.port,
        parallel_workers=args.workers,
        metrics_endpoint="/metrics" if args.stock else None,
        tracing_server=None,
        access_log=False,
        gzip_enabled=args.stock,
        log_level="WARNING",
        model_operation_timeout=120,
        environments_dir=str(args.model.parent / "queue-environments"),
    )
    pool_registry = InferencePoolRegistry(settings) if args.workers else None
    registry = MultiModelRegistry(
        on_model_load=[pool_registry.load_model] if pool_registry else [],
        on_model_unload=[pool_registry.unload_model] if pool_registry else [],
        model_initialiser=(
            pool_registry.model_initialiser if pool_registry else model_initialiser
        ),
        model_operation_timeout=120,
    )
    model = None
    try:
        model = await registry.load(model_settings(args))
        registry.startup_complete()
        # Control: prediction must complete while all parent lifecycle locks
        # are held. This tests the suspected connection to PR326's locks.
        locks = [
            registry._get_operation_lock(model.name),
            registry._models[model.name]._operation_lock,
        ]
        if pool_registry:
            assert pool_registry._default_pool is not None
            locks.extend(
                [
                    await pool_registry._get_pool_lock(model),
                    pool_registry._default_pool._operation_lock,
                    pool_registry._default_pool._dispatcher._worker_starting_lock,
                ]
            )
        async with contextlib.AsyncExitStack() as held_locks:
            for lock in locks:
                await held_locks.enter_async_context(lock)
            await asyncio.wait_for(
                model.predict(InferenceRequest.model_validate(payload(1))), 10
            )
        print("lifecycle-lock prediction control passed", flush=True)
        data_plane = DataPlane(settings, registry)
        handlers = ModelRepositoryHandlers(
            SchemalessModelRepository(str(args.model.parent)), registry
        )

        async def stop_server() -> dict[str, bool]:
            server._server.should_exit = True
            return {"stopping": True}

        async def cpu_stats() -> dict[str, float]:
            usage = resource.getrusage(resource.RUSAGE_SELF)
            result = {"cpu_seconds": usage.ru_utime + usage.ru_stime}
            worker_cpu = 0.0
            if pool_registry and pool_registry._default_pool:
                for pid in pool_registry._default_pool._dispatcher._workers:
                    # Linux /proc process totals include that worker's threads.
                    # Sample only outside load windows, not on every prediction.
                    fields = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1]
                    values = fields.split()
                    worker_cpu += (int(values[11]) + int(values[12])) / os.sysconf(
                        "SC_CLK_TCK"
                    )
            result["worker_cpu_seconds"] = worker_cpu
            # Both transports get the same monitor. Each stats read resets the
            # samples so the after-read describes the measured load/drain window.
            result.update(
                {
                    f"server_loop_lag_{key}_ms": value
                    for key, value in summary(loop_lag).items()
                }
            )
            loop_lag.clear()
            if os.environ.get("MLSERVER_QUEUE_JSON", "frontend") != "frontend":
                from raw_worker import COUNTS as raw_counts

                result.update(
                    {f"raw_{key}": float(value) for key, value in raw_counts.items()}
                )
            if os.environ.get("MLSERVER_QUEUE_TRANSPORT") == "zmq":
                from zmq_transport import COUNTS as transport_counts

                result.update(
                    {
                        f"transport_{key}": float(value)
                        for key, value in transport_counts.items()
                    }
                )
            if os.environ.get("MLSERVER_QUEUE_CODEC") == "msgpack":
                from msgpack_codec import COUNTS

                result.update(
                    {f"codec_{key}": float(value) for key, value in COUNTS.items()}
                )
            if os.environ.get("MLSERVER_QUEUE_TENSORS") == "numpy":
                from tensor_dispatch import COUNTS as tensor_counts

                result.update(
                    {f"tensor_{key}": value for key, value in tensor_counts.items()}
                )
            if os.environ.get("MLSERVER_QUEUE_BALANCE") == "1":
                import worker_balance

                assert pool_registry and pool_registry._default_pool
                worker_balance.sample(
                    list(pool_registry._default_pool._dispatcher._workers)
                )
            return result

        async def balance_snapshot() -> dict[str, Any]:
            from worker_balance import snapshot

            return snapshot()

        if http == "aiohttp":
            from aiohttp_frontend import AiohttpFrontend

            frontend = AiohttpFrontend(settings, registry, data_plane)
            frontend.add_stats(cpu_stats)
            if os.environ.get("MLSERVER_QUEUE_BALANCE") == "1":
                from worker_balance import snapshot

                frontend.add_balance(snapshot)
            await frontend.start()
            return

        server = RESTServer(settings, data_plane, handlers)
        if os.environ.get("MLSERVER_QUEUE_JSON", "frontend") != "frontend":
            from raw_worker import install_routes

            install_routes(server, registry)

        # Avoid SIGINT cancelling cleanup when Uvicorn re-raises its captured
        # signal after draining. This endpoint exists only in this harness.
        server._app.add_api_route("/queue-probe/stop", stop_server, methods=["POST"])
        server._app.add_api_route("/queue-probe/stats", cpu_stats, methods=["GET"])
        if os.environ.get("MLSERVER_QUEUE_BALANCE") == "1":
            server._app.add_api_route(
                "/queue-probe/balance", balance_snapshot, methods=["GET"]
            )
        if os.environ.get("MLSERVER_QUEUE_PROBE") == "1":
            setattr(server, "_app", HTTPProbe(server._app))
        profiler = cProfile.Profile() if args.profile_dir else None
        if profiler:
            profiler.enable()
        try:
            await server.start()
        finally:
            if profiler:
                profiler.disable()
                args.profile_dir.mkdir(parents=True, exist_ok=True)
                profiler.dump_stats(str(args.profile_dir / f"server-{args.port}.prof"))
    finally:
        loop_monitor.cancel()
        await asyncio.gather(loop_monitor, return_exceptions=True)
        if pool_registry:
            await pool_registry.close()
        elif model is not None:
            await registry.unload(model.name)


def request_sizes(sizes: list[int]) -> Iterator[int]:
    # Reshuffle each weighted block with the same seed for paired controls.
    # A fixed repeating size cycle can alias round robin's worker count and
    # manufacture a persistent heavy-worker group instead of measuring it.
    generator = random.Random(20261008)
    while True:
        block = list(sizes)
        generator.shuffle(block)
        yield from block


async def load(args: argparse.Namespace) -> dict[str, Any]:
    bases = [
        f"http://127.0.0.1:{port}"
        for port in (getattr(args, "ports", None) or [args.port])
    ]
    targets = itertools.cycle(bases)
    sizes = getattr(args, "mix", None) or [args.batch]
    if min(sizes) < 1:
        raise ValueError("Request tensor rows must be positive")
    choices = request_sizes(sizes)
    documents = {size: payload(size) for size in set(sizes)}
    encoded = {size: json.dumps(doc).encode() for size, doc in documents.items()}
    # Validate warm-up responses against native ORT outside the measured window.
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.add_session_config_entry("session.intra_op.allow_spinning", "0")
    reference = ort.InferenceSession(
        str(args.model), sess_options=options, providers=["CPUExecutionProvider"]
    )
    expected = {
        size: reference.run(
            ["probabilities"],
            {
                "input": np.asarray(doc["inputs"][0]["data"], dtype=np.float32).reshape(
                    -1, 54
                )
            },
        )[0]
        for size, doc in documents.items()
    }
    timeout = aiohttp.ClientTimeout(total=120)
    connector = aiohttp.TCPConnector(limit=args.concurrency, force_close=False)
    timings: dict[str, list[float]] = {}
    errors = []
    count = 0
    completed = 0
    lag: list[float] = []
    native_active = []
    class_timings: dict[int, list[float]] = {size: [] for size in documents}
    class_completed = dict.fromkeys(documents, 0)
    stage_pairs = {
        "before_asgi_ms": ("asgi-start-ns", "client-send-ns"),
        "to_worker_ms": ("worker-enter-ns", "dispatch-ns"),
        "from_worker_ms": ("dispatch-return-ns", "worker-return-ns"),
        "worker_callback_ms": ("worker-put-ns", "worker-return-ns"),
        "response_transport_ms": ("parent-read-ns", "worker-put-ns"),
        "response_pipe_ms": ("pipe-read-ns", "worker-put-ns"),
        "reader_resume_ms": ("parent-read-ns", "pipe-read-ns"),
        "parent_resume_ms": ("dispatch-return-ns", "parent-read-ns"),
        "predict_ms": ("predict-end-ns", "predict-start-ns"),
        "server_ms": ("response-start-ns", "asgi-start-ns"),
        "front_pre_ms": ("dispatch-ns", "asgi-start-ns"),
        "front_post_ms": ("response-start-ns", "dispatch-return-ns"),
    }
    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:

        async def request(record=False):
            nonlocal count, completed
            size = next(choices)
            started_ns = time.perf_counter_ns()
            try:
                async with session.post(
                    next(targets) + "/v2/models/queue-mlp/infer",
                    data=encoded[size],
                    headers={
                        "content-type": "application/json",
                        PREFIX + "client-send-ns": str(started_ns),
                    },
                ) as response:
                    body = await response.read()
                    ended_ns = time.perf_counter_ns()
                    if response.status != 200:
                        raise RuntimeError(f"HTTP {response.status}: {body[:300]!r}")
                    if not record:
                        result = json.loads(body)["outputs"][0]
                        assert result["shape"] == [size, 7]
                        np.testing.assert_allclose(
                            np.asarray(result["data"]).reshape(size, 7),
                            expected[size],
                            rtol=1e-4,
                            atol=1e-6,
                        )
                        return
                    count += 1
                    if ended_ns <= end_ns:
                        completed += 1
                        class_completed[size] += 1
                    class_timings[size].append((ended_ns - started_ns) / 1e6)
                    timings.setdefault("client_ms", []).append(
                        (ended_ns - started_ns) / 1e6
                    )
                    numbers = {
                        key[len(PREFIX) :]: int(value)
                        for key, value in response.headers.items()
                        if key.startswith(PREFIX)
                    }
                    for label, (end, start) in stage_pairs.items():
                        if end in numbers and start in numbers:
                            timings.setdefault(label, []).append(
                                (numbers[end] - numbers[start]) / 1e6
                            )
                    for key in ("run-ns", "decode-ns", "encode-ns", "admission-ns"):
                        if key in numbers:
                            timings.setdefault(key.replace("-ns", "_ms"), []).append(
                                numbers[key] / 1e6
                            )
                    if "native-active" in numbers:
                        native_active.append(numbers["native-active"])
            except Exception as error:
                errors.append(repr(error))

        await asyncio.gather(*(request() for _ in range(max(20, args.concurrency))))
        if errors:
            raise RuntimeError(errors[:3])
        errors.clear()

        async def server_stats() -> dict[str, float]:
            total: dict[str, float] = {}
            for base in bases:
                async with session.get(base + "/queue-probe/stats") as response:
                    for key, value in (await response.json()).items():
                        # Across replicas report the worst frontend's sampled
                        # statistic, not a meaningless sum of percentiles.
                        total[key] = (
                            max(total.get(key, 0.0), value)
                            if key.startswith("server_loop_lag_")
                            else total.get(key, 0.0) + value
                        )
            return total

        stats_before = await server_stats()
        client_usage = resource.getrusage(resource.RUSAGE_SELF)
        client_cpu_before = client_usage.ru_utime + client_usage.ru_stime
        monitor = asyncio.create_task(heartbeat(lag))
        started_ns = time.perf_counter_ns()
        end_ns = started_ns + int(args.seconds * 1e9)

        async def client():
            while time.perf_counter_ns() < end_ns:
                await request(record=True)

        await asyncio.gather(*(client() for _ in range(args.concurrency)))
        drained_ns = time.perf_counter_ns()
        monitor.cancel()
        await asyncio.gather(monitor, return_exceptions=True)
        stats_after = await server_stats()
        client_usage = resource.getrusage(resource.RUSAGE_SELF)
        client_cpu_after = client_usage.ru_utime + client_usage.ru_stime
        balance_trace = None
        if os.environ.get("MLSERVER_QUEUE_BALANCE") == "1":
            # Retrieve events only after CPU measurement and all request drains.
            # Analysis and trace transfer are not part of the throughput window.
            async with session.get(bases[0] + "/queue-probe/balance") as response:
                balance_trace = await response.json()
    row = {
        "batch": args.batch,
        "concurrency": args.concurrency,
        "rps": completed / args.seconds,
        "completed_in_window": completed,
        "total_drained": count,
        "drain_seconds": (drained_ns - end_ns) / 1e9,
        # Match native perf's explicitly selected CLOCK_MONOTONIC timestamps.
        # These bounds exclude warm-up when analyzing the diagnostic traces.
        "measurement_started_ns": started_ns,
        "measurement_drained_ns": drained_ns,
        "request_bytes": len(encoded[sizes[0]]),
        "request_bytes_by_batch": {size: len(data) for size, data in encoded.items()},
        "mix": sizes,
        "mix_seed": 20261008,
        "classes": {
            size: {
                "total_drained": len(values),
                "completed_in_window": class_completed[size],
                "client_ms": summary(values),
            }
            for size, values in class_timings.items()
        },
        "errors": errors[:10],
        "timings": {key: summary(values) for key, values in timings.items()},
        "client_loop_lag_ms": summary(lag),
        "native_active_max_per_worker": max(native_active, default=0),
        "server_main_cpu_cores": (
            stats_after["cpu_seconds"] - stats_before["cpu_seconds"]
        )
        / ((drained_ns - started_ns) / 1e9),
        "client_cpu_cores": (client_cpu_after - client_cpu_before)
        / ((drained_ns - started_ns) / 1e9),
        "worker_cpu_cores": (
            stats_after["worker_cpu_seconds"] - stats_before["worker_cpu_seconds"]
        )
        / ((drained_ns - started_ns) / 1e9),
        "server_loop_lag_aggregation": "max-across-frontends",
    }
    if balance_trace is not None:
        row["balance_trace"] = balance_trace
    row["codec_counts"] = {
        key: stats_after[key] - stats_before.get(key, 0.0)
        for key in stats_after
        if key.startswith("codec_")
    }
    row["tensor_counts"] = {
        key: stats_after[key] - stats_before.get(key, 0.0)
        for key in stats_after
        if key.startswith("tensor_")
    }
    row["raw_counts"] = {
        key: stats_after[key] - stats_before.get(key, 0.0)
        for key in stats_after
        if key.startswith("raw_")
    }
    row["http_counts"] = {
        key: stats_after[key] - stats_before.get(key, 0.0)
        for key in stats_after
        if key.startswith("http_")
    }
    row["transport_counts"] = {
        key: stats_after[key] - stats_before.get(key, 0.0)
        for key in stats_after
        if key.startswith("transport_")
    }
    row["server_loop_lag_ms"] = {
        key.removeprefix("server_loop_lag_").removesuffix("_ms"): value
        for key, value in stats_after.items()
        if key.startswith("server_loop_lag_")
    }
    print(json.dumps(row), flush=True)
    return row


def free_port() -> int:
    with socket.socket() as connection:
        connection.bind(("127.0.0.1", 0))
        return connection.getsockname()[1]


async def wait_ready(port: int, process: subprocess.Popen) -> None:
    deadline = time.monotonic() + 120
    async with aiohttp.ClientSession() as session:
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(f"Server exited: {process.returncode}")
            try:
                async with session.get(
                    f"http://127.0.0.1:{port}/v2/health/ready"
                ) as response:
                    if response.status == 200:
                        return
            except aiohttp.ClientError:
                pass
            await asyncio.sleep(0.1)
    raise TimeoutError("Server readiness timed out")


async def close_server(port: int, process: subprocess.Popen) -> None:
    if process.poll() is not None:
        return
    try:
        timeout = aiohttp.ClientTimeout(total=5)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                f"http://127.0.0.1:{port}/queue-probe/stop"
            ) as response:
                await response.read()
    except (aiohttp.ClientError, TimeoutError):
        process.send_signal(signal.SIGTERM)
    try:
        await asyncio.to_thread(process.wait, 20)
    except subprocess.TimeoutExpired:
        process.kill()
        await asyncio.to_thread(process.wait)


async def sweep(args: argparse.Namespace) -> None:
    rows = []
    configurations = [
        ("local-default", 0, 0, "inline"),
        ("pool1-default", 1, 0, "inline"),
        ("pool1-tuned", 1, 1, "inline"),
        ("pool6-tuned", 6, 1, "inline"),
        ("pool32-tuned", 32, 1, "inline"),
        ("local-thread", 0, 1, "thread"),
        ("pool1-thread", 1, 1, "thread"),
        ("pool6-pump", 6, 1, "inline"),
        ("pool32-pump", 32, 1, "inline"),
        ("pool1-thread-pump", 1, 1, "thread"),
        ("pool1-stock", 1, 0, "inline"),
        ("pool6-stock", 6, 1, "inline"),
        ("replica6-pool1", 1, 1, "inline"),
        ("replica2-pool3", 3, 1, "inline"),
        ("pool6-intra2", 6, 2, "inline"),
        ("pool6-intra4", 6, 4, "inline"),
        ("replica6-intra2", 1, 2, "inline"),
        ("replica6-intra4", 1, 4, "inline"),
    ]
    for label, workers, threads, execution in configurations:
        if args.configs and label not in args.configs:
            continue
        if args.unprobed and (execution != "inline" or label.endswith("-pump")):
            continue
        replicas = (
            6
            if label.startswith("replica6-")
            else 2 if label.startswith("replica2-") else 1
        )
        ports = [free_port() for _ in range(replicas)]
        env = dict(os.environ)
        env.update(
            MLSERVER_QUEUE_PROBE="0" if args.unprobed else "1",
            MLSERVER_QUEUE_EXECUTION=execution,
            MLSERVER_QUEUE_RESPONSE_PUMP="1" if label.endswith("-pump") else "0",
            MLSERVER_QUEUE_LANES=str(args.lanes),
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
        )
        command = [
            sys.executable,
            str(Path(__file__).resolve()),
            "serve",
            str(args.model),
            "--workers",
            str(workers),
            "--threads",
            str(threads),
        ]
        if threads:
            command.append("--no-spin")
        if label.endswith("-stock"):
            command.append("--stock")
        if args.profile_dir:
            command.extend(["--profile-dir", str(args.profile_dir)])
        processes = [
            subprocess.Popen(command + ["--port", str(port)], env=env) for port in ports
        ]
        try:
            await asyncio.gather(
                *(wait_ready(port, process) for port, process in zip(ports, processes))
            )
            for batch in args.batches:
                for concurrency, trial in itertools.product(
                    args.concurrencies, range(args.repeats)
                ):
                    case = argparse.Namespace(
                        model=args.model,
                        port=ports[0],
                        ports=ports,
                        batch=batch,
                        concurrency=concurrency,
                        seconds=args.seconds,
                    )
                    row = await load(case)
                    row.update(
                        config=label,
                        workers=workers,
                        frontends=replicas,
                        total_workers=workers * replicas,
                        threads=threads,
                        execution=execution,
                        lanes=args.lanes,
                        response_pump=label.endswith("-pump"),
                        stock=label.endswith("-stock"),
                        trial=trial,
                        queue_codec=os.environ.get("MLSERVER_QUEUE_CODEC", "pickle"),
                        queue_tensors=os.environ.get("MLSERVER_QUEUE_TENSORS", "list"),
                        queue_transport=os.environ.get(
                            "MLSERVER_QUEUE_TRANSPORT", "queue"
                        ),
                        queue_json=os.environ.get("MLSERVER_QUEUE_JSON", "frontend"),
                        http_framework=os.environ.get("MLSERVER_QUEUE_HTTP", "fastapi"),
                    )
                    rows.append(row)
                    if args.output:
                        args.output.write_text(
                            json.dumps(
                                {"metadata": metadata(args), "results": rows}, indent=2
                            )
                            + "\n"
                        )
        finally:
            await asyncio.gather(
                *(
                    close_server(port, process)
                    for port, process in zip(ports, processes)
                )
            )


def metadata(args: argparse.Namespace) -> dict[str, Any]:
    libzmq = None
    if os.environ.get("MLSERVER_QUEUE_TRANSPORT") == "zmq":
        import zmq

        libzmq = zmq.zmq_version()
    http = os.environ.get("MLSERVER_QUEUE_HTTP", "fastapi")
    mode = os.environ.get("MLSERVER_QUEUE_HTTP_PARSER", "auto")
    if http == "aiohttp":
        parser = importlib.import_module("aiohttp.http_parser").HttpRequestParser
    elif mode == "h11":
        parser = importlib.import_module("uvicorn.protocols.http.h11_impl").H11Protocol
    elif mode == "httptools":
        parser = importlib.import_module(
            "uvicorn.protocols.http.httptools_impl"
        ).HttpToolsProtocol
    else:
        parser = importlib.import_module("uvicorn.protocols.http.auto").AutoHTTPProtocol
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "cpu_count": os.cpu_count(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "onnxruntime": ort.__version__,
        "onnx": onnx.__version__,
        "numpy": np.__version__,
        "providers": ort.get_available_providers(),
        "libraries": {
            package: importlib.metadata.version(package)
            for package in ("mlserver", "fastapi", "pydantic", "uvicorn", "aiohttp")
            + (
                ("msgpack", "msgpack-numpy")
                if os.environ.get("MLSERVER_QUEUE_CODEC") == "msgpack"
                else ()
            )
            + (
                ("pyzmq",)
                if os.environ.get("MLSERVER_QUEUE_TRANSPORT") == "zmq"
                else ()
            )
            + (("httptools",) if parser.__name__ == "HttpToolsProtocol" else ())
        },
        "git_commit": subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=Path(__file__).resolve().parents[2],
            text=True,
        ).strip(),
        "model": str(args.model),
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "seconds_per_case": args.seconds,
        "synthetic_model": True,
        "probed": not args.unprobed,
        "repeats": args.repeats,
        "queue_codec": os.environ.get("MLSERVER_QUEUE_CODEC", "pickle"),
        "queue_tensors": os.environ.get("MLSERVER_QUEUE_TENSORS", "list"),
        "queue_transport": os.environ.get("MLSERVER_QUEUE_TRANSPORT", "queue"),
        "queue_json": os.environ.get("MLSERVER_QUEUE_JSON", "frontend"),
        "http_framework": os.environ.get("MLSERVER_QUEUE_HTTP", "fastapi"),
        "balance_instrumented": os.environ.get("MLSERVER_QUEUE_BALANCE") == "1",
        "libzmq": libzmq,
        "http_engine": f"{parser.__module__}.{parser.__name__}",
        "event_loop": type(asyncio.get_running_loop()).__module__,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "command", choices=["generate", "micro", "serve", "load", "sweep"]
    )
    parser.add_argument("model", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--profile-dir", type=Path)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--lanes", type=int, default=4)
    parser.add_argument("--no-spin", action="store_true")
    parser.add_argument("--unprobed", action="store_true")
    parser.add_argument("--stock", action="store_true")
    parser.add_argument("--port", type=int, default=18080)
    parser.add_argument("--ports", type=int, nargs="+")
    parser.add_argument("--batch", type=int, default=100)
    parser.add_argument("--mix", type=int, nargs="+")
    parser.add_argument("--concurrency", type=int, default=64)
    parser.add_argument("--seconds", type=float, default=5)
    parser.add_argument("--repeats", type=int, default=1)
    parser.add_argument(
        "--concurrencies", type=int, nargs="+", default=[2, 8, 32, 64, 128]
    )
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--configs", nargs="+")
    return parser.parse_args()


if __name__ == "__main__":
    arguments = parse_args()
    if arguments.command == "generate":
        generate(arguments.model)
    else:
        install_uvloop_event_loop()
        asyncio.run(globals()[arguments.command](arguments))
