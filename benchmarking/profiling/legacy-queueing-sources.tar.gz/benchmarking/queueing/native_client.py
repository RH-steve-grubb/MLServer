"""Python correctness/setup wrapper; native h2load owns the measured HTTP loop.

Fixed request counts allow every admitted prediction to drain. h2load's timed
mode stops connections at the deadline, which would race backend accounting.
An untimed synchronized pilot sizes the fixed count for the requested duration.
"""

import argparse
import asyncio
import hashlib
import importlib
import json
import math
import os
import resource
import subprocess
import time
from pathlib import Path
from typing import Any

import aiohttp
import numpy as np
import onnxruntime as ort
import uvloop

client = importlib.import_module(
    f"{__package__}.single_client" if __package__ else "single_client"
)


def publish(path: Path, value: Any) -> None:
    temporary = path.with_suffix(".partial")
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(path)


async def wait_paths(paths: list[Path]) -> None:
    deadline = time.monotonic() + 240
    while not all(path.exists() for path in paths):
        if time.monotonic() > deadline:
            raise TimeoutError("Native client barrier expired")
        await asyncio.sleep(0.01)


async def wait_start(start: int) -> None:
    while time.monotonic_ns() < start:
        await asyncio.sleep((start - time.monotonic_ns()) / 1e9)


def read_samples(path: Path, count: int) -> np.ndarray:
    samples = np.loadtxt(path, dtype=np.int64, ndmin=2)
    if (
        samples.shape != (count, 3)
        or not (samples[:, 1] == 200).all()
        or not (samples[:, 2] >= 0).all()
    ):
        raise ValueError("Native client missing/failed/invalid HTTP response samples")
    return samples[:, 2] / 1000.0


def request_count(pilot: list[dict[str, Any]], case: dict[str, Any]) -> int:
    start = {row["requested_start_ns"] for row in pilot}
    if len(start) != 1:
        raise ValueError("Pilot clients did not share a start barrier")
    elapsed = (max(row["drained_ns"] for row in pilot) - start.pop()) / 1e9
    if elapsed <= 0:
        raise ValueError("Invalid native pilot duration")
    rate = sum(row["total_drained"] for row in pilot) / elapsed
    total = math.ceil(rate * case["seconds"] / case["concurrency"])
    return max(1, total) * case["concurrency"]


def batch(case: dict[str, Any], location: dict[str, Any], count: int) -> dict[str, Any]:
    command = [
        case["native_binary"],
        "--h1",
        "-t",
        "1",
        "-c",
        str(location["concurrency"]),
        "-m",
        "1",
        "-n",
        str(count),
        "-d",
        str(location["body"]),
        "-H",
        "content-type: application/json",
        "-N",
        "60s",
        "-T",
        f"{case.get('native_timeout', 90)}s",
        f"--log-file={location['samples']}",
        f"http://127.0.0.1:{case['port']}/v2/models/queue-mlp/infer",
    ]
    publish(location["command"], command)
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    actual_start = time.monotonic_ns()
    with location["log"].open("w") as output:
        # Use h2load's native connection deadline. Python's wait(timeout)
        # polls with backoff and adds noticeable delay to short calibration
        # batches; a blocking wait records child exit without that bias.
        subprocess.run(
            command,
            stdout=output,
            stderr=subprocess.STDOUT,
            check=True,
        )
    drained = time.monotonic_ns()
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    latency = read_samples(location["samples"], count)
    return {
        "actual_start_ns": actual_start,
        "drained_ns": drained,
        "client_cpu_seconds": after.ru_utime
        + after.ru_stime
        - before.ru_utime
        - before.ru_stime,
        "total_drained": len(latency),
        "latency": latency,
    }


async def run(case: dict[str, Any], directory: Path, index: int) -> None:
    count = case["clients"]
    concurrency = client.concurrency_for(case, index)
    if case.get("mix"):
        raise ValueError("Native fixed-body client does not implement mixed workloads")
    body = json.dumps(client.document(case["rows"])).encode()
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.add_session_config_entry("session.intra_op.allow_spinning", "0")
    reference = ort.InferenceSession(
        case["model"], sess_options=options, providers=["CPUExecutionProvider"]
    )
    target = f"http://127.0.0.1:{case['port']}"
    async with aiohttp.ClientSession(
        base_url=target,
        connector=aiohttp.TCPConnector(limit=concurrency),
        timeout=aiohttp.ClientTimeout(total=120),
    ) as session:
        seeds = client.warmup_seeds(count, index)
        for seed in seeds:
            await client.validate(
                session,
                json.dumps(client.document(case["rows"], seed)).encode(),
                reference,
            )
        parallel = max(64, case["concurrency"]) // count
        await asyncio.gather(
            *(client.validate(session, body, reference) for _ in range(parallel))
        )
    locations: dict[str, Any] = {
        "concurrency": concurrency,
        "body": directory / f"client-{index}-body.json",
    }
    locations["body"].write_bytes(body)
    publish(directory / f"client-{index}-warm.json", {"pid": os.getpid()})
    await wait_paths([directory / f"client-{i}-warm.json" for i in range(count)])
    if index == 0:
        publish(
            directory / "pilot-go.json", {"start_ns": time.monotonic_ns() + 250_000_000}
        )
    await wait_paths([directory / "pilot-go.json"])
    start = json.loads((directory / "pilot-go.json").read_text())["start_ns"]
    await wait_start(start)
    factor, minimum = {1: (32, 2048), 100: (4, 256), 1000: (2, 128)}[case["rows"]]
    pilot_total = max(minimum, factor * case["concurrency"])
    pilot_total = math.ceil(pilot_total / case["concurrency"]) * case["concurrency"]
    for key in ("samples", "command", "log"):
        locations[key] = directory / f"client-{index}-pilot.{key}"
    pilot = batch(case, locations, pilot_total // count)
    pilot.pop("latency")
    pilot["requested_start_ns"] = start
    publish(directory / f"client-{index}-pilot.json", pilot)
    pilot_paths = [directory / f"client-{i}-pilot.json" for i in range(count)]
    await wait_paths(pilot_paths)
    total = request_count([json.loads(path.read_text()) for path in pilot_paths], case)
    ready = {
        "pid": os.getpid(),
        "client_index": index,
        "client_count": count,
        "concurrency": concurrency,
        "warmups": len(seeds) + parallel,
        "calibration_requests": pilot_total // count,
        "native_requests": total // count,
        "event_loop": "h2load-http1-native",
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "payloads": {
            case["rows"]: {
                "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
            }
        },
    }
    publish(directory / f"client-{index}-ready.json", ready)
    await wait_paths([directory / "go.json"])
    start = json.loads((directory / "go.json").read_text())["start_ns"]
    await wait_start(start)
    for key in ("samples", "command", "log"):
        locations[key] = directory / f"client-{index}-native.{key}"
    result = batch(case, locations, total // count)
    latency = result.pop("latency")
    np.savez_compressed(
        directory / f"client-{index}-latencies.npz",
        latency_ms=latency,
        rows=np.full(len(latency), case["rows"]),
        loop_lag_ms=np.empty(0),
    )
    publish(
        directory / f"client-{index}-result.json",
        dict(
            ready,
            **result,
            errors=[],
            completed_in_window=len(latency),
            requested_start_ns=start,
            measurement="fixed-count-complete-drain",
        ),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", type=Path)
    parser.add_argument("--client", type=int, choices=range(4), required=True)
    args = parser.parse_args()
    case = json.loads(args.case.read_text())
    client.concurrency_for(case, args.client)
    uvloop.install()
    asyncio.run(run(case, args.case.parent, args.client))


if __name__ == "__main__":
    main()
