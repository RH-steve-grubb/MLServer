"""Startup/runtime guards for the single-instance REST comparison.

Only the diagnostic harness is patched. Production model/worker code is not
edited; the earlier opt-in adapters retain their documented API limitations.
"""

import asyncio
import importlib
import importlib.metadata
import json
import os
import sys
import sysconfig
from pathlib import Path
from typing import Any


def state(phase: str) -> dict[str, Any]:
    import mlserver
    import bench
    from balance_scheduler import installed
    from mlserver.codecs import json as json_codec

    gil = getattr(sys, "_is_gil_enabled", lambda: True)()
    runtime = os.environ["MLSERVER_COMPARE_RUNTIME"]
    if sys.version_info[:2] != ((3, 14) if runtime.startswith("314") else (3, 12)):
        raise RuntimeError("Wrong serving interpreter")
    if gil != (os.environ["MLSERVER_COMPARE_GIL"] == "on"):
        raise RuntimeError("Unexpected actual serving GIL state")
    if runtime == "314" and sysconfig.get_config_var("Py_GIL_DISABLED") != 1:
        raise RuntimeError("Expected the free-threaded build")
    if runtime == "314-gil" and sysconfig.get_config_var("Py_GIL_DISABLED"):
        raise RuntimeError("Expected the conventional GIL-enabled build")
    source = Path(mlserver.__file__).resolve().parent.parent
    if source != Path(os.environ["MLSERVER_COMPARE_SOURCE"]).resolve():
        raise RuntimeError("Imported an unexpected production source tree")
    if runtime == "314" and ("orjson" in sys.modules or "grpc" in sys.modules):
        raise RuntimeError("Unexpected unsupported free-threaded REST import")
    http = os.environ["MLSERVER_QUEUE_HTTP"]
    parser = os.environ["MLSERVER_QUEUE_HTTP_PARSER"]
    module, name = (
        ("aiohttp.http_parser", "HttpRequestParser")
        if http == "aiohttp"
        else (
            f"uvicorn.protocols.http.{parser}_impl",
            "H11Protocol" if parser == "h11" else "HttpToolsProtocol",
        )
    )
    engine = getattr(importlib.import_module(module), name)
    packages = [
        "onnxruntime",
        "onnx",
        "numpy",
        "pydantic",
        "pydantic-core",
        "fastapi",
        "starlette",
        "uvicorn",
        "aiohttp",
        "uvloop",
        "h11",
    ]
    if runtime in ("312", "314-gil"):
        packages.append("orjson")
    if parser == "httptools":
        packages.append("httptools")
    if os.environ["MLSERVER_QUEUE_TRANSPORT"] == "zmq":
        packages.append("pyzmq")
    return {
        "phase": phase,
        "pid": os.getpid(),
        "python": sys.version,
        "executable": sys.executable,
        "gil_enabled": gil,
        "free_threaded_build": bool(sysconfig.get_config_var("Py_GIL_DISABLED")),
        "json_codec": "orjson" if json_codec.orjson is not None else "stdlib",
        "source": str(source),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "cgroup": Path("/proc/self/cgroup").read_text().strip(),
        "libraries": {p: importlib.metadata.version(p) for p in packages},
        "http_engine": f"{engine.__module__}.{engine.__name__}",
        "transport": os.environ["MLSERVER_QUEUE_TRANSPORT"],
        "worker_json": os.environ["MLSERVER_QUEUE_JSON"],
        "scheduler": os.environ["MLSERVER_QUEUE_SCHEDULER"],
        "balanced_installed": installed(),
        "model_settings": bench.model_settings(bench.parse_args()).model_dump(
            mode="json", exclude_none=True
        ),
    }


def install() -> None:
    import bench
    from mlserver.parallel.worker import Worker

    print(json.dumps(state("server-imports")), flush=True)
    original_load = bench.OnnxModel.load

    async def load(model: Any) -> Any:
        result = await original_load(model)
        if model.settings.max_batch_size or model.settings.max_batch_time:
            raise RuntimeError("Adaptive batching must remain disabled")
        checkpoint = state("worker-loaded")
        options = model._model.get_session_options()
        checkpoint["onnx_session"] = {
            "providers": model._model.get_providers(),
            "threads": options.intra_op_num_threads,
            "spinning": options.get_session_config_entry(
                "session.intra_op.allow_spinning"
            ),
        }
        print(json.dumps(checkpoint), flush=True)
        return result

    bench.OnnxModel.load = load
    if os.environ["MLSERVER_COMPARE_RUNTIME"] == "314":
        original_start = Worker.start

        def start(worker: Any) -> Any:
            previous = {
                k: os.environ.get(k) for k in ("PYTHON_GIL", "MLSERVER_COMPARE_GIL")
            }
            # Spawned inference processes keep their GIL. Only the frontend
            # changes mode; never force an unsupported extension's GIL off.
            os.environ.update(PYTHON_GIL="1", MLSERVER_COMPARE_GIL="on")
            try:
                return original_start(worker)
            finally:
                for key, value in previous.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value

        setattr(Worker, "start", start)
    original_init = bench.RESTServer.__init__

    def initialise(server: Any, *args: Any, **kwargs: Any) -> None:
        original_init(server, *args, **kwargs)
        threads = os.environ.get("MLSERVER_COMPARE_JSON_THREADS")
        if threads is not None:
            from frontend_offload import install_routes

            install_routes(server, int(threads), os.environ["MLSERVER_QUEUE_JSON_MODE"])

        async def snapshot() -> dict[str, Any]:
            result = state("frontend-ready")
            pool = getattr(server._app.state, "frontend_json_pool", None)
            if pool is not None:
                result["json_pool"] = pool.snapshot()
                result["json_stages"] = [
                    s.snapshot() for s in server._app.state.frontend_json_stages
                ]
            return result

        server._app.add_api_route("/single-instance/state", snapshot, methods=["GET"])

    bench.RESTServer.__init__ = initialise
    if os.environ["MLSERVER_QUEUE_HTTP"] == "aiohttp":
        from aiohttp_frontend import AiohttpFrontend
        from aiohttp import web

        original_aio = AiohttpFrontend.__init__

        def aio_initialise(frontend: Any, *args: Any, **kwargs: Any) -> None:
            original_aio(frontend, *args, **kwargs)

            async def snapshot(request: Any) -> Any:
                return web.json_response(state("frontend-ready"))

            frontend.app.router.add_get("/single-instance/state", snapshot)

        AiohttpFrontend.__init__ = aio_initialise


# multiprocessing spawn reimports this entrypoint, so guards and diagnostic
# adapters apply to actual worker initialization as well as the frontend.
if os.environ.get("MLSERVER_COMPARE_RUNTIME"):
    install()

if __name__ == "__main__":
    import bench

    args = bench.parse_args()
    if args.command != "serve":
        raise ValueError("This entrypoint only serves a diagnostic model")
    bench.install_uvloop_event_loop()
    asyncio.run(bench.serve(args))
