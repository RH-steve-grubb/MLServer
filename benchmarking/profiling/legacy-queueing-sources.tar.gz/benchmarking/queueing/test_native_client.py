"""Native driver guards and a real HTTP/1.1 POST/barrier/drain integration test."""

import contextlib
import hashlib
import json
import os
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from unittest.mock import Mock

import numpy as np
import onnxruntime as ort
import pytest

from . import native_client as native
from . import single_compare as comparison


@pytest.mark.parametrize(
    "contents", ["10\t500\t50\n", "10\t200\t-1\n", "10\t200\t20\n"]
)
def test_native_samples_reject_http_errors_bad_latency_or_missing_count(
    tmp_path: Path, contents: str
) -> None:
    path = tmp_path / "samples"
    path.write_text(contents)
    with pytest.raises(ValueError, match="response samples"):
        native.read_samples(path, 2)


def test_native_latency_conversion_and_pilot_count_alignment(tmp_path: Path) -> None:
    path = tmp_path / "samples"
    path.write_text("10\t200\t1250\n20\t200\t2500\n")
    np.testing.assert_array_equal(native.read_samples(path, 2), [1.25, 2.5])
    pilot = [
        {
            "requested_start_ns": 1_000_000_000,
            "drained_ns": 2_000_000_000,
            "total_drained": 128,
        },
        {
            "requested_start_ns": 1_000_000_000,
            "drained_ns": 3_000_000_000,
            "total_drained": 128,
        },
    ]
    assert native.request_count(pilot, {"seconds": 5, "concurrency": 64}) == 640
    pilot[-1]["requested_start_ns"] += 1
    with pytest.raises(ValueError, match="share a start"):
        native.request_count(pilot, {"seconds": 5, "concurrency": 64})


def test_native_child_forces_http1_one_pipeline_slot_and_complete_fixed_count(
    tmp_path: Path, monkeypatch: Any
) -> None:
    locations = {key: tmp_path / key for key in ("samples", "body", "command", "log")}
    locations["samples"].write_text("10\t200\t100\n20\t200\t100\n")
    launch = Mock()
    monkeypatch.setattr(native.subprocess, "run", launch)
    result = native.batch(
        {"native_binary": "/usr/bin/h2load", "port": 1234},
        dict(locations, concurrency=16),
        2,
    )
    command = launch.call_args.args[0]
    assert "--h1" in command and "-D" not in command
    assert command[command.index("-n") + 1] == "2"
    assert command[command.index("-c") + 1] == "16"
    assert command[command.index("-t") + 1] == "1"
    assert command[command.index("-m") + 1] == "1"
    assert result["total_drained"] == 2


@pytest.mark.parametrize("size", [1, 100, 1000])
def test_real_four_native_clients_warmup_body_identity_and_complete_drain(
    tmp_path: Path, size: int
) -> None:
    model = comparison.STORE / "models/queue-mlp/1/model.onnx"
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.add_session_config_entry("session.intra_op.allow_spinning", "0")
    reference = ort.InferenceSession(str(model), sess_options=options)
    observed: list[bytes] = []

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, format: str, *args: Any) -> None:
            pass

        def do_POST(self) -> None:
            raw = self.rfile.read(int(self.headers["Content-Length"]))
            assert self.path == "/v2/models/queue-mlp/infer"
            assert self.headers["Content-Type"] == "application/json"
            observed.append(raw)
            doc = json.loads(raw)
            tensor = np.asarray(doc["inputs"][0]["data"], dtype=np.float32).reshape(
                size, 54
            )
            output = reference.run(["probabilities"], {"input": tensor})[0]
            response = json.dumps(
                {
                    "model_name": "queue-mlp",
                    "outputs": [
                        {
                            "name": "probabilities",
                            "datatype": "FP32",
                            "shape": [size, 7],
                            "data": output.ravel().tolist(),
                        }
                    ],
                }
            ).encode()
            self.send_response(200)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(response)))
            self.end_headers()
            self.wfile.write(response)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    case = {
        "clients": 4,
        "concurrency": 4,
        "seconds": 0.2,
        "rows": size,
        "model": str(model),
        "port": server.server_port,
        "native_binary": "/usr/bin/h2load",
    }
    native.publish(tmp_path / "case.json", case)
    children = []
    try:
        for index in range(4):
            with (tmp_path / f"child-{index}.log").open("w") as log:
                children.append(
                    subprocess.Popen(
                        [
                            str(comparison.PY312),
                            str(comparison.HERE / "native_client.py"),
                            str(tmp_path / "case.json"),
                            "--client",
                            str(index),
                        ],
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        env=dict(os.environ, PYTHONPATH=":".join(comparison.ADDONS)),
                    )
                )
        deadline = time.monotonic() + 90
        paths = [tmp_path / f"client-{i}-ready.json" for i in range(4)]
        while not all(p.exists() for p in paths):
            if (
                any(c.poll() is not None for c in children)
                or time.monotonic() > deadline
            ):
                raise AssertionError(
                    [p.read_text() for p in tmp_path.glob("child-*.log")]
                )
            time.sleep(0.01)
        native.publish(
            tmp_path / "go.json", {"start_ns": time.monotonic_ns() + 250_000_000}
        )
        assert all(child.wait(timeout=90) == 0 for child in children)
        results = [
            json.loads((tmp_path / f"client-{i}-result.json").read_text())
            for i in range(4)
        ]
        assert len({r["native_requests"] for r in results}) == 1
        assert sum(r["concurrency"] for r in results) == 4
        assert sum(r["warmups"] for r in results) == 72
        for index, result in enumerate(results):
            assert result["total_drained"] == result["native_requests"] > 0
            assert (
                not result["errors"] and result["event_loop"] == "h2load-http1-native"
            )
            body = (tmp_path / f"client-{index}-body.json").read_bytes()
            assert (
                result["payloads"][str(size)]["sha256"]
                == hashlib.sha256(body).hexdigest()
            )
            assert body in observed
            with np.load(tmp_path / f"client-{index}-latencies.npz") as samples:
                assert len(samples["latency_ms"]) == result["total_drained"]
        assert len(observed) == sum(
            r["warmups"] + r["calibration_requests"] + r["total_drained"]
            for r in results
        )
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
                with contextlib.suppress(subprocess.TimeoutExpired):
                    child.wait(timeout=10)
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
