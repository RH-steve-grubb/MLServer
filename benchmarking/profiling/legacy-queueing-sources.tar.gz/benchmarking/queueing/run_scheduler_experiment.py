"""Queue scheduler throughput/latency controls and separate balance traces."""

import argparse
import hashlib
import importlib
import json
import os
import platform
import statistics
import sys
from pathlib import Path

transport = importlib.import_module(
    f"{__package__}.run_frontend_transport" if __package__ else "run_frontend_transport"
)
balance = importlib.import_module(
    f"{__package__}.worker_balance" if __package__ else "worker_balance"
)
study = transport.study
WORKLOADS = {
    "small": [1],
    "medium": [100],
    "large": [1000],
    "mix90-10": [1] * 9 + [1000],
    "mix50-50": [1, 1000],
}


def validate(row: dict) -> None:
    transport.validate(row)
    for phase in ("before", "after"):
        state = row["checks"][phase]
        if state["scheduler"] != row["scheduler"] or state[
            "least_outstanding_installed"
        ] != (row["scheduler"] == "least-outstanding"):
            raise ValueError("Scheduler control was not installed as requested")
    classes = row["classes"]
    if set(map(int, classes)) != set(WORKLOADS[row["workload"]]):
        raise ValueError("Unexpected request classes")
    if (
        sum(value["total_drained"] for value in classes.values())
        != row["total_drained"]
    ):
        raise ValueError("Missing per-class completions")
    if (
        sum(value["completed_in_window"] for value in classes.values())
        != row["completed_in_window"]
    ):
        raise ValueError("Missing per-class window completions")
    trace = row.get("balance_trace")
    if not row["balance"]:
        if trace is not None:
            raise ValueError("Performance control unexpectedly instrumented")
        return
    if (
        not trace
        or trace["dropped"]
        or len(trace["events"]) != row["total_drained"]
        or len(set(trace["worker_pids"])) != 6
    ):
        raise ValueError("Missing/incomplete balance trace")
    if any(
        len(e) != 6 or e[5] not in set(WORKLOADS[row["workload"]])
        for e in trace["events"]
    ):
        raise ValueError("Missing or incorrect request class in trace")
    checked = balance.analyze(
        trace["events"],
        trace["worker_pids"],
        (trace["window_start_ns"], trace["window_end_ns"]),
    )
    if checked != trace["metrics"]:
        raise ValueError("Balance metrics do not match retained timeline")


def summarize(rows: list[dict]) -> str:
    lines = [
        "REST/JSON, no-GIL frontend, eight JSON threads, six GIL-on ONNX workers.",
        "Queue/pickle, h11, one ORT thread/worker; only selection policy changes.",
        "Throughput and traced balance runs are separate; "
        "do not use trace RPS as capacity.",
        "Mixed sizes reshuffle weighted blocks with paired seed 20261008.",
        "Means of per-run statistics; percentiles are not pooled.",
        "",
        "phase workload scheduler trials RPS aggregate-p95-ms",
    ]
    keys = sorted({(r["balance"], r["workload"], r["scheduler"]) for r in rows})
    for instrumented, workload, scheduler in keys:
        group = [
            r
            for r in rows
            if (r["balance"], r["workload"], r["scheduler"])
            == (instrumented, workload, scheduler)
        ]
        lines.append(
            f"{'trace' if instrumented else 'perf':5} {workload:10} "
            f"{scheduler:17} {len(group):2} "
            f"{statistics.mean(r['rps'] for r in group):8.1f} "
            f"{statistics.mean(r['timings']['client_ms']['p95'] for r in group):8.1f}"
        )
        for size in sorted({int(key) for r in group for key in r["classes"]}):
            items = [r["classes"][str(size)] for r in group]
            lines.append(
                f"  rows={size}: mean/p95/p99 ms "
                + " / ".join(
                    f"{statistics.mean(item['client_ms'][key] for item in items):.2f}"
                    for key in ("mean", "p95", "p99")
                )
            )
        if instrumented:
            for key in (
                "waiting_count_skew_mean",
                "waiting_count_skew_p95",
                "waiting_count_skew_max",
                "waiting_stddev_rms",
                "outstanding_count_skew_p95",
                "idle_with_backlog_fraction",
                "idle_worker_capacity_candidate_fraction",
            ):
                values = [r["balance_trace"]["metrics"][key] for r in group]
                lines.append(
                    f"  {key}: mean {statistics.mean(values):.3f}; "
                    f"range {min(values):.3f}..{max(values):.3f}"
                )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> None:
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = {
        "scope": "REST/JSON Queue scheduler study with separate worker timelines",
        "coordinator": sys.version,
        "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "arguments": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "source_manifest": study.source_manifest(args.source),
        "harness_sha256": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in Path(__file__).parent.glob("*.py")
        },
        "load_average_before": os.getloadavg(),
        "workloads": {name: WORKLOADS[name] for name in args.workloads},
    }
    args.output.joinpath("metadata.json").write_text(json.dumps(metadata, indent=2))
    rows = []
    for trial in range(args.repeats):
        policies = (
            ["round-robin", "least-outstanding"]
            if trial % 2 == 0
            else ["least-outstanding", "round-robin"]
        )
        workloads = args.workloads if trial % 2 == 0 else list(reversed(args.workloads))
        for workload in workloads:
            for scheduler in policies:
                case = dict(
                    frontend="threads-8",
                    json_threads=8,
                    transport="queue",
                    mode="off",
                    batch=WORKLOADS[workload][0],
                    mix=WORKLOADS[workload],
                    concurrency=64,
                    trial=trial,
                    workload=workload,
                    scheduler=scheduler,
                    balance=args.balance,
                )
                directory = args.output / f"r{trial}-{workload}-{scheduler}"
                print(f"Starting {directory.name}", flush=True)
                row = study.run_case(args, case, directory)
                validate(row)
                # Full events are already retained in this case's result.json.
                # Avoid repeatedly copying all traces into the aggregate file.
                compact = dict(row, case_result=f"{directory.name}/result.json")
                if args.balance:
                    compact["balance_trace"] = {
                        k: v for k, v in row["balance_trace"].items() if k != "events"
                    }
                    compact["balance_event_count"] = len(row["balance_trace"]["events"])
                rows.append(compact)
                args.output.joinpath("results.json").write_text(
                    json.dumps(rows, indent=2)
                )
                args.output.joinpath("SUMMARY.txt").write_text(summarize(rows))
                print(
                    f"  {row['rps']:.1f} RPS; p95 "
                    f"{row['timings']['client_ms']['p95']:.1f} ms",
                    flush=True,
                )
    print(summarize(rows), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("server-python", "client-python", "source", "model", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument(
        "--workloads", nargs="+", choices=list(WORKLOADS), default=list(WORKLOADS)
    )
    parser.add_argument("--balance", action="store_true")
    parser.add_argument("--seconds", type=float, default=12)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.workers, args.worker_gil = 6, "on"
    if args.seconds <= 0 or args.repeats < 1:
        parser.error("Seconds and repeats must be positive")
    run(args)


if __name__ == "__main__":
    main()
