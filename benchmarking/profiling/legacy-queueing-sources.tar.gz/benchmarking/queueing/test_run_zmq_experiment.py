"""Reject invalid IPC measurements rather than reporting apparent speedups."""

from pathlib import Path
from typing import Any

import pytest

from .run_zmq_experiment import validate_rows, write_summary


def document(transport: str) -> dict[str, Any]:
    return {
        "metadata": {"queue_transport": transport},
        "results": [
            {
                "errors": [],
                "total_drained": 10,
                "queue_codec": "pickle",
                "queue_tensors": "list",
                "total_workers": 6,
                "frontends": 1,
                "transport_counts": (
                    {"transport_sent": 10, "transport_received": 10}
                    if transport == "zmq"
                    else {}
                ),
            }
        ],
    }


@pytest.mark.parametrize("transport", ["queue", "zmq"])
def test_validated_transport(transport: str) -> None:
    validate_rows(document(transport), transport)


@pytest.mark.parametrize(
    "field,value",
    [
        ("errors", ["prediction failed"]),
        ("total_drained", 0),
        ("queue_codec", "msgpack"),
        ("queue_tensors", "numpy"),
        ("total_workers", 32),
        ("frontends", 6),
        ("transport_counts", {"transport_sent": 10, "transport_received": 9}),
        ("transport_counts", {"transport_sent": 11, "transport_received": 10}),
    ],
)
def test_rejects_invalid_zmq_measurement(field: str, value: Any) -> None:
    result = document("zmq")
    result["results"][0][field] = value
    with pytest.raises(ValueError):
        validate_rows(result, "zmq")


def test_rejects_accidentally_enabled_adapter_on_queue_control() -> None:
    result = document("queue")
    result["results"][0]["transport_counts"] = {"transport_sent": 10}
    with pytest.raises(ValueError, match="unexpectedly"):
        validate_rows(result, "queue")


def test_rejects_wrong_transport() -> None:
    with pytest.raises(ValueError, match="not selected"):
        validate_rows(document("queue"), "zmq")


def test_rejects_empty_results() -> None:
    result = document("zmq")
    result["results"] = []
    with pytest.raises(ValueError, match="no cases"):
        validate_rows(result, "zmq")


def test_partial_summary_reports_no_validated_blocks(tmp_path: Path) -> None:
    write_summary(tmp_path, [])
    assert "Completed validated blocks: 0." in (tmp_path / "SUMMARY.txt").read_text()
