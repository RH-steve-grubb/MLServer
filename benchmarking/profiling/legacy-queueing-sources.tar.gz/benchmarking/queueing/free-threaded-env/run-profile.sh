#!/usr/bin/env bash
# Root is required for perf uprobes, not to install packages or change host policy.
set -eu

study_store=/home/codex/mlserver-durable-store/free-threaded-serving-20261008
study_repo="$study_store/source-original"
study_server_python=/home/codex/mlserver-durable-store/venvs/mlserver-free-threaded-serving-study-di2VO4Zh-py3.14/bin/python
study_client_python=/home/codex/tmp/mlserver-perf-venvs/mlserver-bnlygABv-py3.12/bin/python
study_output="$study_store/profile-$(date -u +%Y%m%dT%H%M%SZ)-$$"

# Use the archived collector and source copy, not whatever changes are made in
# the working tree after this experiment. The fixed 3.12 client imports the
# archived original core; it does not use the free-threaded startup patches.
export MLSERVER_STUDY_REPO="$study_repo"
export MLSERVER_STUDY_COMMIT=ac5babeff4ecf5a1359c55dc354932cc4429b7cd
exec "$study_client_python" "$study_store/harness/free_threaded_profile.py" \
    --server-python "$study_server_python" \
    --client-python "$study_client_python" \
    --source "$study_store/source" \
    --model "$study_store/mlserver-queue-mlp.onnx" \
    --output "$study_output" --worker-gil on "$@"
