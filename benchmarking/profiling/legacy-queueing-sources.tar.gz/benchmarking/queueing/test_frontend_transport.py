"""Guard the combined experiment against accidentally unmatched controls."""

from copy import deepcopy
from pathlib import Path

import pytest

from . import free_threaded, run_frontend_transport


def measurement(transport: str, threads: int = 8) -> dict:
    state = dict(gil_enabled=False, transport=transport)
    state["frontend_json_pool"] = dict(
        workers=threads,
        inflight=0,
        completed=148,
        peak_inflight=threads,
        thread_gil_states={"123": False} if threads else {},
    )
    return dict(
        frontend="threads-8" if threads else "inline",
        json_threads=threads,
        mode="off",
        transport=transport,
        batch=100,
        concurrency=64,
        rps=1000,
        errors=[],
        total_drained=10,
        checks=dict(
            before=deepcopy(state),
            after=deepcopy(state),
            startup=[
                dict(
                    phase="onnx-model-loaded",
                    pid=pid,
                    gil_enabled=True,
                    transport=transport,
                )
                for pid in range(6)
            ],
        ),
        transport_counts=(
            dict(transport_sent=10, transport_received=10) if transport == "zmq" else {}
        ),
        timings={"client_ms": {"p95": 10}},
        server_main_cpu_cores=4,
        worker_cpu_cores=3,
    )


@pytest.mark.parametrize("transport", ["queue", "zmq"])
@pytest.mark.parametrize("threads", [0, 8])
def test_matched_controls(transport: str, threads: int) -> None:
    run_frontend_transport.validate(measurement(transport, threads))


@pytest.mark.parametrize("transport", ["queue", "zmq"])
def test_transport_environment_selects_only_requested_adapter(transport: str) -> None:
    env = free_threaded.environment(Path("/source"), "off")
    free_threaded.configure_transport(env, transport, "/tmp/sockets")
    assert env["MLSERVER_QUEUE_TRANSPORT"] == transport
    assert ("MLSERVER_QUEUE_ZMQ_DIR" in env) == (transport == "zmq")
    assert "PYTHON_GIL" not in env
    assert env["MLSERVER_QUEUE_JSON"] == "frontend"
    assert env["MLSERVER_QUEUE_CODEC"] == "pickle"
    assert env["MLSERVER_QUEUE_BALANCE"] == "0"


def test_invalid_transport_is_rejected() -> None:
    with pytest.raises(ValueError, match="transport"):
        free_threaded.configure_transport({}, "unknown", "/tmp/sockets")


@pytest.mark.parametrize("phase", ["before", "after"])
@pytest.mark.parametrize("field,value", [("gil_enabled", True), ("transport", "queue")])
def test_rejects_wrong_frontend_state(phase: str, field: str, value: object) -> None:
    row = measurement("zmq")
    row["checks"][phase][field] = value
    with pytest.raises(ValueError, match="control mismatch"):
        run_frontend_transport.validate(row)


@pytest.mark.parametrize(
    "field,value", [("gil_enabled", False), ("transport", "queue"), ("pid", 1)]
)
def test_rejects_wrong_worker_state(field: str, value: object) -> None:
    row = measurement("zmq")
    row["checks"]["startup"][0][field] = value
    with pytest.raises(ValueError, match="six GIL-enabled workers"):
        run_frontend_transport.validate(row)


@pytest.mark.parametrize(
    "field,value", [("mode", "on"), ("errors", ["failed"]), ("total_drained", 0)]
)
def test_rejects_unsuccessful_measurement(field: str, value: object) -> None:
    row = measurement("zmq")
    row[field] = value
    with pytest.raises(ValueError):
        run_frontend_transport.validate(row)


@pytest.mark.parametrize("key", ["transport_sent", "transport_received"])
@pytest.mark.parametrize("value", [9, 11, None])
def test_rejects_missing_or_duplicate_transport_messages(
    key: str, value: object
) -> None:
    row = measurement("zmq")
    row["transport_counts"][key] = value
    with pytest.raises(ValueError, match="Missing or duplicate"):
        run_frontend_transport.validate(row)


def test_rejects_zmq_counts_in_queue_control() -> None:
    row = measurement("queue")
    row["transport_counts"] = dict(transport_sent=10)
    with pytest.raises(ValueError, match="Queue control"):
        run_frontend_transport.validate(row)


def test_summary_compares_transport_with_same_json_placement() -> None:
    rows = [
        measurement(transport, threads)
        for threads in (0, 8)
        for transport in ("queue", "zmq")
    ]
    for row in rows:
        row["rps"] *= (2 if row["json_threads"] else 1) * (
            1.25 if row["transport"] == "zmq" else 1
        )
    result = run_frontend_transport.summarize(rows)
    assert result.count("1.250") == 2
    assert "no worker JSON" in result
    assert "no pooled percentile" in result
    assert "1250.0" in result and "2500.0" in result
