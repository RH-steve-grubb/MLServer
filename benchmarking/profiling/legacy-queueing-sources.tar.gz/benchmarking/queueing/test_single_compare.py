"""Guard the one-instance comparison, including failed-start cleanup."""

import json
import argparse
import contextlib
import copy
import subprocess
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any
from unittest.mock import Mock

import numpy as np
import pytest

from . import single_compare as comparison


def setup(directory: Path) -> comparison.Setup:
    return comparison.Setup(directory, comparison.Budget(), frozen_harness=directory)


def test_cpu_ranges_and_physical_client_assignment() -> None:
    assert comparison.cpus("0-3,7,16-19") == {0, 1, 2, 3, 7, 16, 17, 18, 19}
    assert comparison.client_sets(comparison.Budget()) == [[14, 30], [15, 31]]
    assert comparison.client_sets(comparison.Budget(), 4) == [[14], [15], [30], [31]]
    with pytest.raises(ValueError, match="four reserved"):
        comparison.client_sets(comparison.Budget(client="14,15,30"), 4)
    with pytest.raises(ValueError, match="two or four"):
        comparison.client_sets(comparison.Budget(), 3)
    with pytest.raises(ValueError):
        comparison.cpus("4-2")
    with pytest.raises(ValueError, match="physical cores"):
        comparison.validate_budget(comparison.Budget(server="0", client="16,17"))


def test_commands_use_rootless_owner_and_identical_scope(tmp_path: Path) -> None:
    config = setup(tmp_path)
    native = comparison.Server(
        config, comparison.Variant("ovms", runtime="ovms"), tmp_path
    )
    command = native.command()
    assert command[:4] == ["runuser", "-u", "codex", "--"]
    assert comparison.IMAGE in command and "--pull=never" in command
    assert "--cgroups=disabled" in command and "--network=host" in command
    assert json.loads(command[command.index("--plugin_config") + 1]) == {
        "INFERENCE_PRECISION_HINT": "f32"
    }
    scope = comparison.scope_command(native.unit, config.budget, command)
    assert f"--property=AllowedCPUs={config.budget.server}" in scope
    assert f"--property=MemoryMax={config.budget.memory}" in scope
    assert "--property=MemorySwapMax=0" in scope
    with pytest.raises(ValueError, match="non-root"):
        comparison.podman("root")


def test_image_preflight_uses_readable_cwd(tmp_path: Path, monkeypatch: Any) -> None:
    launch = tmp_path / "root-shell"
    output = tmp_path / "results"
    launch.mkdir()
    output.mkdir()
    monkeypatch.chdir(launch)
    calls = Mock(
        side_effect=[
            subprocess.CompletedProcess(
                [], 0, json.dumps([{"Id": comparison.IMAGE}]), ""
            ),
            subprocess.CompletedProcess([], 0, "OpenVINO Model Server 2026.4.0\n", ""),
        ]
    )
    monkeypatch.setattr(comparison.subprocess, "run", calls)
    comparison.image_checks(setup(tmp_path), output)
    assert calls.call_count == 2
    assert all(call.kwargs["cwd"] == output for call in calls.call_args_list)


def test_podman_cleanup_uses_case_cwd(tmp_path: Path, monkeypatch: Any) -> None:
    server = comparison.Server(
        setup(tmp_path), comparison.Variant("ovms", runtime="ovms"), tmp_path
    )
    monkeypatch.setattr(server, "inspected_container", Mock(return_value={}))
    run = Mock(return_value=subprocess.CompletedProcess([], 0, "", ""))
    monkeypatch.setattr(comparison.subprocess, "run", run)
    server.stop_server()
    server.clear_scope()
    calls = [call for call in run.call_args_list if "podman" in call.args[0]]
    assert len(calls) == 2
    assert all(call.kwargs["cwd"] == tmp_path for call in calls)


@pytest.mark.parametrize("binary", [False, True])
@pytest.mark.parametrize("timeout", [False, True])
def test_failure_report_retains_subprocess_streams(binary: bool, timeout: bool) -> None:
    stderr = "cannot chdir to /root: Permission denied"
    error_output: str | bytes = stderr.encode() if binary else stderr
    command = ["runuser", "podman", "inspect"]
    error: BaseException = (
        subprocess.TimeoutExpired(command, 30, output=error_output, stderr=error_output)
        if timeout
        else subprocess.CalledProcessError(
            1, command, output=error_output, stderr=error_output
        )
    )
    details = comparison.failure_details(error)
    assert details["command"] == command
    assert details["stdout"] == details["stderr"] == stderr
    assert json.loads(json.dumps(details))["stderr"] == stderr


def test_rejects_wrong_effective_limits(tmp_path: Path) -> None:
    budget = comparison.Budget(server="0-1", client="2-3", memory=1024)
    for name, data in {
        "memory.max": "1024",
        "memory.swap.max": "0",
        "cpuset.cpus.effective": "0-1",
        "cpu.stat": "usage_usec 12\n",
        "memory.current": "12",
        "memory.peak": "24",
        "memory.events": "oom 0\n",
    }.items():
        (tmp_path / name).write_text(data)
    assert comparison.cgroup_snapshot(tmp_path, budget)["cpu"]["usage_usec"] == 12
    (tmp_path / "cpuset.cpus.effective").write_text("0-2")
    with pytest.raises(RuntimeError, match="CPU budget"):
        comparison.cgroup_snapshot(tmp_path, budget)
    (tmp_path / "memory.max").write_text("max")
    with pytest.raises(ValueError):
        comparison.cgroup_snapshot(tmp_path, budget)


def test_environment_clears_inherited_controls(
    tmp_path: Path, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_COMPARE_JSON_THREADS", "999")
    monkeypatch.setenv("MLSERVER_QUEUE_BALANCE", "1")
    monkeypatch.setenv("MLSERVER_DEFAULT_MAX_BATCH_SIZE", "12")
    monkeypatch.setenv("PYTHON_GIL", "1")
    env = comparison.environment(
        comparison.Variant("ft", runtime="314"), setup(tmp_path), "/ipc"
    )
    assert "PYTHON_GIL" not in env and "MLSERVER_COMPARE_JSON_THREADS" not in env
    assert env["MLSERVER_QUEUE_BALANCE"] == "0"
    assert env["MLSERVER_DEFAULT_MAX_BATCH_SIZE"] == "0"
    assert not any(path in env["PYTHONPATH"] for path in comparison.ADDONS)


def test_worker_json_controls_keep_gil_on_and_isolate_ft_pair(tmp_path: Path) -> None:
    original, upgrade, balanced, ft_on, ft_off = comparison.worker_json_variants()
    assert [v.runtime for v in (original, upgrade, balanced)] == [
        "312",
        "314-gil",
        "314-gil",
    ]
    assert all(comparison.gil_enabled(v) for v in (original, upgrade, balanced))
    assert (
        replace(upgrade, name=balanced.name, scheduler=balanced.scheduler) == balanced
    )
    assert balanced.scheduler == "least-outstanding"
    assert replace(ft_on, name=ft_off.name, gil=False) == ft_off
    assert comparison.serving_python(ft_on.runtime) == comparison.serving_python(
        ft_off.runtime
    )
    assert all(
        v.workers == 12
        and v.threads == 2
        and v.raw
        and v.transport == "zmq"
        and v.http == "fastapi"
        for v in comparison.worker_json_variants()
    )
    for variant in comparison.worker_json_variants():
        env = comparison.environment(variant, setup(tmp_path), "/ipc")
        assert (env.get("PYTHON_GIL") == "1") == comparison.gil_enabled(variant)
        assert env["MLSERVER_COMPARE_GIL"] == (
            "on" if comparison.gil_enabled(variant) else "off"
        )
        assert env["MLSERVER_COMPARE_SOURCE"] == str(
            tmp_path / f"source-{comparison.serving_source(variant.runtime)}"
        )
        assert env["MLSERVER_QUEUE_JSON"] == "full"
        assert env["MLSERVER_QUEUE_SCHEDULER"] == variant.scheduler


def test_worker_json_phase_is_fixed_not_a_per_size_architecture_selection(
    monkeypatch: Any, tmp_path: Path
) -> None:
    stage = Mock(return_value=[])
    monkeypatch.setattr(comparison, "stage", stage)
    args = argparse.Namespace(phase="worker-json", seconds=12, repeats=3)
    context = {"output": tmp_path}
    comparison.experiment(args, context)
    assert stage.call_count == 2
    assert all(
        call.args[1] == comparison.worker_json_variants()
        for call in stage.call_args_list
    )
    works = stage.call_args_list[1].args[2]
    assert {(w["rows"], w["concurrency"]) for w in works} == {
        (rows, concurrency) for rows in (1, 100, 1000) for concurrency in (64, 512)
    }
    assert context["driver"] == "native" and context["clients"] == 4
    assert context["repeats"] == 3 and context["seconds"] == 12


def test_failed_start_cleans_scope_even_if_launcher_exited(
    tmp_path: Path, monkeypatch: Any
) -> None:
    server = comparison.Server(setup(tmp_path), comparison.Variant("test"), tmp_path)
    server.log, server.ipc = Mock(), Mock()
    server.process = Mock()
    server.process.poll.return_value = 1
    clear = Mock()
    monkeypatch.setattr(server, "clear_scope", clear)
    server.close()
    clear.assert_called_once()
    server.log.close.assert_called_once()
    server.ipc.cleanup.assert_called_once()


def test_cleanup_resources_survive_shutdown_error(
    tmp_path: Path, monkeypatch: Any
) -> None:
    server = comparison.Server(setup(tmp_path), comparison.Variant("test"), tmp_path)
    server.log, server.ipc = Mock(), Mock()
    clear = Mock()
    monkeypatch.setattr(
        server, "stop_server", Mock(side_effect=RuntimeError("shutdown"))
    )
    monkeypatch.setattr(server, "clear_scope", clear)
    with pytest.raises(RuntimeError, match="shutdown"):
        server.close()
    clear.assert_called_once()
    server.log.close.assert_called_once()
    server.ipc.cleanup.assert_called_once()


def test_ready_server_missing_controller_fails_without_retry(
    tmp_path: Path, monkeypatch: Any
) -> None:
    server = comparison.Server(setup(tmp_path), comparison.Variant("test"), tmp_path)
    child = Mock()
    child.poll.return_value = None
    monkeypatch.setattr(comparison.subprocess, "Popen", Mock(return_value=child))
    ready = Mock(side_effect=[{"pid": 7}, AssertionError("Incorrect readiness retry")])
    monkeypatch.setattr(comparison, "read_json", ready)
    group = tmp_path / f"{server.unit}.scope"
    monkeypatch.setattr(comparison, "cgroup_path", Mock(return_value=group))
    monkeypatch.setattr(
        comparison,
        "cgroup_snapshot",
        Mock(side_effect=FileNotFoundError("cpuset.cpus.effective")),
    )
    monkeypatch.setattr(server, "stop_server", Mock())
    monkeypatch.setattr(server, "clear_scope", Mock())
    try:
        with pytest.raises(FileNotFoundError, match="cpuset"):
            server.start()
        assert ready.call_count == 1
        assert server.owned_http and server.group == group
    finally:
        server.close()


def test_failed_second_client_stops_first(tmp_path: Path, monkeypatch: Any) -> None:
    child = Mock()
    monkeypatch.setattr(
        comparison.subprocess, "Popen", Mock(side_effect=[child, OSError("spawn")])
    )
    stop = Mock()
    monkeypatch.setattr(comparison, "stop_clients", stop)
    with pytest.raises(OSError, match="spawn"):
        comparison.clients({}, tmp_path, setup(tmp_path))
    stop.assert_called_once_with([child])


def test_failed_fourth_client_stops_all_launched_clients(
    tmp_path: Path, monkeypatch: Any
) -> None:
    children = [Mock() for _ in range(3)]
    spawn = Mock(side_effect=[*children, OSError("spawn")])
    monkeypatch.setattr(comparison.subprocess, "Popen", spawn)
    stop = Mock()
    monkeypatch.setattr(comparison, "stop_clients", stop)
    with pytest.raises(OSError, match="spawn"):
        comparison.clients({"clients": 4}, tmp_path, setup(tmp_path))
    stop.assert_called_once_with(children)
    assert [call.args[0][2] for call in spawn.call_args_list] == [
        "14",
        "15",
        "30",
        "31",
    ]


@pytest.mark.parametrize("concurrency", [2, 64, 128, 512])
def test_requested_client_count_preserves_total_concurrency(concurrency: int) -> None:
    for requested in (2, 4):
        count = comparison.client_count(requested, concurrency)
        assert count == min(requested, concurrency)
        assert (concurrency // count) * count == concurrency
    for requested, total in ((3, 64), (4, 3), (4, 6), (2, 1)):
        with pytest.raises(ValueError):
            comparison.client_count(requested, total)


@pytest.mark.parametrize("bad_fourth_client", [False, True])
@pytest.mark.parametrize("driver", ["python", "native"])
def test_four_client_aggregation_and_individual_control_checks(
    tmp_path: Path, monkeypatch: Any, bad_fourth_client: bool, driver: str
) -> None:
    server = comparison.Server(
        setup(tmp_path), comparison.Variant("ovms", runtime="ovms"), tmp_path
    )
    server.group = tmp_path
    start = 1_250_000_000
    for index, affinity in enumerate(comparison.client_sets(server.setup.budget, 4)):
        row = {
            "client_index": index,
            "client_count": 4,
            "concurrency": 16,
            "warmups": 18,
            "errors": [],
            "total_drained": 2,
            "completed_in_window": 2,
            "actual_start_ns": start,
            "drained_ns": start + 2_000_000_000,
            "event_loop": "h2load-http1-native" if driver == "native" else "uvloop",
            "native_requests": 2,
            "cpu_affinity": affinity,
            "payloads": {"1": {"bytes": 1245, "sha256": "same"}},
            "client_cpu_seconds": 0.8,
        }
        if bad_fourth_client and index == 3:
            row["concurrency"] = 32
        comparison.write_json(tmp_path / f"client-{index}-ready.json", row)
        comparison.write_json(tmp_path / f"client-{index}-result.json", row)
        np.savez(
            tmp_path / f"client-{index}-latencies.npz",
            latency_ms=[index + 1.0, index + 5.0],
            rows=[1, 1],
            loop_lag_ms=[index / 10],
        )
    children = [Mock(wait=Mock(return_value=0)) for _ in range(4)]
    stop = Mock()
    monkeypatch.setattr(comparison, "clients", Mock(return_value=children))
    monkeypatch.setattr(comparison, "stop_clients", stop)
    monkeypatch.setattr(server, "checks", Mock(return_value={}))
    monkeypatch.setattr(comparison, "validate_controls", Mock())
    monkeypatch.setattr(comparison, "validate_workers", Mock(return_value=[]))
    monkeypatch.setattr(
        comparison.time, "monotonic_ns", Mock(return_value=1_000_000_000)
    )
    monkeypatch.setattr(comparison.time, "sleep", Mock())
    before: dict[str, Any] = {
        "monotonic_ns": start - 20_000_000,
        "cpu": {"usage_usec": 0},
        "memory_events": "max 0\noom 0\noom_kill 0\n",
        "memory_peak": 1024,
    }
    after = copy.deepcopy(before)
    after["monotonic_ns"] = start + 2_000_000_000
    after["cpu"]["usage_usec"] = 4_000_000
    monkeypatch.setattr(
        comparison, "cgroup_snapshot", Mock(side_effect=[before, after])
    )
    case = {
        "clients": 4,
        "concurrency": 64,
        "seconds": 5 if driver == "native" else 2,
        "rows": 1,
        "driver": driver,
    }
    if bad_fourth_client:
        with pytest.raises(ValueError, match="control mismatch"):
            comparison.measured_load(server, case)
    else:
        result = comparison.measured_load(server, case)
        assert len(result["clients"]) == 4
        assert result["total_drained"] == 8 and result["rps"] == 4
        assert result["load_seconds"] == 2
        assert result["client_ms"] == comparison.percentiles(np.arange(1.0, 9.0))
        assert result["client_cpu_cores"] == pytest.approx(1.6)
        assert result["max_client_cpu_cores"] == pytest.approx(0.4)
    stop.assert_called_once_with(children)


def test_summary_keeps_client_modes_separate_and_scales_cpu_warning() -> None:
    rows = [
        {
            "case": {"phase": "clients", "rows": 1, "concurrency": 64, "clients": n},
            "variant": {"name": "ovms-default-fp32"},
            "rps": n * 100.0,
            "client_ms": {"p95": 1, "p99": 2},
            "server_cpu_ms_per_request": 1,
            "memory_peak_bytes": 1024**2,
            "client_cpu_cores": n * 0.5,
            "max_client_cpu_cores": 0.5,
        }
        for n in (2, 4)
    ]
    text = comparison.summary(rows)
    assert len([line for line in text.splitlines() if line.startswith("clients ")]) == 2
    assert "200.0" in text and "400.0" in text and "300.0" not in text
    assert "CAUTION" not in text  # Four half-busy clients are not two saturated ones.
    rows[-1]["max_client_cpu_cores"] = 0.95
    assert "1 windows had a client near one CPU core" in comparison.summary(rows)


def test_run_case_records_effective_low_concurrency_count_and_unique_label(
    tmp_path: Path, monkeypatch: Any
) -> None:
    server = Mock()
    monkeypatch.setattr(
        comparison, "serving", Mock(return_value=contextlib.nullcontext(server))
    )
    result = {"rps": 1.0, "client_ms": {"p95": 1.0}, "server_cpu_ms_per_request": 1.0}
    measure = Mock(return_value=result)
    monkeypatch.setattr(comparison, "measured_load", measure)
    monkeypatch.setattr(comparison, "summary", Mock(return_value="summary"))
    context = {
        "setup": setup(tmp_path),
        "output": tmp_path,
        "clients": 4,
        "all_rows": [],
    }
    case = {"phase": "sweep", "rows": 1, "concurrency": 2, "trial": 0, "seconds": 2}
    comparison.run_case(context, comparison.Variant("test"), case)
    assert case["requested_clients"] == 4 and case["clients"] == 2
    assert case["concurrency"] == 2
    assert (tmp_path / "sweep-r0-b1-c2-p2-test/result.json").is_file()
    assert result["cleanup_passed"] and context["all_rows"] == [result]


def test_unowned_container_is_never_stopped(tmp_path: Path, monkeypatch: Any) -> None:
    server = comparison.Server(
        setup(tmp_path), comparison.Variant("ovms", runtime="ovms"), tmp_path
    )
    inspected = subprocess.CompletedProcess(
        [], 0, json.dumps([{"Config": {"Labels": {}}}])
    )
    run = Mock(return_value=inspected)
    monkeypatch.setattr(comparison.subprocess, "run", run)
    with pytest.raises(RuntimeError, match="unowned"):
        server.stop_server()
    assert run.call_count == 1
    assert run.call_args.kwargs["cwd"] == tmp_path


def test_ranking_requires_every_size_and_fresh_controls() -> None:
    options = comparison.variants()
    data = [
        {"variant": asdict(v), "case": {"rows": n, "concurrency": 64}, "rps": i + 1}
        for i, v in enumerate(options)
        for n in (1, 100, 1000)
    ]
    selected = comparison.confirmation(data, options)
    assert all(
        any(v.family == family for v in selected)
        for family in ("raw-fastapi", "raw-aiohttp", "ft", "ovms")
    )
    assert any(v.name == "typed312-h11" for v in selected)
    with pytest.raises(ValueError, match="ranking"):
        comparison.ranking(data[:-1], options)


def test_smoke_covers_each_architecture_and_no_replicas() -> None:
    options = comparison.smoke_variants(comparison.variants())
    assert {v.runtime for v in options} == {"312", "314", "ovms"}
    assert {v.http for v in options} == {"fastapi", "aiohttp", "native"}
    assert {v.transport for v in options} == {"queue", "zmq", "native"}
    assert all("replica" not in v.name for v in comparison.variants())
    assert len(comparison.workloads("smoke")) == 3


def test_controller_smoke_cannot_start_later_stages(
    monkeypatch: Any, tmp_path: Path
) -> None:
    stage = Mock()
    monkeypatch.setattr(comparison, "stage", stage)
    comparison.experiment(argparse.Namespace(phase="smoke"), {"output": tmp_path})
    assert stage.call_count == 1


def test_client_control_uses_adjacent_pairs_and_cannot_start_full_comparison(
    monkeypatch: Any, tmp_path: Path
) -> None:
    run = Mock()
    stage = Mock(side_effect=AssertionError("Full comparison was started"))
    monkeypatch.setattr(comparison, "run_case", run)
    monkeypatch.setattr(comparison, "stage", stage)
    args = argparse.Namespace(phase="clients", seconds=12.0, repeats=3)
    comparison.experiment(args, {"output": tmp_path})
    assert run.call_count == 18
    calls = run.call_args_list
    for offset in range(0, 18, 2):
        left, right = calls[offset].args, calls[offset + 1].args
        assert left[1] == right[1]
        first, second = left[2], right[2]
        assert {first["clients"], second["clients"]} == {2, 4}
        assert first["clients"] == (4 if first["trial"] % 2 else 2)
        assert first["concurrency"] == second["concurrency"] == 64
        assert first["rows"] == second["rows"] == 1
        assert first["seconds"] == second["seconds"] == 12
    assert calls[0].args[1] == calls[10].args[1]  # Variant order reversed in trial 1.


def test_native_comparison_stops_if_native_clients_are_still_cpu_bound(
    tmp_path: Path, monkeypatch: Any
) -> None:
    stage = Mock(return_value=[{"case": {"clients": 4}, "max_client_cpu_cores": 0.9}])
    monkeypatch.setattr(comparison, "stage", stage)
    with pytest.raises(RuntimeError, match="headroom"):
        comparison.experiment(
            argparse.Namespace(phase="native-fast"), {"output": tmp_path}
        )
    assert stage.call_count == 1


def test_native_comparison_keeps_original_controls_and_skips_mixed_size(
    tmp_path: Path, monkeypatch: Any
) -> None:
    options = comparison.variants()
    data = [
        {"variant": asdict(v), "case": {"rows": size, "concurrency": 64}, "rps": i + 1}
        for i, v in enumerate(options)
        for size in (1, 100, 1000)
    ]
    stage = Mock(
        side_effect=[
            [{"case": {"clients": 4}, "max_client_cpu_cores": 0.3}],
            data,
            data,
            [],
            [],
            [],
        ]
    )
    monkeypatch.setattr(comparison, "stage", stage)
    args = argparse.Namespace(
        phase="native-fast", screen_seconds=4, seconds=12, repeats=3
    )
    context = {"output": tmp_path}
    comparison.experiment(args, context)
    assert stage.call_count == 6
    confirmation = stage.call_args_list[2].args[1]
    assert any(v.name == "typed312-h11" for v in confirmation)
    assert any(v.name == "ovms-default-fp32" for v in confirmation)
    assert context["driver"] == "native" and context["clients"] == 4
    assert not any(
        work.get("mix") for call in stage.call_args_list for work in call.args[2]
    )
