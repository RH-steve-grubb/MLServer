"""Resource-matched, one-instance MLServer/OVMS comparison (root orchestrator).

Root manages temporary systemd scopes, not a root Podman image store. Podman
runs as the image-owning user with cgroups disabled, inside the same enforced
scope as native MLServer. Effective cgroup limits are checked before timing.
"""

import argparse
import contextlib
import hashlib
import json
import math
import os
import pwd
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import tempfile
import time
import traceback
import uuid
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Iterator
from urllib.request import Request, urlopen

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("MLSERVER_COMPARE_REPO", "/home/codex/MLServer")).resolve()
STORE = Path("/home/codex/mlserver-durable-store/single-instance-ovms-20261013")
PY312 = Path(
    "/home/codex/mlserver-durable-store/venvs/" "mlserver-bnlygABv-py3.12/bin/python"
)
PY314 = Path(
    "/home/codex/mlserver-durable-store/frontend-transport-20261008/"
    "poetry-project/.venv/bin/python"
)
PY314_GIL = Path(
    "/home/codex/mlserver-durable-store/gil-on-worker-json-20261013/"
    "poetry-project/.venv/bin/python"
)
NATIVE_PHASES = {"native-fast", "worker-json"}
ADDONS = (
    "/home/codex/mlserver-durable-store/onnx-baseline-env/"
    ".venv/lib/python3.12/site-packages",
    "/home/codex/mlserver-durable-store/venvs/"
    "mlserver-http-parser-experiment-0BYAyjWO-py3.12/lib/python3.12/site-packages",
    "/home/codex/mlserver-durable-store/venvs/"
    "mlserver-zeromq-experiment-VcR4VGpb-py3.12/lib/python3.12/site-packages",
)
IMAGE = "454b832e81c2203c2cf7732c2b6d6618d6efbe956ccf1f23929a1988b83fc763"
MODEL_SHA = "8f80effa1bbf8d65898410ab1cf2f18722320a51b05ad81fbd97fc643ddc7e8d"
CLIENT_CONTROL_NAMES = {
    "ovms-default-fp32",
    "ovms-s28-t28",
    "worker312-aiohttp-zmq-w14",
}


@dataclass(frozen=True)
class Budget:
    server: str = "0-13,16-29"
    client: str = "14-15,30-31"
    memory: int = 8 * 1024**3


@dataclass(frozen=True)
class Variant:
    name: str
    family: str = "control"
    runtime: str = "312"
    workers: int = 6
    threads: int = 1
    http: str = "fastapi"
    parser: str = "httptools"
    transport: str = "queue"
    raw: bool = False
    json_threads: int | None = None
    fused: bool = False
    scheduler: str = "round-robin"
    ovms_streams: int | None = None
    ovms_threads: int | None = None
    ovms_hint: str | None = None
    gil: bool | None = None


def serving_python(runtime: str) -> Path:
    return {"312": PY312, "314": PY314, "314-gil": PY314_GIL}[runtime]


def serving_source(runtime: str) -> str:
    # Conventional 3.14 uses the EXACT unchanged 3.12 source. The FT pair
    # uses the existing isolated REST startup compatibility copy.
    return "312" if runtime == "314-gil" else runtime


def gil_enabled(variant: Variant) -> bool:
    return variant.runtime != "314" if variant.gil is None else variant.gil


def worker_json_variants() -> list[Variant]:
    reference = Variant(
        "worker312-fastapi-zmq-w12-t2",
        family="raw-fastapi",
        raw=True,
        transport="zmq",
        workers=12,
        threads=2,
    )
    upgrade = replace(reference, name="worker314-gil-rr", runtime="314-gil")
    balanced = replace(upgrade, name="worker314-gil-bal", scheduler="least-outstanding")
    # A conventional build and a free-threaded build differ beyond their GIL
    # state. Compare on/off on the SAME FT binary/environment to isolate that
    # mode, rather than labelling the conventional-vs-FT change a GIL effect.
    paired = replace(
        reference,
        name="worker314-ft-gil-on-rr",
        runtime="314",
        parser="h11",
        gil=True,
    )
    return [
        reference,
        upgrade,
        balanced,
        paired,
        replace(paired, name="worker314-ft-gil-off-rr", gil=False),
    ]


def variants() -> list[Variant]:
    result = [
        Variant("typed312-h11", parser="h11"),
        Variant("typed312-httptools"),
        Variant("inline312-separate", json_threads=0),
        Variant("inline312-fused", json_threads=0, fused=True),
        Variant("worker312-fastapi-queue-w6", family="raw-fastapi", raw=True),
    ]
    for workers, threads in ((6, 1), (12, 1), (14, 1), (12, 2)):
        result.append(
            Variant(
                f"worker312-fastapi-zmq-w{workers}-t{threads}",
                family="raw-fastapi",
                raw=True,
                transport="zmq",
                workers=workers,
                threads=threads,
            )
        )
    for workers in (6, 12, 14):
        result.append(
            Variant(
                f"worker312-aiohttp-zmq-w{workers}",
                family="raw-aiohttp",
                raw=True,
                transport="zmq",
                workers=workers,
                http="aiohttp",
                parser="auto",
            )
        )
    for fused in (False, True):
        for scheduler in ("round-robin", "least-outstanding"):
            suffix = "bal" if scheduler == "least-outstanding" else "rr"
            name = f"ft314-t8-{'fused' if fused else 'separate'}-{suffix}"
            result.append(
                Variant(
                    name,
                    family="ft",
                    runtime="314",
                    parser="h11",
                    json_threads=8,
                    fused=fused,
                    scheduler=scheduler,
                )
            )
    for threads in (1, 2):
        result.append(
            Variant(
                f"ft314-t4-fused-bal-ort{threads}",
                family="ft",
                runtime="314",
                parser="h11",
                json_threads=4,
                fused=True,
                scheduler="least-outstanding",
                threads=threads,
            )
        )
    native = Variant(
        "ovms-default-fp32",
        family="ovms",
        runtime="ovms",
        workers=0,
        threads=0,
        http="native",
        parser="native",
        transport="native",
        scheduler="native",
    )
    result += [
        native,
        replace(native, name="ovms-throughput-auto", ovms_hint="THROUGHPUT"),
    ]
    for streams, threads in ((6, 14), (14, 14), (28, 28)):
        result.append(
            replace(
                native,
                name=f"ovms-s{streams}-t{threads}",
                ovms_streams=streams,
                ovms_threads=threads,
            )
        )
    return result


def cpus(value: str) -> set[int]:
    result: set[int] = set()
    for item in value.split(","):
        parts = item.split("-")
        if len(parts) > 2:
            raise ValueError("Invalid CPU set")
        first, last = int(parts[0]), int(parts[-1])
        if first < 0 or last < first:
            raise ValueError("Invalid CPU range")
        result.update(range(first, last + 1))
    return result


def validate_budget(budget: Budget) -> None:
    server, client = cpus(budget.server), cpus(budget.client)
    if not server or not client or server & client:
        raise ValueError("Server/client CPU sets must be nonempty and disjoint")
    if not (server | client) <= set(os.sched_getaffinity(0)):
        raise ValueError("Requested CPUs are outside the orchestrator's affinity")

    # Sharing SMT siblings would still make the load generator compete for
    # the server's physical cores even when logical CPU IDs are disjoint.
    def cores(selected: set[int]) -> set[str]:
        return {
            Path(f"/sys/devices/system/cpu/cpu{c}/topology/thread_siblings_list")
            .read_text()
            .strip()
            for c in selected
        }

    if cores(server) & cores(client):
        raise ValueError("Server/client sets share physical cores")
    if budget.memory <= 0:
        raise ValueError("RAM budget must be positive")
    client_sets(budget)


def client_sets(budget: Budget, count: int = 2) -> list[list[int]]:
    if count not in (2, 4):
        raise ValueError("Expected two or four load clients")
    groups: dict[str, list[int]] = {}
    for cpu in sorted(cpus(budget.client)):
        name = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list")
        groups.setdefault(name.read_text().strip(), []).append(cpu)
    if len(groups) != 2:
        raise ValueError("The load clients require exactly two physical cores")
    if count == 4:
        if len(cpus(budget.client)) != 4:
            raise ValueError("Four clients require four reserved logical CPUs")
        return [[cpu] for cpu in sorted(cpus(budget.client))]
    return list(groups.values())


def client_count(requested: int, concurrency: int) -> int:
    # C2 still uses two active clients even when the high-load cases use four;
    # neither silently increase request concurrency nor start idle clients.
    count = min(requested, concurrency)
    if requested not in (2, 4) or count not in (2, 4) or concurrency % count:
        raise ValueError("Concurrency must divide evenly across two/four clients")
    return count


def write_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def read_json(port: int, path: str) -> Any:
    with urlopen(f"http://127.0.0.1:{port}{path}", timeout=5) as response:
        return json.load(response)


def free_port() -> int:
    with socket.socket() as connection:
        connection.bind(("127.0.0.1", 0))
        return int(connection.getsockname()[1])


def machine_state() -> dict[str, Any]:
    result: dict[str, Any] = {
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "load_average": os.getloadavg(),
        "uname": tuple(os.uname()),
        "coordinator_python": sys.version,
        "coordinator_affinity": sorted(os.sched_getaffinity(0)),
    }
    result["cpu_model"] = next(
        line.split(":", 1)[1].strip()
        for line in Path("/proc/cpuinfo").read_text().splitlines()
        if line.startswith("model name")
    )
    policies = {}
    for path in sorted(Path("/sys/devices/system/cpu/cpufreq").glob("policy*")):
        policies[path.name] = {
            name: (path / name).read_text().strip()
            for name in (
                "scaling_governor",
                "scaling_driver",
                "scaling_min_freq",
                "scaling_max_freq",
                "energy_performance_preference",
            )
            if (path / name).exists()
        }
    result["cpu_policies"] = policies
    boost = Path("/sys/devices/system/cpu/cpufreq/boost")
    result["boost"] = boost.read_text().strip() if boost.exists() else None
    result["memory"] = Path("/proc/meminfo").read_text()
    for name, command in (
        ("audit_daemon", ["systemctl", "is-active", "auditd"]),
        ("audit_kernel", ["auditctl", "-s"]),
    ):
        if shutil.which(command[0]):
            call = subprocess.run(command, capture_output=True, text=True)
            result[name] = {
                "returncode": call.returncode,
                "stdout": call.stdout.strip(),
                "stderr": call.stderr.strip(),
            }
    return result


def podman(user: str) -> list[str]:
    account = pwd.getpwnam(user)
    if account.pw_uid == 0:
        raise ValueError("Use the non-root owner of the existing image store")
    return [
        "runuser",
        "-u",
        user,
        "--",
        "env",
        f"XDG_RUNTIME_DIR=/run/user/{account.pw_uid}",
        "podman",
    ]


def scope_command(unit: str, budget: Budget, command: list[str]) -> list[str]:
    return [
        "systemd-run",
        "--scope",
        "--quiet",
        f"--unit={unit}",
        f"--property=AllowedCPUs={budget.server}",
        f"--property=MemoryMax={budget.memory}",
        "--property=MemorySwapMax=0",
        "taskset",
        "-c",
        budget.server,
        *command,
    ]


def cgroup_path(pid: int) -> Path:
    entries = Path(f"/proc/{pid}/cgroup").read_text().splitlines()
    matches = [line[3:] for line in entries if line.startswith("0::")]
    if len(matches) != 1:
        raise RuntimeError("The comparison requires cgroup v2")
    return Path("/sys/fs/cgroup") / matches[0].lstrip("/")


def cgroup_snapshot(path: Path, budget: Budget) -> dict[str, Any]:
    if int((path / "memory.max").read_text()) != budget.memory:
        raise RuntimeError("Effective cgroup RAM budget mismatch")
    if int((path / "memory.swap.max").read_text()) != 0:
        raise RuntimeError("Swap must be disabled for the server cgroup")
    effective = (path / "cpuset.cpus.effective").read_text().strip()
    if cpus(effective) != cpus(budget.server):
        raise RuntimeError("Effective cgroup CPU budget mismatch")
    cpu = {
        key: int(value)
        for key, value in (
            line.split() for line in (path / "cpu.stat").read_text().splitlines()
        )
    }
    return {
        "monotonic_ns": time.monotonic_ns(),
        "path": str(path),
        "effective_cpus": effective,
        "cpu": cpu,
        "memory_current": int((path / "memory.current").read_text()),
        "memory_peak": int((path / "memory.peak").read_text()),
        "memory_events": (path / "memory.events").read_text(),
    }


@dataclass(frozen=True)
class Setup:
    store: Path
    budget: Budget
    podman_user: str = "codex"
    frozen_harness: Path | None = None

    @property
    def model(self) -> Path:
        return self.store / "models/queue-mlp/1/model.onnx"

    @property
    def harness(self) -> Path:
        return self.frozen_harness or self.store / "harness"


def environment(variant: Variant, setup: Setup, ipc: str) -> dict[str, str]:
    env = {
        key: value
        for key, value in os.environ.items()
        if not key.startswith(("MLSERVER_", "PYTHON"))
    }
    source = setup.store / f"source-{serving_source(variant.runtime)}"
    paths = [str(source), str(source / "runtimes/onnx"), str(setup.harness)]
    if variant.runtime == "312":
        paths.extend(ADDONS)
    if gil_enabled(variant):
        env["PYTHON_GIL"] = "1"
    env.update(
        PYTHONPATH=os.pathsep.join(paths),
        PYTHONDONTWRITEBYTECODE="1",
        MLSERVER_COMPARE_RUNTIME=variant.runtime,
        MLSERVER_COMPARE_GIL="on" if gil_enabled(variant) else "off",
        MLSERVER_COMPARE_SOURCE=str(source),
        MLSERVER_QUEUE_PROBE="0",
        MLSERVER_QUEUE_CODEC="pickle",
        MLSERVER_QUEUE_TENSORS="list",
        MLSERVER_QUEUE_EXECUTION="inline",
        MLSERVER_QUEUE_PUMP="0",
        MLSERVER_QUEUE_BALANCE="0",
        MLSERVER_QUEUE_HTTP=variant.http,
        MLSERVER_QUEUE_HTTP_PARSER=variant.parser,
        MLSERVER_QUEUE_TRANSPORT=variant.transport,
        MLSERVER_QUEUE_ZMQ_DIR=ipc,
        MLSERVER_QUEUE_JSON="full" if variant.raw else "frontend",
        MLSERVER_QUEUE_JSON_MODE="fused-input" if variant.fused else "separate",
        MLSERVER_QUEUE_SCHEDULER=variant.scheduler,
        MLSERVER_DEFAULT_MAX_BATCH_SIZE="0",
        MLSERVER_DEFAULT_MAX_BATCH_TIME="0",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
    )
    if variant.json_threads is not None:
        env["MLSERVER_COMPARE_JSON_THREADS"] = str(variant.json_threads)
    return env


class Server:
    def __init__(self, setup: Setup, variant: Variant, directory: Path):
        self.setup, self.variant, self.directory = setup, variant, directory
        self.port = free_port()
        self.token = uuid.uuid4().hex
        self.unit = f"mlserver-compare-{self.token}"
        self.container = f"mlserver-compare-{self.token}"
        self.process: subprocess.Popen | None = None
        self.log: Any = None
        self.ipc: Any = None
        self.group: Path | None = None
        self.owned_http = False
        self.native_pid: int | None = None

    def command(self) -> list[str]:
        variant, setup = self.variant, self.setup
        if variant.runtime != "ovms":
            return [
                str(serving_python(variant.runtime)),
                str(setup.harness / "single_server.py"),
                "serve",
                str(setup.model),
                "--port",
                str(self.port),
                "--workers",
                str(variant.workers),
                "--threads",
                str(variant.threads),
                "--no-spin",
                "--unprobed",
            ]
        plugin: dict[str, str] = {"INFERENCE_PRECISION_HINT": "f32"}
        if variant.ovms_streams is not None:
            plugin["NUM_STREAMS"] = str(variant.ovms_streams)
        if variant.ovms_threads is not None:
            plugin["INFERENCE_NUM_THREADS"] = str(variant.ovms_threads)
        if variant.ovms_hint:
            plugin["PERFORMANCE_HINT"] = variant.ovms_hint
        # Keep Podman's existing rootless store and all OCI helper processes
        # in OUR resource-limited scope. Do not let Podman move the container
        # into an unrelated rootless libpod scope with different CPU/RAM limits.
        return [
            *podman(setup.podman_user),
            "run",
            "--rm",
            "--pull=never",
            "--cgroups=disabled",
            "--name",
            self.container,
            "--label",
            f"io.mlserver.compare.owner={self.token}",
            "--network=host",
            "--read-only",
            "--cap-drop=ALL",
            "--security-opt=no-new-privileges",
            "--security-opt=label=disable",
            "--tmpfs",
            "/tmp:rw,nosuid,nodev,size=128m,mode=1777",
            "--mount",
            f"type=bind,src={setup.store / 'models'},dst=/models,ro=true",
            IMAGE,
            "--model_name",
            "queue-mlp",
            "--model_path",
            "/models/queue-mlp",
            "--target_device",
            "CPU",
            "--rest_port",
            str(self.port),
            "--rest_bind_address",
            "127.0.0.1",
            "--port",
            "0",
            "--rest_workers",
            "32",
            "--nireq",
            "64",
            "--plugin_config",
            json.dumps(plugin),
            "--log_level",
            "WARNING",
            "--cache_dir",
            "/tmp/ovms-cache",
            "--file_system_poll_wait_seconds",
            "0",
        ]

    def inspected_container(self) -> dict[str, Any]:
        result = subprocess.run(
            [*podman(self.setup.podman_user), "inspect", self.container],
            cwd=self.directory,
            capture_output=True,
            text=True,
            check=True,
            timeout=20,
        )
        info = json.loads(result.stdout)[0]
        if info["Config"]["Labels"].get("io.mlserver.compare.owner") != self.token:
            raise RuntimeError("Refusing to operate on an unowned container")
        return info

    def start(self) -> dict[str, Any]:
        self.ipc = tempfile.TemporaryDirectory(prefix="mls-compare-ipc-", dir="/tmp")
        os.chmod(self.ipc.name, 0o755)
        self.log = (self.directory / "server.log").open("w")
        command = scope_command(self.unit, self.setup.budget, self.command())
        env = (
            environment(self.variant, self.setup, self.ipc.name)
            if self.variant.runtime != "ovms"
            else None
        )
        write_json(
            self.directory / "server-command.json",
            {"argv": command, "variant": asdict(self.variant), "image": IMAGE},
        )
        self.process = subprocess.Popen(
            command,
            env=env,
            cwd=self.directory,
            stdout=self.log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError("Server exited; inspect server.log")
            try:
                path = (
                    "/v2/models/queue-mlp"
                    if self.variant.runtime == "ovms"
                    else "/single-instance/state"
                )
                result = read_json(self.port, path)
            except (OSError, subprocess.CalledProcessError):
                time.sleep(0.05)
                continue
            if self.variant.runtime == "ovms":
                info = self.inspected_container()
                pid = int(info["State"]["Pid"])
            else:
                pid = result["pid"]
            group = cgroup_path(pid)
            if group.name != f"{self.unit}.scope":
                raise RuntimeError(f"Server escaped its resource scope: {group}")
            self.group, self.native_pid, self.owned_http = group, pid, True
            # Missing controllers/limits after HTTP readiness are a permanent
            # resource-check failure, not a retryable connection refusal.
            cgroup_snapshot(group, self.setup.budget)
            return result
        raise TimeoutError("Server readiness deadline expired")

    def checks(self) -> dict[str, Any]:
        if self.process is None or self.process.poll() is not None:
            raise RuntimeError("Server controller exited during a case")
        if self.native_pid is None or cgroup_path(self.native_pid) != self.group:
            raise RuntimeError("Native server left its verified cgroup")
        if self.variant.runtime == "ovms":
            info = self.inspected_container()
            if int(info["State"]["Pid"]) != self.native_pid:
                raise RuntimeError("Native OVMS process changed during the case")
            return {
                "metadata": read_json(self.port, "/v2/models/queue-mlp"),
                "pid": info["State"]["Pid"],
                "image": info["Image"],
                "container": self.container,
            }
        return {
            "state": read_json(self.port, "/single-instance/state"),
            "stats": read_json(self.port, "/queue-probe/stats"),
        }

    def close(self) -> None:
        try:
            self.stop_server()
        finally:
            # Cleanup must also run when startup failed before readiness or
            # when the launcher exited but spawned inference workers did not.
            try:
                self.clear_scope()
            finally:
                if self.log is not None:
                    self.log.close()
                if self.ipc is not None:
                    self.ipc.cleanup()

    def stop_server(self) -> None:
        if self.variant.runtime == "ovms":
            try:
                self.inspected_container()
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass
            else:
                subprocess.run(
                    [
                        *podman(self.setup.podman_user),
                        "stop",
                        "--time=10",
                        self.container,
                    ],
                    cwd=self.directory,
                    stdout=self.log,
                    stderr=self.log,
                    timeout=25,
                    check=False,
                )
        elif self.owned_http:
            try:
                request = Request(
                    f"http://127.0.0.1:{self.port}/queue-probe/stop",
                    data=b"",
                    method="POST",
                )
                with urlopen(request, timeout=5):
                    pass
            except OSError:
                pass
        if self.process is not None:
            try:
                self.process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                subprocess.run(
                    ["systemctl", "kill", "--signal=KILL", f"{self.unit}.scope"],
                    capture_output=True,
                    timeout=10,
                    check=False,
                )
                if self.process.poll() is None:
                    os.killpg(self.process.pid, signal.SIGKILL)
                self.process.wait(timeout=10)

    def clear_scope(self) -> None:
        call = subprocess.run(
            [
                "systemctl",
                "show",
                f"{self.unit}.scope",
                "--property=ControlGroup",
                "--value",
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        value = call.stdout.strip()
        group = self.group
        if value:
            resolved = Path("/sys/fs/cgroup") / value.lstrip("/")
            if resolved.name != f"{self.unit}.scope" or ".." in resolved.parts:
                raise RuntimeError("Refusing to clean an unexpected cgroup")
            group = resolved
        if group is not None and group.exists():
            remaining = (group / "cgroup.procs").read_text().strip()
            if remaining:
                subprocess.run(
                    ["systemctl", "kill", "--signal=KILL", f"{self.unit}.scope"],
                    capture_output=True,
                    timeout=10,
                    check=False,
                )
                deadline = time.monotonic() + 10
                while group.exists() and (group / "cgroup.procs").read_text().strip():
                    if time.monotonic() >= deadline:
                        raise RuntimeError("Owned scope still contains processes")
                    time.sleep(0.05)
        if self.variant.runtime == "ovms":
            try:
                self.inspected_container()
            except subprocess.CalledProcessError:
                pass
            else:
                # An interrupted --rm launcher can leave a stopped container.
                # The ownership label was checked before removing this one ID.
                subprocess.run(
                    [*podman(self.setup.podman_user), "rm", self.container],
                    cwd=self.directory,
                    capture_output=True,
                    timeout=20,
                    check=True,
                )


@contextlib.contextmanager
def serving(setup: Setup, variant: Variant, directory: Path) -> Iterator[Server]:
    server = Server(setup, variant, directory)
    try:
        server.start()
        yield server
    finally:
        server.close()


def percentiles(values: np.ndarray) -> dict[str, float]:
    if not len(values):
        return {}
    return {
        "mean": float(values.mean()),
        "p50": float(np.percentile(values, 50)),
        "p95": float(np.percentile(values, 95)),
        "p99": float(np.percentile(values, 99)),
        "max": float(values.max()),
    }


def validate_controls(variant: Variant, checks: dict[str, Any], setup: Setup) -> None:
    if variant.runtime == "ovms":
        if checks["image"].removeprefix("sha256:") != IMAGE:
            raise ValueError("Wrong OVMS image")
        return
    state = checks["state"]
    manifest = setup.harness.parent / "interpreters.json"
    if manifest.exists():
        libraries = json.loads(manifest.read_text())[variant.runtime]["libraries"]
        if any(
            state["libraries"].get(name) != version
            for name, version in libraries.items()
        ):
            raise ValueError("Serving dependency versions changed after preflight")
    if (
        state["gil_enabled"] != gil_enabled(variant)
        or state.get("json_codec")
        != ("stdlib" if variant.runtime == "314" else "orjson")
        or set(state["cpu_affinity"]) != cpus(setup.budget.server)
        or state["transport"] != variant.transport
        or state["worker_json"] != ("full" if variant.raw else "frontend")
        or state["scheduler"] != variant.scheduler
        or state["balanced_installed"] != (variant.scheduler == "least-outstanding")
        or state["source"]
        != str(setup.store / f"source-{serving_source(variant.runtime)}")
    ):
        raise ValueError("Serving runtime/control mismatch")
    expected_parser = (
        "aiohttp._http_parser.HttpRequestParser"
        if variant.http == "aiohttp"
        else f"uvicorn.protocols.http.{variant.parser}_impl."
        f"{'H11Protocol' if variant.parser == 'h11' else 'HttpToolsProtocol'}"
    )
    if state["http_engine"] != expected_parser:
        raise ValueError("Wrong actual HTTP parser")
    if variant.json_threads is not None:
        pool, stages = state["json_pool"], state["json_stages"]
        if (
            pool["workers"] != variant.json_threads
            or pool["inflight"]
            or pool["peak_inflight"] > variant.json_threads
            or len(stages) != 2
            or any(s["validation_fallbacks"] for s in stages)
            or any(
                s["mode"] != ("fused-input" if variant.fused else "separate")
                for s in stages
            )
            or (variant.json_threads > 0 and not pool["thread_gil_states"])
            or any(
                gil != gil_enabled(variant)
                for gil in pool["thread_gil_states"].values()
            )
        ):
            raise ValueError("JSON pool/stage control mismatch")


def validate_workers(server: Server) -> list[dict[str, Any]]:
    if server.variant.runtime == "ovms":
        return []
    checkpoints = [
        json.loads(line)
        for line in (server.directory / "server.log").read_text().splitlines()
        if line.startswith('{"phase":')
    ]
    loaded = [row for row in checkpoints if row["phase"] == "worker-loaded"]
    if len({row["pid"] for row in loaded}) != server.variant.workers:
        raise ValueError("Incomplete actual inference worker startup")
    for row in loaded:
        if (
            not row["gil_enabled"]
            or set(row["cpu_affinity"]) != cpus(server.setup.budget.server)
            or cgroup_path(row["pid"]) != server.group
            or row["model_settings"]["max_batch_size"]
            or row["model_settings"]["max_batch_time"]
            or row["source"]
            != str(
                server.setup.store / f"source-{serving_source(server.variant.runtime)}"
            )
            or row["onnx_session"]
            != {
                "providers": ["CPUExecutionProvider"],
                "threads": server.variant.threads,
                "spinning": "0",
            }
        ):
            raise ValueError("Worker GIL/resource/adaptive-batching control mismatch")
    return checkpoints


def clients(
    case: dict[str, Any], directory: Path, setup: Setup
) -> list[subprocess.Popen]:
    write_json(directory / "case.json", case)
    result = []
    env = environment(Variant("client"), setup, str(directory))
    env.pop("MLSERVER_COMPARE_RUNTIME", None)
    env.pop("MLSERVER_COMPARE_GIL", None)
    assignments = client_sets(setup.budget, case.get("clients", 2))
    script = (
        "native_client.py" if case.get("driver") == "native" else "single_client.py"
    )
    try:
        for index, selected in enumerate(assignments):
            # Discover SMT pairs instead of assuming a particular CPU numbering.
            command = [
                "taskset",
                "-c",
                ",".join(map(str, selected)),
                str(PY312),
                str(setup.harness / script),
                str(directory / "case.json"),
                "--client",
                str(index),
            ]
            with (directory / f"client-{index}.log").open("w") as log:
                process = subprocess.Popen(
                    command,
                    env=env,
                    cwd=directory,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
            result.append(process)
        return result
    except BaseException:
        stop_clients(result)
        raise


def stop_clients(processes: list[subprocess.Popen]) -> None:
    for process in processes:
        if process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
    for process in processes:
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=5)


def measured_load(server: Server, case: dict[str, Any]) -> dict[str, Any]:
    directory, setup = server.directory, server.setup
    case.update(model=str(setup.model), port=server.port)
    processes: list[subprocess.Popen] = []
    try:
        processes = clients(case, directory, setup)
        if len(processes) != case.get("clients", 2):
            raise ValueError("Unexpected active load-client count")
        deadline = time.monotonic() + 240
        ready_paths = [
            directory / f"client-{i}-ready.json" for i in range(len(processes))
        ]
        while not all(path.exists() for path in ready_paths):
            if any(p.poll() is not None for p in processes):
                raise RuntimeError(
                    "Client correctness warm-up failed; inspect client logs"
                )
            if time.monotonic() > deadline:
                raise TimeoutError("Numerical warm-up deadline expired")
            time.sleep(0.01)
        before = server.checks()
        validate_controls(server.variant, before, setup)
        worker_checks = validate_workers(server)
        start_ns = time.monotonic_ns() + 250_000_000
        write_json(directory / "go.json", {"start_ns": start_ns})
        time.sleep(max(0, (start_ns - time.monotonic_ns() - 20_000_000) / 1e9))
        assert server.group is not None
        cpu_before = cgroup_snapshot(server.group, setup.budget)
        if cpu_before["monotonic_ns"] >= start_ns:
            raise RuntimeError("CPU baseline missed the synchronized load start")
        for process in processes:
            code = process.wait(timeout=case["seconds"] + 180)
            if code:
                raise RuntimeError("Load client failed; inspect its log")
        cpu_after = cgroup_snapshot(server.group, setup.budget)
        after = server.checks()
        validate_controls(server.variant, after, setup)
    finally:
        stop_clients(processes)
    rows = [
        json.loads((directory / f"client-{i}-result.json").read_text())
        for i in range(len(processes))
    ]
    if any(row["errors"] or not row["total_drained"] for row in rows):
        raise RuntimeError("Timed request errors or empty load")
    if any(row["actual_start_ns"] - start_ns > 10_000_000 for row in rows):
        raise RuntimeError("Load clients missed the start barrier by more than 10ms")
    native = case.get("driver") == "native"
    expected_loop = "h2load-http1-native" if native else "uvloop"
    for index, (row, assignment) in enumerate(
        zip(rows, client_sets(setup.budget, len(rows)))
    ):
        if (
            row["actual_start_ns"] < start_ns
            or row["client_index"] != index
            or row["client_count"] != len(rows)
            or row["concurrency"] != case["concurrency"] // len(rows)
            or row["event_loop"] != expected_loop
            or set(row["cpu_affinity"]) != set(assignment)
            or not row["completed_in_window"]
        ):
            raise ValueError("Client start/affinity/event-loop/window control mismatch")
    if before != after and server.variant.runtime != "ovms":
        if before["state"]["libraries"] != after["state"]["libraries"]:
            raise ValueError("Serving libraries changed during the case")
    for snapshot in (cpu_before, cpu_after):
        events = dict(line.split() for line in snapshot["memory_events"].splitlines())
        if any(int(events.get(key, 0)) for key in ("max", "oom", "oom_kill")):
            raise RuntimeError("Server reached its memory limit; reject this case")
    if any(row["payloads"] != rows[0]["payloads"] for row in rows):
        raise ValueError("The clients sent different input bytes")
    arrays = []
    classes = []
    lags = []
    for index in range(len(rows)):
        with np.load(directory / f"client-{index}-latencies.npz") as samples:
            arrays.append(samples["latency_ms"])
            classes.append(samples["rows"])
            lags.append(samples["loop_lag_ms"])
    latency, labels = np.concatenate(arrays), np.concatenate(classes)
    count = sum(row["total_drained"] for row in rows)
    if len(latency) != count:
        raise ValueError("Missing raw latency samples")
    if native and (
        len({row["native_requests"] for row in rows}) != 1
        or any(row["total_drained"] != row["native_requests"] for row in rows)
    ):
        raise ValueError("Native fixed-count requests did not fully drain")
    if server.variant.json_threads is not None:
        delta = (
            after["state"]["json_pool"]["completed"]
            - before["state"]["json_pool"]["completed"]
        )
        if delta != 2 * count:
            raise ValueError("Missing/extra frontend JSON jobs")
    if server.variant.raw:
        for key in ("raw_requests", "raw_worker_replies", "raw_byte_replies"):
            if after["stats"][key] - before["stats"][key] != count:
                raise ValueError("Missing/extra worker JSON requests/replies")
    if server.variant.transport == "zmq" and server.variant.runtime != "ovms":
        for key in ("transport_sent", "transport_received"):
            if after["stats"][key] - before["stats"][key] != count:
                raise ValueError("Missing/extra ZeroMQ requests/replies")
    cpu_seconds = (
        cpu_after["cpu"]["usage_usec"] - cpu_before["cpu"]["usage_usec"]
    ) / 1e6
    duration = (cpu_after["monotonic_ns"] - cpu_before["monotonic_ns"]) / 1e9
    load_seconds = (max(row["drained_ns"] for row in rows) - start_ns) / 1e9
    rate_seconds = load_seconds if native else case["seconds"]
    result = {
        "case": case,
        "variant": asdict(server.variant),
        "clients": rows,
        "checks": {"before": before, "after": after, "workers": worker_checks},
        "cpu": {"before": cpu_before, "after": cpu_after},
        "rps": sum(row["completed_in_window"] for row in rows) / rate_seconds,
        "load_seconds": load_seconds,
        "measurement": "fixed-count-complete-drain" if native else "fixed-time-window",
        "total_drained": count,
        "client_ms": percentiles(latency),
        "classes_ms": {int(n): percentiles(latency[labels == n]) for n in set(labels)},
        "client_loop_lag_ms": percentiles(np.concatenate(lags)),
        "server_cpu_cores": cpu_seconds / duration,
        "server_cpu_ms_per_request": cpu_seconds * 1000 / count,
        "client_cpu_cores": sum(row["client_cpu_seconds"] for row in rows)
        / ((max(row["drained_ns"] for row in rows) - start_ns) / 1e9),
        "max_client_cpu_cores": max(
            row["client_cpu_seconds"]
            / ((row["drained_ns"] - row["actual_start_ns"]) / 1e9)
            for row in rows
        ),
        "memory_peak_bytes": cpu_after["memory_peak"],
    }
    write_json(directory / "result.json", result)
    return result


def source_hashes(source: Path) -> dict[str, str]:
    return {
        str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest()
        for package in (source / "mlserver", source / "runtimes/onnx/mlserver_onnx")
        for path in package.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts
    }


def prepare(store: Path, budget: Budget, user: str) -> tuple[Setup, Path]:
    store.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    output = store / f"run-{stamp}-{os.getpid()}"
    output.mkdir(exist_ok=False)
    harness = output / "harness"
    shutil.copytree(
        HERE,
        harness,
        ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", ".venv"),
    )
    for runtime, source in (
        ("312", ROOT),
        ("314", Path("/home/codex/mlserver-durable-store/fused-json-20261008/source")),
    ):
        destination = store / f"source-{runtime}"
        for name in ("mlserver", "runtimes/onnx/mlserver_onnx"):
            package = source / name
            if runtime == "314" and name != "mlserver":
                package = source / "mlserver_onnx"
            if not (destination / name).exists():
                shutil.copytree(
                    package,
                    destination / name,
                    ignore=shutil.ignore_patterns("__pycache__"),
                )
        for name in (
            "pyproject.toml",
            "poetry.lock",
            "runtimes/onnx/pyproject.toml",
            "runtimes/onnx/poetry.lock",
        ):
            if not (destination / name).exists():
                shutil.copy2(ROOT / name, destination / name)
    setup = Setup(store, budget, user, harness)
    setup.model.parent.mkdir(parents=True, exist_ok=True)
    if not setup.model.exists():
        shutil.copy2(
            Path("/home/codex/mlserver-durable-store/fused-json-20261008")
            / "mlserver-queue-mlp.onnx",
            setup.model,
        )
    if hashlib.sha256(setup.model.read_bytes()).hexdigest() != MODEL_SHA:
        raise ValueError("Unexpected ONNX model artifact")
    old, new = source_hashes(store / "source-312"), source_hashes(store / "source-314")
    if old != source_hashes(ROOT):
        raise ValueError("Frozen Python 3.12 source differs from this checkout")
    changed = {
        name for name in old.keys() | new.keys() if old.get(name) != new.get(name)
    }
    if changed != {
        "mlserver/__init__.py",
        "mlserver/tracing.py",
        "mlserver/rest/openapi/schema.py",
    }:
        raise ValueError("Unexpected source differences between Python controls")
    write_json(output / "source-hashes.json", {"312": old, "314": new})
    for name, project in (
        ("baseline-onnx", Path(ADDONS[0]).parents[3]),
        ("free-threaded", PY314.parent.parent.parent),
        ("conventional-314", PY314_GIL.parent.parent.parent),
    ):
        if not project.exists():
            continue
        destination = output / "dependency-records" / name
        destination.mkdir(parents=True)
        for file in ("pyproject.toml", "poetry.lock"):
            shutil.copy2(project / file, destination / file)
    return setup, output


def image_checks(setup: Setup, output: Path) -> dict[str, Any]:
    # runuser retains its caller's cwd. A root shell may be in /root, which
    # the rootless image-store owner cannot traverse. Use our readable run
    # directory for every Podman helper, not just the serving launcher.
    call = subprocess.run(
        [*podman(setup.podman_user), "image", "inspect", IMAGE],
        cwd=output,
        capture_output=True,
        text=True,
        check=True,
        timeout=30,
    )
    data = json.loads(call.stdout)[0]
    if data["Id"].removeprefix("sha256:") != IMAGE:
        raise ValueError("Wrong immutable OVMS image")
    # Do not persist unrelated container environment variables or credentials.
    result = {
        key: data.get(key)
        for key in ("Id", "RepoTags", "Architecture", "Os", "Size", "Created", "Labels")
    }
    write_json(output / "ovms-image.json", result)
    call = subprocess.run(
        [
            *podman(setup.podman_user),
            "run",
            "--rm",
            "--pull=never",
            "--cgroups=disabled",
            "--network=none",
            "--read-only",
            "--cap-drop=ALL",
            "--security-opt=no-new-privileges",
            IMAGE,
            "--version",
        ],
        cwd=output,
        capture_output=True,
        text=True,
        check=True,
        timeout=30,
    )
    (output / "ovms-version.txt").write_text(call.stdout + call.stderr)
    if "OpenVINO Model Server 2026.4.0" not in call.stdout:
        raise ValueError("Unexpected actual OVMS binary version")
    return result


def ranking(rows: list[dict[str, Any]], options: list[Variant]) -> list[Variant]:
    def score(variant: Variant) -> float:
        means = []
        for size in (1, 100, 1000):
            rates = [
                r["rps"]
                for r in rows
                if r["variant"]["name"] == variant.name
                and r["case"]["rows"] == size
                and r["case"]["concurrency"] == 64
                and not r["case"].get("mix")
            ]
            if not rates or any(not math.isfinite(rate) or rate <= 0 for rate in rates):
                raise ValueError("Incomplete/invalid ranking controls")
            means.append(statistics.mean(rates))
        return math.exp(statistics.mean(math.log(rate) for rate in means))

    return sorted(options, key=score, reverse=True)


def confirmation(screen: list[dict[str, Any]], options: list[Variant]) -> list[Variant]:
    required = {
        "typed312-h11",
        "typed312-httptools",
        "inline312-separate",
        "inline312-fused",
        "ft314-t8-separate-rr",
        "ft314-t8-separate-bal",
        "ft314-t8-fused-rr",
        "ft314-t8-fused-bal",
        "ft314-t4-fused-bal-ort1",
        "ovms-default-fp32",
    }
    for family in ("raw-fastapi", "raw-aiohttp", "ft", "ovms"):
        candidates = [v for v in options if v.family == family]
        required.add(ranking(screen, candidates)[0].name)
        # A large-tensor winner need not win the geometric mean. Preserve
        # per-size winners so tuning does not favor only the small REST case.
        required.update(
            size_winner(screen, candidates, size).name for size in (1, 100, 1000)
        )
    return [v for v in options if v.name in required]


def size_winner(
    rows: list[dict[str, Any]], options: list[Variant], size: int
) -> Variant:
    def rate(option: Variant) -> float:
        values = [
            r["rps"]
            for r in rows
            if r["variant"]["name"] == option.name
            and r["case"]["rows"] == size
            and r["case"]["concurrency"] == 64
            and not r["case"].get("mix")
        ]
        if not values or any(not math.isfinite(v) or v <= 0 for v in values):
            raise ValueError("Incomplete/invalid per-size selection")
        return statistics.mean(values)

    return max(options, key=rate)


def summary(rows: list[dict[str, Any]]) -> str:
    lines = [
        "Single-instance REST/JSON comparison",
        "===================================",
        "One frontend; no horizontal replicas or adaptive batching.",
        "Same ONNX bytes/payloads; fixed Python-3.12/uvloop load clients.",
        "Client budget stays two physical/four logical CPUs by default.",
        "14 physical/28 logical server CPUs, 8 GiB RAM by default; cgroup verified.",
        "CPU cost includes the whole server cgroup, load plus drain and snapshots.",
        "Latency pools clients WITHIN a run; means below average per-run statistics.",
        "Native h2load uses calibrated fixed counts, complete drain, elapsed-time RPS.",
        "Screening selects configurations; fresh confirmation/sweep are comparisons.",
        "Experimental adapters are not production API replacements or an upgrade.",
        "",
        "C=request concurrency; P=client processes; client-max=CPU cores/process.",
        "phase rows C P mix variant trials RPS SD p95-ms p99-ms "
        "CPU-ms/request peak-MiB client-max",
    ]
    keys = sorted(
        {
            (
                r["case"]["phase"],
                r["case"]["rows"],
                r["case"]["concurrency"],
                r["case"].get("clients", 2),
                bool(r["case"].get("mix")),
                r["variant"]["name"],
            )
            for r in rows
        }
    )
    for phase, size, concurrency, processes, mixed, name in keys:
        group = [
            r
            for r in rows
            if (
                r["case"]["phase"],
                r["case"]["rows"],
                r["case"]["concurrency"],
                r["case"].get("clients", 2),
                bool(r["case"].get("mix")),
                r["variant"]["name"],
            )
            == (phase, size, concurrency, processes, mixed, name)
        ]
        rates = [r["rps"] for r in group]
        deviation = statistics.stdev(rates) if len(rates) > 1 else 0
        p95, p99 = (
            statistics.mean(r["client_ms"][key] for r in group)
            for key in ("p95", "p99")
        )
        cpu = statistics.mean(r["server_cpu_ms_per_request"] for r in group)
        memory = max(r["memory_peak_bytes"] for r in group) / 1024**2
        client_cpu = max(r.get("max_client_cpu_cores", 0) for r in group)
        lines.append(
            f"{phase:7} {size:4} {concurrency:3} {processes} {int(mixed)} {name:38} "
            f"{len(group):2} {statistics.mean(rates):8.1f} {deviation:7.1f} "
            f"{p95:8.1f} {p99:8.1f} {cpu:8.2f} {memory:8.1f} {client_cpu:5.2f}"
        )
    saturated = [
        r
        for r in rows
        if r.get("max_client_cpu_cores", r["client_cpu_cores"] / 2) >= 0.9
    ]
    if saturated:
        lines += [
            "",
            f"CAUTION: {len(saturated)} windows had a client near one CPU core.",
            "Those rates do not establish server maximum; inspect client CPU/lag.",
        ]
    if any(r["case"]["phase"] == "worker-json" for r in rows):
        lines += [
            "",
            "WORKER-JSON: fixed FastAPI, 12 workers, 2 ORT threads, ZeroMQ/pickle.",
            "312 -> conventional 314 includes changed dependencies, not just Python.",
            "314-gil RR -> balanced changes only scheduler; both keep the GIL.",
            "FT on/off pair uses identical FT build/dependencies/h11/stdlib JSON.",
            "Only the FT frontend changes GIL state; all inference workers keep it.",
            "Do not attribute conventional-vs-FT differences to GIL removal.",
        ]
    if rows:
        lines += [
            "",
            "Four clients still share two physical cores; a plateau or no CPU warning",
            "does not prove the load generator can measure server maximum capacity.",
        ]
    return "\n".join(lines) + "\n"


def run_case(
    context: dict[str, Any], variant: Variant, case: dict[str, Any]
) -> dict[str, Any]:
    setup, output = context["setup"], context["output"]
    if context.get("deadline") and time.monotonic() >= context["deadline"]:
        raise TimeoutError("Comparison time budget expired before the next case")
    requested = case.get("clients", context.get("clients", 2))
    case.update(
        requested_clients=requested,
        clients=client_count(requested, case["concurrency"]),
    )
    if context.get("driver") == "native":
        case.update(
            driver="native", native_binary=context["native_binary"], native_timeout=90
        )
    label = (
        f"{case['phase']}-r{case['trial']}-b{case['rows']}-"
        f"c{case['concurrency']}-p{case['clients']}-{variant.name}"
    )
    if case.get("mix"):
        label += "-mixed"
    directory = output / label
    directory.mkdir(exist_ok=False)
    print(f"Starting {label}", flush=True)
    with serving(setup, variant, directory) as server:
        result = measured_load(server, case)
    result["cleanup_passed"] = True
    write_json(directory / "result.json", result)
    context["all_rows"].append(result)
    write_json(output / "results.json", context["all_rows"])
    (output / "SUMMARY.txt").write_text(summary(context["all_rows"]))
    print(
        f"  {result['rps']:.1f} RPS; "
        f"p95 {result['client_ms']['p95']:.1f} ms; "
        f"CPU {result['server_cpu_ms_per_request']:.2f} ms/request",
        flush=True,
    )
    return result


def stage(
    context: dict[str, Any], selected: list[Variant], workloads: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    fresh = []
    repeats = context["repeats"]
    for trial in range(repeats):
        order = selected if trial % 2 == 0 else list(reversed(selected))
        work = workloads if trial % 2 == 0 else list(reversed(workloads))
        # Fresh frontend/pool per case, and no benchmark/test/profiler overlaps.
        for workload in work:
            for variant in order:
                case = dict(workload, trial=trial, seconds=context["seconds"])
                fresh.append(run_case(context, variant, case))
    return fresh


def client_control(args: argparse.Namespace, context: dict[str, Any]) -> None:
    selected = [option for option in variants() if option.name in CLIENT_CONTROL_NAMES]
    for trial in range(args.repeats):
        order = selected if trial % 2 == 0 else list(reversed(selected))
        counts = (2, 4) if trial % 2 == 0 else (4, 2)
        for variant in order:
            # Adjacent pairs reduce drift; all server settings, total request
            # concurrency, warm-up counts, and reserved CPU IDs stay unchanged.
            for count in counts:
                run_case(
                    context,
                    variant,
                    {
                        "phase": "clients",
                        "rows": 1,
                        "concurrency": 64,
                        "clients": count,
                        "trial": trial,
                        "seconds": args.seconds,
                    },
                )


def workloads(phase: str, concurrency: tuple[int, ...] = (64,)) -> list[dict[str, Any]]:
    return [
        {"phase": phase, "rows": size, "concurrency": count}
        for count in concurrency
        for size in (1, 100, 1000)
    ]


def smoke_variants(options: list[Variant]) -> list[Variant]:
    names = {
        "typed312-h11",
        "typed312-httptools",
        "inline312-fused",
        "worker312-fastapi-queue-w6",
        "worker312-fastapi-zmq-w14-t1",
        "worker312-aiohttp-zmq-w14",
        "ft314-t8-separate-rr",
        "ft314-t8-fused-bal",
        "ovms-default-fp32",
        "ovms-s28-t28",
    }
    return [option for option in options if option.name in names]


def interpreter_checks(
    setup: Setup, output: Path, selected: list[Variant] | None = None
) -> dict[str, Any]:
    checks = {}
    options = selected or [Variant("312"), Variant("314", runtime="314")]
    for variant in options:
        runtime, binary = variant.runtime, serving_python(variant.runtime)
        if not binary.is_file():
            raise FileNotFoundError(f"Missing benchmark interpreter: {binary}")
        packages = [
            "onnxruntime",
            "onnx",
            "numpy",
            "pydantic",
            "pydantic-core",
            "fastapi",
            "starlette",
            "uvicorn",
            "uvloop",
            "aiohttp",
            "h11",
        ]
        if runtime != "314":
            packages.append("orjson")
        if variant.parser == "httptools":
            packages.append("httptools")
        if variant.transport == "zmq":
            packages.append("pyzmq")
        script = (
            "import sys,sysconfig,json,importlib.metadata as m; "
            "import bench; "
            "print(json.dumps(dict(python=sys.version,executable=sys.executable,"
            "gil=getattr(sys,'_is_gil_enabled',lambda:True)(),"
            "free_threaded=sysconfig.get_config_var('Py_GIL_DISABLED'),"
            f"libraries={{p:m.version(p) for p in {packages!r}}})))"
        )
        env = environment(variant, setup, str(output))
        call = subprocess.run(
            [str(binary), "-c", script],
            env=env,
            cwd=output,
            capture_output=True,
            text=True,
            check=True,
            timeout=60,
        )
        row = json.loads(call.stdout.splitlines()[-1])
        if row["gil"] != gil_enabled(variant):
            raise ValueError("Interpreter preflight GIL mismatch")
        if runtime == "314-gil" and row["free_threaded"]:
            raise ValueError("Expected conventional, not free-threaded, Python 3.14")
        checks[runtime] = row
    # Dependency sets differ across Python versions: never attribute an
    # end-to-end 3.12-vs-3.14 change to the interpreter alone. Only the on/off
    # FT pair has identical dependencies, source, parser and executable.
    write_json(output / "interpreters.json", checks)
    return checks


def experiment(args: argparse.Namespace, context: dict[str, Any]) -> None:
    if args.phase == "worker-json":
        worker_json_experiment(args, context)
        return
    if args.phase == "native-fast":
        native_experiment(args, context)
        return
    if args.phase == "clients":
        client_control(args, context)
        return
    options, output = variants(), context["output"]
    smoke = smoke_variants(options)
    context.update(repeats=1, seconds=2.0)
    stage(context, smoke, workloads("smoke"))
    if args.phase == "smoke":
        return
    context.update(seconds=args.screen_seconds)
    screen = stage(context, options, workloads("screen"))
    selected = confirmation(screen, options)
    write_json(
        output / "selection.json",
        {
            "selection_rule": "Highest geometric mean RPS over rows 1/100/1000 at C64",
            "confirmation": [asdict(v) for v in selected],
            "warning": "Shortlist only; winners may differ by size or latency target",
        },
    )
    context.update(repeats=args.repeats, seconds=args.seconds)
    confirmed = stage(context, selected, workloads("confirm"))
    matrix = [v for v in options if v.name.startswith("ft314-t8-")]
    stage(
        context,
        matrix,
        [{"phase": "mixed", "rows": 0, "concurrency": 64, "mix": [1, 1000]}],
    )
    winners = {
        size: [
            size_winner(confirmed, [v for v in selected if v.runtime != "ovms"], size),
            size_winner(confirmed, [v for v in selected if v.family == "ovms"], size),
        ]
        for size in (1, 100, 1000)
    }
    write_json(
        output / "sweep-selection.json",
        {
            "selected_by_rows": {
                size: [asdict(v) for v in choices] for size, choices in winners.items()
            },
            "basis": "Fresh repeated confirmation; per-size RPS, not universal best",
        },
    )
    for size, choices in winners.items():
        stage(
            context,
            choices,
            [w for w in workloads("sweep", (2, 128, 512)) if w["rows"] == size],
        )


def worker_json_experiment(args: argparse.Namespace, context: dict[str, Any]) -> None:
    options = worker_json_variants()
    context.update(driver="native", clients=4, repeats=1, seconds=2.0)
    # Every combination must start, preserve numerical output, drain its
    # counters and pass actual GIL/source/cgroup guards before confirmation.
    stage(context, options, workloads("smoke"))
    context.update(repeats=args.repeats, seconds=args.seconds)
    results = stage(context, options, workloads("worker-json", (64, 512)))
    if any(r["max_client_cpu_cores"] >= 0.85 for r in results):
        raise RuntimeError("Native load clients lack CPU headroom")


def native_experiment(args: argparse.Namespace, context: dict[str, Any]) -> None:
    options, output = variants(), context["output"]
    context.update(driver="native", clients=4, repeats=1, seconds=5.0)
    probe = [
        v for v in options if v.name in {"ovms-s28-t28", "worker312-aiohttp-zmq-w14"}
    ]
    checked = stage(
        context,
        probe,
        [
            {"phase": "native", "rows": 1, "concurrency": 64, "clients": n}
            for n in (2, 4)
        ],
    )
    native_four = [r for r in checked if r["case"]["clients"] == 4]
    # Do not spend the user's remaining window on another client-capped matrix.
    if any(r["max_client_cpu_cores"] >= 0.85 for r in native_four):
        raise RuntimeError(
            "Native four-client probe lacks CPU headroom; inspect results"
        )
    context.update(seconds=args.screen_seconds)
    screen = stage(context, options, workloads("screen"))
    selected = confirmation(screen, options)
    write_json(
        output / "selection.json",
        {
            "confirmation": [asdict(v) for v in selected],
            "basis": "Native C64 screening, geometric mean and per-size winners",
            "omitted": "Mixed-size scheduler trial: native client has one POST body",
        },
    )
    context.update(repeats=args.repeats, seconds=args.seconds)
    confirmed = stage(context, selected, workloads("confirm"))
    winners = {
        size: [
            size_winner(confirmed, [v for v in selected if v.runtime != "ovms"], size),
            size_winner(confirmed, [v for v in selected if v.family == "ovms"], size),
        ]
        for size in (1, 100, 1000)
    }
    write_json(
        output / "sweep-selection.json",
        {
            "selected_by_rows": {
                size: [asdict(v) for v in group] for size, group in winners.items()
            },
            "basis": "Fresh repeated native confirmation, per-size throughput winners",
        },
    )
    for size, choices in winners.items():
        stage(
            context,
            choices,
            [w for w in workloads("sweep", (2, 128, 512)) if w["rows"] == size],
        )


def file_hashes(directory: Path) -> dict[str, str]:
    return {
        str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in directory.rglob("*")
        if p.is_file() and not {"__pycache__", ".pytest_cache"} & set(p.parts)
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--phase",
        choices=("smoke", "clients", "all", "native-fast", "worker-json"),
        default="all",
    )
    parser.add_argument("--clients", type=int, choices=(2, 4), default=2)
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument("--store", type=Path, default=STORE)
    parser.add_argument("--podman-user", default="codex")
    parser.add_argument("--server-cpus", default=Budget().server)
    parser.add_argument("--client-cpus", default=Budget().client)
    parser.add_argument("--memory-gib", type=int, default=8)
    parser.add_argument("--seconds", type=float, default=20)
    parser.add_argument("--screen-seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--max-minutes", type=int, default=120)
    args = parser.parse_args()
    if args.phase in NATIVE_PHASES:
        args.clients = 4
    if (
        not math.isfinite(args.seconds)
        or args.seconds < 2
        or not math.isfinite(args.screen_seconds)
        or args.screen_seconds < 2
        or args.repeats < 1
        or args.max_minutes < 1
    ):
        parser.error(
            "Durations must be finite and at least 2s; repeats must be positive"
        )
    return args


def failure_details(error: BaseException) -> dict[str, Any]:
    result: dict[str, Any] = {"error": repr(error), "traceback": traceback.format_exc()}
    if isinstance(error, (subprocess.CalledProcessError, subprocess.TimeoutExpired)):
        result["command"] = error.cmd
        # CalledProcessError's repr omits the captured output. Retain both
        # streams so root-only startup failures are diagnosable afterwards.
        for name in ("stdout", "stderr"):
            stream = getattr(error, name, None)
            result[name] = (
                stream.decode("utf-8", errors="replace")
                if isinstance(stream, bytes)
                else stream
            )
    return result


def main() -> None:
    args = parse_args()
    budget = Budget(args.server_cpus, args.client_cpus, args.memory_gib * 1024**3)
    validate_budget(budget)
    client_sets(budget, 4 if args.phase == "clients" else args.clients)
    if args.phase in NATIVE_PHASES:
        client_sets(budget, 4)
    options = variants()
    if args.phase == "clients":
        options = [v for v in options if v.name in CLIENT_CONTROL_NAMES]
    elif args.phase == "worker-json":
        options = worker_json_variants()
    plan = {
        "scope": "CPU-only REST/V2 JSON; ONE instance, adaptive batching disabled",
        "budget": asdict(budget),
        "image_owner": args.podman_user,
        "image": IMAGE,
        "coordinator_and_clients": str(PY312),
        "phase": args.phase,
        "stages": {
            "clients": ["clients"],
            "smoke": ["smoke"],
            "all": ["smoke", "screen", "confirm", "mixed", "sweep"],
            "native-fast": ["native", "screen", "confirm", "sweep"],
            "worker-json": ["smoke", "worker-json"],
        }[args.phase],
        "requested_client_processes": (
            [2, 4] if args.phase == "clients" else args.clients
        ),
        "client_control": {
            "processes": [2, 4],
            "rows": 1,
            "concurrency": 64,
            "seconds": args.seconds,
            "repeats": args.repeats,
            "server_budget_unchanged": True,
        },
        "client_assignment": "Two SMT pairs or four single CPUs in the same budget",
        "low_concurrency_clients": "C2 uses two active clients even with --clients 4",
        "native_fast": {
            "client_processes": 4,
            "driver": "h2load HTTP/1.1, one native thread per process",
            "measurement": "Calibrated fixed count, complete drain, elapsed-time RPS",
            "max_minutes": args.max_minutes,
            "omitted": "Mixed-size trial; historical mixed results remain separate",
        },
        "variants": [asdict(v) for v in options],
        "worker_json_comparison": {
            "concurrency": [64, 512],
            "rows": [1, 100, 1000],
            "workers": 12,
            "onnx_threads": 2,
            "frontend": "FastAPI throughout",
            "primary": "Conventional 3.12 RR vs conventional 3.14 RR "
            "vs 3.14 balanced",
            "gil_pair": "SAME FT 3.14 build/libraries/source/h11/stdlib JSON, "
            "GIL on/off",
            "caveat": "Primary 3.12/3.14 uses orjson/httptools; "
            "FT pair uses stdlib/h11. "
            "Dependency differences prevent a pure interpreter-only attribution.",
        },
        "screen": {"seconds": args.screen_seconds, "repeats": 1, "concurrency": 64},
        "confirmation": {
            "seconds": args.seconds,
            "repeats": args.repeats,
            "concurrency": 64,
        },
        "sweep_concurrency": [2, 128, 512],
        "mixed_rows": [1, 1000],
        "timed_response_validation": "HTTP 200/full body; numerical concurrent warm-up",
        "not_paper_reproduction": "Synthetic weights/different hardware; not 4-6x test",
    }
    if args.phase == "worker-json":
        for irrelevant in (
            "image_owner",
            "image",
            "client_control",
            "screen",
            "confirmation",
            "sweep_concurrency",
            "mixed_rows",
        ):
            plan.pop(irrelevant)
        plan["comparison"] = {
            "seconds_target": args.seconds,
            "repeats": args.repeats,
            "measured_cases": 30 * args.repeats,
            "smoke_cases": 15,
            "gil_switch": "FT frontend only; ONNX workers always GIL-enabled",
            "ovms": "Not rerun; compare fixed 312 reference with prior OVMS study",
        }
    if args.plan_only:
        print(json.dumps(plan, indent=2))
        return
    if os.geteuid() != 0:
        raise SystemExit(f"Run as root with the fixed interpreter: {PY312}")
    if sys.version_info[:2] != (3, 12):
        raise SystemExit(
            "Use the recorded Python 3.12 interpreter, not root's host Python"
        )
    os.umask(0o022)
    setup, output = prepare(args.store, budget, args.podman_user)
    print(f"Output: {output}", flush=True)
    context: dict[str, Any] = {
        "setup": setup,
        "output": output,
        "all_rows": [],
        "clients": args.clients,
    }
    initial = machine_state()
    hashes = file_hashes(setup.harness)
    write_json(output / "plan.json", plan)
    write_json(output / "harness-hashes.json", hashes)
    write_json(output / "machine-before.json", initial)
    (output / "SUMMARY.txt").write_text(
        "IN PROGRESS: startup/resource checks; no complete comparison yet.\n"
    )
    try:
        executables = ["systemd-run", "systemctl", "taskset"]
        if args.phase != "worker-json":
            executables += ["runuser", "podman"]
        for executable in executables:
            if shutil.which(executable) is None:
                raise FileNotFoundError(f"Required tool: {executable}")
        interpreter_checks(
            setup, output, options if args.phase == "worker-json" else None
        )
        if args.phase != "worker-json":
            image_checks(setup, output)
        native_hash = None
        if args.phase in NATIVE_PHASES:
            binary = shutil.which("h2load")
            if not binary:
                raise FileNotFoundError("Required native load driver: h2load")
            native_hash = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
            version = subprocess.check_output([binary, "--version"], text=True).strip()
            write_json(
                output / "native-tool.json",
                {"path": binary, "sha256": native_hash, "version": version},
            )
            context.update(
                native_binary=binary, deadline=time.monotonic() + args.max_minutes * 60
            )

            def timed_out(signum: int, frame: Any) -> None:
                raise TimeoutError("Native comparison reached its wall-clock cutoff")

            signal.signal(signal.SIGALRM, timed_out)
            signal.setitimer(signal.ITIMER_REAL, args.max_minutes * 60)
        os.sched_setaffinity(0, cpus(budget.client))
        experiment(args, context)
        if native_hash is not None:
            signal.setitimer(signal.ITIMER_REAL, 0)
            if (
                hashlib.sha256(Path(context["native_binary"]).read_bytes()).hexdigest()
                != native_hash
            ):
                raise RuntimeError("Native load generator changed during the run")
        final = machine_state()
        write_json(output / "machine-after.json", final)
        if (
            initial["cpu_policies"] != final["cpu_policies"]
            or initial["boost"] != final["boost"]
            or initial.get("audit_daemon") != final.get("audit_daemon")
            or initial.get("audit_kernel") != final.get("audit_kernel")
        ):
            raise RuntimeError(
                "Governor/boost/audit settings changed; this is not a matched run"
            )
        if file_hashes(setup.harness) != hashes:
            raise RuntimeError("Frozen diagnostic harness changed during the run")
        final_sources = {
            runtime: source_hashes(setup.store / f"source-{runtime}")
            for runtime in ("312", "314")
        }
        if final_sources != json.loads((output / "source-hashes.json").read_text()):
            raise RuntimeError("Production source snapshots changed during the run")
        if hashlib.sha256(setup.model.read_bytes()).hexdigest() != MODEL_SHA:
            raise RuntimeError("ONNX model changed during the run")
        write_json(
            output / "COMPLETED.json",
            {
                "phase": args.phase,
                "cases": len(context["all_rows"]),
                "utc": final["utc"],
                "scope": plan["scope"],
                "smoke_is_not_a_comparison": args.phase == "smoke",
                "client_control_is_not_full_comparison": args.phase == "clients",
            },
        )
        text = summary(context["all_rows"])
        if args.phase == "smoke":
            text = (
                "SMOKE ONLY: startup/correctness/resource checks, not conclusions.\n\n"
                + text
            )
        elif args.phase == "clients":
            text = "CLIENT CONTROL ONLY: not the full server comparison.\n\n" + text
        (output / "SUMMARY.txt").write_text(text)
        print(f"Complete: {output / 'SUMMARY.txt'}", flush=True)
    except BaseException as error:
        if args.phase in NATIVE_PHASES:
            signal.setitimer(signal.ITIMER_REAL, 0)
        write_json(
            output / "FAILED.json",
            dict(failure_details(error), completed_cases=len(context["all_rows"])),
        )
        text = "FAILED / INCOMPLETE: do not call this a completed comparison.\n\n"
        (output / "SUMMARY.txt").write_text(text + summary(context["all_rows"]))
        print(f"Failed: {output / 'FAILED.json'}", file=sys.stderr, flush=True)
        if isinstance(
            error, (subprocess.CalledProcessError, subprocess.TimeoutExpired)
        ):
            diagnostic = failure_details(error).get("stderr")
            if diagnostic:
                print(diagnostic, file=sys.stderr, flush=True)
        raise


if __name__ == "__main__":
    main()
