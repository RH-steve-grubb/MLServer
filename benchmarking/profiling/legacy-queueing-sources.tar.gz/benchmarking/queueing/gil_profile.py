"""Root-run perf diagnostic for the existing ONNX serving benchmark.

No sudo, installation, sysctl changes or production hooks. Temporary uprobes
are uniquely named and removed on normal completion, errors and Ctrl-C. Only
the launched frontend is profiled, not its independent inference workers.
"""

import argparse
import contextlib
import json
import os
import re
import select
import shutil
import signal
import socket
import statistics
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.error import URLError
from urllib.request import urlopen

BENCH = Path(__file__).with_name("bench.py").resolve()
REPO = BENCH.parents[2]
EVENT_LINE = re.compile(r"^\s*(\d+)\s+(\d+)\.(\d{1,9}):\s+(\S+):\s*$")


def command(args: list[str], env: dict[str, str] | None = None) -> str:
    result = subprocess.run(args, capture_output=True, text=True, timeout=60, env=env)
    if result.returncode:
        raise RuntimeError(f"{args!r}\n{result.stderr[-4000:]}")
    return result.stdout


def python_info(python: Path) -> dict[str, Any]:
    code = (
        "import json,sys,sysconfig; "
        "print(json.dumps(dict(version=sys.version,minor=sys.version_info[:2],"
        "implementation=sys.implementation.name,executable=sys._base_executable,"
        "gil_disabled=sysconfig.get_config_var('Py_GIL_DISABLED'))))"
    )
    info = json.loads(command([str(python), "-c", code]))
    if info["implementation"] != "cpython" or info["minor"] != [3, 12]:
        raise RuntimeError("This GIL diagnostic is scoped to ordinary CPython 3.12.")
    if info["gil_disabled"]:
        raise RuntimeError("This diagnostic requires a GIL-enabled interpreter.")
    return info


def audit_status() -> dict[str, Any]:
    """Read host audit state without enabling, disabling or changing rules."""
    tool = shutil.which("auditctl")
    if tool is None:
        return {"available": False}
    result = subprocess.run([tool, "-s"], capture_output=True, text=True, timeout=10)
    return {
        "available": True,
        "returncode": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    }


def gil_symbols(image: Path) -> dict[str, str]:
    symbols = command(["nm", "-a", str(image)])
    result = {}
    for line in symbols.splitlines():
        fields = line.split()
        if len(fields) != 3 or fields[1].lower() != "t":
            continue
        name = fields[2]
        # BOLT/LLVM suffixes are real function names; cold/warm/org fragments
        # are not separate entries and must not produce duplicate acquisitions.
        for base in ("take_gil", "drop_gil"):
            if re.fullmatch(base + r"(?:\.llvm\.\d+)?", name):
                result[base] = name
    return result


def symbol_offsets(image: Path, function: str) -> list[int]:
    """Resolve ELF function entries to file offsets, without DWARF line lookup."""
    dynamic = "libc.so" in image.name
    symbols = command(["nm", "-D" if dynamic else "-a", str(image)])
    addresses = set()
    for line in symbols.splitlines():
        fields = line.split()
        if len(fields) == 3 and fields[1].lower() == "t":
            if fields[2].split("@", 1)[0] == function:
                addresses.add(int(fields[0], 16))
    offsets = set()
    sections = command(["objdump", "-h", str(image)]).splitlines()
    for index, line in enumerate(sections[:-1]):
        fields = line.split()
        if len(fields) != 7 or not fields[0].isdigit():
            continue
        if "CODE" not in sections[index + 1]:
            continue
        size, address, offset = (int(fields[i], 16) for i in (2, 3, 5))
        for symbol in addresses:
            if address <= symbol < address + size:
                offsets.add(offset + symbol - address)
    if not addresses or len(offsets) != len(addresses):
        raise RuntimeError(f"Cannot resolve ELF entries for {function} in {image}")
    return sorted(offsets)


def mapped_images(pid: int) -> list[Path]:
    images = {Path(f"/proc/{pid}/exe").resolve()}
    for line in Path(f"/proc/{pid}/maps").read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith("/"):
            path = Path(fields[5])
            if "libpython3.12" in path.name or path.name == "libc.so.6":
                images.add(path.resolve())
    return sorted(images)


class Probes:
    def __init__(self, images: list[Path]) -> None:
        self.group = "mlsgil_" + uuid.uuid4().hex[:12]
        self.specs: list[tuple[Path, str]] = []
        self.events: dict[str, str] = {}
        self.definitions: list[str] = []
        self.installed: list[str] = []
        for index, image in enumerate(images):
            symbols = gil_symbols(image) if "libc.so" not in image.name else {}
            functions = {
                "take_in": symbols.get("take_gil"),
                "take_out": symbols.get("take_gil"),
            }
            if "libc.so" in image.name:
                functions = {"cond_in": "pthread_cond_timedwait"}
                functions["cond_out"] = "pthread_cond_timedwait"
            for role, function in functions.items():
                if function is None:
                    continue
                for alias, offset in enumerate(symbol_offsets(image, function)):
                    event = f"{self.group}:{role}_{index}_{alias}"
                    suffix = "%return" if role.endswith("out") else ""
                    # Symbol-name probes can select a DWARF source statement,
                    # rather than the actual entry, when root has debuginfo.
                    # Numeric file offsets keep both probes at the same entry.
                    spec = f"{event}=0x{offset:x}{suffix}"
                    definitions = command(
                        ["perf", "probe", "-x", str(image), "--definition", spec]
                    )
                    for line in definitions.splitlines():
                        if line.startswith(("p:", "r:")):
                            actual = line.split()[0][2:].replace("/", ":", 1)
                            self.events[actual] = role
                            self.definitions.append(line)
                    self.specs.append((image, spec))
        roles = set(self.events.values())
        if roles != {"take_in", "take_out", "cond_in", "cond_out"}:
            raise RuntimeError(f"Cannot resolve all GIL/condition probes: {roles}")

    def install(self) -> None:
        # Reserve names before adding: a failed add can still install some aliases.
        self.installed = list(self.events)
        for image, spec in self.specs:
            command(["perf", "probe", "-x", str(image), "--add", spec])

    def close(self) -> None:
        if not self.installed:
            return
        # An interrupted --add may have registered only some symbol aliases.
        # Read the registry so cleanup deletes only events actually present.
        registry = next(
            (
                path
                for path in (
                    Path("/sys/kernel/tracing/uprobe_events"),
                    Path("/sys/kernel/debug/tracing/uprobe_events"),
                )
                if path.is_file()
            ),
            None,
        )
        present = set(self.installed)
        if registry is not None:
            present = {
                line.split()[0][2:].replace("/", ":", 1)
                for line in registry.read_text().splitlines()
                if line.startswith((f"p:{self.group}/", f"r:{self.group}/"))
            }
        failures = []
        for event in self.installed:
            if event not in present:
                continue
            result = subprocess.run(
                ["perf", "probe", "--del", event],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode:
                failures.append(f"{event}: {result.stderr.strip()}")
        self.installed.clear()
        if failures:
            raise RuntimeError("Probe cleanup needs attention:\n" + "\n".join(failures))


@dataclass
class Window:
    start: int
    end: int

    def __post_init__(self) -> None:
        if self.end <= self.start:
            raise ValueError("Measurement window must have positive duration.")

    def overlap(self, start: int, end: int) -> int:
        return max(0, min(self.end, end) - max(self.start, start))


def distribution(values: list[int]) -> dict[str, float | int]:
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(values),
        "mean_us": statistics.mean(values) / 1000,
        "p50_us": ordered[(len(ordered) - 1) // 2] / 1000,
        "p95_us": ordered[int((len(ordered) - 1) * 0.95)] / 1000,
        "p99_us": ordered[int((len(ordered) - 1) * 0.99)] / 1000,
        "max_us": ordered[-1] / 1000,
    }


class TraceAnalysis:
    def __init__(self, window: Window) -> None:
        self.window = window
        self.threads: dict[int, dict[str, Any]] = {}
        self.pending: dict[int, tuple[int, bool]] = {}
        self.condition: dict[int, int] = {}
        self.unmatched = 0
        self.event_counts: dict[str, int] = {}

    def mismatch(self, stamp: int, began: int | None = None) -> None:
        # Attachment can start halfway through a warm-up acquisition. Only
        # mismatches within the measurement window invalidate its metrics.
        if self.window.start <= stamp <= self.window.end or (
            began is not None and self.window.overlap(began, stamp)
        ):
            self.unmatched += 1

    def feed(self, tid: int, stamp: int, role: str) -> None:
        row = self.threads.setdefault(
            tid, {"acquire_ns": [], "contended": 0, "condition_ns": 0}
        )
        if self.window.start <= stamp <= self.window.end:
            self.event_counts[role] = self.event_counts.get(role, 0) + 1
        if role == "take_in":
            if tid in self.pending:
                self.mismatch(stamp, self.pending[tid][0])
            self.pending[tid] = (stamp, False)
        elif role == "cond_in" and tid in self.pending:
            if tid in self.condition:
                self.mismatch(stamp, self.condition[tid])
            self.condition[tid] = stamp
            self.pending[tid] = (self.pending[tid][0], True)
        elif role == "cond_out" and tid in self.pending:
            # A wait return is positive evidence of contention even if its
            # entry probe failed. Never turn that failure into "zero waits".
            self.pending[tid] = (self.pending[tid][0], True)
            if tid in self.condition:
                row["condition_ns"] += self.window.overlap(
                    self.condition.pop(tid), stamp
                )
            else:
                self.mismatch(stamp, self.pending[tid][0])
        elif role == "take_out":
            if tid in self.pending:
                started, contended = self.pending.pop(tid)
                if tid in self.condition:
                    self.mismatch(stamp, self.condition.pop(tid))
                if self.window.start <= started <= stamp <= self.window.end:
                    row["acquire_ns"].append(stamp - started)
                    row["contended"] += int(contended)
            else:
                self.mismatch(stamp)

    def finish(self) -> dict[str, Any]:
        # Recording can stop while an interval is open. Clip, but flag it rather
        # than treating an unfinished acquisition as a completed slow call.
        for tid, started in self.condition.items():
            self.threads[tid]["condition_ns"] += self.window.overlap(
                started, self.window.end
            )
        rows = []
        acquisitions = []
        for tid, state in sorted(self.threads.items()):
            acquisitions.extend(state["acquire_ns"])
            rows.append(
                {
                    "tid": tid,
                    "acquisition": distribution(state["acquire_ns"]),
                    "acquisitions_with_condition_wait": state["contended"],
                    "condition_wait_ms": state["condition_ns"] / 1e6,
                }
            )
        duration = (self.window.end - self.window.start) / 1e9
        return {
            "duration_seconds": duration,
            "acquisition": distribution(acquisitions),
            "acquisitions_per_second": len(acquisitions) / duration,
            "acquisitions_with_condition_wait": sum(
                row["acquisitions_with_condition_wait"] for row in rows
            ),
            "condition_wait_thread_ms": sum(row["condition_wait_ms"] for row in rows),
            "unmatched_events": self.unmatched,
            "open_acquisitions": sum(
                start <= self.window.end for start, _ in self.pending.values()
            ),
            "open_condition_waits": sum(
                start <= self.window.end for start in self.condition.values()
            ),
            "event_counts": self.event_counts,
            "threads": rows,
        }


def analyze_trace(path: Path, events: dict[str, str], window: Window) -> dict[str, Any]:
    analysis = TraceAnalysis(window)
    parsed = 0
    lost = False
    with path.open() as source:
        for line in source:
            if "LOST" in line.upper():
                lost = True
            match = EVENT_LINE.match(line)
            if match is None:
                continue
            tid, seconds, fraction, event = match.groups()
            if event not in events:
                continue
            stamp = int(seconds) * 10**9 + int(fraction.ljust(9, "0"))
            analysis.feed(int(tid), stamp, events[event])
            parsed += 1
    result = analysis.finish()
    result["parsed_events"] = parsed
    result["lost_events_reported"] = lost
    reasons = []
    if lost:
        reasons.append("perf reported lost events")
    if result["unmatched_events"]:
        reasons.append("unpaired acquisition/condition events inside the window")
    if result["open_acquisitions"] or result["open_condition_waits"]:
        reasons.append("recording stopped with unfinished calls")
    result["valid"] = not reasons
    result["invalid_reasons"] = reasons
    if reasons:
        # Retain acquisition/count evidence for diagnosis, but a missing entry
        # makes elapsed wait time unknowable, not zero.
        result["condition_wait_thread_ms"] = None
        for row in result["threads"]:
            row["condition_wait_ms"] = None
    if result["acquisition"]["count"] == 0:
        raise RuntimeError(
            "No complete GIL acquisitions: missing probes or trace format."
        )
    return result


def require_valid_trace(result: dict[str, Any]) -> None:
    if not result["valid"]:
        raise RuntimeError("Invalid GIL trace: " + "; ".join(result["invalid_reasons"]))


def stop_process(process: subprocess.Popen, sig: int = signal.SIGTERM) -> None:
    if process.poll() is not None:
        return
    process.send_signal(sig)
    try:
        process.wait(timeout=20)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=10)


def wait_ready(process: subprocess.Popen, port: int) -> None:
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                "Server exited; inspect server.log in the case directory."
            )
        try:
            with urlopen(
                f"http://127.0.0.1:{port}/v2/health/ready", timeout=1
            ) as response:
                if response.status == 200:
                    return
        except (URLError, TimeoutError):
            pass
        time.sleep(0.1)
    raise RuntimeError("Server startup timed out.")


def load_case(args: argparse.Namespace, port: int) -> dict[str, Any]:
    result = subprocess.run(
        [
            str(args.python),
            str(BENCH),
            "load",
            str(args.model),
            "--port",
            str(port),
            "--batch",
            str(args.batch),
            "--concurrency",
            str(args.concurrency),
            "--seconds",
            str(args.seconds),
        ],
        capture_output=True,
        text=True,
        env=args.env,
        cwd=REPO,
        timeout=args.seconds + 180,
    )
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:])
    row = json.loads(result.stdout.splitlines()[-1])
    if row["errors"]:
        raise RuntimeError(f"Prediction errors: {row['errors']}")
    return row


@contextlib.contextmanager
def recording(
    pid: int | str, phase: Path, probes: Probes | None
) -> Iterator[subprocess.Popen]:
    # A comma-separated PID list lets newer diagnostics attach to the frontend
    # and its already-spawned workers in this same synchronized perf session.
    data = phase / "perf.data"
    record = [
        "perf",
        "record",
        "-p",
        str(pid),
        "-k",
        "mono",
        "-m",
        "1024",
        "--no-buildid-cache",
        "-o",
        str(data),
    ]
    if probes:
        record += ["-e", ",".join(probes.events), "-c", "1"]
    else:
        record += ["-e", "cpu-clock", "-F", "99", "--call-graph", "dwarf,8192"]
    with contextlib.ExitStack() as cleanup:
        if probes:
            cleanup.callback(probes.close)
            (phase / "probes.json").write_text(json.dumps(probes.events, indent=2))
            (phase / "probe-definitions.txt").write_text(
                "\n".join(probes.definitions) + "\n"
            )
            probes.install()
        log = cleanup.enter_context((phase / "perf.log").open("w"))
        control_read, control_write = os.pipe()
        ack_read, ack_write = os.pipe()
        for descriptor in (control_read, control_write, ack_read, ack_write):
            cleanup.callback(os.close, descriptor)
        record += ["--delay=-1", "--control", f"fd:{control_read},{ack_write}"]
        process = subprocess.Popen(
            record, stdout=log, stderr=log, pass_fds=(control_read, ack_write)
        )
        cleanup.callback(stop_process, process, signal.SIGINT)
        # File creation precedes attachment. Use perf's enable acknowledgement
        # so the workload cannot start before every existing thread is traced.
        os.write(control_write, b"enable\n")
        deadline = time.monotonic() + 10
        acknowledged = False
        reply = b""
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(
                    f"perf could not attach; inspect {phase / 'perf.log'}"
                )
            readable, _, _ = select.select([ack_read], [], [], 0.1)
            if readable:
                chunk = os.read(ack_read, 64)
                reply += chunk
                # perf writes its C-string terminator as well as the newline.
                # Pipes are byte streams: accumulate any fragmented reply,
                # but accept only the exact acknowledgement, optionally NUL.
                if b"\n" in reply:
                    acknowledged = reply in (b"ack\n", b"ack\n\x00")
                    break
                if not chunk or len(reply) >= 64:
                    break
        if not acknowledged:
            raise RuntimeError(
                f"perf enable handshake failed (reply={reply!r}); "
                f"inspect {phase / 'perf.log'}"
            )
        yield process
        if process.poll() is not None:
            raise RuntimeError("perf exited during load; inspect perf.log.")
        stop_process(process, signal.SIGINT)
        if process.returncode not in (0, -signal.SIGINT, 128 + signal.SIGINT):
            raise RuntimeError(
                f"perf failed with exit {process.returncode}; inspect log."
            )


def read_trace(phase: Path, probes: Probes, window: Window) -> dict[str, Any]:
    trace = phase / "events.txt"
    with trace.open("w") as destination:
        result = subprocess.run(
            [
                "perf",
                "script",
                "--ns",
                "--show-lost-events",
                "-i",
                str(phase / "perf.data"),
                "-F",
                "tid,time,event",
            ],
            stdout=destination,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60,
        )
    (phase / "decode.log").write_text(result.stderr)
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:])
    analysis = analyze_trace(trace, probes.events, window)
    warnings = result.stderr + (phase / "perf.log").read_text()
    analysis["decode_or_record_warnings"] = warnings.strip()
    (phase / "analysis.json").write_text(json.dumps(analysis, indent=2))
    require_valid_trace(analysis)
    return analysis


def collect(args: argparse.Namespace, pid: int, port: int) -> dict[str, Any]:
    phase = args.phase_dir
    phase.mkdir()
    if args.phase.startswith("baseline"):
        return load_case(args, port)
    probes = Probes(mapped_images(pid)) if args.phase == "gil" else None
    with recording(pid, phase, probes):
        row = load_case(args, port)
    # Preserve the workload window even if strict trace validation aborts.
    (phase / "load.json").write_text(json.dumps(row, indent=2))
    if probes:
        row["gil"] = read_trace(
            phase,
            probes,
            Window(row["measurement_started_ns"], row["measurement_drained_ns"]),
        )
    else:
        report = command(
            [
                "perf",
                "report",
                "--stdio",
                "--no-children",
                "-i",
                str(phase / "perf.data"),
                "--sort",
                "comm,tgid,pid,dso,symbol",
                "--time",
                f"{row['measurement_started_ns'] / 1e9:.9f},"
                f"{row['measurement_drained_ns'] / 1e9:.9f}",
            ]
        )
        (phase / "cpu-report.txt").write_text(report)
    return row


def contention_worker() -> None:
    """Controlled workload: idle helpers, then two Python threads sharing a GIL."""
    start = threading.Event()
    ready = threading.Barrier(3)
    until = 0.0

    def busy() -> None:
        ready.wait()
        start.wait()
        value = 0
        while time.perf_counter() < until:
            for _ in range(10000):
                value += 1

    threads = [threading.Thread(target=busy) for _ in range(2)]
    for thread in threads:
        thread.start()
    ready.wait()
    print(json.dumps({"ready": True}), flush=True)
    if sys.stdin.readline().strip() != "quiet":
        raise RuntimeError("Expected quiet self-test command")
    began = time.perf_counter_ns()
    for _ in range(100):
        time.sleep(0.01)
    print(json.dumps({"start": began, "end": time.perf_counter_ns()}), flush=True)
    if sys.stdin.readline().strip() != "contended":
        raise RuntimeError("Expected contended self-test command")
    sys.setswitchinterval(0.002)
    began = time.perf_counter_ns()
    until = time.perf_counter() + 2
    start.set()
    for thread in threads:
        thread.join()
    print(json.dumps({"start": began, "end": time.perf_counter_ns()}), flush=True)
    sys.stdin.readline()


def validate_self_test(quiet: dict[str, Any], contended: dict[str, Any]) -> None:
    for result in (quiet, contended):
        require_valid_trace(result)
    if quiet["acquisitions_with_condition_wait"]:
        raise RuntimeError("Idle self-test unexpectedly detected GIL contention")
    if (
        not contended["acquisitions_with_condition_wait"]
        or not contended["condition_wait_thread_ms"]
    ):
        raise RuntimeError("Known-contention self-test did not detect paired GIL waits")


def self_test(args: argparse.Namespace, output: Path) -> None:
    directory = output / "self-test"
    directory.mkdir()
    with contextlib.ExitStack() as cleanup:
        log = cleanup.enter_context((directory / "worker.log").open("w"))
        worker = subprocess.Popen(
            [str(args.python), str(Path(__file__).resolve()), "--self-test-worker"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=log,
            text=True,
            env=args.env,
        )
        cleanup.callback(stop_process, worker)
        if worker.stdin is None or worker.stdout is None:
            raise RuntimeError("Cannot open self-test control pipes")
        cleanup.callback(worker.stdin.close)
        cleanup.callback(worker.stdout.close)
        # The worker creates both threads before we attach, so perf includes
        # them. Pipe reads have a deadline rather than hanging a root run.
        stream = worker.stdout

        def receive() -> dict[str, Any]:
            readable, _, _ = select.select([stream], [], [], 15)
            if not readable:
                raise RuntimeError("Self-test worker timed out; inspect worker.log")
            return json.loads(stream.readline())

        if not receive().get("ready"):
            raise RuntimeError("Self-test worker was not ready")
        probes = Probes(mapped_images(worker.pid))
        with recording(worker.pid, directory, probes):
            windows = {}
            for name in ("quiet", "contended"):
                worker.stdin.write(name + "\n")
                worker.stdin.flush()
                windows[name] = receive()
        (directory / "windows.json").write_text(json.dumps(windows, indent=2))
        # The target stays alive until recording stops. Closing stdin releases
        # its final read only after perf has drained the trace.
        worker.stdin.close()
        worker.wait(timeout=10)
        if worker.returncode:
            raise RuntimeError("Self-test worker failed; inspect worker.log")
        results = {
            name: read_trace(directory, probes, Window(row["start"], row["end"]))
            for name, row in windows.items()
        }
        (directory / "results.json").write_text(json.dumps(results, indent=2))
        validate_self_test(results["quiet"], results["contended"])
        (directory / "PASSED").write_text(
            "Idle control and paired GIL waits verified.\n"
        )
        print(
            "GIL probe self-test PASSED (idle control + known contention).", flush=True
        )


def run_case(
    args: argparse.Namespace, directory: Path, rows: list[dict[str, Any]]
) -> None:
    directory.mkdir()
    with socket.socket() as connection:
        connection.bind(("127.0.0.1", 0))
        port = connection.getsockname()[1]
    with (directory / "server.log").open("w") as log:
        server = subprocess.Popen(
            [
                str(args.python),
                str(BENCH),
                "serve",
                str(args.model),
                "--port",
                str(port),
                "--workers",
                str(args.workers),
                "--threads",
                "1",
                "--no-spin",
            ],
            env=args.env,
            cwd=REPO,
            stdout=log,
            stderr=log,
            start_new_session=True,
        )
        try:
            wait_ready(server, port)
            # Exercise all round-robin request queues before attaching perf, so
            # their feeder threads exist and are included in the PID attachment.
            warmup = argparse.Namespace(**vars(args))
            warmup.seconds = 0.25
            load_case(warmup, port)
            phases = ["gil", "cpu"] if args.batch % 2 else ["cpu", "gil"]
            for name in ["baseline-before", *phases, "baseline-after"]:
                args.phase = name
                args.phase_dir = directory / name
                print(
                    f"batch={args.batch} concurrency={args.concurrency}: {name}",
                    flush=True,
                )
                row = collect(args, server.pid, port)
                row.update(
                    batch=args.batch,
                    concurrency=args.concurrency,
                    phase=name,
                    frontend_pid=server.pid,
                )
                (args.phase_dir / "load.json").write_text(json.dumps(row, indent=2))
                rows.append(row)
                write_summary(directory.parent, rows)
        finally:
            if server.poll() is None:
                from urllib.request import Request

                try:
                    with urlopen(
                        Request(
                            f"http://127.0.0.1:{port}/queue-probe/stop", method="POST"
                        ),
                        timeout=5,
                    ):
                        pass
                    server.wait(timeout=20)
                except (URLError, TimeoutError, subprocess.TimeoutExpired):
                    stop_process(server)
            # Only the new session we created: catch orphaned worker descendants
            # even if the frontend died before its ordinary pool cleanup.
            try:
                os.killpg(server.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass


def write_summary(output: Path, rows: list[dict[str, Any]]) -> None:
    lines = ["MLServer frontend GIL/native profiling", "=" * 38, ""]
    passed = (output / "self-test" / "PASSED").is_file()
    lines.append(
        f"Known-contention probe self-test: {'PASSED' if passed else 'NOT PASSED'}"
    )
    for row in rows:
        lines.append(
            f"batch={row['batch']} concurrency={row['concurrency']} "
            f"{row['phase']}: {row['rps']:.2f} RPS, "
            f"{row['timings']['client_ms']['mean']:.2f} ms latency"
        )
        if "gil" in row:
            gil = row["gil"]
            if not gil["valid"]:
                lines.append(
                    "  INVALID GIL TRACE: " + "; ".join(gil["invalid_reasons"])
                )
                continue
            acquisition = gil["acquisition"]
            lines += [
                f"  GIL acquisitions: {acquisition['count']} "
                f"({gil['acquisitions_per_second']:.1f}/s); "
                f"mean/p99/max: {acquisition['mean_us']:.1f}/"
                f"{acquisition['p99_us']:.1f}/{acquisition['max_us']:.1f} us",
                f"  Acquisitions entering condition wait: "
                f"{gil['acquisitions_with_condition_wait']}; "
                "summed condition wait: "
                f"{gil['condition_wait_thread_ms']:.2f} thread-ms",
                f"  Trace quality: valid={gil['valid']}, "
                f"lost={gil['lost_events_reported']}, "
                f"unmatched={gil['unmatched_events']}, "
                f"open acquisitions={gil['open_acquisitions']}",
                "  TID       Main?   Acquisitions   Contended   Wait ms",
            ]
            for thread in gil["threads"]:
                main_thread = "yes" if thread["tid"] == row["frontend_pid"] else "no"
                lines.append(
                    f"  {thread['tid']:<9} {main_thread:<7} "
                    f"{thread['acquisition']['count']:<14} "
                    f"{thread['acquisitions_with_condition_wait']:<11} "
                    f"{thread['condition_wait_ms']:.2f}"
                )
    lines += [
        "",
        "Interpretation:",
        "Condition waits are counted ONLY inside a traced take_gil call.",
        "They include wakeup/scheduling and mutex reacquisition, not just sleep.",
        "Acquisition duration includes bookkeeping, scheduling and probe overhead.",
        "GIL-held time is NOT estimated: optimized builds inline release paths.",
        "Thread-wait totals can exceed elapsed time.",
        "Lost/unmatched events or missing probes invalidate an absence-of-contention",
        "claim. Compare traced RPS with both baselines to judge perturbation.",
        "Native CPU samples identify running work, NOT blocked-thread duration.",
        "Only the frontend is traced; inference workers have independent GILs.",
    ]
    (output / "SUMMARY.txt").write_text("\n".join(lines) + "\n")
    (output / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[2, 64])
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument(
        "--check", action="store_true", help="Read-only preflight; no root"
    )
    parser.add_argument("--self-test-only", action="store_true")
    parser.add_argument(
        "--self-test-worker", action="store_true", help=argparse.SUPPRESS
    )
    args = parser.parse_args()
    if args.self_test_worker:
        contention_worker()
        return
    args.python = args.python.absolute()
    info = python_info(args.python)
    for tool in ("perf", "nm", "objdump"):
        if not shutil.which(tool):
            parser.error(f"Required tool missing: {tool}")
    symbols = gil_symbols(Path(info["executable"]).resolve())
    print(
        json.dumps(
            {
                "python": info,
                "executable_gil_symbols": symbols,
                "perf": command(["perf", "version"]).strip(),
            },
            indent=2,
        )
    )
    if args.check:
        images = [Path(info["executable"]).resolve()]
        images.extend(
            image for image in mapped_images(os.getpid()) if "libc.so" in image.name
        )
        probes = Probes(images)
        print(json.dumps({"read_only_probe_definitions": probes.events}, indent=2))
        print("\n".join(probes.definitions))
        return
    if os.geteuid() != 0:
        parser.error("Run from a root shell; this harness never invokes sudo.")

    def interrupted(signum: int, frame: Any) -> None:
        raise KeyboardInterrupt

    signal.signal(signal.SIGTERM, interrupted)
    if (
        args.seconds <= 0
        or args.workers <= 0
        or min(args.batches + args.concurrencies) <= 0
    ):
        parser.error("Duration, workers, batches and concurrency must be positive.")
    output = (
        args.output.absolute()
        if args.output
        else Path(tempfile.mkdtemp(prefix="mlserver-gil-"))
    )
    if args.output:
        output.mkdir(parents=True, exist_ok=False)
    output.chmod(0o755)
    print(f"Artifacts: {output}", flush=True)
    (output / "metadata.json").write_text(
        json.dumps(
            {
                "python": info,
                "perf": command(["perf", "version"]).strip(),
                "cpu_count": os.cpu_count(),
                "workers": args.workers,
                "seconds_per_phase": args.seconds,
                "batches": args.batches,
                "concurrencies": args.concurrencies,
                "ort_threads_per_worker": 1,
                "ort_spinning": False,
                "queue_codec": "pickle",
                "queue_tensors": "list",
                "audit_status": audit_status(),
            },
            indent=2,
        )
    )
    args.model = output / "queue-mlp.onnx"
    args.env = dict(os.environ)
    args.env.update(
        MLSERVER_QUEUE_PROBE="0",
        MLSERVER_QUEUE_CODEC="pickle",
        MLSERVER_QUEUE_TENSORS="list",
        OMP_NUM_THREADS="1",
        OPENBLAS_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    rows: list[dict[str, Any]] = []
    try:
        self_test(args, output)
        if not args.self_test_only:
            generated = command(
                [str(args.python), str(BENCH), "generate", str(args.model)],
                env=args.env,
            )
            (output / "model.json").write_text(generated)
            for batch in args.batches:
                for concurrency in args.concurrencies:
                    args.batch, args.concurrency = batch, concurrency
                    run_case(args, output / f"b{batch}-c{concurrency}", rows)
                    write_summary(output, rows)
    finally:
        write_summary(output, rows)
        # This directory was created exclusively for this run. Let the ordinary
        # user read the synthetic diagnostics afterwards, even with root umask 077.
        for path in output.rglob("*"):
            if not path.is_symlink():
                path.chmod(0o755 if path.is_dir() else 0o644)
    print(f"Finished. Read {output / 'SUMMARY.txt'}", flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted; owned processes/probes were cleaned up.", file=sys.stderr)
        sys.exit(130)
