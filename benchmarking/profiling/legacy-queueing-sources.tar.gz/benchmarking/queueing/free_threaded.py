"""Matched REST/JSON serving comparison on one free-threaded interpreter.

Only startup compatibility is changed in an isolated source copy. Production
inference, Queue/pickle, round robin and existing thread ownership are retained.
The coordinator and client can use the earlier Python 3.12 environment; only
the server and its workers change GIL mode. Never force an extension's GIL off.
"""

import argparse
import asyncio
import hashlib
import importlib.metadata
import json
import os
import platform
import signal
import socket
import statistics
import subprocess
import sys
import sysconfig
import tempfile
import threading
import time
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
REPO = Path(os.environ.get("MLSERVER_STUDY_REPO", HERE.parents[1])).resolve()
QUEUE_DEFAULTS = {
    "MLSERVER_QUEUE_PROBE": "0",
    "MLSERVER_QUEUE_HTTP": "fastapi",
    "MLSERVER_QUEUE_HTTP_PARSER": "h11",
    "MLSERVER_QUEUE_JSON": "frontend",
    "MLSERVER_QUEUE_JSON_MODE": "separate",
    "MLSERVER_QUEUE_TRANSPORT": "queue",
    "MLSERVER_QUEUE_CODEC": "pickle",
    "MLSERVER_QUEUE_TENSORS": "list",
    "MLSERVER_QUEUE_EXECUTION": "inline",
    "MLSERVER_QUEUE_PUMP": "0",
    "MLSERVER_QUEUE_BALANCE": "0",
    "MLSERVER_QUEUE_SCHEDULER": "round-robin",
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
}


def environment(source: Path, mode: str) -> dict[str, str]:
    env = {
        key: value
        for key, value in os.environ.items()
        if not key.startswith("MLSERVER_QUEUE_")
        and not key.startswith("MLSERVER_FT_")
        and key not in ("PYTHON_GIL", "PYTHONPATH")
    }
    env.update(QUEUE_DEFAULTS)
    env["PYTHONPATH"] = os.pathsep.join((str(source), str(HERE)))
    if mode == "on":
        # Spawned workers inherit this setting; sys._xoptions alone would not.
        env["PYTHON_GIL"] = "1"
    elif mode != "off":
        raise ValueError("Expected GIL mode 'on' or 'off'")
    return env


def check_state(phase: str) -> dict[str, Any]:
    enabled = getattr(sys, "_is_gil_enabled", lambda: True)()
    expected = os.environ["MLSERVER_FT_EXPECT"] == "on"
    if sysconfig.get_config_var("Py_GIL_DISABLED") != 1:
        raise RuntimeError("The server must use a free-threaded Python build")
    if enabled != expected:
        raise RuntimeError(f"Unexpected GIL state at {phase}: {enabled}")
    import mlserver

    actual = Path(mlserver.__file__).resolve().parent.parent
    if actual != Path(os.environ["MLSERVER_FT_SOURCE"]).resolve():
        raise RuntimeError(f"Imported production tree instead of copy: {actual}")
    if "orjson" in sys.modules or "grpc" in sys.modules:
        raise RuntimeError("REST diagnostic unexpectedly imported orjson or gRPC")
    from balance_scheduler import installed

    result: dict[str, Any] = {
        "phase": phase,
        "pid": os.getpid(),
        "gil_enabled": enabled,
        "python": sys.version,
        "executable": sys.executable,
        "source": str(actual),
        "source_version": mlserver.__version__,
        "transport": os.environ.get("MLSERVER_QUEUE_TRANSPORT", "queue"),
        "scheduler": os.environ.get("MLSERVER_QUEUE_SCHEDULER", "round-robin"),
        "least_outstanding_installed": installed(),
        "libraries": {
            package: importlib.metadata.version(package)
            for package in (
                "onnxruntime",
                "onnx",
                "numpy",
                "pandas",
                "fastapi",
                "starlette",
                "uvicorn",
                "h11",
                "pydantic",
                "pydantic-core",
                "aiohttp",
                "uvloop",
                "protobuf",
            )
        },
    }
    if result["transport"] == "zmq":
        import zmq

        result["libraries"]["pyzmq"] = zmq.__version__
        result["libraries"]["libzmq"] = zmq.zmq_version()
    return result


def thread_snapshot() -> dict[str, Any]:
    names = {thread.native_id: thread.name for thread in threading.enumerate()}
    result = {}
    for path in Path("/proc/self/task").iterdir():
        try:
            values = path.joinpath("stat").read_text().rsplit(")", 1)[1].split()
            schedule = path.joinpath("schedstat").read_text().split()
            result[path.name] = {
                "name": names.get(int(path.name), "native thread"),
                "start_ticks": int(values[19]),
                "cpu_ns": int(schedule[0]),
                "runqueue_wait_ns": int(schedule[1]),
                "timeslices": int(schedule[2]),
            }
        except FileNotFoundError:
            # Native helper threads may exit during this out-of-window sample.
            continue
    return result


def install_checks() -> None:
    import bench

    print(json.dumps(check_state("all-server-imports")), flush=True)
    original_load = bench.OnnxModel.load

    async def load(model: Any) -> Any:
        result = await original_load(model)
        print(json.dumps(check_state("onnx-model-loaded")), flush=True)
        return result

    bench.OnnxModel.load = load
    if os.environ.get("MLSERVER_FT_WORKER_GIL") == "on":
        from mlserver.parallel.worker import Worker

        original_start = Worker.start

        def start(worker: Any) -> Any:
            # This runs only during startup, before serving any requests. Spawn
            # reads this environment synchronously. Changing it cannot change
            # the running parent's GIL, only the new worker's startup setting.
            previous = {
                key: os.environ.get(key) for key in ("PYTHON_GIL", "MLSERVER_FT_EXPECT")
            }
            os.environ.update(PYTHON_GIL="1", MLSERVER_FT_EXPECT="on")
            try:
                return original_start(worker)
            finally:
                for key, value in previous.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value

        setattr(Worker, "start", start)
    original_init = bench.RESTServer.__init__

    def initialise(server: Any, *args: Any, **kwargs: Any) -> None:
        original_init(server, *args, **kwargs)
        if "MLSERVER_FT_JSON_THREADS" in os.environ:
            from frontend_offload import install_routes

            install_routes(
                server,
                int(os.environ["MLSERVER_FT_JSON_THREADS"]),
                os.environ["MLSERVER_QUEUE_JSON_MODE"],
            )

        async def state() -> dict[str, Any]:
            result = check_state("frontend-after-load-and-requests")
            result["threads"] = thread_snapshot()
            result["monotonic_ns"] = time.monotonic_ns()
            pool = getattr(server._app.state, "frontend_json_pool", None)
            if pool is not None:
                result["frontend_json_pool"] = pool.snapshot()
                result["frontend_json_stages"] = [
                    stages.snapshot()
                    for stages in server._app.state.frontend_json_stages
                ]
            return result

        # Sample only before/after load, never once per prediction.
        server._app.add_api_route("/free-threaded/state", state, methods=["GET"])

    bench.RESTServer.__init__ = initialise


# multiprocessing spawn re-imports this main module. Checks consequently apply
# to worker imports and actual ONNX model initialization, not just the frontend.
if os.environ.get("MLSERVER_FT_EXPECT"):
    install_checks()


def read_json(port: int, path: str) -> dict[str, Any]:
    with urlopen(f"http://127.0.0.1:{port}{path}", timeout=5) as response:
        return json.load(response)


def free_port() -> int:
    with socket.socket() as connection:
        connection.bind(("127.0.0.1", 0))
        return int(connection.getsockname()[1])


def wait_ready(process: subprocess.Popen, port: int) -> None:
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("Server exited: inspect case server.log")
        try:
            read_json(port, "/free-threaded/state")
            return
        except OSError:
            time.sleep(0.05)
    raise RuntimeError("Server did not become ready")


def close_server(process: subprocess.Popen, port: int) -> None:
    if process.poll() is not None:
        return
    try:
        request = Request(
            f"http://127.0.0.1:{port}/queue-probe/stop", data=b"", method="POST"
        )
        with urlopen(request, timeout=5):
            pass
        process.wait(timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        # The group was created by this harness and contains only this server
        # and its workers. Never terminate unrelated benchmark processes.
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)


def thread_deltas(before: dict, after: dict) -> dict[str, Any]:
    duration = (after["monotonic_ns"] - before["monotonic_ns"]) / 1e9
    rows = []
    for tid, end in after["threads"].items():
        start = before["threads"].get(tid)
        if start is None or start["start_ticks"] != end["start_ticks"]:
            continue
        rows.append(
            {
                "tid": int(tid),
                "name": end["name"],
                "cpu_cores": (end["cpu_ns"] - start["cpu_ns"]) / 1e9 / duration,
                "runqueue_wait_ms": (
                    end["runqueue_wait_ns"] - start["runqueue_wait_ns"]
                )
                / 1e6,
                "timeslices": end["timeslices"] - start["timeslices"],
            }
        )
    return {
        "scope": "client startup + correctness warm-up + load + drain",
        "duration_seconds": duration,
        "threads": rows,
        "caution": "runqueue wait is CPU scheduling delay, not GIL/lock wait",
    }


def configure_transport(env: dict[str, str], transport: str, directory: str) -> None:
    if transport not in ("queue", "zmq"):
        raise ValueError("Expected inference transport 'queue' or 'zmq'")
    env["MLSERVER_QUEUE_TRANSPORT"] = transport
    if transport == "zmq":
        env["MLSERVER_QUEUE_ZMQ_DIR"] = directory


def run_case(args: argparse.Namespace, case: dict, directory: Path) -> dict:
    directory.mkdir(parents=True)
    port = free_port()
    mode = case["mode"]
    server_env = environment(args.source, mode)
    server_env.update(MLSERVER_FT_EXPECT=mode, MLSERVER_FT_SOURCE=str(args.source))
    server_env["MLSERVER_FT_WORKER_GIL"] = args.worker_gil
    if "json_threads" in case:
        server_env["MLSERVER_FT_JSON_THREADS"] = str(case["json_threads"])
    server_env["MLSERVER_QUEUE_SCHEDULER"] = case.get("scheduler", "round-robin")
    server_env["MLSERVER_QUEUE_JSON_MODE"] = case.get("json_mode", "separate")
    if case.get("balance"):
        server_env["MLSERVER_QUEUE_BALANCE"] = "1"
    command = [
        str(args.server_python),
        str(Path(__file__).resolve()),
        "serve",
        str(args.model),
        "--port",
        str(port),
        "--workers",
        str(args.workers),
        "--threads",
        "1",
        "--no-spin",
        "--unprobed",
    ]
    # Client interpreter and environment are fixed across both server modes.
    client_env = environment(REPO, "on")
    if case.get("balance"):
        client_env["MLSERVER_QUEUE_BALANCE"] = "1"
    client_env["PYTHONPATH"] += os.pathsep + str(REPO / "runtimes/onnx")
    client_command = [
        str(args.client_python),
        str(HERE / "bench.py"),
        "load",
        str(args.model),
        "--port",
        str(port),
        "--batch",
        str(case["batch"]),
        "--concurrency",
        str(case["concurrency"]),
        "--seconds",
        str(args.seconds),
    ]
    if case.get("mix"):
        client_command += ["--mix", *(str(value) for value in case["mix"])]
    # Unix socket paths have a short platform limit. Keep only disposable IPC
    # endpoints in /tmp; measurements, logs and source snapshots stay durable.
    with (
        tempfile.TemporaryDirectory(prefix="mls-ft-ipc-", dir="/tmp") as ipc,
        directory.joinpath("server.log").open("w") as log,
    ):
        configure_transport(server_env, case.get("transport", "queue"), ipc)
        process = subprocess.Popen(
            command,
            env=server_env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            wait_ready(process, port)
            before = read_json(port, "/free-threaded/state")
            with directory.joinpath("client.log").open("w") as client_log:
                subprocess.run(
                    client_command,
                    env=client_env,
                    stdout=client_log,
                    stderr=subprocess.STDOUT,
                    check=True,
                    timeout=args.seconds + 240,
                )
            after = read_json(port, "/free-threaded/state")
        finally:
            close_server(process, port)
    rows = [
        json.loads(line)
        for line in directory.joinpath("client.log").read_text().splitlines()
        if line.startswith('{"batch":')
    ]
    if len(rows) != 1 or rows[0]["errors"]:
        raise RuntimeError("Missing result or request errors; inspect client.log")
    checkpoints = [
        json.loads(line)
        for line in directory.joinpath("server.log").read_text().splitlines()
        if line.startswith('{"phase":')
    ]
    loaded = {
        item["pid"] for item in checkpoints if item["phase"] == "onnx-model-loaded"
    }
    if len(loaded) != args.workers:
        raise RuntimeError(
            f"Expected {args.workers} verified worker models, got {loaded}"
        )
    result = dict(rows[0], **case)
    result["worker_gil"] = args.worker_gil
    result["checks"] = {"before": before, "after": after, "startup": checkpoints}
    result["frontend_threads"] = thread_deltas(before, after)
    result["commands"] = {"server": command, "client": client_command}
    directory.joinpath("result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def summarize(rows: list[dict]) -> str:
    lines = [
        "REST/HTTP JSON, typed frontend, multiprocessing.Queue/pickle.",
        "Same CPython free-threaded build and libraries; fixed Python 3.12 client.",
        "No new prediction threads, JSON offloading or transport changes.",
        (
            "Workers remain GIL-enabled; only frontend GIL mode changes."
            if rows and rows[0].get("worker_gil") == "on"
            else "Both frontend and inference workers change GIL mode."
        ),
        "Unprofiled windows; /proc thread samples include warm-up (not GIL waits).",
        "",
        "batch concurrency GIL-on-RPS GIL-off-RPS off/on on-p95-ms off-p95-ms",
    ]
    for batch, concurrency in sorted({(r["batch"], r["concurrency"]) for r in rows}):
        grouped = {
            mode: [
                r
                for r in rows
                if r["batch"] == batch
                and r["concurrency"] == concurrency
                and r["mode"] == mode
            ]
            for mode in ("on", "off")
        }
        if not all(grouped.values()):
            continue
        on, off = (statistics.mean(r["rps"] for r in grouped[m]) for m in ("on", "off"))
        p95 = [
            statistics.mean(r["timings"]["client_ms"]["p95"] for r in grouped[m])
            for m in ("on", "off")
        ]
        lines.append(
            f"{batch:5} {concurrency:11} {on:10.1f} {off:11.1f} "
            f"{off/on:6.3f} {p95[0]:9.2f} {p95[1]:10.2f}"
        )
    return "\n".join(lines) + "\n"


def source_manifest(source: Path, repo: Path = REPO) -> dict[str, Any]:
    files = {}
    changed = []
    for package, original in (
        ("mlserver", repo / "mlserver"),
        ("mlserver_onnx", repo / "runtimes/onnx/mlserver_onnx"),
    ):
        for path in original.rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            relative = path.relative_to(original)
            name = str(Path(package) / relative)
            baseline = hashlib.sha256(path.read_bytes()).hexdigest()
            diagnostic = hashlib.sha256((source / name).read_bytes()).hexdigest()
            files[name] = {"original": baseline, "diagnostic": diagnostic}
            if baseline != diagnostic:
                changed.append(name)
    allowed = {
        "mlserver/__init__.py",
        "mlserver/tracing.py",
        "mlserver/rest/openapi/schema.py",
    }
    if set(changed) != allowed:
        raise RuntimeError(f"Unexpected diagnostic source changes: {changed}")
    return {"changed_files": sorted(changed), "files": files}


def run(args: argparse.Namespace) -> None:
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = {
        "scope": "REST/HTTP JSON only; synthetic CPU ONNX MLP",
        "python_coordinator": sys.version,
        "server_python": str(args.server_python),
        "client_python": str(args.client_python),
        "source": str(args.source),
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "workers": args.workers,
        "worker_gil": args.worker_gil,
        "seconds": args.seconds,
        "repeats": args.repeats,
        "git_commit": os.environ.get("MLSERVER_STUDY_COMMIT")
        or subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
        ).strip(),
        "load_average_before": os.getloadavg(),
        "source_manifest": source_manifest(args.source),
    }
    args.output.joinpath("metadata.json").write_text(
        json.dumps(metadata, indent=2) + "\n"
    )
    rows = []
    for trial in range(args.repeats):
        for batch in args.batches:
            for concurrency in args.concurrencies:
                # Alternate pair order to reduce monotonic thermal/order bias.
                for mode in ("on", "off") if trial % 2 == 0 else ("off", "on"):
                    case = dict(
                        mode=mode, batch=batch, concurrency=concurrency, trial=trial
                    )
                    directory = args.output / f"r{trial}-b{batch}-c{concurrency}-{mode}"
                    print(f"Starting {directory.name}", flush=True)
                    row = run_case(args, case, directory)
                    rows.append(row)
                    args.output.joinpath("results.json").write_text(
                        json.dumps(rows, indent=2) + "\n"
                    )
                    args.output.joinpath("SUMMARY.txt").write_text(summarize(rows))
                    print(
                        f"  {row['rps']:.1f} RPS; frontend "
                        f"{row['server_main_cpu_cores']:.2f} CPU cores",
                        flush=True,
                    )
    print(summarize(rows), flush=True)


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "serve":
        import bench

        args = bench.parse_args()
        bench.install_uvloop_event_loop()
        asyncio.run(bench.serve(args))
        return
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--server-python", type=Path, required=True)
    parser.add_argument("--client-python", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--worker-gil", choices=["matched", "on"], default="matched")
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[2, 64])
    args = parser.parse_args()
    if args.workers < 1 or args.seconds <= 0 or args.repeats < 1:
        parser.error("Workers, seconds and repeats must be positive")
    run(args)


if __name__ == "__main__":
    main()
