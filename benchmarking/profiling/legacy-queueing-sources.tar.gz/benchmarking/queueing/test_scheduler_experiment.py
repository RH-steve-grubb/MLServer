"""Reject confounded scheduler runs, class counts and incomplete timelines."""

import pytest

from . import run_scheduler_experiment as experiment
from .test_frontend_transport import measurement


def result(instrumented: bool = False) -> dict:
    row = measurement("queue")
    row.update(
        workload="medium",
        scheduler="round-robin",
        balance=instrumented,
        completed_in_window=10,
        classes={
            "100": dict(
                total_drained=10,
                completed_in_window=10,
                client_ms=dict(mean=8, p95=10, p99=12),
            )
        },
    )
    for phase in ("before", "after"):
        row["checks"][phase].update(
            scheduler="round-robin", least_outstanding_installed=False
        )
    if instrumented:
        trace = dict(
            worker_pids=list(range(6)),
            window_start_ns=0,
            window_end_ns=1000,
            events=[
                [i % 6, i * 10 + 1, i * 10 + 2, i * 10 + 3, i * 10 + 4, 100]
                for i in range(10)
            ],
            dropped=0,
        )
        trace["metrics"] = experiment.balance.analyze(
            trace["events"], trace["worker_pids"], (0, 1000)
        )
        row["balance_trace"] = trace
    return row


@pytest.mark.parametrize("instrumented", [False, True])
def test_validated_scheduler_controls(instrumented: bool) -> None:
    experiment.validate(result(instrumented))


@pytest.mark.parametrize("phase", ["before", "after"])
@pytest.mark.parametrize(
    "field,value",
    [("scheduler", "least-outstanding"), ("least_outstanding_installed", True)],
)
def test_rejects_uninstalled_scheduler(phase: str, field: str, value: object) -> None:
    row = result()
    row["checks"][phase][field] = value
    with pytest.raises(ValueError, match="Scheduler control"):
        experiment.validate(row)


@pytest.mark.parametrize("field", ["total_drained", "completed_in_window"])
def test_rejects_missing_class_completions(field: str) -> None:
    row = result()
    row["classes"]["100"][field] -= 1
    with pytest.raises(ValueError, match="per-class"):
        experiment.validate(row)


def test_rejects_wrong_request_classes() -> None:
    row = result()
    row["workload"] = "large"
    with pytest.raises(ValueError, match="request classes"):
        experiment.validate(row)


@pytest.mark.parametrize(
    "defect", ["missing", "dropped", "count", "workers", "class", "metrics"]
)
def test_rejects_incomplete_trace(defect: str) -> None:
    row = result(True)
    trace = row["balance_trace"]
    if defect == "missing":
        del row["balance_trace"]
    elif defect == "dropped":
        trace["dropped"] = 1
    elif defect == "count":
        trace["events"].pop()
    elif defect == "workers":
        trace["worker_pids"] = [0] * 6
    elif defect == "class":
        trace["events"][0][5] = 1000
    else:
        trace["metrics"]["requests"] = 99
    with pytest.raises(ValueError):
        experiment.validate(row)


def test_rejects_trace_in_performance_control() -> None:
    row = result(True)
    row["balance"] = False
    with pytest.raises(ValueError, match="unexpectedly instrumented"):
        experiment.validate(row)


def test_summary_keeps_trace_and_performance_separate() -> None:
    text = experiment.summarize([result(), result(True)])
    assert "perf" in text and "trace" in text
    assert "not use trace RPS as capacity" in text
    assert "mean/p95/p99" in text and "waiting_stddev_rms" in text
