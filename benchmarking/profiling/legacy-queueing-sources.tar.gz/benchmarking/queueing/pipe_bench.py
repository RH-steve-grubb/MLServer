"""Compare pickle and MessagePack over identical anonymous multiprocessing pipes.

Two parent threads send and receive while an asyncio heartbeat measures their
interference with the parent event loop. A separate spawned process decodes and
re-encodes each message. List and ndarray representations are separate controls;
arrays are constructed before timing, not converted for free inside the test.
No ONNX compute or HTTP traffic is included in this transport-only experiment.
"""

import argparse
import asyncio
import contextlib
import importlib.metadata
import json
import multiprocessing
import pickle
import resource
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import msgpack
import msgpack_numpy
import numpy as np


class Codec:
    def __init__(self, mode: str) -> None:
        self.mode = mode

    def dumps(self, value: Any) -> bytes:
        if self.mode.startswith("pickle"):
            return pickle.dumps(value, protocol=4)
        if self.mode.endswith("array"):
            return msgpack.packb(value, default=msgpack_numpy.encode)
        return msgpack.packb(value)

    def loads(self, value: bytes) -> Any:
        if self.mode.startswith("pickle"):
            return pickle.loads(value)
        if self.mode.endswith("array"):
            return msgpack.unpackb(value, object_hook=msgpack_numpy.decode)
        return msgpack.unpackb(value)


def echo_worker(receiver: Any, sender: Any, mode: str) -> None:
    codec = Codec(mode)
    try:
        while True:
            packed = receiver.recv_bytes()
            if not packed:
                sender.send_bytes(b"")
                return
            sender.send_bytes(codec.dumps(codec.loads(packed)))
    finally:
        receiver.close()
        sender.close()


def statistics(values: list[float]) -> dict[str, float]:
    if not values:
        return {}
    percentiles = np.percentile(values, [50, 95, 99, 100])
    return {
        key: float(value)
        for key, value in zip(("p50", "p95", "p99", "max"), percentiles)
    }


async def heartbeat(delays: list[float]) -> None:
    previous = time.perf_counter()
    while True:
        await asyncio.sleep(0.001)
        current = time.perf_counter()
        delays.append(max(0, current - previous - 0.001) * 1000)
        previous = current


async def run_case(args: argparse.Namespace, mode: str, batch: int) -> dict:
    codec = Codec(mode)
    array = np.random.default_rng(7).normal(size=(batch, 54)).astype(np.float32)
    data = array if mode.endswith("array") else array.ravel().tolist()
    context = multiprocessing.get_context("spawn")
    child_reader, parent_writer = context.Pipe(duplex=False)
    parent_reader, child_writer = context.Pipe(duplex=False)
    process = context.Process(
        target=echo_worker, args=(child_reader, child_writer, mode)
    )
    executor = ThreadPoolExecutor(max_workers=2)
    stop = threading.Event()
    slots = threading.Semaphore(args.inflight)
    lag: list[float] = []
    packed_times: list[float] = []
    unpacked_times: list[float] = []
    latencies: list[float] = []
    count = 0
    sent = 0
    monitor = None
    finished = False
    process.start()
    child_reader.close()
    child_writer.close()
    try:
        # Numerical validation and process startup are outside the measurement
        # window and heartbeat, including converting restored lists to arrays.
        warmup = codec.dumps({"tensor": data, "sent_ns": time.perf_counter_ns()})
        parent_writer.send_bytes(warmup)
        if not parent_reader.poll(15):
            raise TimeoutError("Pipe worker warm-up timed out")
        restored = codec.loads(parent_reader.recv_bytes())["tensor"]
        np.testing.assert_array_equal(
            np.asarray(restored, dtype=np.float32).reshape(array.shape), array
        )
        monitor = asyncio.create_task(heartbeat(lag))
        await asyncio.sleep(0.01)
        lag.clear()
        usage = resource.getrusage(resource.RUSAGE_SELF)
        cpu_start = usage.ru_utime + usage.ru_stime
        started = time.perf_counter()
        deadline = started + args.seconds

        def send() -> None:
            nonlocal sent
            while not stop.is_set() and time.perf_counter() < deadline:
                if not slots.acquire(timeout=0.1):
                    continue
                if stop.is_set() or time.perf_counter() >= deadline:
                    slots.release()
                    break
                message = {"tensor": data, "sent_ns": time.perf_counter_ns()}
                before = time.perf_counter()
                packed = codec.dumps(message)
                packed_times.append((time.perf_counter() - before) * 1000)
                parent_writer.send_bytes(packed)
                sent += 1
            if not stop.is_set():
                parent_writer.send_bytes(b"")

        def receive() -> None:
            nonlocal count
            while True:
                packed = parent_reader.recv_bytes()
                if not packed:
                    return
                before = time.perf_counter()
                message = codec.loads(packed)
                unpacked_times.append((time.perf_counter() - before) * 1000)
                completed = time.perf_counter()
                latencies.append(
                    (time.perf_counter_ns() - message["sent_ns"]) / 1_000_000
                )
                if completed <= deadline:
                    count += 1
                slots.release()

        sending = executor.submit(send)
        receiving = executor.submit(receive)
        await asyncio.wait_for(asyncio.wrap_future(receiving), args.seconds + 30)
        await asyncio.wrap_future(sending)
        ended = time.perf_counter()
        usage = resource.getrusage(resource.RUSAGE_SELF)
        monitor.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await monitor
        process.join(10)
        if process.exitcode != 0:
            raise RuntimeError(f"Pipe worker failed: {process.exitcode}")
        if sent != len(latencies):
            raise RuntimeError("Pipe benchmark lost responses while draining")
        finished = True
        return {
            "mode": mode,
            "batch": batch,
            "inflight": args.inflight,
            "seconds": args.seconds,
            "rps": count / args.seconds,
            "completed_in_window": count,
            "sent_and_drained": sent,
            "drain_seconds": max(0, ended - deadline),
            "wire_bytes": len(warmup),
            "parent_cpu_cores": (usage.ru_utime + usage.ru_stime - cpu_start)
            / (ended - started),
            "loop_lag_ms": statistics(lag),
            "heartbeat_samples": len(lag),
            "serialize_ms": statistics(packed_times),
            "deserialize_ms": statistics(unpacked_times),
            "latency_ms": statistics(latencies),
        }
    finally:
        stop.set()
        if monitor:
            monitor.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await monitor
        # Closing a descriptor in another thread need not interrupt read().
        # Stop our own child first on failure so its peer closure releases I/O.
        if not finished and process.is_alive():
            process.terminate()
            process.join(10)
            if process.is_alive():
                process.kill()
                process.join()
        parent_writer.close()
        parent_reader.close()
        await asyncio.to_thread(executor.shutdown, wait=True, cancel_futures=True)
        process.close()


async def main(args: argparse.Namespace) -> None:
    rows = []
    for batch in args.batches:
        for trial in range(args.repeats):
            # Reverse alternating trials to reduce codec order/thermal bias.
            modes = args.modes if trial % 2 == 0 else list(reversed(args.modes))
            for mode in modes:
                row = await run_case(args, mode, batch)
                row["trial"] = trial
                rows.append(row)
                print(json.dumps(row), flush=True)
                if args.output:
                    args.output.write_text(
                        json.dumps(
                            {
                                "python": sys.version,
                                "libraries": {
                                    name: importlib.metadata.version(name)
                                    for name in ("numpy", "msgpack", "msgpack-numpy")
                                },
                                "tensor_values": "deterministic FP32; 54 features",
                                "transport": "two anonymous pipes; echo round trip",
                                "heartbeat_interval_ms": 1,
                                "msgpack_packer": msgpack.Packer.__module__,
                                "results": rows,
                            },
                            indent=2,
                        )
                        + "\n"
                    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batches", type=int, nargs="+", default=[100, 1000])
    parser.add_argument("--seconds", type=float, default=3)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--inflight", type=int, default=32)
    parser.add_argument("--output", type=Path)
    parser.add_argument(
        "--modes",
        nargs="+",
        choices=["pickle-list", "msgpack-list", "pickle-array", "msgpack-array"],
        default=["pickle-list", "msgpack-list", "pickle-array", "msgpack-array"],
    )
    options = parser.parse_args()
    if options.seconds <= 0 or options.inflight <= 0 or options.repeats <= 0:
        parser.error("seconds, inflight and repeats must be positive")
    if any(batch <= 0 for batch in options.batches):
        parser.error("batches must be positive")
    asyncio.run(main(options))
