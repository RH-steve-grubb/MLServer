"""Opt-in worker-side JSON diagnostic over Queue or diagnostic ZeroMQ/pickle.

Input mode moves parsing/validation and DataPlane preparation to workers but
retains normal FastAPI response serialization. Full mode additionally returns
worker-encoded JSON bytes. HTTP/IPC adapters are selected separately; no
shared memory or production route is installed outside explicit opt-in.
"""

import asyncio
import json
import os
from dataclasses import dataclass, field
from typing import Any

from fastapi import Request, Response
from fastapi.encoders import jsonable_encoder
from pydantic import TypeAdapter, ValidationError

from mlserver.codecs.json import (
    decode_from_bytelike_json_to_dict,
    encode_to_json_bytes,
)
from mlserver.errors import ModelNotReady
from mlserver.handlers import DataPlane
from mlserver.parallel.errors import WorkerError
from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.model import ParallelModel
from mlserver.parallel.worker import Worker
from mlserver.registry import MultiModelRegistry
from mlserver.rest import RESTServer
from mlserver.rest.app import APIRoute
from mlserver.types import InferenceRequest, InferenceResponse
from mlserver.utils import extract_headers, insert_headers

METHOD = "__queue_diagnostic_raw_infer__"
PATHS = (
    "/v2/models/{model_name}/infer",
    "/v2/models/{model_name}/versions/{model_version}/infer",
)
COUNTS = {"requests": 0, "input_bytes": 0, "worker_replies": 0, "byte_replies": 0}
_ORIGINAL_PROCESS = Worker._process_request
_RESPONSE_ADAPTER = TypeAdapter(InferenceResponse)


@dataclass
class RawReply:
    body: bytes | InferenceResponse
    headers: dict[str, str]
    status: int = 200
    worker_pid: int = field(default_factory=os.getpid)


def validation_reply(errors: list[dict[str, Any]]) -> RawReply:
    return RawReply(
        encode_to_json_bytes({"detail": jsonable_encoder(errors)}), {}, status=422
    )


def parse_body(body: bytes) -> InferenceRequest | RawReply:
    # Deliberately keep the existing orjson -> Python objects -> Pydantic path.
    # A fused model_validate_json() would be another optimization/confound.
    if not body:
        return validation_reply(
            [
                {
                    "type": "missing",
                    "loc": ("body",),
                    "msg": "Field required",
                    "input": None,
                }
            ]
        )
    try:
        decoded = decode_from_bytelike_json_to_dict(body)
    except json.JSONDecodeError as error:
        return validation_reply(
            [
                {
                    "type": "json_invalid",
                    "loc": ("body", error.pos),
                    "msg": "JSON decode error",
                    "input": {},
                    "ctx": {"error": error.msg},
                }
            ]
        )
    try:
        return InferenceRequest.model_validate(decoded, from_attributes=True)
    except ValidationError as error:
        errors: list[dict[str, Any]] = [
            dict(item) for item in error.errors(include_url=False)
        ]
        for item in errors:
            item["loc"] = ("body", *tuple(item["loc"]))
        return validation_reply(errors)


def encode_response(response: InferenceResponse) -> bytes:
    # Mirror FastAPI's validated response schema and serialization flags.
    checked = _RESPONSE_ADAPTER.validate_python(response, from_attributes=True)
    content = _RESPONSE_ADAPTER.dump_python(
        checked, mode="json", by_alias=True, exclude_unset=True, exclude_none=True
    )
    return encode_to_json_bytes(content)


async def process_request(
    self: Worker, request: ModelRequestMessage
) -> ModelResponseMessage:
    if request.method_name != METHOD:
        return await _ORIGINAL_PROCESS(self, request)
    try:
        body, headers = request.method_args
        if not isinstance(body, bytes) or not isinstance(headers, dict):
            raise TypeError("Raw diagnostic requires body bytes and HTTP headers")
        payload = parse_body(body)
        if isinstance(payload, RawReply):
            return ModelResponseMessage(id=request.id, return_value=payload)
        insert_headers(payload, headers)
        data_plane = getattr(self, "_queue_raw_data_plane", None)
        if data_plane is None:
            # One instance per spawned worker. Core inference metrics and
            # CloudEvents processing move with the DataPlane, not disappear.
            data_plane = DataPlane(self._settings, self._model_registry)
            setattr(self, "_queue_raw_data_plane", data_plane)
        response = await data_plane.infer(
            payload, request.model_name, request.model_version
        )
        response_headers = extract_headers(response) or {}
        result = (
            encode_response(response)
            if os.environ["MLSERVER_QUEUE_JSON"] == "full"
            else response
        )
        return ModelResponseMessage(
            id=request.id, return_value=RawReply(result, response_headers)
        )
    except (Exception, asyncio.CancelledError) as error:
        return ModelResponseMessage(id=request.id, exception=WorkerError(error))


class RawEndpoints:
    def __init__(self, registry: MultiModelRegistry):
        self.registry = registry

    async def resolve_model(self, name: str, version: str | None) -> ParallelModel:
        # Resolve the actual version and its pool through the original parent
        # registry; do not hardcode a model or bypass request-time selection.
        model = await self.registry.get_model(name, version)
        if not model.ready:
            raise ModelNotReady(name, version)
        if not isinstance(model, ParallelModel):
            raise TypeError("Raw diagnostic requires a parallel model")
        return model

    async def dispatch_body(
        self, model: ParallelModel, body: bytes, headers: dict[str, str]
    ) -> RawReply:
        # Both HTTP implementations call this exact boundary. Framework tests
        # must not accidentally select different envelopes or worker work.
        message = ModelRequestMessage(
            model_name=model.name,
            model_version=model.version,
            method_name=METHOD,
            method_args=[body, headers],
        )
        COUNTS["requests"] += 1
        COUNTS["input_bytes"] += len(body)
        response = await model._dispatcher.dispatch_request(message)
        reply = response.return_value
        if not isinstance(reply, RawReply) or reply.worker_pid == os.getpid():
            raise TypeError("Raw diagnostic did not receive a worker-side reply")
        COUNTS["worker_replies"] += 1
        if isinstance(reply.body, bytes):
            COUNTS["byte_replies"] += 1
        return reply

    async def dispatch(self, request: Request) -> RawReply:
        model = await self.resolve_model(
            request.path_params["model_name"],
            request.path_params.get("model_version"),
        )
        return await self.dispatch_body(
            model, await request.body(), dict(request.headers)
        )

    async def input_only(self, request: Request, response: Response) -> Any:
        reply = await self.dispatch(request)
        if reply.status != 200:
            return Response(
                reply.body,
                status_code=reply.status,
                headers=reply.headers,
                media_type="application/json",
            )
        if not isinstance(reply.body, InferenceResponse):
            raise TypeError("Input-only mode requires the original response object")
        response.headers.update(reply.headers)
        return reply.body

    async def full(self, request: Request) -> Response:
        reply = await self.dispatch(request)
        if not isinstance(reply.body, bytes):
            raise TypeError("Full mode requires worker-encoded response bytes")
        return Response(
            reply.body,
            status_code=reply.status,
            headers=reply.headers,
            media_type="application/json",
        )


def install_routes(server: RESTServer, registry: MultiModelRegistry) -> None:
    endpoints = RawEndpoints(registry)
    full = os.environ["MLSERVER_QUEUE_JSON"] == "full"
    for index, route in enumerate(server._app.router.routes):
        path = getattr(route, "path", None)
        if path in PATHS:
            server._app.router.routes[index] = APIRoute(
                path,
                endpoints.full if full else endpoints.input_only,
                methods=["POST"],
                response_model=None if full else InferenceResponse,
            )


def install() -> None:
    """Install worker parsing only for explicitly selected diagnostic modes."""
    if os.environ.get("MLSERVER_QUEUE_JSON") not in ("input", "full"):
        raise ValueError("Raw diagnostic requires input or full JSON mode")
    if any(
        os.environ.get(key, default) != default
        for key, default in (
            ("MLSERVER_QUEUE_CODEC", "pickle"),
            ("MLSERVER_QUEUE_TENSORS", "list"),
        )
    ) or os.environ.get("MLSERVER_QUEUE_TRANSPORT", "queue") not in ("queue", "zmq"):
        raise ValueError("Raw diagnostic requires Queue or ZeroMQ with pickle/list")
    setattr(Worker, "_process_request", process_request)
