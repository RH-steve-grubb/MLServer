"""Verify worker timelines distinguish assignment fairness from waiting."""

from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest

from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.worker import Worker

from . import raw_worker, worker_balance as balance


async def test_equal_busy_workers_do_not_report_a_scheduler_opportunity() -> None:
    events = [[pid, 1, 2, 8, 9] for pid in range(1, 7)]
    metrics = balance.analyze(events, list(range(1, 7)), (0, 10))
    assert metrics["busy_workers_mean"] == pytest.approx(3.6)
    assert metrics["idle_with_backlog_fraction"] == 0
    for pid in range(1, 7):
        assert metrics[f"worker_{pid}_requests"] == 1
        assert metrics[f"worker_{pid}_busy_fraction"] == pytest.approx(0.6)


async def test_backlog_behind_busy_worker_with_an_idle_peer() -> None:
    events = [[1, 0, 1, 8, 8], [1, 2, 9, 10, 10]]
    metrics = balance.analyze(events, [1, 2], (0, 12))
    assert metrics["idle_with_backlog_fraction"] == pytest.approx(0.5)
    assert metrics["busy_workers_mean"] == pytest.approx(8 / 12)
    assert metrics["waiting_count_skew_max"] == 1
    assert metrics["worker_2_requests"] == 0


async def test_in_transit_requests_alone_are_not_a_busy_worker_backlog() -> None:
    metrics = balance.analyze([[1, 1, 5, 6, 7], [2, 2, 5, 6, 7]], [1, 2], (0, 8))
    assert metrics["idle_with_backlog_fraction"] == 0
    assert metrics["admission_mean_ms"] > 0


async def test_simultaneous_and_zero_duration_transitions_are_valid() -> None:
    events = [[1, 0, 0, 5, 5], [1, 5, 5, 5, 5], [1, 5, 5, 10, 10]]
    metrics = balance.analyze(events, [1], (0, 10))
    assert metrics["requests"] == 3
    assert metrics["busy_workers_mean"] == 1


@pytest.mark.parametrize(
    "events",
    [
        [[9, 1, 2, 3, 4]],
        [[1, -1, 2, 3, 4]],
        [[1, 3, 2, 3, 4]],
        [[1, 1, 2, 11, 12]],
        [[1, 1, 2, 7, 8], [1, 3, 4, 8, 9]],
    ],
)
async def test_invalid_or_overlapping_events_are_rejected(events: list) -> None:
    with pytest.raises(ValueError):
        balance.analyze(events, [1, 2], (0, 10))


@pytest.mark.parametrize("capacity", [0, 10])
async def test_install_records_and_strips_only_diagnostic_headers(
    capacity: int, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "full")
    monkeypatch.setattr(balance, "EVENTS", [])
    monkeypatch.setattr(balance, "MAX_EVENTS", capacity)
    monkeypatch.setattr(balance, "DROPPED", 0)
    reply = raw_worker.RawReply(b"{}", {"x-test": "retained"}, worker_pid=11)
    process = AsyncMock(
        return_value=ModelResponseMessage(id="test", return_value=reply)
    )
    monkeypatch.setattr(Worker, "_process_request", process)

    async def dispatch(self: Any, model: Any, body: bytes, headers: dict) -> Any:
        response = await Worker._process_request(
            Mock(),
            ModelRequestMessage(model_name="test", method_name=raw_worker.METHOD),
        )
        return response.return_value

    monkeypatch.setattr(raw_worker.RawEndpoints, "dispatch_body", dispatch)
    balance.install()
    endpoint = raw_worker.RawEndpoints(Mock())
    result = await endpoint.dispatch_body(Mock(), b"{}", {})
    assert result is reply
    assert result.headers == {"x-test": "retained"}
    if capacity:
        assert len(balance.EVENTS) == 1 and balance.EVENTS[0][0] == 11
        assert balance.EVENTS[0][1:] == sorted(balance.EVENTS[0][1:])
    else:
        assert not balance.EVENTS and balance.DROPPED == 1


async def test_sampling_clears_window_and_preserves_full_trace(
    monkeypatch: Any,
) -> None:
    now = balance.time.perf_counter_ns()
    monkeypatch.setattr(balance, "WINDOW_START", now - 10)
    monkeypatch.setattr(balance, "EVENTS", [[1, now - 9, now - 8, now - 7, now - 6]])
    monkeypatch.setattr(balance, "LAST", {})
    monkeypatch.setattr(balance, "DROPPED", 0)
    balance.sample([1])
    trace = balance.snapshot()
    assert trace["metrics"]["requests"] == 1
    assert len(trace["events"]) == 1 and not balance.EVENTS
    assert balance.WINDOW_START >= trace["window_end_ns"]


async def test_install_rejects_input_only_worker_json(monkeypatch: Any) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "input")
    with pytest.raises(ValueError):
        balance.install()
