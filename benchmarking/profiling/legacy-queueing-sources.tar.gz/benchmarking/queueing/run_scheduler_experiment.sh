#!/usr/bin/env bash
set -euo pipefail

SCHEDULER_STORE=${MLSERVER_SCHEDULER_STORE:-/home/codex/mlserver-durable-store/scheduler-20261008}
SCHEDULER_CLIENT=/home/codex/tmp/mlserver-perf-venvs/mlserver-bnlygABv-py3.12/bin/python
SCHEDULER_SERVER=/home/codex/mlserver-durable-store/frontend-transport-20261008/poetry-project/.venv/bin/python

export MLSERVER_STUDY_REPO="$SCHEDULER_STORE/source-original"
exec "$SCHEDULER_CLIENT" "$SCHEDULER_STORE/harness/run_scheduler_experiment.py" \
    --server-python "$SCHEDULER_SERVER" \
    --client-python "$SCHEDULER_CLIENT" \
    --source "$SCHEDULER_STORE/source" \
    --model "$SCHEDULER_STORE/mlserver-queue-mlp.onnx" \
    --output "$SCHEDULER_STORE/run-$(date -u +%Y%m%dT%H%M%SZ)-$$" \
    "$@"
