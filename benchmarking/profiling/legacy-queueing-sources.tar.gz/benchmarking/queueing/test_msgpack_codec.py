"""Check the diagnostic codec, not a production serialization contract."""

import pickle
from multiprocessing import queues, reduction
from typing import Any

import pytest

from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.types import (
    InferenceRequest,
    InferenceResponse,
    Parameters,
    RequestInput,
    ResponseOutput,
)

from . import msgpack_codec as codec


def request_message() -> ModelRequestMessage:
    request = InferenceRequest(
        id="request-id",
        parameters=Parameters(headers={"custom": "value"}, extra_parameter=42),
        inputs=[
            RequestInput(
                name="input", shape=[1, 3], datatype="FP32", data=[0.0, -1.5, 2.0]
            )
        ],
    )
    return ModelRequestMessage(
        model_name="test", method_name="predict", method_args=[request]
    )


def response_message() -> ModelResponseMessage:
    response = InferenceResponse(
        model_name="test",
        id="request-id",
        outputs=[
            ResponseOutput(
                name="output", shape=[1, 3], datatype="FP32", data=[0.0, -1.5, 2.0]
            )
        ],
    )
    return ModelResponseMessage(id="response-id", return_value=response)


@pytest.mark.parametrize("message", [request_message(), response_message()])
async def test_protocol_round_trip(message: Any) -> None:
    before = codec.COUNTS.copy()
    packed = codec.QueueCodec.dumps(message)
    assert packed[0] == 0x92
    restored = codec.QueueCodec.loads(packed)
    assert type(restored) is type(message)
    assert restored == message
    # Field presence controls exclude_unset JSON output. Preserve it, not just
    # the values; model_construct() must not make default fields explicit.
    assert restored.model_dump(exclude_unset=True) == message.model_dump(
        exclude_unset=True
    )
    assert codec.COUNTS["packed"] == before["packed"] + 1
    assert codec.COUNTS["unpacked"] == before["unpacked"] + 1
    assert codec.COUNTS["fallback"] == before["fallback"]


@pytest.mark.parametrize("value", [None, True, {"control": "unchanged"}])
async def test_control_messages_use_original_pickle(value: Any) -> None:
    packed = codec.QueueCodec.dumps(value)
    assert bytes(packed) == bytes(codec._ORIGINAL.dumps(value))
    assert codec.QueueCodec.loads(packed) == value


async def test_error_response_falls_back_without_losing_exception() -> None:
    message = ModelResponseMessage(id="error", exception=ValueError("test error"))
    before = codec.COUNTS["fallback"]
    packed = codec.QueueCodec.dumps(message)
    restored = codec.QueueCodec.loads(packed)
    assert isinstance(restored.exception, ValueError)
    assert str(restored.exception) == "test error"
    assert codec.COUNTS["fallback"] == before + 1


async def test_install_changes_only_queue_codec(monkeypatch: Any) -> None:
    startup_pickler = reduction.ForkingPickler
    monkeypatch.setattr(queues, "_ForkingPickler", codec._ORIGINAL)
    codec.install()
    assert getattr(queues, "_ForkingPickler") is codec.QueueCodec
    assert reduction.ForkingPickler is startup_pickler
    assert pickle.loads(bytes(codec.QueueCodec.dumps(None))) is None
