"""Validate the input-only buffer experiment separately from production code."""

from unittest.mock import AsyncMock, Mock
from typing import Any

import numpy as np
import pytest

from mlserver.codecs import NumpyCodec
from mlserver.parallel.messages import ModelRequestMessage
from mlserver.types import InferenceRequest, RequestInput

from . import msgpack_codec, tensor_dispatch


def request() -> InferenceRequest:
    return InferenceRequest(
        id="client-id",
        parameters={"headers": {"custom": "unchanged"}},
        inputs=[
            RequestInput(
                name="input", shape=[1, 3], datatype="FP32", data=[0.0, -1.5, 2.0]
            )
        ],
    )


async def test_compact_request_preserves_values_and_caller() -> None:
    original = request()
    snapshot = original.model_dump()
    before = tensor_dispatch.COUNTS.copy()
    compact = tensor_dispatch.compact_request(original)
    assert compact is not original
    assert original.model_dump() == snapshot
    assert compact.id == original.id
    assert compact.parameters == original.parameters
    assert compact.model_fields_set == original.model_fields_set
    assert compact.inputs[0].model_fields_set == original.inputs[0].model_fields_set
    data = compact.inputs[0].data.root
    assert isinstance(data, np.ndarray)
    assert data.dtype == np.float32
    assert data.shape == (1, 3)
    assert data.flags.c_contiguous
    np.testing.assert_array_equal(
        NumpyCodec.decode_input(compact.inputs[0]),
        NumpyCodec.decode_input(original.inputs[0]),
    )
    assert tensor_dispatch.COUNTS["requests"] == before["requests"] + 1
    assert tensor_dispatch.COUNTS["inputs"] == before["inputs"] + 1
    assert tensor_dispatch.COUNTS["bytes"] == before["bytes"] + 12


async def test_each_original_request_is_converted_not_cached() -> None:
    original = request()
    before = tensor_dispatch.COUNTS["requests"]
    first = tensor_dispatch.compact_request(original)
    second = tensor_dispatch.compact_request(original)
    assert first.inputs[0].data.root is not second.inputs[0].data.root
    assert tensor_dispatch.COUNTS["requests"] == before + 2
    assert tensor_dispatch.compact_request(first) is first


@pytest.mark.parametrize("datatype,value", [("FP64", 1.1), ("INT64", 2**63 - 1)])
async def test_other_numeric_datatypes_are_not_forced_to_fp32(
    datatype: str, value: float | int
) -> None:
    original = InferenceRequest(
        inputs=[RequestInput(name="other", shape=[1], datatype=datatype, data=[value])]
    )
    assert tensor_dispatch.compact_request(original) is original
    assert original.inputs[0].data.root == [value]


@pytest.mark.parametrize("codec", [msgpack_codec._ORIGINAL, msgpack_codec.QueueCodec])
async def test_buffer_survives_queue_serialization(codec: Any) -> None:
    original = request()
    compact = tensor_dispatch.compact_request(original)
    message = ModelRequestMessage(
        model_name="queue-mlp", method_name="predict", method_args=[compact]
    )
    before = msgpack_codec.COUNTS["fallback"]
    restored = codec.loads(codec.dumps(message))
    assert restored.id == message.id
    assert restored.model_name == message.model_name
    assert restored.method_name == "predict"
    tensor = restored.method_args[0].inputs[0]
    assert isinstance(tensor.data.root, np.ndarray)
    assert tensor.data.root.dtype == np.float32
    assert tensor.shape == [1, 3]
    # msgpack-numpy can decode a read-only view. The unmodified worker codec
    # must still deliver the ordinary writable array to ONNX.
    decoded = NumpyCodec.decode_input(tensor)
    assert decoded.flags.writeable
    np.testing.assert_array_equal(decoded, NumpyCodec.decode_input(original.inputs[0]))
    assert msgpack_codec.COUNTS["fallback"] == before


@pytest.mark.parametrize("name", ["queue-mlp", "other-model"])
async def test_prediction_hook_is_scoped_to_benchmark_model(
    name: str, monkeypatch: Any
) -> None:
    model = Mock()
    model.name = name
    original = AsyncMock(return_value=Mock())
    monkeypatch.setattr(tensor_dispatch, "_ORIGINAL", original)
    payload = request()
    result = await tensor_dispatch.buffered_predict(model, payload)
    assert result is original.return_value
    passed_model, passed_payload = original.call_args.args
    assert passed_model is model
    if name == "queue-mlp":
        assert isinstance(passed_payload.inputs[0].data.root, np.ndarray)
    else:
        assert passed_payload is payload


async def test_bytes_request_is_unchanged() -> None:
    original = InferenceRequest(
        inputs=[RequestInput(name="text", shape=[1], datatype="BYTES", data=["text"])]
    )
    assert tensor_dispatch.compact_request(original) is original


async def test_multiple_inputs_keep_order_and_unconverted_data() -> None:
    original = request()
    integer = RequestInput(name="integer", shape=[1], datatype="INT64", data=[42])
    other = RequestInput(name="other", shape=[1, 2], datatype="FP32", data=[3.0, 4.0])
    original.inputs.extend([integer, other])
    before = tensor_dispatch.COUNTS.copy()
    compact = tensor_dispatch.compact_request(original)
    assert [tensor.name for tensor in compact.inputs] == ["input", "integer", "other"]
    assert compact.inputs[1] is integer
    assert isinstance(compact.inputs[0].data.root, np.ndarray)
    assert isinstance(compact.inputs[2].data.root, np.ndarray)
    assert tensor_dispatch.COUNTS["inputs"] == before["inputs"] + 2
    assert tensor_dispatch.COUNTS["bytes"] == before["bytes"] + 20
