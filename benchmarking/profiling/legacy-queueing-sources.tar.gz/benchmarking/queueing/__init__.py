"""Diagnostic ONNX serving and IPC experiments; not production server code."""
