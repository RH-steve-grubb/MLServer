"""Reject confounded framework/transport comparisons and incomplete traces."""

from typing import Any

import pytest

from . import test_pending_experiments as pending
from .run_http_experiments import VARIANTS, validate


def document(variant: str, balance: bool = False) -> dict[str, Any]:
    http, transport, mode = VARIANTS[variant]
    doc = pending.document("worker-json-1x6" if mode == "full" else "stock-1x6")
    doc["metadata"].update(
        http_framework=http, queue_transport=transport, balance_instrumented=balance
    )
    row = doc["results"][0]
    row.update(
        http_framework=http,
        queue_transport=transport,
        execution="inline",
        response_pump=False,
        stock=False,
        http_counts={"http_aiohttp_replies": 10} if http == "aiohttp" else {},
        transport_counts=(
            {"transport_sent": 10, "transport_received": 10}
            if transport == "zmq"
            else {}
        ),
    )
    if balance:
        row["balance_trace"] = {
            "worker_pids": list(range(1, 7)),
            "window_start_ns": 0,
            "window_end_ns": 1000,
            "events": [
                [i % 6 + 1, i * 10 + 1, i * 10 + 2, i * 10 + 3, i * 10 + 4]
                for i in range(10)
            ],
            "dropped": 0,
        }
    return doc


@pytest.mark.parametrize("variant", list(VARIANTS))
async def test_expected_factorial_variant(variant: str) -> None:
    validate(document(variant), variant)


@pytest.mark.parametrize("variant", [v for v in VARIANTS if v.startswith("raw-")])
async def test_expected_balance_variant(variant: str) -> None:
    validate(document(variant, True), variant, True)


@pytest.mark.parametrize(
    "key,value",
    [
        ("errors", ["failed"]),
        ("total_drained", 0),
        ("rps", float("nan")),
        ("rps", float("inf")),
        ("rps", 0),
        ("frontends", 2),
        ("total_workers", 32),
        ("threads", 4),
        ("execution", "thread"),
        ("response_pump", True),
        ("stock", True),
        ("queue_codec", "msgpack"),
        ("queue_tensors", "numpy"),
        ("queue_json", "input"),
        ("queue_transport", "queue"),
        ("http_framework", "fastapi"),
        ("http_counts", {}),
        (
            "raw_counts",
            {
                "raw_requests": 0,
                "raw_worker_replies": 0,
                "raw_byte_replies": 0,
                "raw_input_bytes": 0,
            },
        ),
        ("transport_counts", {"transport_sent": 10, "transport_received": 9}),
        ("balance_trace", {}),
    ],
)
async def test_rejects_confounded_or_unexercised_variant(key: str, value: Any) -> None:
    doc = document("raw-aiohttp-zmq")
    doc["results"][0][key] = value
    with pytest.raises(ValueError):
        validate(doc, "raw-aiohttp-zmq")


@pytest.mark.parametrize(
    "key",
    [
        "http_framework",
        "queue_transport",
        "queue_json",
        "probed",
        "balance_instrumented",
    ],
)
async def test_metadata_mismatch_is_rejected(key: str) -> None:
    doc = document("raw-aiohttp-zmq")
    doc["metadata"][key] = "incorrect"
    with pytest.raises(ValueError):
        validate(doc, "raw-aiohttp-zmq")


@pytest.mark.parametrize(
    "defect", ["missing", "count", "pid", "order", "bounds", "dropped", "workers"]
)
async def test_incomplete_balance_trace_is_rejected(defect: str) -> None:
    doc = document("raw-aiohttp-zmq", True)
    trace = doc["results"][0]["balance_trace"]
    if defect == "missing":
        del doc["results"][0]["balance_trace"]
    elif defect == "count":
        trace["events"].pop()
    elif defect == "pid":
        trace["events"][0][0] = 999
    elif defect == "order":
        trace["events"][0][2] = 0
    elif defect == "bounds":
        trace["window_end_ns"] = 5
    elif defect == "workers":
        trace["worker_pids"] = [1] * 6
    else:
        trace["dropped"] = 1
    with pytest.raises(ValueError):
        validate(doc, "raw-aiohttp-zmq", True)
