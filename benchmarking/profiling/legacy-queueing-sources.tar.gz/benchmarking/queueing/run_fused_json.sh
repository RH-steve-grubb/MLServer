#!/usr/bin/env bash
set -euo pipefail

FUSED_STORE=${MLSERVER_FUSED_JSON_STORE:-/home/codex/mlserver-durable-store/fused-json-20261008}
FUSED_CLIENT=/home/codex/tmp/mlserver-perf-venvs/mlserver-bnlygABv-py3.12/bin/python
FUSED_SERVER=/home/codex/mlserver-durable-store/frontend-transport-20261008/poetry-project/.venv/bin/python

export MLSERVER_STUDY_REPO="$FUSED_STORE/source-original"
exec "$FUSED_CLIENT" "$FUSED_STORE/harness/run_fused_json.py" \
    --server-python "$FUSED_SERVER" \
    --client-python "$FUSED_CLIENT" \
    --source "$FUSED_STORE/source" \
    --model "$FUSED_STORE/mlserver-queue-mlp.onnx" \
    --output "$FUSED_STORE/run-$(date -u +%Y%m%dT%H%M%SZ)-$$" \
    "$@"
