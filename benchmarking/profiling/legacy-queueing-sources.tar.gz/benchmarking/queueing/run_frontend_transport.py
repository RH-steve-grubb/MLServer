"""Matched no-GIL REST JSON placement / Queue versus ZeroMQ experiment."""

import argparse
import hashlib
import importlib
import json
import os
import platform
import statistics
import sys
from pathlib import Path

offload = importlib.import_module(
    f"{__package__}.run_frontend_offload" if __package__ else "run_frontend_offload"
)
study = offload.study


def validate(row: dict) -> None:
    offload.validate(row)
    if row["mode"] != "off" or row["errors"] or row["total_drained"] <= 0:
        raise ValueError("Expected successful no-GIL measurement")
    for phase in ("before", "after"):
        state = row["checks"][phase]
        if state["gil_enabled"] or state["transport"] != row["transport"]:
            raise ValueError("Frontend GIL/transport control mismatch")
    loaded = [
        state
        for state in row["checks"]["startup"]
        if state["phase"] == "onnx-model-loaded"
    ]
    if (
        len({state["pid"] for state in loaded}) != 6
        or any(not state["gil_enabled"] for state in loaded)
        or any(state["transport"] != row["transport"] for state in loaded)
    ):
        raise ValueError("Expected six GIL-enabled workers with matched transport")
    counts = row["transport_counts"]
    if row["transport"] == "zmq":
        if any(
            counts.get(f"transport_{key}") != row["total_drained"]
            for key in ("sent", "received")
        ):
            raise ValueError("Missing or duplicate ZeroMQ request/reply")
    elif counts:
        raise ValueError("Queue control unexpectedly used ZeroMQ")


def summarize(rows: list[dict]) -> str:
    lines = [
        "REST/HTTP JSON; no-GIL frontend, six GIL-enabled ONNX workers.",
        "Same interpreter/libraries, h11, pickle/lists and round robin.",
        "Inline and threads use identical custom JSON stages; no worker JSON.",
        "RPS and per-run p95 are means; no pooled percentile or GIL trace.",
        "",
        "rows C JSON-threads transport trials RPS vs-Queue "
        "p95-ms FE-cores worker-cores",
    ]
    keys = sorted({(r["batch"], r["concurrency"], r["json_threads"]) for r in rows})
    for batch, concurrency, threads in keys:
        matching = [
            r
            for r in rows
            if (r["batch"], r["concurrency"], r["json_threads"])
            == (batch, concurrency, threads)
        ]
        baseline = [r["rps"] for r in matching if r["transport"] == "queue"]
        for transport in ("queue", "zmq"):
            group = [r for r in matching if r["transport"] == transport]
            if not group:
                continue
            rps = statistics.mean(r["rps"] for r in group)
            ratio = rps / statistics.mean(baseline) if baseline else float("nan")
            p95 = statistics.mean(r["timings"]["client_ms"]["p95"] for r in group)
            cpu = statistics.mean(r["server_main_cpu_cores"] for r in group)
            workers = statistics.mean(r["worker_cpu_cores"] for r in group)
            lines.append(
                f"{batch:4} {concurrency:2} {threads:12} {transport:9} {len(group):2} "
                f"{rps:8.1f} {ratio:8.3f} {p95:8.2f} {cpu:8.3f} {workers:8.3f}"
            )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> None:
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = {
        "scope": "REST/HTTP JSON only; no-GIL frontend JSON threads and IPC",
        "coordinator": sys.version,
        "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "arguments": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in vars(args).items()
        },
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "source_manifest": study.source_manifest(args.source),
        "harness_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in Path(__file__).parent.glob("*.py")
        },
        "load_average_before": os.getloadavg(),
    }
    args.output.joinpath("metadata.json").write_text(json.dumps(metadata, indent=2))
    variants = [
        (threads, transport)
        for threads in args.threads
        for transport in args.transports
    ]
    rows = []
    for trial in range(args.repeats):
        # Reverse alternate rounds and rotate the next one. Each case gets a
        # fresh frontend/pool so state cannot carry between transport controls.
        ordered = variants if trial % 2 == 0 else list(reversed(variants))
        offset = (trial // 2) % len(ordered)
        ordered = ordered[offset:] + ordered[:offset]
        batches = args.batches if trial % 2 == 0 else list(reversed(args.batches))
        for batch in batches:
            for concurrency in args.concurrencies:
                for threads, transport in ordered:
                    case = dict(
                        frontend="inline" if threads == 0 else f"threads-{threads}",
                        json_threads=threads,
                        transport=transport,
                        mode="off",
                        batch=batch,
                        concurrency=concurrency,
                        trial=trial,
                    )
                    directory = (
                        args.output
                        / f"r{trial}-b{batch}-c{concurrency}-t{threads}-{transport}"
                    )
                    print(f"Starting {directory.name}", flush=True)
                    row = study.run_case(args, case, directory)
                    validate(row)
                    rows.append(row)
                    args.output.joinpath("results.json").write_text(
                        json.dumps(rows, indent=2)
                    )
                    args.output.joinpath("SUMMARY.txt").write_text(summarize(rows))
                    print(
                        f"  {row['rps']:.1f} RPS; p95 "
                        f"{row['timings']['client_ms']['p95']:.1f} ms; "
                        f"frontend {row['server_main_cpu_cores']:.2f} cores",
                        flush=True,
                    )
    print(summarize(rows), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("server-python", "client-python", "source", "model", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--threads", type=int, nargs="+", default=[0, 8])
    parser.add_argument(
        "--transports", choices=["queue", "zmq"], nargs="+", default=["queue", "zmq"]
    )
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[64])
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.workers, args.worker_gil = 6, "on"
    if (
        args.seconds <= 0
        or args.repeats < 1
        or min(args.threads) < 0
        or min(args.batches + args.concurrencies) < 1
    ):
        parser.error(
            "Threads must be nonnegative; "
            "rows, concurrency, seconds and repeats positive"
        )
    run(args)


if __name__ == "__main__":
    main()
