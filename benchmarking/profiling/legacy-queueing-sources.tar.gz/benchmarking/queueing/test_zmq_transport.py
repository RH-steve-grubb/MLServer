"""Check the opt-in IPC adapter without altering production transport classes."""

import asyncio
from multiprocessing.reduction import ForkingPickler
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
import zmq
import zmq.asyncio

from mlserver.parallel.dispatcher import AsyncResponses
from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.types import InferenceRequest, RequestInput

from . import zmq_transport as transport


def message() -> ModelRequestMessage:
    return ModelRequestMessage(
        model_name="queue-mlp",
        model_version="v1",
        method_name="predict",
        method_args=[
            InferenceRequest(
                id="client-id",
                inputs=[
                    RequestInput(
                        name="input", datatype="FP32", shape=[1, 3], data=[0, 1, -2]
                    )
                ],
            )
        ],
    )


async def test_pickle_bytes_and_nested_models_match_stock_queue() -> None:
    original = message()
    before = transport.COUNTS.copy()
    encoded = transport.pack(original)
    assert bytes(encoded) == bytes(ForkingPickler.dumps(original))
    restored = transport.unpack(bytes(encoded))
    assert isinstance(restored, ModelRequestMessage)
    assert restored.model_dump() == original.model_dump()
    assert restored.model_fields_set == original.model_fields_set
    assert isinstance(restored.method_args[0], InferenceRequest)
    assert transport.COUNTS["sent"] == before["sent"] + 1
    assert transport.COUNTS["received"] == before["received"] + 1


async def test_exception_envelope_survives_pickle() -> None:
    response = ModelResponseMessage(id="request", exception=ValueError("bad input"))
    restored = transport.unpack(bytes(transport.pack(response)))
    assert restored.id == response.id
    assert isinstance(restored.exception, ValueError)
    assert str(restored.exception) == "bad input"


async def test_endpoint_requires_existing_short_directory(
    tmp_path: Any, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_ZMQ_DIR", str(tmp_path / "missing"))
    with pytest.raises(ValueError, match="already exist"):
        transport.endpoint("q")
    long_path = tmp_path / ("x" * 100)
    long_path.mkdir()
    monkeypatch.setenv("MLSERVER_QUEUE_ZMQ_DIR", str(long_path))
    with pytest.raises(ValueError, match="safe limit"):
        transport.endpoint("q")


async def test_real_async_socket_and_idle_receiver_cleanup(tmp_path: Any) -> None:
    context = zmq.asyncio.Context()
    inbound = transport.make_socket(context, zmq.PULL)
    outbound = transport.make_socket(context, zmq.PUSH)
    state = transport.ParentTransport(context, inbound, {123: outbound})
    address = f"ipc://{tmp_path}/data.sock"
    try:
        inbound.bind(address)
        outbound.connect(address)
        assert outbound.getsockopt(zmq.SNDHWM) == 0
        assert inbound.getsockopt(zmq.RCVHWM) == 0
        assert outbound.getsockopt(zmq.LINGER) == 0
        original = message()
        async with asyncio.timeout(5):
            await outbound.send(transport.pack(original))
            restored = transport.unpack(await inbound.recv())
        assert restored.model_dump() == original.model_dump()

        async def idle_receive() -> None:
            await inbound.recv()

        state.receiver = asyncio.create_task(idle_receive())
        await asyncio.sleep(0)
    finally:
        await state.close()
    assert state.receiver is not None and state.receiver.cancelled()
    assert inbound.closed and outbound.closed and context.closed


async def test_future_registered_before_suspending_send() -> None:
    original = message()
    responses = AsyncResponses()
    worker = SimpleNamespace(pid=123)

    async def immediate_reply(data: Any, copy: bool) -> None:
        restored = transport.unpack(bytes(data))
        assert copy is True
        assert restored.id in responses._futures
        responses.resolve(ModelResponseMessage(id=restored.id, return_value="ok"))
        await asyncio.sleep(0)

    receiver = asyncio.create_task(asyncio.sleep(60))
    sender = SimpleNamespace(send=immediate_reply)
    state = SimpleNamespace(receiver=receiver, requests={123: sender})
    dispatcher: Any = SimpleNamespace(
        _queue_zmq=state,
        _get_worker=lambda: (worker, worker.pid),
        _async_responses=responses,
    )
    try:
        result = await transport.dispatch_request(dispatcher, original)
        assert result.return_value == "ok"
        assert not responses._futures
        assert not responses._futures_map
        assert not responses._workers_map[worker.pid]
    finally:
        receiver.cancel()
        await asyncio.gather(receiver, return_exceptions=True)


@pytest.mark.parametrize(
    "error", [RuntimeError("send failed"), asyncio.CancelledError()]
)
async def test_send_failure_clears_registered_future(error: BaseException) -> None:
    original = message()
    responses = AsyncResponses()
    worker = SimpleNamespace(pid=123)
    receiver = asyncio.create_task(asyncio.sleep(60))
    state = SimpleNamespace(
        receiver=receiver,
        requests={123: SimpleNamespace(send=AsyncMock(side_effect=error))},
    )
    dispatcher: Any = SimpleNamespace(
        _queue_zmq=state,
        _get_worker=lambda: (worker, worker.pid),
        _async_responses=responses,
    )
    try:
        with pytest.raises(type(error)):
            await transport.dispatch_request(dispatcher, original)
        assert not responses._futures
        assert not responses._futures_map
        assert not responses._workers_map[worker.pid]
    finally:
        receiver.cancel()
        await asyncio.gather(receiver, return_exceptions=True)


async def test_response_loop_uses_original_future_resolution() -> None:
    response = ModelResponseMessage(id="request", return_value="ok")
    sock = SimpleNamespace(recv=AsyncMock(return_value=transport.pack(response)))
    responses = SimpleNamespace(resolve=Mock())
    dispatcher: Any = SimpleNamespace(_async_responses=responses)
    task = asyncio.create_task(transport.receive_responses(dispatcher, sock))
    try:
        await asyncio.sleep(0)
        assert responses.resolve.call_args.args[0].model_dump() == response.model_dump()
    finally:
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@pytest.mark.parametrize(
    "setting,value",
    [("MLSERVER_QUEUE_CODEC", "msgpack"), ("MLSERVER_QUEUE_TENSORS", "numpy")],
)
async def test_install_rejects_confounded_experiments(
    setting: str, value: str, monkeypatch: Any
) -> None:
    monkeypatch.setenv(setting, value)
    with pytest.raises(ValueError, match="requires the stock"):
        transport.install()
