"""Explicit Uvicorn HTTP parser selection for isolated diagnostic controls."""

import os

import uvicorn

from mlserver.rest import RESTServer


def install() -> None:
    mode = os.environ.get("MLSERVER_QUEUE_HTTP_PARSER")
    if mode not in ("h11", "httptools"):
        raise ValueError("Parser control requires h11 or httptools")
    original = RESTServer._get_config

    def config(self: RESTServer) -> uvicorn.Config:
        result = original(self)
        # Select explicitly, so exposing the isolated compiled library cannot
        # silently change a fresh h11 control via Uvicorn's auto detection.
        result.http = "h11" if mode == "h11" else "httptools"
        return result

    setattr(RESTServer, "_get_config", config)
