"""Opt-in least-outstanding selection for single-loop IPC diagnostics.

Outstanding counts already include dispatch/IPC, inference and response return.
They are not physical queue depths or estimates of heterogeneous service cost.
Cancellation can clear a waiter before its inference ends, so this experiment
must not be presented as production workload accounting.
"""

import os
from typing import Any

from mlserver.parallel.dispatcher import Dispatcher
from mlserver.parallel.errors import NoWorkersAvailable


def select_worker(self: Any) -> tuple[Any, int]:
    if not self._ready_workers:
        raise NoWorkersAvailable()
    # Advance the original round-robin cursor once, then rotate equal-score
    # preference. Iterating its entire cycle would not advance the next tie.
    first = next(self._workers_round_robin)
    pids = list(self._ready_workers)
    offset = pids.index(first)
    candidates = pids[offset:] + pids[:offset]
    counts = self._async_responses._workers_map
    chosen = min(candidates, key=lambda pid: len(counts.get(pid, ())))
    # Both supported dispatchers register without yielding after selection.
    # The ZeroMQ adapter reserves BEFORE its potentially suspending send.
    # Awaiting sends without that reservation would send concurrent requests
    # to the same apparently idle worker. Cross-loop callers are unsupported.
    return self._ready_workers[chosen], chosen


def installed() -> bool:
    return Dispatcher._get_worker is select_worker


def install() -> None:
    """Replace selection only when dispatch reserves before its first yield."""
    transport = os.environ.get("MLSERVER_QUEUE_TRANSPORT", "queue")
    if transport == "zmq":
        from zmq_transport import dispatch_request

        if Dispatcher.dispatch_request is not dispatch_request:
            raise ValueError("Install the reservation-safe ZeroMQ adapter first")
    elif transport != "queue":
        raise ValueError("Least-outstanding experiment requires Queue or ZeroMQ")
    setattr(Dispatcher, "_get_worker", select_worker)
