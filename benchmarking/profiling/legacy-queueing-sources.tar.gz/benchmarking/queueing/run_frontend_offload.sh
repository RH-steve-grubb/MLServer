#!/usr/bin/env bash
# Run only archived diagnostic code and the fixed Poetry-created environments.
set -euo pipefail

OFFLOAD_STORE=${MLSERVER_FRONTEND_OFFLOAD_STORE:-/home/codex/mlserver-durable-store/frontend-offload-20261008}
OFFLOAD_CLIENT=/home/codex/tmp/mlserver-perf-venvs/mlserver-bnlygABv-py3.12/bin/python
OFFLOAD_SERVER=/home/codex/mlserver-durable-store/venvs/mlserver-free-threaded-serving-study-di2VO4Zh-py3.14/bin/python

export MLSERVER_STUDY_REPO="$OFFLOAD_STORE/source-original"
exec "$OFFLOAD_CLIENT" "$OFFLOAD_STORE/harness/run_frontend_offload.py" \
    --server-python "$OFFLOAD_SERVER" \
    --client-python "$OFFLOAD_CLIENT" \
    --source "$OFFLOAD_STORE/source" \
    --model "$OFFLOAD_STORE/mlserver-queue-mlp.onnx" \
    --output "$OFFLOAD_STORE/run-$(date -u +%Y%m%dT%H%M%SZ)-$$" \
    "$@"
