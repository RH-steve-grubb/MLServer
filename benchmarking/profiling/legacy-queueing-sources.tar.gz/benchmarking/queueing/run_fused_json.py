"""Matched input JSON fusion, GIL and frontend thread-placement controls."""

import argparse
import hashlib
import importlib
import json
import os
import platform
import statistics
import sys
from pathlib import Path

offload = importlib.import_module(
    f"{__package__}.run_frontend_offload" if __package__ else "run_frontend_offload"
)
study = offload.study


def validate(row: dict) -> None:
    offload.validate(row)
    if (
        row["mode"] not in ("on", "off")
        or row["json_mode"] not in ("separate", "fused-input")
        or row["errors"]
        or row["total_drained"] <= 0
        or row["transport"] != "queue"
    ):
        raise ValueError("Expected successful matched Queue measurement")
    for phase in ("before", "after"):
        state = row["checks"][phase]
        if (
            state["gil_enabled"] != (row["mode"] == "on")
            or state["transport"] != "queue"
            or state["scheduler"] != "round-robin"
            or state["least_outstanding_installed"]
        ):
            raise ValueError("Frontend control mismatch")
        stages = state["frontend_json_stages"]
        if len(stages) != 2 or any(
            stage["mode"] != row["json_mode"] or stage["validation_fallbacks"]
            for stage in stages
        ):
            raise ValueError("Wrong JSON stage or validation fallback")
    loaded = [s for s in row["checks"]["startup"] if s["phase"] == "onnx-model-loaded"]
    if len({s["pid"] for s in loaded}) != 6 or any(
        not s["gil_enabled"] or s["transport"] != "queue" for s in loaded
    ):
        raise ValueError("Expected six GIL-enabled Queue workers")
    if any(
        row.get(key)
        for key in (
            "transport_counts",
            "codec_counts",
            "tensor_counts",
            "raw_counts",
            "http_counts",
            "balance_trace",
        )
    ):
        raise ValueError("Unexpected transport/representation/profiling adapter")


def summarize(rows: list[dict]) -> str:
    lines = [
        "REST/JSON, input fusion only; response formatting unchanged.",
        "Same free-threaded Python binary GIL on/off, Queue/pickle, round robin.",
        "Six GIL-on ONNX workers; JSON inline or eight bounded frontend threads.",
        "No adaptive batching, ZeroMQ or buffer conversion.",
        "Means of per-run statistics, not pooled percentiles; "
        "not a Python 3.12 performance comparison.",
        "",
        "rows GIL threads codec trials RPS vs-separate p95-ms FE-cores worker-cores",
    ]
    keys = sorted({(r["batch"], r["mode"], r["json_threads"]) for r in rows})
    for batch, mode, threads in keys:
        matched = [
            r
            for r in rows
            if (r["batch"], r["mode"], r["json_threads"]) == (batch, mode, threads)
        ]
        baseline = [r["rps"] for r in matched if r["json_mode"] == "separate"]
        for codec in ("separate", "fused-input"):
            group = [r for r in matched if r["json_mode"] == codec]
            if not group:
                continue
            rps = statistics.mean(r["rps"] for r in group)
            ratio = rps / statistics.mean(baseline) if baseline else float("nan")
            p95 = statistics.mean(r["timings"]["client_ms"]["p95"] for r in group)
            lines.append(
                f"{batch:4} {mode:3} {threads:7} {codec:11} {len(group):2} "
                f"{rps:8.1f} {ratio:8.3f} "
                f"{p95:8.1f} "
                f"{statistics.mean(r['server_main_cpu_cores'] for r in group):8.3f} "
                f"{statistics.mean(r['worker_cpu_cores'] for r in group):8.3f}"
            )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> None:
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = {
        "scope": "REST/JSON input fusion; response validation/encoding unchanged",
        "coordinator": sys.version,
        "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "arguments": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in vars(args).items()
        },
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "source_manifest": study.source_manifest(args.source),
        "harness_sha256": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in Path(__file__).parent.glob("*.py")
        },
        "load_average_before": os.getloadavg(),
    }
    args.output.joinpath("metadata.json").write_text(json.dumps(metadata, indent=2))
    rows = []
    for trial in range(args.repeats):
        variants = [
            (threads, codec)
            for threads in args.threads
            for codec in ("separate", "fused-input")
        ]
        if trial % 2:
            variants.reverse()
        batches = args.batches if trial % 2 == 0 else list(reversed(args.batches))
        for batch in batches:
            for threads, codec in variants:
                modes = args.modes if trial % 2 == 0 else list(reversed(args.modes))
                for mode in modes:
                    case = dict(
                        frontend="threads-8" if threads else "inline",
                        json_threads=threads,
                        json_mode=codec,
                        transport="queue",
                        scheduler="round-robin",
                        mode=mode,
                        batch=batch,
                        concurrency=64,
                        trial=trial,
                    )
                    directory = (
                        args.output / f"r{trial}-b{batch}-t{threads}-{codec}-{mode}"
                    )
                    print(f"Starting {directory.name}", flush=True)
                    row = study.run_case(args, case, directory)
                    validate(row)
                    rows.append(row)
                    args.output.joinpath("results.json").write_text(
                        json.dumps(rows, indent=2)
                    )
                    args.output.joinpath("SUMMARY.txt").write_text(summarize(rows))
                    print(
                        f"  {row['rps']:.1f} RPS; p95 "
                        f"{row['timings']['client_ms']['p95']:.1f} ms",
                        flush=True,
                    )
    print(summarize(rows), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("server-python", "client-python", "source", "model", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument(
        "--modes", nargs="+", choices=["on", "off"], default=["on", "off"]
    )
    parser.add_argument(
        "--threads", nargs="+", type=int, choices=[0, 8], default=[0, 8]
    )
    parser.add_argument("--batches", nargs="+", type=int, default=[1, 100, 1000])
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.workers, args.worker_gil = 6, "on"
    if args.seconds <= 0 or args.repeats < 1 or min(args.batches) < 1:
        parser.error("Seconds, repeats and rows must be positive")
    if any(
        len(set(value)) != len(value)
        for value in (args.modes, args.threads, args.batches)
    ):
        parser.error("Control selections must not contain duplicates")
    run(args)


if __name__ == "__main__":
    main()
