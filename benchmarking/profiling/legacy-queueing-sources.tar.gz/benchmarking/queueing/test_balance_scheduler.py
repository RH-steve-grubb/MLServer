"""Selection, coordinated Queue registration and time-weighted skew checks."""

import asyncio
import importlib
import itertools
from pathlib import Path
from multiprocessing.reduction import ForkingPickler
from types import MethodType, SimpleNamespace
from unittest.mock import AsyncMock, Mock
from typing import Any

import pytest

from mlserver.parallel.dispatcher import AsyncResponses, Dispatcher
from mlserver.parallel.errors import NoWorkersAvailable
from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.worker import Worker
from mlserver.types import InferenceRequest

from . import balance_scheduler as scheduler, worker_balance as balance


def dispatcher(counts: list[int]) -> Any:
    workers = {
        pid: SimpleNamespace(pid=pid, send_request=Mock())
        for pid in range(1, len(counts) + 1)
    }
    result = SimpleNamespace(
        _ready_workers=workers,
        _workers_round_robin=itertools.cycle(workers),
        _async_responses=SimpleNamespace(
            _workers_map={pid: set(range(count)) for pid, count in enumerate(counts, 1)}
        ),
    )
    result._get_worker = MethodType(scheduler.select_worker, result)
    return result


def test_picks_smallest_ready_outstanding_count() -> None:
    worker, pid = dispatcher([5, 0, 3])._get_worker()
    assert pid == worker.pid == 2


def test_rotates_equal_score_ties() -> None:
    state = dispatcher([0, 0, 0])
    assert [state._get_worker()[1] for _ in range(6)] == [1, 2, 3, 1, 2, 3]


def test_uses_live_counts_and_ignores_unready_workers() -> None:
    state = dispatcher([1, 2, 3])
    state._async_responses._workers_map[99] = set()
    assert state._get_worker()[1] == 1
    state._async_responses._workers_map[1].update(range(10))
    assert state._get_worker()[1] == 2


def test_empty_ready_set() -> None:
    with pytest.raises(NoWorkersAvailable):
        dispatcher([])._get_worker()


async def test_original_queue_send_registers_before_another_dispatch_selects() -> None:
    state = dispatcher([0, 0])
    state._async_responses = AsyncResponses()
    requests = [
        ModelRequestMessage(model_name="test", method_name="predict") for _ in range(2)
    ]
    tasks = [
        asyncio.create_task(Dispatcher.dispatch_request(state, req)) for req in requests
    ]
    try:
        await asyncio.sleep(0)
        assert [len(state._async_responses._workers_map[pid]) for pid in (1, 2)] == [
            1,
            1,
        ]
        for request in requests:
            state._async_responses.resolve(
                ModelResponseMessage(id=request.id, return_value="ok")
            )
        assert all(reply.return_value == "ok" for reply in await asyncio.gather(*tasks))
        assert not state._async_responses._futures
        assert not any(state._async_responses._workers_map.values())
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


async def test_failed_queue_send_does_not_leave_a_reservation() -> None:
    state = dispatcher([0])
    state._async_responses = AsyncResponses()
    state._ready_workers[1].send_request.side_effect = ValueError("send failed")
    with pytest.raises(ValueError, match="send failed"):
        await Dispatcher.dispatch_request(
            state, ModelRequestMessage(model_name="test", method_name="predict")
        )
    assert (
        not state._async_responses._futures and not state._async_responses._workers_map
    )


def test_rejects_uninstalled_zmq_transport(monkeypatch) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_TRANSPORT", "zmq")
    monkeypatch.syspath_prepend(str(Path(__file__).parent))
    with pytest.raises(ValueError, match="adapter first"):
        scheduler.install()


def test_installed_zmq_transport_preserves_dispatch(monkeypatch) -> None:
    monkeypatch.syspath_prepend(str(Path(__file__).parent))
    transport = importlib.import_module("zmq_transport")
    monkeypatch.setenv("MLSERVER_QUEUE_TRANSPORT", "zmq")
    monkeypatch.setattr(Dispatcher, "dispatch_request", transport.dispatch_request)
    monkeypatch.setattr(Dispatcher, "_get_worker", Dispatcher._get_worker)
    scheduler.install()
    assert scheduler.installed()
    assert Dispatcher.dispatch_request is transport.dispatch_request


async def test_balanced_zmq_reserves_all_requests_before_suspending_send() -> None:
    from . import zmq_transport as transport

    state = dispatcher([0, 0, 0])
    state._async_responses = AsyncResponses()
    gate = asyncio.Event()

    async def send(data: Any, copy: bool) -> None:
        await gate.wait()
        request = transport.unpack(bytes(data))
        state._async_responses.resolve(
            ModelResponseMessage(id=request.id, return_value="ok")
        )

    receiver = asyncio.create_task(asyncio.sleep(60))
    state._queue_zmq = SimpleNamespace(
        receiver=receiver,
        requests={pid: SimpleNamespace(send=send) for pid in (1, 2, 3)},
    )
    tasks = [
        asyncio.create_task(
            transport.dispatch_request(
                state, ModelRequestMessage(model_name="test", method_name="predict")
            )
        )
        for _ in range(9)
    ]
    try:
        await asyncio.sleep(0)
        assert [len(state._async_responses._workers_map[p]) for p in (1, 2, 3)] == [
            3,
            3,
            3,
        ]
        # Cancellation during an awaiting send must release its reservation.
        tasks[0].cancel()
        await asyncio.gather(tasks[0], return_exceptions=True)
        assert state._get_worker()[1] == 1
        gate.set()
        assert all(
            reply.return_value == "ok" for reply in await asyncio.gather(*tasks[1:])
        )
        assert not state._async_responses._futures
        assert not any(state._async_responses._workers_map.values())
    finally:
        receiver.cancel()
        for task in tasks:
            task.cancel()
        await asyncio.gather(receiver, *tasks, return_exceptions=True)


def test_install_preserves_dispatch_and_reports_actual_method(monkeypatch) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_TRANSPORT", "queue")
    original = Dispatcher.dispatch_request
    monkeypatch.setattr(Dispatcher, "_get_worker", Dispatcher._get_worker)
    scheduler.install()
    assert scheduler.installed() and Dispatcher.dispatch_request is original


def test_weighted_percentile_is_duration_not_edge_weighted() -> None:
    assert balance.weighted_percentile({0: 90, 5: 10}, 50) == 0
    assert balance.weighted_percentile({0: 90, 5: 10}, 95) == 5


def test_variance_of_waiting_and_outstanding_is_distinct() -> None:
    events = [[1, 0, 1, 8, 8, 1000], [1, 2, 9, 10, 10, 1]]
    metrics = balance.analyze(events, [1, 2], (0, 12))
    assert metrics["waiting_variance_time_mean"] == pytest.approx(1 / 6)
    assert metrics["outstanding_variance_time_mean"] == pytest.approx(7 / 12)
    assert metrics["waiting_count_skew_p95"] == 1
    assert metrics["outstanding_count_skew_p95"] == 2
    assert metrics["waiting_rows_skew_p95"] == 1000
    assert metrics["idle_with_backlog_fraction"] == pytest.approx(0.5)
    assert metrics["idle_worker_capacity_candidate_fraction"] == pytest.approx(0.25)
    assert metrics["rows_1_requests"] == metrics["rows_1000_requests"] == 1


def test_idle_tail_is_in_time_weighted_percentiles() -> None:
    metrics = balance.analyze([[1, 0, 1, 2, 3]], [1, 2], (0, 100))
    assert metrics["waiting_count_skew_p95"] == 0
    assert metrics["waiting_variance_time_mean"] == pytest.approx(0.0025)


async def test_typed_trace_survives_pickle_and_never_leaks_into_payload(
    monkeypatch,
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "frontend")
    monkeypatch.setenv("MLSERVER_QUEUE_TRANSPORT", "queue")
    monkeypatch.setattr(balance, "EVENTS", [])
    payload = InferenceRequest(
        inputs=[dict(name="input", shape=[100, 54], datatype="FP32", data=[0.0] * 5400)]
    )
    request = ModelRequestMessage(
        model_name="test", method_name="predict", method_args=[payload]
    )
    response = ModelResponseMessage(id=request.id, return_value="untouched")
    monkeypatch.setattr(Worker, "_process_request", AsyncMock(return_value=response))

    async def dispatch(self, request):
        result = await Worker._process_request(Mock(), request)
        return ForkingPickler.loads(ForkingPickler.dumps(result))

    monkeypatch.setattr(Dispatcher, "dispatch_request", dispatch)
    balance.install()
    reply = await Dispatcher.dispatch_request(Mock(), request)
    assert reply.return_value == "untouched" and not hasattr(reply, "_queue_balance")
    assert len(balance.EVENTS) == 1 and balance.EVENTS[0][5] == 100
    assert balance.EVENTS[0][1:5] == sorted(balance.EVENTS[0][1:5])


def test_mixed_stream_is_paired_and_does_not_repeat_an_aliasing_cycle(
    monkeypatch,
) -> None:
    monkeypatch.syspath_prepend(str(Path(__file__).parent))
    bench = importlib.import_module("bench")
    left = list(itertools.islice(bench.request_sizes([1] * 9 + [1000]), 100))
    right = list(itertools.islice(bench.request_sizes([1] * 9 + [1000]), 100))
    assert left == right and left.count(1000) == 10
    assert len({left[i : i + 10].index(1000) for i in range(0, 100, 10)}) > 1


def test_latency_summary_calculates_p99(monkeypatch) -> None:
    monkeypatch.syspath_prepend(str(Path(__file__).parent))
    bench = importlib.import_module("bench")
    assert bench.summary([1, 2, 3, 4])["p99"] == pytest.approx(3.97)
