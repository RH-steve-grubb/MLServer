"""Benchmark-only probes; production MLServer and runtime files stay unchanged.

Set MLSERVER_QUEUE_PROBE=1 before launching bench.py so spawn workers install
the same probes. Timings use the host's monotonic clock across local processes.
"""

import asyncio
import contextvars
import functools
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from mlserver.parallel.dispatcher import AsyncResponses, Dispatcher
from mlserver.parallel.worker import Worker
from mlserver.parallel.utils import END_OF_QUEUE
from mlserver.types import InferenceResponse, Parameters
from mlserver_onnx import OnnxModel

PROFILE = contextvars.ContextVar("queue_probe_profile", default=None)
PREFIX = "x-queue-probe-"


def now() -> int:
    return time.perf_counter_ns()


def headers(payload: Any) -> dict[str, str]:
    if payload.parameters is None:
        payload.parameters = Parameters()
    if payload.parameters.headers is None:
        payload.parameters.headers = {}
    return payload.parameters.headers


class SessionProbe:
    def __init__(self, session: Any) -> None:
        self.session = session
        self.lock = threading.Lock()
        self.active = 0

    def __getattr__(self, name: str) -> Any:
        return getattr(self.session, name)

    def run(self, *args: Any, **kwargs: Any) -> Any:
        profile = PROFILE.get()
        with self.lock:
            self.active += 1
            active = self.active
        started = now()
        try:
            return self.session.run(*args, **kwargs)
        finally:
            elapsed = now() - started
            if profile is not None:
                profile["run-ns"] = elapsed
                profile["native-active"] = active
            with self.lock:
                self.active -= 1


class HTTPProbe:
    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        started = str(now()).encode()
        scope["headers"] = list(scope["headers"]) + [
            ((PREFIX + "asgi-start-ns").encode(), started)
        ]

        async def measured_send(message):
            if message["type"] == "http.response.start":
                message["headers"] = list(message.get("headers", [])) + [
                    ((PREFIX + "asgi-start-ns").encode(), started),
                    ((PREFIX + "response-start-ns").encode(), str(now()).encode()),
                ]
            await send(message)

        await self.app(scope, receive, measured_send)


class ResponseQueueProbe:
    def __init__(self, queue: Any) -> None:
        self.queue = queue

    def __getattr__(self, name: str) -> Any:
        return getattr(self.queue, name)

    def get(self) -> Any:
        response = self.queue.get()
        if response is not END_OF_QUEUE and isinstance(
            response.return_value, InferenceResponse
        ):
            headers(response.return_value)[PREFIX + "pipe-read-ns"] = str(now())
        return response


def install() -> None:
    if getattr(OnnxModel, "_queue_probe_installed", False):
        return
    OnnxModel._queue_probe_installed = True
    original_load = OnnxModel.load
    original_predict = OnnxModel.predict
    original_prepare = OnnxModel._prepare_inputs
    original_encode = OnnxModel.encode
    original_dispatch = Dispatcher.dispatch_request
    original_worker_request = Worker._process_request
    original_worker_response = Worker._handle_response
    original_resolve = AsyncResponses.resolve
    original_process_responses = Dispatcher._process_responses

    @functools.wraps(original_load)
    async def load(self):
        loaded = await original_load(self)
        self._model = SessionProbe(self._model)
        self._queue_probe_slots = asyncio.Semaphore(
            int(os.environ.get("MLSERVER_QUEUE_LANES", "4"))
        )
        self._queue_probe_executor = ThreadPoolExecutor(max_workers=32)
        return loaded

    def prepare(self, payload):
        started = now()
        try:
            return original_prepare(self, payload)
        finally:
            profile = PROFILE.get()
            if profile is not None:
                profile["decode-ns"] = now() - started

    def encode(self, *args, **kwargs):
        started = now()
        try:
            return original_encode(self, *args, **kwargs)
        finally:
            profile = PROFILE.get()
            if profile is not None:
                profile["encode-ns"] += now() - started

    @functools.wraps(original_predict)
    async def predict(self, payload):
        profile = {"predict-start-ns": now(), "encode-ns": 0}
        token = PROFILE.set(profile)
        try:
            if os.environ.get("MLSERVER_QUEUE_EXECUTION", "inline") == "thread":
                # Experimental bounded offload of the EXISTING synchronous
                # decode -> session.run -> encode path, not a replacement model.
                payload = self._check_request(payload)
                waiting = now()
                async with self._queue_probe_slots:
                    profile["admission-ns"] = now() - waiting
                    context = contextvars.copy_context()
                    outputs = await asyncio.get_running_loop().run_in_executor(
                        self._queue_probe_executor,
                        context.run,
                        self._get_model_outputs,
                        payload,
                    )
                result = InferenceResponse(
                    model_name=self.name,
                    model_version=self.version,
                    outputs=outputs,
                )
            else:
                result = await original_predict(self, payload)
            profile["predict-end-ns"] = now()
            output_headers = headers(result)
            for key, value in profile.items():
                output_headers[PREFIX + key] = str(value)
            for key, value in headers(payload).items():
                if key.startswith(PREFIX):
                    output_headers[key] = value
            return result
        finally:
            PROFILE.reset(token)

    @functools.wraps(original_dispatch)
    async def dispatch(self, message):
        if message.method_name == "predict":
            headers(message.method_args[0])[PREFIX + "dispatch-ns"] = str(now())
        result = await original_dispatch(self, message)
        if isinstance(result.return_value, InferenceResponse):
            headers(result.return_value)[PREFIX + "dispatch-return-ns"] = str(now())
        return result

    @functools.wraps(original_worker_request)
    async def worker_request(self, message):
        if message.method_name == "predict":
            headers(message.method_args[0])[PREFIX + "worker-enter-ns"] = str(now())
        result = await original_worker_request(self, message)
        if isinstance(result.return_value, InferenceResponse):
            headers(result.return_value)[PREFIX + "worker-return-ns"] = str(now())
        return result

    def worker_response(self, task):
        result = task.result()
        if isinstance(result.return_value, InferenceResponse):
            headers(result.return_value)[PREFIX + "worker-put-ns"] = str(now())
        return original_worker_response(self, task)

    def resolve(self, response):
        if isinstance(response.return_value, InferenceResponse):
            headers(response.return_value)[PREFIX + "parent-read-ns"] = str(now())
        return original_resolve(self, response)

    async def process_responses(self):
        self._responses = ResponseQueueProbe(self._responses)
        if os.environ.get("MLSERVER_QUEUE_RESPONSE_PUMP") != "1":
            return await original_process_responses(self)
        loop = asyncio.get_running_loop()

        def pump():
            # Hypothesis test: keep reading completed IPC messages without an
            # executor -> event loop -> executor round trip for every result.
            # Resolve on the parent event loop so future bookkeeping stays there.
            while True:
                response = self._responses.get()
                if response is END_OF_QUEUE:
                    return
                loop.call_soon_threadsafe(self._async_responses.resolve, response)

        await loop.run_in_executor(self._executor, pump)

    # These are deliberately runtime-only method replacements in a diagnostic
    # process, not changes to the production class definitions.
    setattr(OnnxModel, "load", load)
    setattr(OnnxModel, "predict", predict)
    setattr(OnnxModel, "_prepare_inputs", prepare)
    setattr(OnnxModel, "encode", encode)
    setattr(Dispatcher, "dispatch_request", dispatch)
    setattr(Worker, "_process_request", worker_request)
    setattr(Worker, "_handle_response", worker_response)
    setattr(AsyncResponses, "resolve", resolve)
    setattr(Dispatcher, "_process_responses", process_responses)
