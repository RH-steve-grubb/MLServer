"""Diagnostic MessagePack adapter for MLServer's existing multiprocessing pipes.

Only explicitly listed protocol objects are supported. This is not a general
serializer for arbitrary runtimes, exceptions, streaming or custom handlers.
Unknown objects fall back to the original pickle implementation. Production
sources and the multiprocessing process-startup serializer are unchanged.
"""

from enum import Enum
from multiprocessing import queues
from typing import Any

import msgpack
import msgpack_numpy
import numpy as np
from pydantic import BaseModel

from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.types import (
    InferenceRequest,
    InferenceResponse,
    MetadataModelResponse,
    MetadataTensor,
    Parameters,
    RequestInput,
    RequestOutput,
    ResponseOutput,
    TensorData,
)

_ORIGINAL = getattr(queues, "_ForkingPickler")
_TAG = "mlserver-msgpack-experiment-v1"
_MODEL_KEY = "__queue_benchmark_model__"
_MODELS = {
    cls.__name__: cls
    for cls in (
        ModelRequestMessage,
        ModelResponseMessage,
        InferenceRequest,
        InferenceResponse,
        MetadataModelResponse,
        MetadataTensor,
        Parameters,
        RequestInput,
        RequestOutput,
        ResponseOutput,
        TensorData,
    )
}
COUNTS = {"packed": 0, "unpacked": 0, "fallback": 0}


def encode(value: Any) -> Any:
    if isinstance(value, BaseModel):
        name = type(value).__name__
        if _MODELS.get(name) is not type(value):
            raise TypeError(f"Unsupported benchmark model: {name}")
        # Preserve nested model objects and numeric lists, without a deep
        # model_dump() conversion that would confound the serializer comparison.
        return {
            _MODEL_KEY: name,
            "fields": value.__dict__,
            "extra": value.__pydantic_extra__,
            "set": list(value.__pydantic_fields_set__),
        }
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, np.ndarray):
        return msgpack_numpy.encode(value)
    raise TypeError(f"Unsupported benchmark object: {type(value).__name__}")


def decode(value: dict) -> Any:
    if _MODEL_KEY not in value:
        return msgpack_numpy.decode(value)
    model = _MODELS[value[_MODEL_KEY]]
    fields = dict(value["fields"])
    fields.update(value["extra"] or {})
    # These are already-validated, trusted IPC objects. Revalidation here would
    # add work not done by pickle and can change RootModel representations.
    return model.model_construct(_fields_set=set(value["set"]), **fields)


class QueueCodec:
    @classmethod
    def dumps(cls, value: Any, protocol: int | None = None) -> Any:
        if isinstance(value, (ModelRequestMessage, ModelResponseMessage)):
            try:
                # A two-element MessagePack array starts with 0x92; pickle
                # streams used by Queue start with 0x80. Put the tag inside the
                # packed envelope to avoid copying a large payload to prepend it.
                packed = msgpack.packb([_TAG, value], default=encode)
                COUNTS["packed"] += 1
                return packed
            except (TypeError, ValueError, OverflowError):
                COUNTS["fallback"] += 1
        return _ORIGINAL.dumps(value, protocol)

    @classmethod
    def loads(cls, value: Any) -> Any:
        if value[0] == 0x92:
            tag, restored = msgpack.unpackb(value, object_hook=decode)
            if tag != _TAG:
                raise ValueError("Unexpected benchmark MessagePack envelope")
            COUNTS["unpacked"] += 1
            return restored
        return _ORIGINAL.loads(value)


def install() -> None:
    """Replace only the process-local Queue codec, not spawning or transport."""
    if getattr(queues, "_ForkingPickler") is not QueueCodec:
        setattr(queues, "_ForkingPickler", QueueCodec)
