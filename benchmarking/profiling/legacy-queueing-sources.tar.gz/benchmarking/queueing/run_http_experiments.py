"""Isolate HTTP framework and IPC with identical worker-side JSON/ONNX work.

Four raw-body variants plus a fresh original typed FastAPI/Queue reference.
Run with the study's Python-3.12 Poetry environment and isolated PyZMQ site.
--balance selects separate instrumented runs of the four raw-body variants.
Results and source/dependency snapshots go into a NEW durable output directory.
"""

import argparse
import importlib
import json
import math
import os
import shutil
import statistics
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

_cleanup = importlib.import_module(
    f"{__package__}.run_zmq_experiment" if __package__ else "run_zmq_experiment"
)
BENCH = Path(__file__).with_name("bench.py")
VARIANTS = {
    "stock-fastapi-queue": ("fastapi", "queue", "frontend"),
    "raw-fastapi-queue": ("fastapi", "queue", "full"),
    "raw-aiohttp-queue": ("aiohttp", "queue", "full"),
    "raw-fastapi-zmq": ("fastapi", "zmq", "full"),
    "raw-aiohttp-zmq": ("aiohttp", "zmq", "full"),
}


def validate(document: dict[str, Any], variant: str, balance: bool = False) -> None:
    http, transport, mode = VARIANTS[variant]
    meta = document["metadata"]
    if (
        any(
            meta[key] != value
            for key, value in (
                ("http_framework", http),
                ("queue_transport", transport),
                ("queue_json", mode),
                ("probed", False),
                ("balance_instrumented", balance),
            )
        )
        or not document["results"]
    ):
        raise ValueError("Requested HTTP/transport/JSON/instrumentation not selected")
    for row in document["results"]:
        if row["errors"] or row["total_drained"] <= 0:
            raise ValueError("Prediction failure or empty measurement")
        if not math.isfinite(row["rps"]) or row["rps"] <= 0:
            raise ValueError("Invalid completion rate")
        if (
            any(
                row[key] != value
                for key, value in (
                    ("config", "pool6-tuned"),
                    ("frontends", 1),
                    ("total_workers", 6),
                    ("threads", 1),
                    ("execution", "inline"),
                    ("response_pump", False),
                    ("stock", False),
                    ("queue_codec", "pickle"),
                    ("queue_tensors", "list"),
                    ("queue_transport", transport),
                    ("queue_json", mode),
                    ("http_framework", http),
                )
            )
            or row["codec_counts"]
            or row["tensor_counts"]
        ):
            raise ValueError("Confounded framework/transport comparison")
        count = row["total_drained"]
        raw = row["raw_counts"]
        if mode == "full":
            if any(
                raw[key] != expected
                for key, expected in (
                    ("raw_requests", count),
                    ("raw_worker_replies", count),
                    ("raw_byte_replies", count),
                    ("raw_input_bytes", count * row["request_bytes"]),
                )
            ):
                raise ValueError("Raw request/reply/byte validation failed")
        elif raw:
            raise ValueError("Stock reference unexpectedly used raw worker JSON")
        counts = row["transport_counts"]
        if transport == "zmq":
            if any(counts[f"transport_{key}"] != count for key in ("sent", "received")):
                raise ValueError("ZeroMQ request/reply validation failed")
        elif counts:
            raise ValueError("Queue control unexpectedly used ZeroMQ")
        expected_http = {"http_aiohttp_replies": count} if http == "aiohttp" else {}
        if row["http_counts"] != expected_http:
            raise ValueError("Selected HTTP frontend was not exercised")
        trace = row.get("balance_trace")
        if balance:
            if (
                mode != "full"
                or trace is None
                or len(trace["events"]) != count
                or len(set(trace["worker_pids"])) != 6
                or trace["dropped"]
            ):
                raise ValueError("Incomplete worker-balance trace")
            pids = set(trace["worker_pids"])
            for pid, dispatched, entered, finished, returned in trace["events"]:
                if pid not in pids or not (
                    trace["window_start_ns"]
                    <= dispatched
                    <= entered
                    <= finished
                    <= returned
                    <= trace["window_end_ns"]
                ):
                    raise ValueError("Invalid worker-balance event")
        elif trace is not None:
            raise ValueError("Throughput run unexpectedly collected a balance trace")


def run_block(args: argparse.Namespace, variant: str, index: int) -> dict[str, Any]:
    http, transport, mode = VARIANTS[variant]
    ipc = args.output / f"ipc-{index}"
    ipc.mkdir(mode=0o700)
    result = args.output / f"{index:02d}-{variant}.json"
    env = dict(os.environ)
    env.update(
        MLSERVER_QUEUE_HTTP=http,
        MLSERVER_QUEUE_TRANSPORT=transport,
        MLSERVER_QUEUE_JSON=mode,
        MLSERVER_QUEUE_ZMQ_DIR=str(ipc),
        MLSERVER_QUEUE_CODEC="pickle",
        MLSERVER_QUEUE_TENSORS="list",
        MLSERVER_QUEUE_PROBE="0",
        MLSERVER_QUEUE_BALANCE="1" if args.balance else "0",
        PYTHONDONTWRITEBYTECODE="1",
    )
    reverse = (index // len(args.variants)) % 2 == 1
    batches = args.batches[::-1] if reverse else args.batches
    concurrency = args.concurrencies[::-1] if reverse else args.concurrencies
    command = [
        sys.executable,
        str(BENCH),
        "sweep",
        str(args.model),
        "--configs",
        "pool6-tuned",
        "--unprobed",
        "--batches",
        *map(str, batches),
        "--concurrencies",
        *map(str, concurrency),
        "--seconds",
        str(args.seconds),
        "--repeats",
        "1",
        "--output",
        str(result),
    ]
    print(f"Block {index + 1}: {variant}; {result}", flush=True)
    with result.with_suffix(".log").open("w") as log:
        process = subprocess.Popen(
            command,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            code = process.wait(
                timeout=300 + args.seconds * len(batches) * len(concurrency)
            )
            if code:
                raise RuntimeError(f"Benchmark exited {code}; inspect {log.name}")
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Benchmark left a live process in its owned group")
        except BaseException:
            _cleanup.stop_owned_group(process)
            raise
    document = json.loads(result.read_text())
    validate(document, variant, args.balance)
    expected = {(b, c) for b in args.batches for c in args.concurrencies}
    actual = {(r["batch"], r["concurrency"]) for r in document["results"]}
    if actual != expected or len(document["results"]) != len(expected):
        raise ValueError("Incomplete or duplicate workload matrix")
    for row in document["results"]:
        row.update(
            variant=variant,
            independent_trial=index // len(args.variants),
            block=index,
        )
    return document


def summarize(output: Path, documents: list[dict[str, Any]], balance: bool) -> None:
    groups: dict[tuple[int, int, str], list[dict[str, Any]]] = defaultdict(list)
    for doc in documents:
        for row in doc["results"]:
            groups[(row["batch"], row["concurrency"], row["variant"])].append(row)
    lines = [
        "HTTP framework / IPC ONNX experiment",
        "===================================",
        f"Completed validated blocks: {len(documents)}.",
        f"Worker-balance instrumentation: {balance}.",
        "One frontend, six workers, one ORT thread each, spinning disabled.",
        "Raw variants use identical worker JSON/validation/DataPlane/encoding.",
        "Stock reference uses original typed FastAPI/Queue request and reply.",
        "All use pickle/list and round robin; control queues remain unchanged.",
        "No adaptive batching, timing decorators, gzip or HTTP metrics middleware.",
        "aiohttp is a thin diagnostic, not a complete MLServer API replacement.",
        "",
        "Rows C Variant Repeats MeanRPS SD LatencyMean/P95ms FrontCPU WorkerCPU "
        "ClientCPU LoopP95/MaxMs",
    ]
    for (batch, c, variant), rows in sorted(groups.items()):
        rates = [r["rps"] for r in rows]
        sd = statistics.stdev(rates) if len(rates) > 1 else 0
        latency = [
            statistics.mean(r["timings"]["client_ms"][k] for r in rows)
            for k in ("mean", "p95")
        ]
        cpu = [
            statistics.mean(r[key] for r in rows)
            for key in ("server_main_cpu_cores", "worker_cpu_cores", "client_cpu_cores")
        ]
        lag = statistics.mean(r["server_loop_lag_ms"]["p95"] for r in rows)
        worst = max(r["server_loop_lag_ms"]["max"] for r in rows)
        lines.append(
            f"{batch:4} {c:2} {variant:20} {len(rows):7} "
            f"{statistics.mean(rates):8.2f} {sd:7.2f} "
            f"{latency[0]:7.2f}/{latency[1]:.2f} {cpu[0]:7.2f} "
            f"{cpu[1]:9.2f} {cpu[2]:9.2f} {lag:7.2f}/{worst:.2f}"
        )
        if balance:
            metrics = [r["balance_trace"]["metrics"] for r in rows]
            idle_fraction = statistics.mean(
                m["idle_with_backlog_fraction"] for m in metrics
            )
            lines.append(
                "  Balance: mean queued-while-idle fraction="
                f"{idle_fraction:.4f}, "
                "max waiting count skew="
                f"{max(m['waiting_count_skew_max'] for m in metrics):.0f}, "
                "mean busy-worker count="
                f"{statistics.mean(m['busy_workers_mean'] for m in metrics):.2f}"
            )
    lines += ["", "Relative mean RPS:"]
    pairs = (
        ("raw-aiohttp-queue", "raw-fastapi-queue"),
        ("raw-aiohttp-zmq", "raw-fastapi-zmq"),
        ("raw-fastapi-zmq", "raw-fastapi-queue"),
        ("raw-aiohttp-zmq", "raw-aiohttp-queue"),
        ("raw-aiohttp-zmq", "stock-fastapi-queue"),
    )
    for batch, c in sorted({(key[0], key[1]) for key in groups}):
        for variant, control in pairs:
            a, b = groups.get((batch, c, variant)), groups.get((batch, c, control))
            if a and b:
                gain = statistics.mean(r["rps"] for r in a) / statistics.mean(
                    r["rps"] for r in b
                )
                lines.append(
                    f"  rows={batch} C={c} {variant}/{control}: {100*(gain-1):+.2f}%"
                )
    lines += [
        "",
        "Short CPU-only localhost closed-loop windows, not production SLOs.",
        "Case p95 values are averaged, not pooled request percentiles.",
        "Core inference metrics/middleware move into workers in every raw variant.",
        "ZeroMQ copies and pickle remain; not pure pipe/socket bandwidth or GIL waits.",
        "Balance traces include IPC/admission delays, not pure worker queue waits.",
        "Instrumented rates are NOT the primary throughput comparison.",
        "No heterogeneous-model load, recovery/cancellation, shared memory or TLS.",
    ]
    (output / "SUMMARY.txt").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[2, 64])
    parser.add_argument("--balance", action="store_true")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        parser.error("Use the study's MLServer Python-3.12 Poetry environment")
    if (
        not math.isfinite(args.seconds)
        or args.seconds <= 0
        or args.repeats <= 0
        or min(args.batches + args.concurrencies) <= 0
    ):
        parser.error("Duration, repeats and workload values must be positive/finite")
    args.output, args.model = args.output.absolute(), args.model.absolute()
    args.variants = [v for v in VARIANTS if not args.balance or v.startswith("raw-")]
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    source = args.output / "source"
    source.mkdir()
    for name in (
        "bench.py",
        "probe.py",
        "raw_worker.py",
        "aiohttp_frontend.py",
        "worker_balance.py",
        "http_parser.py",
        "zmq_transport.py",
        "run_http_experiments.py",
        "run_zmq_experiment.py",
        "test_raw_worker.py",
        "test_aiohttp_frontend.py",
        "test_worker_balance.py",
        "test_http_experiments.py",
    ):
        shutil.copy2(BENCH.with_name(name), source / name)
    shutil.copytree(BENCH.parent / "zeromq-env", source / "zeromq-env")
    for name in ("pyproject.toml", "poetry.lock"):
        shutil.copy2(BENCH.parents[2] / name, source / name)
    documents: list[dict[str, Any]] = []
    try:
        for trial in range(args.repeats):
            order = args.variants[::-1] if trial % 2 else args.variants
            for variant in order:
                documents.append(run_block(args, variant, len(documents)))
                (args.output / "results.json").write_text(
                    json.dumps(documents, indent=2)
                )
                summarize(args.output, documents, args.balance)
    finally:
        summarize(args.output, documents, args.balance)
    print(f"Finished. Read {args.output / 'SUMMARY.txt'}", flush=True)


if __name__ == "__main__":
    main()
