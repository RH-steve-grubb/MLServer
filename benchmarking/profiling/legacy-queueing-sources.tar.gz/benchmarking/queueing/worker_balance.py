"""Opt-in per-request worker timelines, separate from throughput controls.

Record frontend dispatch/return and worker entry/finish on the host monotonic
clock. Entry delay includes IPC and admission, not just queue wait. A backlog
behind a busy worker while another has no active/unstarted requests is only a
scheduler opportunity candidate: transport and OS scheduling also contribute.
"""

import importlib
import os
import time
from collections import Counter
from itertools import groupby
from typing import Any

import numpy as np

from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.dispatcher import Dispatcher
from mlserver.parallel.worker import Worker

_raw = importlib.import_module(
    f"{__package__}.raw_worker" if __package__ else "raw_worker"
)
ENTER = "x-queue-diagnostic-worker-enter-ns"
FINISH = "x-queue-diagnostic-worker-finish-ns"
EVENTS: list[list[int]] = []
DROPPED = 0
WINDOW_START = 0
LAST: dict[str, Any] = {}
MAX_EVENTS = 100000


def weighted_percentile(histogram: dict[int, int], q: float) -> float:
    """Percentile weighted by duration, not by the number of event edges."""
    threshold = sum(histogram.values()) * q / 100
    total = 0
    for value, duration in sorted(histogram.items()):
        total += duration
        if total >= threshold:
            return float(value)
    return 0.0


def percentile(values: list[float], q: float) -> float:
    return float(np.percentile(values, q)) if values else 0.0


def analyze(
    events: list[list[int]], pids: list[int], bounds: tuple[int, int]
) -> dict[str, float]:
    start, end = bounds
    if end <= start or not pids:
        raise ValueError("Invalid worker-balance interval")
    service: dict[int, list[float]] = {pid: [] for pid in pids}
    admission: list[float] = []
    changes: list[tuple[int, int, int, int, int, int]] = []
    class_service: dict[int, list[float]] = {}
    class_admission: dict[int, list[float]] = {}
    worker_classes: dict[int, Counter[int]] = {pid: Counter() for pid in pids}
    for event in events:
        if len(event) not in (5, 6):
            raise ValueError("Invalid worker-balance event width")
        pid, dispatched, entered, finished, returned = event[:5]
        rows = event[5] if len(event) == 6 else 0
        if (
            pid not in service
            or rows < 0
            or not start <= dispatched <= entered <= finished <= returned <= end
        ):
            raise ValueError("Invalid worker-balance event or unknown worker")
        service[pid].append((finished - entered) / 1e6)
        admission.append((entered - dispatched) / 1e6)
        if rows:
            worker_classes[pid][rows] += 1
            class_service.setdefault(rows, []).append((finished - entered) / 1e6)
            class_admission.setdefault(rows, []).append((entered - dispatched) / 1e6)
        changes += [
            (dispatched, pid, 1, 0, 1, rows),
            (entered, pid, -1, 1, 0, -rows),
            (finished, pid, 0, -1, 0, 0),
            (returned, pid, 0, 0, -1, 0),
        ]
    queued = dict.fromkeys(pids, 0)
    busy = dict.fromkeys(pids, 0)
    pending = dict.fromkeys(pids, 0)
    queued_rows = dict.fromkeys(pids, 0)
    elapsed_busy = 0
    idle_backlog = 0
    skew_time = 0
    max_skew = 0
    waiting_hist: Counter[int] = Counter()
    pending_hist: Counter[int] = Counter()
    row_hist: Counter[int] = Counter()
    waiting_variance = pending_variance = 0.0
    idle_worker_time = 0
    max_depth = max_pending = 0
    previous = start
    for stamp, group in groupby(
        sorted(changes, key=lambda c: c[0]), key=lambda c: c[0]
    ):
        dt = stamp - previous
        elapsed_busy += dt * sum(value > 0 for value in busy.values())
        skew = max(queued.values()) - min(queued.values())
        pending_skew = max(pending.values()) - min(pending.values())
        row_skew = max(queued_rows.values()) - min(queued_rows.values())
        if dt:
            waiting_hist[skew] += dt
            pending_hist[pending_skew] += dt
            row_hist[row_skew] += dt
            # Across-worker population variance at each instant, integrated
            # over time. This is not variance of the total assignment counts.
            waiting_mean = sum(queued.values()) / len(pids)
            pending_mean = sum(pending.values()) / len(pids)
            waiting_variance += (
                dt * sum((v - waiting_mean) ** 2 for v in queued.values()) / len(pids)
            )
            pending_variance += (
                dt * sum((v - pending_mean) ** 2 for v in pending.values()) / len(pids)
            )
            max_depth = max(max_depth, max(queued.values()))
            max_pending = max(max_pending, max(pending.values()))
        max_skew = max(max_skew, skew)
        if skew >= 2:
            skew_time += dt
        if any(busy[p] > 0 and queued[p] > 0 for p in pids) and any(
            busy[p] == 0 and queued[p] == 0 for p in pids
        ):
            idle_backlog += dt
            idle_worker_time += dt * sum(busy[p] == 0 and queued[p] == 0 for p in pids)
        # Apply simultaneous transitions together; zero-duration calls and one
        # call finishing when another starts are not overlapping inference.
        for _, pid, queue_delta, busy_delta, pending_delta, rows_delta in group:
            queued[pid] += queue_delta
            busy[pid] += busy_delta
            pending[pid] += pending_delta
            queued_rows[pid] += rows_delta
        if any(
            queued[p] < 0
            or pending[p] < 0
            or queued_rows[p] < 0
            or not 0 <= busy[p] <= 1
            for p in pids
        ):
            raise ValueError("Unpaired or overlapping worker events")
        previous = stamp
    if any(queued.values()) or any(busy.values()) or any(pending.values()):
        raise ValueError("Undrained worker-balance timeline")
    width = end - start
    # Include idle tail time through the observation boundary in duration
    # percentiles; all counters are zero after the final returned response.
    waiting_hist[0] += end - previous
    pending_hist[0] += end - previous
    row_hist[0] += end - previous
    metrics: dict[str, float] = {
        "requests": float(len(events)),
        "busy_workers_mean": elapsed_busy / width,
        "idle_with_backlog_fraction": idle_backlog / width,
        "waiting_skew_ge2_fraction": skew_time / width,
        "waiting_count_skew_max": float(max_skew),
        "waiting_depth_max": float(max_depth),
        "outstanding_depth_max": float(max_pending),
        "waiting_count_skew_mean": sum(k * v for k, v in waiting_hist.items()) / width,
        "waiting_count_skew_p50": weighted_percentile(waiting_hist, 50),
        "waiting_count_skew_p95": weighted_percentile(waiting_hist, 95),
        "waiting_count_skew_p99": weighted_percentile(waiting_hist, 99),
        "outstanding_count_skew_max": float(max(pending_hist, default=0)),
        "outstanding_count_skew_p95": weighted_percentile(pending_hist, 95),
        "waiting_variance_time_mean": waiting_variance / width,
        "waiting_stddev_rms": (waiting_variance / width) ** 0.5,
        "outstanding_variance_time_mean": pending_variance / width,
        "outstanding_stddev_rms": (pending_variance / width) ** 0.5,
        "waiting_rows_skew_p95": weighted_percentile(row_hist, 95),
        "waiting_rows_skew_max": float(max(row_hist, default=0)),
        "idle_worker_capacity_candidate_fraction": idle_worker_time / width / len(pids),
        "admission_mean_ms": sum(admission) / len(admission) if admission else 0.0,
        "admission_p95_ms": percentile(admission, 95),
    }
    for rows, times in class_service.items():
        metrics.update(
            {
                f"rows_{rows}_requests": float(len(times)),
                f"rows_{rows}_service_mean_ms": sum(times) / len(times),
                f"rows_{rows}_admission_mean_ms": sum(class_admission[rows])
                / len(times),
                f"rows_{rows}_admission_p95_ms": percentile(class_admission[rows], 95),
                f"rows_{rows}_admission_p99_ms": percentile(class_admission[rows], 99),
            }
        )
    for pid in pids:
        times = service[pid]
        metrics.update(
            {
                f"worker_{pid}_rows_{rows}_requests": float(count)
                for rows, count in worker_classes[pid].items()
            }
        )
        metrics.update(
            {
                f"worker_{pid}_requests": float(len(times)),
                f"worker_{pid}_busy_fraction": sum(times) * 1e6 / width,
                f"worker_{pid}_service_mean_ms": (
                    sum(times) / len(times) if times else 0
                ),
                f"worker_{pid}_service_p95_ms": percentile(times, 95),
            }
        )
    return metrics


def sample(pids: list[int]) -> None:
    global WINDOW_START, DROPPED, LAST
    end = time.perf_counter_ns()
    start = WINDOW_START or min((e[1] for e in EVENTS), default=end - 1)
    events = list(EVENTS)
    EVENTS.clear()
    LAST = {
        "worker_pids": pids,
        "window_start_ns": start,
        "window_end_ns": end,
        "events": events,
        "dropped": DROPPED,
        "metrics": analyze(events, pids, (start, end)),
    }
    DROPPED = 0
    # Analysis occurs outside load windows. Begin the next interval after it,
    # so warm-up/measurement boundary stats do not count analysis as idle time.
    WINDOW_START = time.perf_counter_ns()


def snapshot() -> dict[str, Any]:
    return LAST


def record(event: list[int]) -> None:
    global DROPPED
    if len(EVENTS) < MAX_EVENTS:
        EVENTS.append(event)
    else:
        DROPPED += 1


def install_typed() -> None:
    original_process = Worker._process_request
    original_dispatch = Dispatcher.dispatch_request

    async def process(
        self: Worker, request: ModelRequestMessage
    ) -> ModelResponseMessage:
        entered = time.perf_counter_ns()
        response = await original_process(self, request)
        finished = time.perf_counter_ns()
        if request.method_name == "predict":
            payload = (
                request.method_args[0]
                if request.method_args
                else request.method_kwargs["payload"]
            )
            # Private diagnostic envelope metadata survives stock pickle but
            # never enters the inference payload or HTTP response headers.
            setattr(
                response,
                "_queue_balance",
                [os.getpid(), entered, finished, int(payload.inputs[0].shape[0])],
            )
        return response

    async def dispatch(
        self: Dispatcher, request: ModelRequestMessage
    ) -> ModelResponseMessage:
        dispatched = time.perf_counter_ns()
        response = await original_dispatch(self, request)
        returned = time.perf_counter_ns()
        if request.method_name == "predict":
            pid, entered, finished, rows = getattr(response, "_queue_balance")
            delattr(response, "_queue_balance")
            record([pid, dispatched, entered, finished, returned, rows])
        return response

    setattr(Worker, "_process_request", process)
    setattr(Dispatcher, "dispatch_request", dispatch)


def install() -> None:
    """Install extra wire timestamps only in explicitly instrumented runs."""
    if os.environ.get("MLSERVER_QUEUE_JSON", "frontend") == "frontend":
        if os.environ.get("MLSERVER_QUEUE_TRANSPORT", "queue") != "queue":
            raise ValueError("Typed worker-balance diagnostic requires Queue")
        install_typed()
        return
    if os.environ.get("MLSERVER_QUEUE_JSON") != "full":
        raise ValueError("Worker-balance diagnostic requires full worker JSON")
    original_process = Worker._process_request
    original_dispatch = _raw.RawEndpoints.dispatch_body

    async def process(
        self: Worker, request: ModelRequestMessage
    ) -> ModelResponseMessage:
        entered = time.perf_counter_ns()
        response = await original_process(self, request)
        finished = time.perf_counter_ns()
        if request.method_name == _raw.METHOD and isinstance(
            response.return_value, _raw.RawReply
        ):
            response.return_value.headers.update(
                {ENTER: str(entered), FINISH: str(finished)}
            )
        return response

    async def dispatch(self: Any, model: Any, body: bytes, headers: dict) -> Any:
        dispatched = time.perf_counter_ns()
        reply = await original_dispatch(self, model, body, headers)
        returned = time.perf_counter_ns()
        event = [
            reply.worker_pid,
            dispatched,
            int(reply.headers.pop(ENTER)),
            int(reply.headers.pop(FINISH)),
            returned,
        ]
        record(event)
        return reply

    setattr(Worker, "_process_request", process)
    setattr(_raw.RawEndpoints, "dispatch_body", dispatch)
