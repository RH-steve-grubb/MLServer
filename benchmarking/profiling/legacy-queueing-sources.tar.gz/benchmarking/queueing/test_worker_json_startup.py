"""Numerical serving checks for both GIL modes and the ZeroMQ scheduler.

These are correctness tests, not resource-matched performance measurements.
Each subprocess receives the explicit comparison environment rather than
inheriting pytest's production/trusted-runtime fixture configuration.
"""

import asyncio
import contextlib
import json
import os
import signal
import subprocess
import tempfile
import time
from dataclasses import replace
from pathlib import Path

import aiohttp
import onnxruntime as ort
import pytest

from . import single_compare as comparison, single_client as client


@pytest.mark.parametrize(
    "variant", comparison.worker_json_variants(), ids=lambda v: v.name
)
async def test_worker_json_numerical_startup(
    variant: comparison.Variant, tmp_path: Path
) -> None:
    binary = comparison.serving_python(variant.runtime)
    if not binary.exists() or not (comparison.STORE / "source-312").is_dir():
        pytest.skip("Needs the durable serving environments and ONNX artifact")
    # Two workers exercise actual dispatch, but avoid treating test resource
    # usage or abbreviated warm-up as a benchmark of the twelve-worker pool.
    variant = replace(variant, workers=2, threads=1)
    setup = comparison.Setup(
        comparison.STORE, comparison.Budget(), frozen_harness=comparison.HERE
    )
    server = comparison.Server(setup, variant, tmp_path)
    with tempfile.TemporaryDirectory(prefix="mj-", dir="/tmp") as ipc:
        env = comparison.environment(variant, setup, ipc)
        with (tmp_path / "server.log").open("w") as log:
            process = subprocess.Popen(
                server.command(),
                env=env,
                cwd=tmp_path,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            try:
                async with aiohttp.ClientSession(
                    base_url=f"http://127.0.0.1:{server.port}",
                    timeout=aiohttp.ClientTimeout(total=60),
                ) as session:
                    deadline = time.monotonic() + 90
                    while True:
                        if process.poll() is not None:
                            pytest.fail((tmp_path / "server.log").read_text())
                        try:
                            async with session.get(
                                "/single-instance/state"
                            ) as response:
                                if response.status == 200:
                                    state = await response.json()
                                    break
                        except aiohttp.ClientError:
                            pass
                        if time.monotonic() > deadline:
                            pytest.fail("Diagnostic server did not become ready")
                        await asyncio.sleep(0.05)
                    assert state["gil_enabled"] == comparison.gil_enabled(variant)
                    assert state["balanced_installed"] == (
                        variant.scheduler == "least-outstanding"
                    )
                    assert state["json_codec"] == (
                        "stdlib" if variant.runtime == "314" else "orjson"
                    )
                    options = ort.SessionOptions()
                    options.intra_op_num_threads = 1
                    options.add_session_config_entry(
                        "session.intra_op.allow_spinning", "0"
                    )
                    reference = ort.InferenceSession(
                        str(setup.model), options, providers=["CPUExecutionProvider"]
                    )
                    for rows in (1, 100, 1000):
                        bodies = [
                            json.dumps(client.document(rows, seed)).encode()
                            for seed in range(4)
                        ]
                        await asyncio.gather(
                            *(
                                client.validate(session, body, reference)
                                for body in bodies
                            )
                        )
                    async with session.get("/single-instance/state") as response:
                        after = await response.json()
                    assert after["gil_enabled"] == state["gil_enabled"]
                    checkpoints = [
                        json.loads(line)
                        for line in (tmp_path / "server.log").read_text().splitlines()
                        if line.startswith('{"phase":')
                    ]
                    workers = [
                        row for row in checkpoints if row["phase"] == "worker-loaded"
                    ]
                    assert len({row["pid"] for row in workers}) == 2
                    assert all(row["gil_enabled"] for row in workers)
            finally:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGINT)
                    try:
                        process.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait(timeout=10)
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
