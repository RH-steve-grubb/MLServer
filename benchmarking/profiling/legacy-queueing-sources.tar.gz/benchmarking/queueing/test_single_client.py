"""Client process count must not change request concurrency or warm-up volume."""

from collections import Counter

import pytest

from . import single_client as client


@pytest.mark.parametrize("count", [2, 4])
@pytest.mark.parametrize("total", [64, 128, 512])
def test_concurrency_is_partitioned_not_multiplied(count: int, total: int) -> None:
    assert (
        sum(
            client.concurrency_for({"clients": count, "concurrency": total}, index)
            for index in range(count)
        )
        == total
    )


@pytest.mark.parametrize("count", [2, 4])
def test_invalid_indices_and_concurrency_are_rejected(count: int) -> None:
    case = {"clients": count, "concurrency": 64}
    for index in (-1, count):
        with pytest.raises(ValueError, match="index"):
            client.concurrency_for(case, index)
    with pytest.raises(ValueError, match="divide evenly"):
        client.concurrency_for({"clients": count, "concurrency": 1}, 0)
    with pytest.raises(ValueError):
        client.concurrency_for({"clients": 3, "concurrency": 64}, 0)


@pytest.mark.parametrize("total", [64, 512])
def test_two_and_four_clients_have_identical_overall_warmup(total: int) -> None:
    seeds = [
        Counter(seed for index in range(n) for seed in client.warmup_seeds(n, index))
        for n in (2, 4)
    ]
    assert seeds[0] == seeds[1] == Counter({0: 2, 3: 2, 11: 2, 29: 2})
    for sizes in (1, 2):
        volumes = [
            sum(
                sizes * len(client.warmup_seeds(n, index)) + max(64, total) // n
                for index in range(n)
            )
            for n in (2, 4)
        ]
        assert volumes[0] == volumes[1] == 8 * sizes + max(64, total)
