"""Compare stock, inline-control and bounded JSON-thread REST frontends."""

import argparse
import hashlib
import importlib
import json
import os
import platform
import statistics
import sys
from pathlib import Path

study = importlib.import_module(
    f"{__package__}.free_threaded" if __package__ else "free_threaded"
)


def validate(row: dict) -> None:
    after = row["checks"]["after"]
    pool = after.get("frontend_json_pool")
    if row["frontend"] == "stock":
        if pool is not None:
            raise ValueError("Stock control unexpectedly installed JSON offloading")
        return
    count = row["json_threads"]
    if pool is None or pool["workers"] != count or pool["inflight"]:
        raise ValueError("Incorrect pool or undrained CPU work")
    requests = max(20, row["concurrency"]) + row["total_drained"]
    if pool["completed"] != 2 * requests:
        raise ValueError("Missing JSON parse/encode operations")
    if pool["peak_inflight"] > count:
        raise ValueError("Executor admission exceeded its configured bound")
    if count:
        states = pool["thread_gil_states"]
        if not states or any(
            value != (row["mode"] == "on") for value in states.values()
        ):
            raise ValueError("JSON thread GIL state did not match frontend")
    elif pool["thread_gil_states"]:
        raise ValueError("Inline control unexpectedly created JSON threads")


def summarize(rows: list[dict]) -> str:
    lines = [
        "REST/HTTP JSON frontend CPU placement; synthetic CPU ONNX MLP.",
        "One frontend, six GIL-enabled ONNX workers, Queue/pickle, h11.",
        "Same CPython 3.14 free-threaded build and standard-library JSON.",
        "Stock = original FastAPI route; inline = same custom stages as threads.",
        "Only parsing/validation and response formatting move to JSON threads.",
        "No gRPC, ZeroMQ, raw worker JSON, scheduler or inference changes.",
        "RPS and per-run p95 are arithmetic means, not pooled percentiles.",
        "",
        "rows C GIL frontend trials RPS vs-stock p95-ms frontend-cores worker-cores",
    ]
    keys = sorted({(r["batch"], r["concurrency"], r["mode"]) for r in rows})
    for batch, concurrency, mode in keys:
        matching = [
            r
            for r in rows
            if (r["batch"], r["concurrency"], r["mode"]) == (batch, concurrency, mode)
        ]
        baseline = [r["rps"] for r in matching if r["frontend"] == "stock"]
        for frontend in dict.fromkeys(r["frontend"] for r in matching):
            group = [r for r in matching if r["frontend"] == frontend]
            rps = statistics.mean(r["rps"] for r in group)
            ratio = rps / statistics.mean(baseline) if baseline else float("nan")
            p95 = statistics.mean(r["timings"]["client_ms"]["p95"] for r in group)
            cpu = statistics.mean(r["server_main_cpu_cores"] for r in group)
            worker = statistics.mean(r["worker_cpu_cores"] for r in group)
            lines.append(
                f"{batch:4} {concurrency:2} {mode:3} {frontend:12} {len(group):2} "
                f"{rps:8.1f} {ratio:8.3f} {p95:8.2f} {cpu:8.3f} {worker:8.3f}"
            )
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> None:
    args.output.mkdir(parents=True, exist_ok=False)
    metadata = {
        "scope": "REST/HTTP JSON only; bounded frontend JSON CPU offloading",
        "coordinator": sys.version,
        "platform": platform.platform(),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "arguments": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in vars(args).items()
        },
        "model_sha256": hashlib.sha256(args.model.read_bytes()).hexdigest(),
        "source_manifest": study.source_manifest(args.source),
        "harness_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in Path(__file__).parent.glob("*.py")
        },
        "load_average_before": os.getloadavg(),
    }
    args.output.joinpath("metadata.json").write_text(
        json.dumps(metadata, indent=2) + "\n"
    )
    variants = [("stock", None), ("inline", 0)] + [
        (f"threads-{threads}", threads) for threads in args.threads
    ]
    rows = []
    for trial in range(args.repeats):
        ordered = variants[trial % len(variants) :] + variants[: trial % len(variants)]
        for batch in args.batches:
            for concurrency in args.concurrencies:
                for frontend, threads in ordered:
                    modes = args.modes if trial % 2 == 0 else list(reversed(args.modes))
                    for mode in modes:
                        case = dict(
                            frontend=frontend,
                            mode=mode,
                            batch=batch,
                            concurrency=concurrency,
                            trial=trial,
                        )
                        if threads is not None:
                            case["json_threads"] = threads
                        directory = args.output / (
                            f"r{trial}-b{batch}-c{concurrency}-{mode}-{frontend}"
                        )
                        print(f"Starting {directory.name}", flush=True)
                        row = study.run_case(args, case, directory)
                        validate(row)
                        rows.append(row)
                        args.output.joinpath("results.json").write_text(
                            json.dumps(rows, indent=2) + "\n"
                        )
                        args.output.joinpath("SUMMARY.txt").write_text(summarize(rows))
                        print(
                            f"  {row['rps']:.1f} RPS; p95 "
                            f"{row['timings']['client_ms']['p95']:.1f} ms; frontend "
                            f"{row['server_main_cpu_cores']:.2f} cores",
                            flush=True,
                        )
    print(summarize(rows), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("server-python", "client-python", "source", "model", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--threads", type=int, nargs="+", default=[1, 4, 8, 32])
    parser.add_argument(
        "--modes", choices=["on", "off"], nargs="+", default=["on", "off"]
    )
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[64])
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    args.workers, args.worker_gil = 6, "on"
    if (
        args.seconds <= 0
        or args.repeats < 1
        or min(args.threads + args.batches + args.concurrencies) < 1
    ):
        parser.error(
            "Thread counts, rows, concurrency, seconds and repeats must be positive"
        )
    run(args)


if __name__ == "__main__":
    main()
