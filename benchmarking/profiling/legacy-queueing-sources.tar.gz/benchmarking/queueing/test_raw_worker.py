"""Check worker JSON semantics separately from transport performance."""

import json
import os
from functools import partial
from multiprocessing.reduction import ForkingPickler
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
from httpx import AsyncClient
from prometheus_client import CollectorRegistry, Counter, Summary

from mlserver.errors import MLServerError, ModelNotFound
from mlserver.handlers import DataPlane
from mlserver.handlers import dataplane as dataplane_module
from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.model import ParallelModel
from mlserver.rest.app import create_app
from mlserver.rest.requests import Request
from mlserver.settings import ModelSettings, Settings
from mlserver.types import InferenceResponse
from tests.fixtures import SumModel

from . import raw_worker


def body() -> bytes:
    return json.dumps(
        {
            "id": "client-id",
            "inputs": [
                {
                    "name": "input",
                    "shape": [1, 3],
                    "datatype": "FP32",
                    "data": [1, 2, 3],
                    "parameters": {"content_type": "np"},
                }
            ],
        }
    ).encode()


@pytest.fixture
def worker(monkeypatch: Any) -> Any:
    # Isolate real inference counters without changing the shared test allowlist
    # or adding a new test-only runtime. SumModel is already registered.
    metrics = CollectorRegistry()
    monkeypatch.setattr(dataplane_module, "Counter", partial(Counter, registry=metrics))
    monkeypatch.setattr(dataplane_module, "Summary", partial(Summary, registry=metrics))
    models = {
        name: SumModel(
            ModelSettings(
                name=name,
                parameters={"version": "v1"},
                implementation="tests.fixtures.SumModel",
            )
        )
        for name in ("sum-model", "other-model")
    }
    for model in models.values():
        model.ready = True

    async def get_model(name: str, version: str | None = None) -> SumModel:
        if name not in models or version not in (None, "v1"):
            raise ModelNotFound(name, version)
        return models[name]

    return SimpleNamespace(
        _settings=Settings(),
        _model_registry=SimpleNamespace(get_model=get_model),
    )


def message(name: str = "sum-model", version: str | None = "v1") -> ModelRequestMessage:
    return ModelRequestMessage(
        model_name=name,
        model_version=version,
        method_name=raw_worker.METHOD,
        method_args=[body(), {"x-test": "retained"}],
    )


@pytest.mark.parametrize("mode", ["input", "full"])
@pytest.mark.parametrize("target", [("sum-model", "v1"), ("other-model", None)])
async def test_worker_preserves_model_selection_ids_headers_and_pickle(
    mode: str, target: tuple[str, str | None], worker: Any, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", mode)
    name, version = target
    original = message(name, version)
    original = ForkingPickler.loads(ForkingPickler.dumps(original))
    response = await raw_worker.process_request(worker, original)
    response = ForkingPickler.loads(ForkingPickler.dumps(response))
    assert response.id == original.id and response.exception is None
    reply = response.return_value
    assert isinstance(reply, raw_worker.RawReply)
    assert reply.worker_pid == os.getpid()
    if mode == "full":
        assert isinstance(reply.body, bytes)
        parsed = InferenceResponse.model_validate_json(reply.body)
    else:
        assert isinstance(reply.body, InferenceResponse)
        parsed = reply.body
    assert parsed.id == "client-id"
    assert parsed.model_name == name and parsed.model_version == "v1"
    assert parsed.outputs[0].data.root == [6]
    assert reply.headers["x-test"] == "retained"
    assert reply.headers["Ce-Requestid"] == "client-id"
    assert reply.headers["Ce-Specversion"] == "0.3"


@pytest.mark.parametrize("invalid", [b"{", b"{}", b'{"inputs": "not a list"}'])
async def test_worker_returns_validation_errors_without_inference(
    invalid: bytes, worker: Any
) -> None:
    request = message()
    request.method_args[0] = invalid
    response = await raw_worker.process_request(worker, request)
    reply = response.return_value
    assert isinstance(reply, raw_worker.RawReply) and isinstance(reply.body, bytes)
    assert reply.status == 422
    errors = json.loads(reply.body)["detail"]
    assert errors and errors[0]["loc"][0] == "body"
    assert not hasattr(worker, "_queue_raw_data_plane")


@pytest.mark.parametrize("name,version", [("absent", None), ("sum-model", "absent")])
async def test_worker_keeps_model_error_status(
    name: str, version: str | None, worker: Any, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "full")
    response = await raw_worker.process_request(worker, message(name, version))
    assert isinstance(response.exception, MLServerError)
    assert response.exception.status_code == 404


async def test_non_raw_messages_use_original_process_handler(monkeypatch: Any) -> None:
    original = AsyncMock(return_value=ModelResponseMessage(id="normal"))
    monkeypatch.setattr(raw_worker, "_ORIGINAL_PROCESS", original)
    request = message()
    request.method_name = "predict"
    worker = Mock()
    assert await raw_worker.process_request(worker, request) is original.return_value
    original.assert_awaited_once_with(worker, request)


@pytest.mark.parametrize("mode", ["input", "full"])
@pytest.mark.parametrize("encoded", [body(), b"{", b"{}", b"", b"[]"])
async def test_worker_body_matches_existing_rest_contract(
    mode: str, encoded: bytes, worker: Any, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", mode)
    plane = DataPlane(worker._settings, worker._model_registry)
    worker._queue_raw_data_plane = plane
    app = create_app(Settings(gzip_enabled=False, metrics_endpoint=None), plane, Mock())
    async with AsyncClient(app=app, base_url="http://test") as client:
        expected = await client.post(
            "/v2/models/sum-model/infer",
            content=encoded,
            headers={"content-type": "application/json", "x-test": "retained"},
        )
    request = message()
    request.method_args = [encoded, {"x-test": "retained"}]
    result = await raw_worker.process_request(worker, request)
    assert result.exception is None
    reply = result.return_value
    assert isinstance(reply, raw_worker.RawReply)
    actual = (
        json.loads(reply.body)
        if isinstance(reply.body, bytes)
        else reply.body.model_dump(mode="json", exclude_unset=True, exclude_none=True)
    )
    assert reply.status == expected.status_code
    assert actual == expected.json()
    if reply.status == 200:
        for key, value in reply.headers.items():
            assert expected.headers[key] == value


@pytest.mark.parametrize("mode", ["input", "full"])
@pytest.mark.parametrize("versioned", [False, True])
async def test_raw_http_route_never_parses_json_in_frontend(
    mode: str, versioned: bool, worker: Any, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", mode)
    frontend_parser = AsyncMock(side_effect=AssertionError("frontend JSON parse"))
    monkeypatch.setattr(Request, "json", frontend_parser)

    async def dispatch(request: ModelRequestMessage) -> ModelResponseMessage:
        assert request.method_args[0] == body()
        response = await raw_worker.process_request(worker, request)
        assert isinstance(response.return_value, raw_worker.RawReply)
        response.return_value.worker_pid = os.getpid() + 10000  # Simulated IPC peer.
        return response

    model = Mock(spec=ParallelModel)
    model.name, model.version, model.ready = "sum-model", "v1", True
    model._dispatcher = SimpleNamespace(dispatch_request=dispatch)
    registry: Any = SimpleNamespace(get_model=AsyncMock(return_value=model))
    app = create_app(Settings(gzip_enabled=False), Mock(spec=DataPlane), Mock())
    server: Any = SimpleNamespace(_app=app)
    raw_worker.install_routes(server, registry)
    path = "/v2/models/sum-model"
    if versioned:
        path += "/versions/v1"
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            path + "/infer", content=body(), headers={"x-test": "retained"}
        )
    assert response.status_code == 200
    assert response.json()["outputs"][0]["data"] == [6]
    assert response.json()["id"] == "client-id"
    assert response.headers["x-test"] == "retained"
    frontend_parser.assert_not_awaited()
    registry.get_model.assert_awaited_once_with(
        "sum-model", "v1" if versioned else None
    )


@pytest.mark.parametrize(
    "key,value",
    [
        ("MLSERVER_QUEUE_CODEC", "msgpack"),
        ("MLSERVER_QUEUE_TENSORS", "numpy"),
        ("MLSERVER_QUEUE_TRANSPORT", "unsupported"),
        ("MLSERVER_QUEUE_JSON", "frontend"),
    ],
)
async def test_install_rejects_confounded_modes(
    key: str, value: str, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "full")
    monkeypatch.setenv(key, value)
    with pytest.raises(ValueError, match="requires"):
        raw_worker.install()


@pytest.mark.parametrize("transport", ["queue", "zmq"])
async def test_raw_worker_accepts_both_pickle_transports(
    transport: str, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "full")
    monkeypatch.setenv("MLSERVER_QUEUE_TRANSPORT", transport)
    # Register the original attribute with monkeypatch so install() is undone.
    monkeypatch.setattr(
        raw_worker.Worker, "_process_request", raw_worker.Worker._process_request
    )
    raw_worker.install()
    assert raw_worker.Worker._process_request is raw_worker.process_request
