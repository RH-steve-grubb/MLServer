"""JSON stage parity, thread ownership, admission and cancellation controls."""

import asyncio
import json
import threading
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
from httpx import ASGITransport, AsyncClient

from mlserver.errors import ModelNotFound
from mlserver.rest.app import create_app
from mlserver.settings import Settings
from mlserver.types import InferenceResponse

from . import frontend_offload, run_frontend_offload


def body() -> bytes:
    return json.dumps(
        {
            "id": "client-id",
            "inputs": [
                {
                    "name": "input",
                    "shape": [1, 2],
                    "datatype": "FP32",
                    "data": [1.25, 2.5],
                }
            ],
        }
    ).encode()


def make_server(owner_ids: list[int]) -> Any:
    async def infer(payload: Any, name: str, version: str | None) -> InferenceResponse:
        owner_ids.append(threading.get_native_id())
        if name == "absent":
            raise ModelNotFound(name, version)
        assert payload.parameters.headers["x-input"] == "retained"
        return InferenceResponse(
            id=payload.id,
            model_name=name,
            model_version=version,
            outputs=[
                {
                    "name": "output",
                    "shape": [1, 2],
                    "datatype": "FP32",
                    "data": list(payload.inputs[0].data.root),
                }
            ],
            parameters={"headers": {"x-output": "retained"}},
        )

    plane = Mock()
    plane.infer = AsyncMock(side_effect=infer)
    return SimpleNamespace(
        _app=create_app(
            Settings(gzip_enabled=False, metrics_endpoint=None), plane, Mock()
        )
    )


@pytest.mark.parametrize("workers", [0, 1, 4])
@pytest.mark.parametrize("versioned", [False, True])
@pytest.mark.parametrize("encoded", [body(), b"", b"{}", b"[]", b"null", b"{", b"\xff"])
async def test_json_routes_match_stock_body_headers_and_errors(
    workers: int, versioned: bool, encoded: bytes, monkeypatch: Any
) -> None:
    # Force the same standard JSON path used by the free-threaded environment,
    # even when the ordinary Python test environment has orjson installed.
    from mlserver.codecs import json as codec
    from mlserver.rest import requests

    monkeypatch.setattr(codec, "orjson", None)
    monkeypatch.setattr(requests, "orjson", None)
    owners: list[int] = []
    original, experimental = make_server(owners), make_server(owners)
    pool = frontend_offload.install_routes(experimental, workers)
    path = "/v2/models/chosen-model"
    if versioned:
        path += "/versions/v2"
    try:
        responses = []
        for server in (original, experimental):
            async with AsyncClient(
                transport=ASGITransport(app=server._app), base_url="http://test"
            ) as client:
                responses.append(
                    await client.post(
                        path + "/infer",
                        content=encoded,
                        headers={
                            "content-type": "application/json",
                            "x-input": "retained",
                        },
                    )
                )
        expected, actual = responses
        assert actual.status_code == expected.status_code
        assert actual.json() == expected.json()
        if actual.status_code == 200:
            assert actual.headers["x-output"] == expected.headers["x-output"]
            assert actual.headers["content-length"] == str(len(actual.content))
            assert actual.json()["model_name"] == "chosen-model"
            assert actual.json()["id"] == "client-id"
        assert all(owner == threading.get_native_id() for owner in owners)
        assert pool.inflight == 0 and pool.peak_inflight <= workers
        if workers:
            assert pool.thread_states
            assert threading.get_native_id() not in pool.thread_states
    finally:
        await pool.close()


@pytest.mark.parametrize("workers", [0, 2])
async def test_model_errors_and_other_routes_remain_on_original_loop(
    workers: int,
) -> None:
    server = make_server([])
    untouched = {
        route.path: route
        for route in server._app.routes
        if getattr(route, "path", None) not in frontend_offload.PATHS
    }
    pool = frontend_offload.install_routes(server, workers)
    try:
        assert all(route in server._app.routes for route in untouched.values())
        async with AsyncClient(
            transport=ASGITransport(app=server._app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/v2/models/absent/infer",
                content=body(),
                headers={"content-type": "application/json", "x-input": "retained"},
            )
        assert response.status_code == 404
    finally:
        await pool.close()


@pytest.mark.parametrize("workers", [4, 32])
async def test_concurrent_routes_keep_each_requests_data_and_identity(
    workers: int,
) -> None:
    owners: list[int] = []
    server = make_server(owners)
    pool = frontend_offload.install_routes(server, workers)
    try:
        async with AsyncClient(
            transport=ASGITransport(app=server._app), base_url="http://test"
        ) as client:

            async def predict(index: int) -> None:
                document = json.loads(body())
                document["id"] = f"request-{index}"
                document["inputs"][0]["data"] = [index, index + 0.25]
                response = await client.post(
                    f"/v2/models/model-{index % 8}/versions/v2/infer",
                    json=document,
                    headers={"x-input": "retained"},
                )
                assert response.status_code == 200
                result = response.json()
                assert result["id"] == document["id"]
                assert result["model_name"] == f"model-{index % 8}"
                assert result["model_version"] == "v2"
                assert result["outputs"][0]["data"] == [index, index + 0.25]

            await asyncio.gather(*(predict(index) for index in range(64)))
        assert pool.completed == 128 and pool.inflight == 0
        assert pool.peak_inflight <= workers
        assert all(owner == threading.get_native_id() for owner in owners)
    finally:
        await pool.close()


async def test_cancelled_caller_does_not_release_running_job_slot() -> None:
    pool = frontend_offload.JsonPool(1)
    entered, release, second_entered = (
        threading.Event(),
        threading.Event(),
        threading.Event(),
    )

    def blocking() -> None:
        entered.set()
        assert release.wait(timeout=5)
        raise ValueError("abandoned job exception must be retrieved")

    first = asyncio.create_task(pool.run(blocking))
    try:
        assert await asyncio.to_thread(entered.wait, 2)
        first.cancel()
        with pytest.raises(asyncio.CancelledError):
            await first
        second = asyncio.create_task(pool.run(second_entered.set))
        await asyncio.sleep(0.02)
        assert pool.inflight == 1 and not second_entered.is_set()
        release.set()
        await asyncio.wait_for(second, 2)
        assert pool.peak_inflight == 1 and pool.completed == 2
        assert pool.inflight == 0
    finally:
        release.set()
        await pool.close()


async def test_cancelled_admission_does_not_submit_job() -> None:
    pool = frontend_offload.JsonPool(1)
    entered, release = threading.Event(), threading.Event()

    def blocking() -> None:
        entered.set()
        assert release.wait(timeout=5)

    first = asyncio.create_task(pool.run(blocking))
    try:
        assert await asyncio.to_thread(entered.wait, 2)
        blocked = asyncio.create_task(pool.run(lambda: pytest.fail("queued job ran")))
        await asyncio.sleep(0.01)
        blocked.cancel()
        with pytest.raises(asyncio.CancelledError):
            await blocked
        release.set()
        await first
        assert pool.completed == 1 and pool.inflight == 0
    finally:
        release.set()
        await pool.close()


async def test_pool_admission_bounds_many_concurrent_jobs() -> None:
    pool = frontend_offload.JsonPool(4)
    lock = threading.Lock()
    active, peak = 0, 0

    def operation() -> int:
        nonlocal active, peak
        with lock:
            active += 1
            peak = max(peak, active)
        # Waiting releases the GIL, so this checks parallel admission in the
        # ordinary Python test environment too, without requiring a 3.14 port.
        threading.Event().wait(0.005)
        with lock:
            active -= 1
        return threading.get_native_id()

    try:
        ids = await asyncio.gather(*(pool.run(operation) for _ in range(64)))
        assert pool.completed == 64 and pool.inflight == 0
        assert 1 < peak <= 4 and pool.peak_inflight == 4
        assert threading.get_native_id() not in ids
    finally:
        await pool.close()


def test_result_validation_rejects_missing_operations_and_wrong_thread_gil() -> None:
    row: dict[str, Any] = {
        "frontend": "threads-2",
        "json_threads": 2,
        "mode": "off",
        "concurrency": 64,
        "total_drained": 100,
        "checks": {
            "after": {
                "frontend_json_pool": {
                    "workers": 2,
                    "inflight": 0,
                    "completed": 328,
                    "peak_inflight": 2,
                    "thread_gil_states": {123: False},
                }
            }
        },
    }
    run_frontend_offload.validate(row)
    pool = row["checks"]["after"]["frontend_json_pool"]
    pool["completed"] = 326
    with pytest.raises(ValueError, match="Missing JSON"):
        run_frontend_offload.validate(row)
    pool["completed"] = 328
    pool["thread_gil_states"] = {123: True}
    with pytest.raises(ValueError, match="GIL state"):
        run_frontend_offload.validate(row)
