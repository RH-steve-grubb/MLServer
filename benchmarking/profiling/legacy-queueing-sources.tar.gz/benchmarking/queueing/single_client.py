"""Synchronized fixed-Python REST load client shared by MLServer and OVMS.

Both servers receive the same V2 JSON bytes. Numerical checks and input/body
construction are outside timing. Raw latencies permit pooling the clients
within a run without averaging their percentiles.
"""

import argparse
import asyncio
import hashlib
import itertools
import json
import os
import random
import resource
import time
from pathlib import Path
from typing import Any, Iterator

import aiohttp
import numpy as np
import onnxruntime as ort
import uvloop


def document(rows: int, seed: int = 7) -> dict[str, Any]:
    data = np.random.default_rng(seed).normal(size=(rows, 54)).astype(np.float32)
    return {
        "inputs": [
            {
                "name": "input",
                "shape": [rows, 54],
                "datatype": "FP32",
                "data": data.ravel().tolist(),
            }
        ],
        "outputs": [{"name": "probabilities"}],
    }


def sizes(values: list[int], client: int) -> Iterator[int]:
    # Shuffled weighted blocks avoid aliasing input size to round robin.
    generator = random.Random(20261013 + client)
    while True:
        block = list(values)
        generator.shuffle(block)
        yield from block


async def validate(session: aiohttp.ClientSession, body: bytes, reference: Any) -> None:
    data = json.loads(body)
    rows = data["inputs"][0]["shape"][0]
    expected = reference.run(
        ["probabilities"],
        {
            "input": np.asarray(data["inputs"][0]["data"], dtype=np.float32).reshape(
                rows, 54
            )
        },
    )[0]
    async with session.post(
        "/v2/models/queue-mlp/infer",
        data=body,
        headers={"content-type": "application/json"},
    ) as response:
        raw = await response.read()
        if response.status != 200:
            raise RuntimeError(f"Warm-up HTTP {response.status}: {raw[:300]!r}")
        result = json.loads(raw)
        output = result["outputs"][0]
        if (
            result["model_name"] != "queue-mlp"
            or output["name"] != "probabilities"
            or output["datatype"] != "FP32"
            or output["shape"] != [rows, 7]
        ):
            raise ValueError("Prediction model/output contract mismatch")
        actual = np.asarray(output["data"], dtype=np.float32).reshape(rows, 7)
        np.testing.assert_allclose(actual, expected, rtol=1e-4, atol=1e-6)


def concurrency_for(case: dict[str, Any], client: int) -> int:
    count, total = case.get("clients", 2), case["concurrency"]
    if count not in (2, 4) or total < count or total % count:
        raise ValueError("Total concurrency must divide evenly across two/four clients")
    if not 0 <= client < count:
        raise ValueError("Client index exceeds the active client count")
    return total // count


def warmup_seeds(count: int, client: int) -> tuple[int, ...]:
    seeds = (0, 3, 11, 29)
    if count == 2:
        return seeds
    if count != 4:
        raise ValueError("Expected two or four clients")
    # Preserve the original eight varied-input checks per size overall when
    # doubling the clients; warm-up volume is not part of this experiment.
    start = 2 * (client % 2)
    return seeds[start : start + 2]


async def run(case: dict[str, Any], directory: Path, client: int) -> None:
    concurrency = concurrency_for(case, client)
    client_count = case.get("clients", 2)
    values = case.get("mix") or [case["rows"]]
    encoded = {n: json.dumps(document(n)).encode() for n in set(values)}
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.add_session_config_entry("session.intra_op.allow_spinning", "0")
    reference = ort.InferenceSession(
        case["model"], sess_options=options, providers=["CPUExecutionProvider"]
    )
    connector = aiohttp.TCPConnector(limit=concurrency)
    timeout = aiohttp.ClientTimeout(total=120)
    target = f"http://127.0.0.1:{case['port']}"
    timings: list[float] = []
    row_counts: list[int] = []
    window_counts = dict.fromkeys(encoded, 0)
    errors: list[str] = []
    sequence = sizes(values, client)
    lag: list[float] = []
    warmups = 0
    async with aiohttp.ClientSession(
        base_url=target, connector=connector, timeout=timeout
    ) as session:
        # Different numerical inputs detect more than one memorized output.
        for rows, seed in itertools.product(
            sorted(encoded), warmup_seeds(client_count, client)
        ):
            await validate(
                session, json.dumps(document(rows, seed)).encode(), reference
            )
            warmups += 1
        count = max(64, case["concurrency"]) // client_count
        await asyncio.gather(
            *(
                validate(session, encoded[next(sequence)], reference)
                for _ in range(count)
            )
        )
        warmups += count
        ready = {
            "pid": os.getpid(),
            "client_index": client,
            "client_count": client_count,
            "concurrency": concurrency,
            "warmups": warmups,
            "event_loop": type(asyncio.get_running_loop()).__module__,
            "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "payloads": {
                n: {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
                for n, body in encoded.items()
            },
        }
        (directory / f"client-{client}-ready.json").write_text(json.dumps(ready))
        # The controller publishes one absolute monotonic start for all
        # clients only after all correctness warm-ups and server checks pass.
        gate = directory / "go.json"
        deadline = time.monotonic() + 240
        while not gate.exists():
            if time.monotonic() > deadline:
                raise TimeoutError("Controller did not release the load barrier")
            await asyncio.sleep(0.01)
        control = json.loads(gate.read_text())
        start_ns = control["start_ns"]
        end_ns = start_ns + int(case["seconds"] * 1e9)
        # A timer may wake early; never send a request before the shared start.
        while time.monotonic_ns() < start_ns:
            await asyncio.sleep((start_ns - time.monotonic_ns()) / 1e9)
        actual_start = time.monotonic_ns()
        usage = resource.getrusage(resource.RUSAGE_SELF)
        cpu_before = usage.ru_utime + usage.ru_stime

        async def heartbeat() -> None:
            while True:
                expected = time.monotonic_ns() + 5_000_000
                await asyncio.sleep(0.005)
                lag.append(max(0, time.monotonic_ns() - expected) / 1e6)

        async def requests() -> None:
            while time.monotonic_ns() < end_ns and not errors:
                rows = next(sequence)
                sent = time.monotonic_ns()
                try:
                    async with session.post(
                        "/v2/models/queue-mlp/infer",
                        data=encoded[rows],
                        headers={"content-type": "application/json"},
                    ) as response:
                        raw = await response.read()
                        received = time.monotonic_ns()
                        if response.status != 200:
                            raise RuntimeError(f"HTTP {response.status}: {raw[:300]!r}")
                    timings.append((received - sent) / 1e6)
                    row_counts.append(rows)
                    if received <= end_ns:
                        window_counts[rows] += 1
                except Exception as error:
                    if len(errors) < 10:
                        errors.append(repr(error))

        monitor = asyncio.create_task(heartbeat())
        try:
            await asyncio.gather(*(requests() for _ in range(concurrency)))
        finally:
            monitor.cancel()
            await asyncio.gather(monitor, return_exceptions=True)
        drained_ns = time.monotonic_ns()
        usage = resource.getrusage(resource.RUSAGE_SELF)
        cpu_after = usage.ru_utime + usage.ru_stime
    np.savez_compressed(
        directory / f"client-{client}-latencies.npz",
        latency_ms=np.asarray(timings),
        rows=np.asarray(row_counts),
        loop_lag_ms=np.asarray(lag),
    )
    result = dict(
        ready,
        errors=errors,
        completed_in_window=sum(window_counts.values()),
        window_counts=window_counts,
        total_drained=len(timings),
        requested_start_ns=start_ns,
        actual_start_ns=actual_start,
        drained_ns=drained_ns,
        client_cpu_seconds=cpu_after - cpu_before,
    )
    (directory / f"client-{client}-result.json").write_text(
        json.dumps(result, indent=2)
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", type=Path)
    parser.add_argument("--client", type=int, choices=range(4), required=True)
    args = parser.parse_args()
    case = json.loads(args.case.read_text())
    try:
        concurrency_for(case, args.client)
    except ValueError as error:
        parser.error(str(error))
    uvloop.install()
    asyncio.run(run(case, args.case.parent, args.client))


if __name__ == "__main__":
    main()
