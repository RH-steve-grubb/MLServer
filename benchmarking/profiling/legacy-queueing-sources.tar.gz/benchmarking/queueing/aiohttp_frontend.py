"""Thin localhost-only raw-JSON frontend, not an alternate production server.

Share model routing, dispatch envelopes and worker JSON with FastAPI controls.
Only infer, health and diagnostic stop/stats routes are implemented. The fixed
trusted workload has no body cap, matching the measured FastAPI control; this
is not a deployment admission policy. No extra worker threads are introduced.
"""

import asyncio
import importlib
import os
from collections.abc import Awaitable, Callable
from typing import Any

from aiohttp import web

from mlserver.codecs.json import encode_to_json_bytes
from mlserver.errors import MLServerError
from mlserver.handlers import DataPlane
from mlserver.registry import MultiModelRegistry
from mlserver.settings import Settings

_raw = importlib.import_module(
    f"{__package__}.raw_worker" if __package__ else "raw_worker"
)


class AiohttpFrontend:
    def __init__(
        self, settings: Settings, registry: MultiModelRegistry, data_plane: DataPlane
    ) -> None:
        if os.environ.get("MLSERVER_QUEUE_JSON") != "full":
            raise ValueError("aiohttp diagnostic requires full worker JSON")
        self.settings = settings
        self.endpoints = _raw.RawEndpoints(registry)
        self.data_plane = data_plane
        self.stopped = asyncio.Event()
        self.replies = 0
        # aiohttp defaults to 1MiB, less than our 1000-row JSON input. The stock
        # FastAPI control has no request-body cap, so do not confound capacity.
        self.app = web.Application(client_max_size=0)
        for path in _raw.PATHS:
            self.app.router.add_post(path, self.infer)
        self.app.router.add_get("/v2/health/ready", self.ready)
        self.app.router.add_get("/v2/health/live", self.live)
        self.app.router.add_post("/queue-probe/stop", self.stop)

    async def infer(self, request: web.Request) -> web.Response:
        try:
            model = await self.endpoints.resolve_model(
                request.match_info["model_name"],
                request.match_info.get("model_version"),
            )
            reply = await self.endpoints.dispatch_body(
                model,
                await request.read(),
                {key.lower(): value for key, value in request.headers.items()},
            )
        except MLServerError as error:
            return web.Response(
                body=encode_to_json_bytes({"error": str(error)}),
                status=error.status_code,
                content_type="application/json",
            )
        if not isinstance(reply.body, bytes):
            raise TypeError("aiohttp diagnostic requires worker response bytes")
        self.replies += 1
        return web.Response(
            body=reply.body,
            status=reply.status,
            headers=reply.headers,
            content_type="application/json",
        )

    async def ready(self, request: web.Request) -> web.Response:
        return web.Response(status=200 if await self.data_plane.ready() else 503)

    async def live(self, request: web.Request) -> web.Response:
        return web.Response(status=200 if await self.data_plane.live() else 503)

    async def stop(self, request: web.Request) -> web.Response:
        self.stopped.set()
        return web.Response(
            body=encode_to_json_bytes({"stopping": True}),
            content_type="application/json",
        )

    def add_stats(self, stats: Callable[[], Awaitable[dict[str, float]]]) -> None:
        async def endpoint(request: web.Request) -> web.Response:
            result = await stats()
            result["http_aiohttp_replies"] = float(self.replies)
            return web.Response(
                body=encode_to_json_bytes(result), content_type="application/json"
            )

        self.app.router.add_get("/queue-probe/stats", endpoint)

    def add_balance(self, snapshot: Callable[[], dict[str, Any]]) -> None:
        async def endpoint(request: web.Request) -> web.Response:
            return web.Response(
                body=encode_to_json_bytes(snapshot()), content_type="application/json"
            )

        self.app.router.add_get("/queue-probe/balance", endpoint)

    async def start(self) -> None:
        # Use the same already-installed uvloop as the FastAPI control. Keepalive
        # and listen backlog match Uvicorn defaults. Peer-cancellation behavior
        # is deliberately not claimed equivalent by this throughput diagnostic.
        runner = web.AppRunner(
            self.app,
            access_log=None,
            handle_signals=False,
            handler_cancellation=False,
            keepalive_timeout=5,
            shutdown_timeout=20,
        )
        try:
            await runner.setup()
            site = web.TCPSite(
                runner, self.settings.host, self.settings.http_port, backlog=2048
            )
            await site.start()
            print(f"aiohttp frontend started pid={os.getpid()}", flush=True)
            await self.stopped.wait()
        finally:
            await runner.cleanup()
            print(f"aiohttp frontend stopped pid={os.getpid()}", flush=True)
