"""Explicit parser controls must not silently select the other HTTP engine."""

from typing import Any
from unittest.mock import Mock

import pytest

from mlserver.rest import RESTServer
from mlserver.settings import Settings

from . import http_parser, run_http_experiments, run_parser_experiments
from .test_http_experiments import document


@pytest.mark.parametrize("mode", ["h11", "httptools"])
async def test_explicit_config_preserves_server_settings(
    mode: str, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_HTTP_PARSER", mode)
    # Restore the original class method after each test's diagnostic hook.
    monkeypatch.setattr(RESTServer, "_get_config", RESTServer._get_config)
    http_parser.install()
    settings = Settings(http_port=19481, access_log=False, metrics_endpoint=None)
    config = RESTServer(settings, Mock(), Mock())._get_config()
    assert config.http == mode
    assert config.port == 19481
    assert config.access_log is False
    config.load()
    expected = "H11Protocol" if mode == "h11" else "HttpToolsProtocol"
    assert config.http_protocol_class.__name__ == expected


@pytest.mark.parametrize("mode", ["auto", "unknown", ""])
async def test_install_rejects_implicit_or_invalid_parser(
    mode: str, monkeypatch: Any
) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_HTTP_PARSER", mode)
    with pytest.raises(ValueError, match="h11 or httptools"):
        http_parser.install()


@pytest.mark.parametrize("variant", list(run_parser_experiments.PARSERS))
@pytest.mark.parametrize("correct", [True, False])
async def test_actual_parser_validation(
    variant: str, correct: bool, monkeypatch: Any
) -> None:
    for name in ("stock-fastapi-queue", "raw-fastapi-zmq"):
        monkeypatch.setitem(
            run_http_experiments.VARIANTS,
            f"{name}-httptools",
            run_http_experiments.VARIANTS[name],
        )
    doc = document(variant)
    mode = run_parser_experiments.PARSERS[variant]
    parser = (
        "aiohttp._http_parser.HttpRequestParser"
        if variant == "raw-aiohttp-zmq"
        else (
            "uvicorn.protocols.http.h11_impl.H11Protocol"
            if mode == "h11"
            else "uvicorn.protocols.http.httptools_impl.HttpToolsProtocol"
        )
    )
    doc["metadata"]["http_engine"] = parser if correct else "wrong.parser.Class"
    if correct:
        run_parser_experiments.validate_parser(doc, variant)
    else:
        with pytest.raises(ValueError, match="Wrong actual HTTP parser"):
            run_parser_experiments.validate_parser(doc, variant)
