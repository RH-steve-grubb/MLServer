"""Run sequential, counterbalanced Queue/pickle and ZeroMQ/pickle ONNX controls.

Run with the MLServer Python-3.12 Poetry interpreter and the isolated PyZMQ
site-packages on PYTHONPATH. This script never installs packages or invokes sudo.
Results, logs, dependency manifests and source snapshots go into --output.
"""

import argparse
import json
import os
import shutil
import signal
import statistics
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

BENCH = Path(__file__).with_name("bench.py")


def validate_rows(document: dict[str, Any], transport: str) -> None:
    if document["metadata"]["queue_transport"] != transport:
        raise ValueError("Requested transport was not selected")
    if not document["results"]:
        raise ValueError("Benchmark produced no cases")
    for row in document["results"]:
        if row["errors"] or row["total_drained"] <= 0:
            raise ValueError("Benchmark request failure or empty measurement")
        if row["queue_codec"] != "pickle" or row["queue_tensors"] != "list":
            raise ValueError("Serializer/tensor comparison was confounded")
        if row["total_workers"] != 6 or row["frontends"] != 1:
            raise ValueError("Frontend/worker comparison was confounded")
        counts = row["transport_counts"]
        if transport == "zmq":
            if any(
                counts[f"transport_{key}"] != row["total_drained"]
                for key in ("sent", "received")
            ):
                raise ValueError(
                    "ZeroMQ did not carry exactly one request/reply per call"
                )
        elif counts:
            raise ValueError("Queue baseline unexpectedly used the ZeroMQ adapter")


def stop_owned_group(process: subprocess.Popen) -> None:
    # Every block starts in its own process group. Never target other servers
    # or infer ownership from a process name. SIGINT gives sweep's finally block
    # time to stop its own servers and pools before forced group cleanup.
    try:
        os.killpg(process.pid, signal.SIGINT)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=25)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait()


def run_block(args: argparse.Namespace, transport: str, index: int) -> dict[str, Any]:
    ipc_dir = args.output / f"ipc-{index}"
    ipc_dir.mkdir(mode=0o700)
    result = args.output / f"{index:02d}-{transport}.json"
    env = dict(os.environ)
    env.update(
        MLSERVER_QUEUE_TRANSPORT=transport,
        MLSERVER_QUEUE_ZMQ_DIR=str(ipc_dir),
        MLSERVER_QUEUE_CODEC="pickle",
        MLSERVER_QUEUE_TENSORS="list",
        PYTHONDONTWRITEBYTECODE="1",
    )
    # Reverse case order on alternate independent pairs to reduce systematic
    # model-size/load-order bias as well as alternating transport order.
    reverse = (index // 2) % 2 == 1
    batches = list(reversed(args.batches)) if reverse else args.batches
    concurrencies = (
        list(reversed(args.concurrencies)) if reverse else args.concurrencies
    )
    command = [
        sys.executable,
        str(BENCH),
        "sweep",
        str(args.model),
        "--configs",
        "pool6-tuned",
        "--unprobed",
        "--batches",
        *map(str, batches),
        "--concurrencies",
        *map(str, concurrencies),
        "--seconds",
        str(args.seconds),
        "--repeats",
        "1",
        "--output",
        str(result),
    ]
    print(f"Block {index + 1}: {transport}; logs/results: {result}", flush=True)
    with (args.output / f"{index:02d}-{transport}.log").open("w") as log:
        process = subprocess.Popen(
            command,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            code = process.wait(
                timeout=300 + args.seconds * len(batches) * len(concurrencies)
            )
            if code:
                raise RuntimeError(f"Benchmark exited {code}; inspect {log.name}")
            # A finished coordinator must not leave inference workers running
            # and interfering with later control blocks.
            try:
                os.killpg(process.pid, 0)
            except ProcessLookupError:
                pass
            else:
                raise RuntimeError("Benchmark left a live process in its owned group")
        except BaseException:
            stop_owned_group(process)
            raise
    document = json.loads(result.read_text())
    validate_rows(document, transport)
    expected = {(batch, c) for batch in args.batches for c in args.concurrencies}
    actual = {(row["batch"], row["concurrency"]) for row in document["results"]}
    if actual != expected or len(document["results"]) != len(expected):
        raise ValueError("Benchmark did not finish exactly the requested case matrix")
    for row in document["results"]:
        row.update(transport=transport, independent_trial=index // 2, block=index)
    return document


def write_summary(output: Path, documents: list[dict[str, Any]]) -> None:
    groups: dict[tuple[int, int, str], list[dict[str, Any]]] = defaultdict(list)
    for document in documents:
        for row in document["results"]:
            groups[(row["batch"], row["concurrency"], row["transport"])].append(row)
    lines = [
        "ONNX Queue/pickle versus ZeroMQ/pickle",
        "=====================================",
        "",
        "One frontend / six workers / one ORT thread each / spinning disabled.",
        "Stock REST JSON, Pydantic, list tensors, pickle and round-robin selection.",
        "No adaptive batching, timing decorators, gzip or REST metrics middleware.",
        "ZeroMQ uses copy=True, one native I/O thread/context and unbounded HWM",
        "to match the stock unbounded queue policy. Control-plane queues remain stock.",
        "Serialization moves from Queue feeder/executor threads to event loops.",
        "This measures IPC architecture, NOT intrinsic pipe/socket bandwidth.",
        f"Completed validated blocks: {len(documents)}.",
        "Completed blocks passed numerical warm-ups, errors and transport checks.",
        "",
        "Rows/request Concurrency Transport Repeats Mean RPS SD RPS Latency ms "
        "Frontend cores Server loop p95/max ms",
    ]
    for (batch, concurrency, transport), rows in sorted(groups.items()):
        rates = [row["rps"] for row in rows]
        deviation = statistics.stdev(rates) if len(rows) > 1 else 0
        latency = statistics.mean(row["timings"]["client_ms"]["mean"] for row in rows)
        cores = statistics.mean(row["server_main_cpu_cores"] for row in rows)
        lag_p95 = statistics.mean(row["server_loop_lag_ms"]["p95"] for row in rows)
        lag_max = max(row["server_loop_lag_ms"]["max"] for row in rows)
        lines.append(
            f"{batch:12} {concurrency:11} {transport:9} {len(rows):7} "
            f"{statistics.mean(rates):8.2f} {deviation:6.2f} "
            f"{latency:10.2f} {cores:14.2f} {lag_p95:8.2f}/{lag_max:.2f}"
        )
    lines += ["", "Relative mean RPS (ZeroMQ / Queue - 1):"]
    for batch, concurrency in sorted({(key[0], key[1]) for key in groups}):
        queue = groups.get((batch, concurrency, "queue"))
        native = groups.get((batch, concurrency, "zmq"))
        if queue and native:
            ratio = statistics.mean(row["rps"] for row in native) / statistics.mean(
                row["rps"] for row in queue
            )
            lines.append(
                f"  batch={batch} concurrency={concurrency}: {100*(ratio-1):+.2f}%"
            )
    lines += [
        "",
        "Short localhost closed-loop windows, not production SLO/capacity claims.",
        "Server loop lag is a sampled 5ms heartbeat, not pure GIL waiting.",
        "Copy-free shared memory, raw-body worker parsing, multi-frontend routing,",
        "worker recovery and a production cancellation/lifecycle redesign "
        "are NOT tested.",
    ]
    (output / "SUMMARY.txt").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[2, 64])
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        parser.error("Use the study's MLServer Python-3.12 Poetry environment")
    if (
        args.seconds <= 0
        or args.repeats <= 0
        or min(args.batches + args.concurrencies) <= 0
    ):
        parser.error(
            "Duration, repeats, input batches and concurrency must be positive"
        )
    args.output = args.output.absolute()
    args.model = args.model.absolute()
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    source = args.output / "source"
    source.mkdir()
    for name in (
        "bench.py",
        "probe.py",
        "zmq_transport.py",
        "test_zmq_transport.py",
        "test_run_zmq_experiment.py",
        "run_zmq_experiment.py",
    ):
        shutil.copy2(BENCH.with_name(name), source / name)
    shutil.copytree(BENCH.parent / "zeromq-env", source / "zeromq-env")
    documents: list[dict[str, Any]] = []
    try:
        for trial in range(args.repeats):
            order = ("zmq", "queue") if trial % 2 else ("queue", "zmq")
            for transport in order:
                document = run_block(args, transport, len(documents))
                documents.append(document)
                (args.output / "results.json").write_text(
                    json.dumps(documents, indent=2)
                )
                write_summary(args.output, documents)
    finally:
        write_summary(args.output, documents)
    print(f"Finished. Read {args.output / 'SUMMARY.txt'}", flush=True)


if __name__ == "__main__":
    main()
