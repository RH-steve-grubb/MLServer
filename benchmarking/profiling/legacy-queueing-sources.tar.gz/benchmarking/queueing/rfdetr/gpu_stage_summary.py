"""Validate completed RF-DETR stage captures and select measured requests.

The raw files include readiness checks, pilot traffic, and warmup. Their whole
process summaries must not be presented as steady-state measurements. This
study runs on Linux, where monotonic_ns and perf_counter_ns share a clock.
"""

from collections import Counter
import json
from pathlib import Path
from typing import Any

from gpu_stages import summarize

_WORKER_COUNTS = {
    "worker.request.inclusive": 1,
    "onnx.prepare_inputs.inclusive": 1,
    "onnx.run.inclusive": 1,
    "onnx.outputs.inclusive": 1,
    "numpy.input": 1,
    "numpy.output_lists": 2,
}
_FRONTEND_COUNTS = {
    "dispatch.wait.inclusive": 1,
    "dataplane.infer.inclusive": 1,
}
_PROTOCOL_COUNTS = {
    "rest": {"rest.route.inclusive": 1, "rest.json.inclusive": 1, "rest.render": 1},
    "grpc": {
        "grpc.handler.inclusive": 1,
        "grpc.request_conversion": 1,
        "grpc.raw_unpack": 1,
        "grpc.response_conversion": 1,
        "grpc.raw_pack": 2,
    },
}


def _expected(result: dict, version: int) -> tuple[dict[str, int], dict[str, int]]:
    adapter = result.get("adapter", "stock")
    if adapter not in ("stock", "buffers", "worker-json", "compact"):
        raise RuntimeError(f"Unknown stage adapter: {adapter}")
    protocol = result["protocol"]
    if protocol not in _PROTOCOL_COUNTS:
        raise RuntimeError(f"Unknown stage protocol: {protocol}")
    frontend = {**_FRONTEND_COUNTS, **_PROTOCOL_COUNTS[protocol]}
    worker = dict(_WORKER_COUNTS)
    if version == 1:
        if adapter != "stock":
            raise RuntimeError("Optimized adapters require stage capture format 2")
        return frontend, worker
    if protocol == "rest":
        if adapter in ("worker-json", "compact"):
            frontend = {
                "rest.route.inclusive": 1,
                "rest.body.inclusive": 1,
                "dispatch.wait.inclusive": 1,
            }
            worker.update(
                {
                    "dataplane.infer.inclusive": 1,
                    "worker.json.decode.inclusive": 1,
                    "worker.json.encode.inclusive": 1,
                }
            )
        else:
            frontend["rest.body.inclusive"] = 2
    elif adapter in ("buffers", "compact"):
        del frontend["grpc.raw_unpack"]
    return frontend, worker


def _read(path: Path, pid: int) -> dict[str, Any]:
    capture = json.loads(path.read_text())
    records = capture["records"]
    if capture["format_version"] not in (1, 2) or capture["pid"] != pid:
        raise RuntimeError(f"Invalid stage capture identity: {path}")
    if capture["record_count"] != len(records) or capture["overflow_records"]:
        raise RuntimeError(f"Incomplete stage capture: {path}")
    for record in records:
        if record["pid"] != pid or not record["succeeded"]:
            raise RuntimeError(f"Failed or misattributed stage record: {path}")
        if not (
            0 < record["start_ns"] <= record["end_ns"]
            and record["wall_ns"] == record["end_ns"] - record["start_ns"]
        ):
            raise RuntimeError(f"Invalid stage timestamps: {path}")
    return capture


def _select(records: list[dict], window: tuple[int, int]) -> list[dict]:
    start, end = window
    selected = []
    for row in records:
        inside = start <= row["start_ns"] and row["end_ns"] <= end
        intersects = row["start_ns"] < end and row["end_ns"] > start
        if intersects and not inside:
            raise RuntimeError("Stage crosses measured request window")
        if inside:
            selected.append(row)
    return selected


def _counts(rows: list[dict], expected: dict[str, int], requests: int) -> None:
    actual = Counter(row["stage"] for row in rows)
    required = Counter({name: count * requests for name, count in expected.items()})
    if actual != required:
        raise RuntimeError(f"Measured stage count mismatch: {actual} != {required}")


def _unique(rows: list[dict], stage: str, key: str) -> dict[str, dict]:
    selected = [row for row in rows if row["stage"] == stage]
    indexed = {row[key]: row for row in selected}
    if None in indexed or "" in indexed or len(indexed) != len(selected):
        raise RuntimeError(f"Missing or duplicate {key}: {stage}")
    return indexed


def _correlate(
    front: list[dict],
    workers: list[dict],
    handler: str,
    expected: tuple[dict[str, int], dict[str, int]],
) -> int:
    handlers = _unique(front, handler, "trace_id")
    dispatches = _unique(front, "dispatch.wait.inclusive", "message_id")
    if {row["trace_id"] for row in dispatches.values()} != set(handlers):
        raise RuntimeError("Frontend trace IDs do not link handlers to dispatch")
    if any(row["trace_id"] not in handlers for row in front):
        raise RuntimeError("Frontend stage lost request context")
    by_trace: dict[str, list[dict]] = {}
    for row in front:
        by_trace.setdefault(row["trace_id"], []).append(row)
    for rows in by_trace.values():
        _counts(rows, expected[0], 1)
    requests = _unique(workers, "worker.request.inclusive", "message_id")
    if set(requests) != set(dispatches):
        raise RuntimeError("Dispatch and worker message IDs do not match")
    grouped: dict[tuple[str, str], list[dict]] = {}
    for row in workers:
        grouped.setdefault((row["stage"], row["message_id"]), []).append(row)
    for name, count in expected[1].items():
        for message, request in requests.items():
            related = grouped.get((name, message), [])
            if len(related) != count or any(
                row["pid"] != request["pid"]
                or row["start_ns"] < request["start_ns"]
                or row["end_ns"] > request["end_ns"]
                for row in related
            ):
                raise RuntimeError(f"Worker stage lost request context: {name}")
    for message, request in requests.items():
        dispatch = dispatches[message]
        if not (
            dispatch["start_ns"] <= request["start_ns"]
            and request["end_ns"] <= dispatch["end_ns"]
        ):
            raise RuntimeError("Worker span falls outside its dispatch wait")
    return len(requests)


def collect(case: Path, result: dict, server: dict) -> dict:
    """Validate after server teardown and publish measured-only stage metrics."""
    frontend = server["frontend"]["pid"]
    pids = {frontend, *(worker["pid"] for worker in server["workers"])}
    paths = {case / "stages" / f"stages-{pid}.json" for pid in pids}
    if set((case / "stages").glob("*")) != paths:
        raise RuntimeError("Stage capture files do not match frontend/worker PIDs")
    window = result["requested_start_ns"], result["drained_ns"]
    requests = result["total_drained"]
    if not (0 < window[0] < window[1] and requests > 0):
        raise RuntimeError("Invalid measured request window or count")
    captures = {pid: _read(case / "stages" / f"stages-{pid}.json", pid) for pid in pids}
    versions = {capture["format_version"] for capture in captures.values()}
    if len(versions) != 1:
        raise RuntimeError("Inconsistent stage capture format versions")
    version = versions.pop()
    expected = _expected(result, version)
    selected = {
        pid: _select(capture["records"], window) for pid, capture in captures.items()
    }
    front = selected[frontend]
    workers = [row for pid, rows in selected.items() if pid != frontend for row in rows]
    protocol = result["protocol"]
    _counts(front, expected[0], requests)
    _counts(workers, expected[1], requests)
    handler = "rest.route.inclusive" if protocol == "rest" else "grpc.handler.inclusive"
    matched = _correlate(front, workers, handler, expected)
    summary = {
        "valid": True,
        "capture_format_version": version,
        "adapter": result.get("adapter", "stock"),
        "protocol": protocol,
        "scope": "Measured requests only; nested inclusive stages must not be summed",
        "requested_start_ns": window[0],
        "drained_ns": window[1],
        "requests": requests,
        "matched_message_ids": matched,
        "nvtx_note": "Marker IDs require separate validation against Nsight events",
        "processes": {
            str(pid): {
                "role": "frontend" if pid == frontend else "worker",
                "record_count": capture["record_count"],
                "measured_record_count": len(selected[pid]),
                "excluded_record_count": capture["record_count"] - len(selected[pid]),
                "overflow_records": capture["overflow_records"],
                "collector_append_wall_ns": capture["collector_append_wall_ns"],
                "nvtx_records": sum("nvtx_range_id" in row for row in selected[pid]),
                "nvtx_zero_ids": sum(
                    row.get("nvtx_range_id") == 0 for row in selected[pid]
                ),
                "stages": summarize(selected[pid]),
            }
            for pid, capture in captures.items()
        },
    }
    destination = case / "stage-summary.json"
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(summary, indent=2) + "\n")
    temporary.replace(destination)
    return summary
