"""Root-run RF-DETR single-GPU serving baseline and profiling orchestrator.

Profiling and performance measurements are separate passes. Model servers and
load generators run as the normal user; root owns resource limits and perf.
No driver, governor, audit, clock, or kernel-policy settings are changed.
"""

import argparse
from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import pwd
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
from typing import Any, Iterator
import urllib.error
import urllib.request
import uuid

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import single_compare as previous  # noqa: E402
import gpu_tools  # noqa: E402
import validate as fixture  # noqa: E402

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]
DEFAULT_BUNDLE = Path("/home/codex/mlserver-durable-store/rfdetr-small-20261025")
DEFAULT_STORE = Path(
    "/home/codex/mlserver-durable-store/rfdetr-gpu-master-study-20261026"
)
# This host's compositor is reported as a compute client as well as a graphics
# client. Keep it in telemetry, but do not confuse it with another model job.
DISPLAY_PROCESS = "/usr/bin/kwin_wayland"


def publish(path: Path, value: Any) -> None:
    temporary = path.with_suffix(".partial")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def digest(path: Path) -> str:
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def owned_directory(path: Path, user: str) -> None:
    path.mkdir(parents=True, exist_ok=False)
    if os.geteuid() == 0:
        identity = pwd.getpwnam(user)
        os.chown(path, identity.pw_uid, identity.pw_gid)


def automatic_budget() -> previous.Budget:
    groups: dict[str, list[int]] = {}
    for cpu in sorted(os.sched_getaffinity(0)):
        siblings = Path(
            f"/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list"
        )
        groups.setdefault(siblings.read_text().strip(), []).append(cpu)
    if len(groups) < 4:
        raise RuntimeError("Need at least four physical cores for isolated clients")
    selected = list(groups.values())
    server = sorted(cpu for group in selected[:-2] for cpu in group)
    clients = sorted(cpu for group in selected[-2:] for cpu in group)
    return previous.Budget(
        server=",".join(map(str, server)),
        client=",".join(map(str, clients)),
        memory=16 * 1024**3,
    )


@dataclass(frozen=True)
class Variant:
    workers: int
    threads: int | None
    adapter: str = "stock"
    transport: str = "queue"
    engine: str = "run"
    metadata_only: bool = False
    buffer_inject: bool = False

    @property
    def name(self) -> str:
        threads = self.threads or "default"
        ipc = "-zmq" if self.transport == "zmq" else ""
        engine = f"-{self.engine}" if self.engine != "run" else ""
        metadata = "-metadata" if self.metadata_only else ""
        inject = "-inject" if self.buffer_inject else ""
        return (
            f"{self.adapter}{ipc}{engine}{metadata}{inject}-w{self.workers}-t{threads}"
        )


@dataclass
class Study:
    args: argparse.Namespace
    run: Path
    budget: previous.Budget
    gpu_uuid: str

    @property
    def harness(self) -> Path:
        return self.run / "source" / "benchmarking" / "queueing" / "rfdetr"

    def environment(self) -> dict[str, str]:
        environment = {
            key: value
            for key, value in os.environ.items()
            if not key.startswith(
                (
                    "MLSERVER_",
                    "PYTHON",
                    "OMP_",
                    "MKL_",
                    "OPENBLAS_",
                    "NUMEXPR_",
                    "BLIS_",
                    "VECLIB_",
                    "ORT_",
                    "CUDA_MPS_",
                )
            )
            and key not in ("CUDA_LAUNCH_BLOCKING", "NVIDIA_TF32_OVERRIDE")
        }
        source = self.run / "source"
        environment.update(
            {
                "PYTHONPATH": os.pathsep.join(
                    [str(source), str(source / "runtimes" / "onnx"), str(self.harness)]
                ),
                "PYTHONDONTWRITEBYTECODE": "1",
                "PYTHONUNBUFFERED": "1",
                "CUDA_VISIBLE_DEVICES": self.gpu_uuid,
                "MLSERVER_GPU_ADAPTER": getattr(self.args, "adapter", "stock"),
                "MLSERVER_GPU_TRANSPORT": getattr(self.args, "transport", "queue"),
                "MLSERVER_GPU_ENGINE": getattr(self.args, "engine", "run"),
                "MLSERVER_GPU_METADATA_ONLY": (
                    "1" if getattr(self.args, "metadata_only", False) else "0"
                ),
                "MLSERVER_GPU_BUFFER_INJECT": (
                    "1" if getattr(self.args, "buffer_inject", False) else "0"
                ),
            }
        )
        return environment


def configure(study: Study, case: Path, variant: Variant) -> tuple[int, int]:
    sockets = [socket.socket() for _ in range(2)]
    try:
        for connection in sockets:
            connection.bind(("127.0.0.1", 0))
        http_port, grpc_port = [connection.getsockname()[1] for connection in sockets]
    finally:
        for connection in sockets:
            connection.close()
    repository = case / "repository"
    model_dir = repository / "rfdetr-small"
    model_dir.mkdir(parents=True)
    extra: dict[str, Any] = {
        "providers": ["CUDAExecutionProvider", "CPUExecutionProvider"],
        "provider_options": [{"device_id": 0}, {}],
    }
    if variant.threads is not None:
        extra["session_options"] = {
            "intra_op_num_threads": variant.threads,
            "inter_op_num_threads": 1,
        }
        extra["session_config_entries"] = {
            "session.intra_op.allow_spinning": "0",
            "session.inter_op.allow_spinning": "0",
        }
    if variant.engine != "run":
        extra["provider_options"][0].update(
            use_tf32="1",
            enable_cuda_graph="1" if variant.engine.startswith("cuda-graph") else "0",
        )
    publish(
        model_dir / "model-settings.json",
        {
            "name": "rfdetr-small",
            "implementation": "mlserver_onnx.OnnxModel",
            "max_batch_size": 0,
            "max_batch_time": 0,
            "parameters": {
                "uri": str(study.args.bundle / "model" / "model.onnx"),
                "extra": extra,
            },
        },
    )
    publish(
        repository / "settings.json",
        {
            "host": "127.0.0.1",
            "http_port": http_port,
            "grpc_port": grpc_port,
            "parallel_workers": variant.workers,
            "metrics_endpoint": None,
            "access_log": False,
            "gzip_enabled": False,
            "grpc_max_message_length": 64 * 1024 * 1024,
        },
    )
    return http_port, grpc_port


def normal_user_command(study: Study, command: list[str]) -> list[str]:
    if os.geteuid() == 0:
        return ["runuser", "-u", study.args.user, "--", *command]
    return command


def validate_identity(study: Study, receipt: dict[str, Any]) -> None:
    adapter = getattr(study.args, "adapter", "stock")
    expected = {
        "uid": pwd.getpwnam(study.args.user).pw_uid,
        "affinity": sorted(previous.cpus(study.budget.server)),
        "source": str(study.run / "source" / "mlserver" / "__init__.py"),
        "onnx_source": str(
            study.run / "source" / "runtimes" / "onnx" / "mlserver_onnx" / "__init__.py"
        ),
        "executable": str(study.args.python),
        "gil_enabled": True,
        "cuda_visible_devices": study.gpu_uuid,
        "adapter": adapter,
        "transport": getattr(study.args, "transport", "queue"),
        "engine": getattr(study.args, "engine", "run"),
        "metadata_only": getattr(study.args, "metadata_only", False),
        "buffer_inject": getattr(study.args, "buffer_inject", False),
        "zmq_installed": getattr(study.args, "transport", "queue") == "zmq",
        "adapter_installed": {
            "buffers": adapter in ("buffers", "compact"),
            "worker_json": adapter in ("worker-json", "compact"),
        },
    }
    for key, value in expected.items():
        if receipt.get(key) != value:
            raise RuntimeError(f"Server identity mismatch: {key}")


def require_idle_gpu(study: Study) -> dict[str, Any]:
    snapshot = gpu_tools.gpu_snapshot()
    active = [
        row
        for row in snapshot["compute_processes"]
        if row["gpu_uuid"] == study.gpu_uuid and row["process_name"] != DISPLAY_PROCESS
    ]
    if active:
        raise RuntimeError(f"Unrelated compute processes are using the GPU: {active}")
    return snapshot


def validate_engine(worker: dict[str, Any], variant: Variant) -> None:
    proof = worker.get("engine_receipt", {})
    installed = variant.engine != "run"
    if (
        proof.get("variant") != variant.engine
        or proof.get("installed") is not installed
    ):
        raise RuntimeError("Actual worker engine installation does not match selection")
    if not installed:
        return
    bound = variant.engine in ("binding", "cuda-graph", "cuda-graph-blocking")
    if proof.get("bound_device_buffers") is not bound or proof.get("input_shape") != [
        1,
        3,
        512,
        512,
    ]:
        raise RuntimeError("Actual engine buffers do not match fixed RF-DETR")
    options = worker["provider_options"]["CUDAExecutionProvider"]
    graph = "1" if variant.engine.startswith("cuda-graph") else "0"
    if options.get("enable_cuda_graph") != graph or options.get("use_tf32") != "1":
        raise RuntimeError("Actual worker CUDA provider options differ from selection")
    if variant.engine.endswith("-blocking"):
        wait = proof.get("wait_policy", {})
        if (
            wait.get("requested_flags") != 4
            or wait.get("before_session_flags", 0) & 7 != 4
            or wait.get("after_session_flags", 0) & 7 != 4
        ):
            raise RuntimeError("Actual CUDA context did not retain blocking sync")


def validate_clients(study: Study, rows: list[dict[str, Any]], start_ns: int) -> None:
    groups = previous.client_sets(study.budget, study.args.clients)
    groups = groups[: min(study.args.concurrency, study.args.clients)]
    if len(rows) != len(groups):
        raise RuntimeError("Unexpected load client count")
    payload = "request.json" if study.args.protocol == "rest" else "request.grpc.pb"
    expected_hash = digest(study.args.bundle / "sample" / payload)
    for row, affinity in zip(rows, groups):
        expected = {
            "protocol": study.args.protocol,
            "requests": study.args.requests // len(groups),
            "total_drained": study.args.requests // len(groups),
            "concurrency": study.args.concurrency // len(groups),
            "requested_start_ns": start_ns,
            "cpu_affinity": sorted(affinity),
            "request_sha256": expected_hash,
        }
        for key, value in expected.items():
            if row.get(key) != value:
                raise RuntimeError(f"Load client control mismatch: {key}")
        if row.get("errors") or not 0 <= row["start_lateness_ns"] <= 50_000_000:
            raise RuntimeError("Client errors or excessive admission-start jitter")


def wait_server(process: subprocess.Popen, case: Path, port: int) -> dict[str, Any]:
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"Server exited; inspect {case / 'server.log'}")
        try:
            with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/v2/models/rfdetr-small/ready", timeout=2
            ) as response:
                if response.status == 200:
                    return json.loads((case / "receipts" / "frontend.json").read_text())
        except (urllib.error.URLError, TimeoutError, FileNotFoundError):
            time.sleep(0.1)
    raise TimeoutError(f"Server startup timed out; inspect {case / 'server.log'}")


@contextmanager
def ipc_directory(study: Study) -> Iterator[Path | None]:
    if getattr(study.args, "transport", "queue") == "queue":
        yield None
        return
    # Unix socket paths are short; durable capture directories exceed the
    # platform limit. Only these owned, disposable sockets live in /tmp.
    with tempfile.TemporaryDirectory(prefix="mlserver-gpu-zmq-", dir="/tmp") as folder:
        path = Path(folder)
        if os.geteuid() == 0:
            user = pwd.getpwnam(study.args.user)
            os.chown(path, user.pw_uid, user.pw_gid)
        yield path


@contextmanager
def serving(study: Study, case: Path, variant: Variant) -> Iterator[dict[str, Any]]:
    publish(case / "gpu-before-start.json", require_idle_gpu(study))
    ports = configure(study, case, variant)
    receipts = case / "receipts"
    owned_directory(receipts, study.args.user)
    environment = study.environment()
    environment["MLSERVER_GPU_RECEIPTS"] = str(receipts)
    if study.args.phase in ("stages", "cuda"):
        trace = case / "stages"
        owned_directory(trace, study.args.user)
        environment["MLSERVER_GPU_TRACE_DIR"] = str(trace)
    application = [
        str(study.args.python),
        str(study.harness / "gpu_server.py"),
        "start",
        str(case / "repository"),
    ]
    if study.args.phase == "cuda":
        nsys = gpu_tools.capabilities()["nsys"]
        if not nsys["available"]:
            raise RuntimeError(
                "Nsight Systems payload is missing; repair it before --phase cuda"
            )
        help_text = subprocess.check_output(
            [nsys["path"], "profile", "--help"], text=True
        )
        required = ("--trace", "--sample", "--cpuctxsw", "--wait", "--output")
        if any(flag not in help_text for flag in required):
            raise RuntimeError("Installed Nsight profile options need qualification")
        (case / "nsys-profile-help.txt").write_text(help_text)
        library = study.run / "gpu-nvtx.so"
        if not library.exists():
            subprocess.run(
                [
                    "cc",
                    "-O2",
                    "-fPIC",
                    "-shared",
                    "-I/usr/local/cuda-13.3/include",
                    str(study.harness / "gpu_nvtx.c"),
                    "-o",
                    str(library),
                    "-ldl",
                ],
                check=True,
            )
        environment["MLSERVER_GPU_NVTX_LIBRARY"] = str(library)
        application = [
            nsys["path"],
            "profile",
            "--trace=cuda,nvtx",
            "--sample=none",
            "--cpuctxsw=none",
            "--wait=all",
            "--output",
            str(case / "cuda-timeline"),
            *application,
        ]
        if variant.engine.startswith("cuda-graph"):
            application.insert(2, "--cuda-graph-trace=node")
    command = normal_user_command(
        study,
        application,
    )
    command = ["taskset", "-c", study.budget.server, *command]
    unit = f"mlserver-rfdetr-{uuid.uuid4().hex[:12]}-{case.name[-24:]}"
    if os.geteuid() == 0:
        command = [
            "systemd-run",
            "--scope",
            "--quiet",
            f"--unit={unit}",
            f"--property=AllowedCPUs={study.budget.server}",
            f"--property=MemoryMax={study.budget.memory}",
            "--property=MemorySwapMax=0",
            *command,
        ]
    publish(case / "server-command.json", command)
    with ipc_directory(study) as ipc, (case / "server.log").open("w") as log:
        if ipc is not None:
            environment["MLSERVER_QUEUE_ZMQ_DIR"] = str(ipc)
        process = subprocess.Popen(
            command,
            cwd=case,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        group = None
        try:
            frontend = wait_server(process, case, ports[0])
            validate_identity(study, frontend)
            workers = [
                json.loads(path.read_text()) for path in receipts.glob("worker-*.json")
            ]
            if len(workers) != variant.workers:
                raise RuntimeError(
                    f"Expected {variant.workers} workers, got {len(workers)}"
                )
            for worker in workers:
                validate_identity(study, worker)
                validate_engine(worker, variant)
                if (
                    variant.threads is not None
                    and worker["intra_op_threads"] != variant.threads
                ):
                    raise RuntimeError(
                        "Actual ORT thread count does not match the variant"
                    )
                if worker["cgroup"] != frontend["cgroup"]:
                    raise RuntimeError(
                        "Inference worker escaped the frontend's resource group"
                    )
            group = previous.cgroup_path(frontend["pid"])
            if os.geteuid() == 0:
                previous.cgroup_snapshot(group, study.budget)
            yield {
                "http_port": ports[0],
                "grpc_port": ports[1],
                "frontend": frontend,
                "workers": workers,
                "cgroup": group,
            }
        finally:
            receipt = receipts / "frontend.json"
            if receipt.exists():
                try:
                    os.kill(json.loads(receipt.read_text())["pid"], signal.SIGTERM)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                if os.geteuid() == 0:
                    subprocess.run(
                        [
                            "systemctl",
                            "kill",
                            "--kill-whom=all",
                            "--signal=KILL",
                            unit + ".scope",
                        ],
                        check=False,
                        timeout=10,
                    )
                else:
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=10)
            # The controller can exit before orphaned worker processes. Always
            # stop the uniquely owned scope/group, even after a successful wait.
            if os.geteuid() == 0:
                try:
                    subprocess.run(
                        ["systemctl", "stop", unit + ".scope"],
                        check=False,
                        capture_output=True,
                        timeout=15,
                    )
                except subprocess.TimeoutExpired:
                    subprocess.run(
                        [
                            "systemctl",
                            "kill",
                            "--kill-whom=all",
                            "--signal=KILL",
                            unit + ".scope",
                        ],
                        check=False,
                        timeout=10,
                    )
                    raise RuntimeError(f"Cleanup timed out for owned scope {unit}")
            else:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            if group is not None and group.exists() and os.geteuid() == 0:
                if (group / "cgroup.procs").read_text().strip():
                    raise RuntimeError(
                        f"Owned serving scope still contains tasks: {group}"
                    )


def load(study: Study, server: dict[str, Any], location: Path) -> dict[str, Any]:
    owned_directory(location, study.args.user)
    clients = []
    concurrency = study.args.concurrency
    groups = previous.client_sets(study.budget, study.args.clients)
    groups = groups[: min(concurrency, study.args.clients)]
    if concurrency < len(groups) or concurrency % len(groups):
        raise ValueError("Concurrency must divide evenly across active load clients")
    total = study.args.requests
    if total < concurrency or total % concurrency:
        raise ValueError("Request count must be >= concurrency and divisible by it")
    gate = location / "go.json"
    logs = []
    try:
        for index, affinity in enumerate(groups):
            directory = location / f"client-{index}"
            owned_directory(directory, study.args.user)
            spec = {
                "protocol": study.args.protocol,
                "host": "127.0.0.1",
                "http_port": server["http_port"],
                "grpc_port": server["grpc_port"],
                "bundle": str(study.args.bundle),
                "concurrency": concurrency // len(groups),
                "requests": total // len(groups),
                "warmup_requests": concurrency // len(groups),
                "start_file": str(gate),
                "timeout_seconds": 120,
            }
            publish(directory / "spec.json", spec)
            command = normal_user_command(
                study,
                [
                    str(study.args.python),
                    str(study.harness / "gpu_load.py"),
                    "--spec",
                    str(directory / "spec.json"),
                    "--output",
                    str(directory),
                ],
            )
            command = ["taskset", "-c", ",".join(map(str, affinity)), *command]
            log = (directory / "client.log").open("w")
            logs.append(log)
            clients.append(
                subprocess.Popen(
                    command,
                    cwd=study.run,
                    env=study.environment(),
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
            )
        deadline = time.monotonic() + 180
        while not all(
            (location / f"client-{i}" / "ready.json").exists()
            for i in range(len(groups))
        ):
            if any(process.poll() is not None for process in clients):
                raise RuntimeError(
                    f"Load client failed before readiness; inspect {location}"
                )
            if time.monotonic() > deadline:
                raise TimeoutError("Load clients failed to become ready")
            time.sleep(0.02)
        start_ns = time.monotonic_ns() + 250_000_000
        publish(gate, {"start_ns": start_ns})
        # Take the CPU counter before clients are admitted, not just after the
        # start gate. Preserve the counter timestamps so its small idle/drain
        # brackets are not mistaken for exact per-request CPU attribution.
        time.sleep(max(0, (start_ns - 20_000_000 - time.monotonic_ns()) / 1e9))
        before = (
            previous.cgroup_snapshot(server["cgroup"], study.budget)
            if os.geteuid() == 0
            else None
        )
        if before is not None and before["monotonic_ns"] >= start_ns:
            raise RuntimeError("CPU counter snapshot missed the admission boundary")
        for process in clients:
            if process.wait(timeout=600):
                raise RuntimeError(f"Load client failed; inspect {location}")
        rows = [
            json.loads((location / f"client-{i}" / "result.json").read_text())
            for i in range(len(groups))
        ]
        validate_clients(study, rows, start_ns)
        drained = max(row["drained_ns"] for row in rows)
        latencies = np.concatenate(
            [
                np.load(location / f"client-{i}" / "latencies.npy", allow_pickle=False)
                for i in range(len(groups))
            ]
        )
        if (
            len(latencies) != total
            or sum(row["total_drained"] for row in rows) != total
        ):
            raise RuntimeError("Missing or duplicate completed requests")
        elapsed = (drained - start_ns) / 1e9
        result = {
            "protocol": study.args.protocol,
            "concurrency": concurrency,
            "total_drained": total,
            "requested_start_ns": start_ns,
            "drained_ns": drained,
            "duration_seconds": elapsed,
            "rps": total / elapsed,
            "latency_ms": {
                f"p{p}": float(np.percentile(latencies, p)) for p in (50, 95, 99)
            },
            "client_cpu_seconds": sum(row["client_cpu_seconds"] for row in rows),
            "clients": rows,
        }
        if before is not None:
            after = previous.cgroup_snapshot(server["cgroup"], study.budget)
            cpu_us = after["cpu"]["usage_usec"] - before["cpu"]["usage_usec"]
            result["server_resources"] = {
                "before": before,
                "after": after,
                "cpu_ms_per_request": cpu_us / 1000 / total,
                "counter_window_includes_idle_and_drain_brackets": True,
            }
            events = dict(line.split() for line in after["memory_events"].splitlines())
            if any(int(events.get(key, "0")) for key in ("max", "oom", "oom_kill")):
                raise RuntimeError(
                    "Server reached a host-memory limit; reject this trial"
                )
        result["client_headroom_needs_confirmation"] = any(
            row["client_cpu_seconds"] / row["duration_seconds"] > 0.8 for row in rows
        )
        np.save(location / "latencies.npy", latencies)
        publish(location / "result.json", result)
        return result
    finally:
        for process in clients:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=10)
        for log in logs:
            log.close()


def validate_response(study: Study, server: dict[str, Any]) -> None:
    if study.args.protocol == "rest":
        request = urllib.request.Request(
            f"http://127.0.0.1:{server['http_port']}/v2/models/rfdetr-small/infer",
            data=(study.args.bundle / "sample" / "request.json").read_bytes(),
            headers={"Content-Type": "application/json", "Accept-Encoding": "identity"},
        )
        with urllib.request.urlopen(request, timeout=120) as response:
            value = json.load(response)
        outputs = {
            item["name"]: np.asarray(item["data"], dtype=np.float32).reshape(
                item["shape"]
            )
            for item in value["outputs"]
        }
    else:
        request = fixture.pb.ModelInferRequest.FromString(
            (study.args.bundle / "sample" / "request.grpc.pb").read_bytes()
        )
        with fixture.grpc.insecure_channel(
            f"127.0.0.1:{server['grpc_port']}"
        ) as channel:
            response = fixture.rpc.GRPCInferenceServiceStub(channel).ModelInfer(
                request, timeout=120
            )
        outputs = {
            item.name: np.frombuffer(data, dtype="<f4").reshape(item.shape)
            for item, data in zip(response.outputs, response.raw_output_contents)
        }
    if set(outputs) != {"dets", "labels"}:
        raise RuntimeError("Serving did not return both model outputs")
    expected = json.loads(
        (study.args.bundle / "reference" / "pytorch-detections.json").read_text()
    )
    manifest = json.loads((study.args.bundle / "manifest.json").read_text())
    fixture.compare_detections(
        expected, fixture.decoded(outputs, manifest["sample"]["image_size_wh"])
    )


def run_case(study: Study, variant: Variant, index: int) -> dict[str, Any]:
    case = study.run / f"case-{index:03}-{study.args.protocol}-{variant.name}"
    owned_directory(case, study.args.user)
    with serving(study, case, variant) as server:
        validate_response(study, server)
        pilot = load(study, server, case / "pilot")
        previous_requests = study.args.requests
        study.args.requests = max(
            study.args.concurrency,
            math.ceil(pilot["rps"] * study.args.seconds / study.args.concurrency)
            * study.args.concurrency,
        )
        try:
            with gpu_tools.sampling(case):
                if study.args.phase == "profile":
                    import gpu_perf

                    captured = gpu_perf.collect(
                        [
                            server["frontend"]["pid"],
                            *[row["pid"] for row in server["workers"]],
                        ],
                        case / study.args.capture,
                        study.args.capture,
                        lambda: load(study, server, case / "measured"),
                    )
                    result = dict(captured.pop("load"))
                    result["capture"] = captured
                else:
                    result = load(study, server, case / "measured")
            if os.geteuid() == 0:
                result["cgroup"] = previous.cgroup_snapshot(
                    server["cgroup"], study.budget
                )
            validate_response(study, server)
            expected_pids = {row["pid"] for row in server["workers"]}
            final_pids = {
                json.loads(path.read_text())["pid"]
                for path in (case / "receipts").glob("worker-*.json")
            }
            if final_pids != expected_pids or any(
                not Path(f"/proc/{pid}").exists() for pid in expected_pids
            ):
                raise RuntimeError("Inference workers restarted during the trial")
            result.update(
                variant=variant.name,
                workers=variant.workers,
                threads=variant.threads,
                adapter=variant.adapter,
                transport=variant.transport,
                engine=variant.engine,
                metadata_only=variant.metadata_only,
                buffer_inject=variant.buffer_inject,
                profiled=study.args.phase in ("profile", "stages", "cuda"),
            )
            publish(case / "result.json", result)
        finally:
            study.args.requests = previous_requests
    if variant.transport == "zmq":
        import gpu_transport

        result["transport_capture"] = gpu_transport.collect(case, server)
        publish(case / "result.json", result)
    if study.args.phase in ("stages", "cuda"):
        import gpu_stage_summary

        result["stage_capture"] = gpu_stage_summary.collect(case, result, server)
        publish(case / "result.json", result)
    if study.args.phase == "cuda":
        reports = list(case.glob("cuda-timeline*.nsys-rep"))
        if len(reports) != 1:
            raise RuntimeError(f"Nsight did not produce one capture; inspect {case}")
        nsys = gpu_tools.capabilities()["nsys"]["path"]
        subprocess.run(
            normal_user_command(
                study,
                [
                    nsys,
                    "export",
                    "--type=sqlite",
                    "--output",
                    str(case / "cuda-timeline.sqlite"),
                    str(reports[0]),
                ],
            ),
            check=True,
        )
        import gpu_cuda_summary

        result["cuda_timeline"] = {
            **gpu_cuda_summary.collect(case),
            "capture": str(reports[0]),
            "scope": (
                "Full server lifetime including startup/warmup. Use NVTX IDs "
                "and measured request window to select steady state."
            ),
            "measured_start_ns": result["requested_start_ns"],
            "measured_end_ns": result["drained_ns"],
        }
        publish(case / "result.json", result)
        import gpu_cuda_analyze

        # A successful export alone cannot establish complete measured work.
        # Fail the qualification before a long study if node/launch coverage,
        # clock alignment or measured request correlation is incomplete.
        analysis = gpu_cuda_analyze.analyze(case)
        path = case / "cuda-measured.json"
        publish(path, analysis)
        result["cuda_analysis"] = {
            "valid": analysis["valid"],
            "path": str(path),
            "request_count": analysis["request_count"],
            "coverage": analysis["coverage"],
            "clock_alignment": analysis["clock_alignment"],
            "active_fraction": analysis["device_activity"]["active_fraction"],
        }
        publish(case / "result.json", result)
    return result


def freeze(run: Path) -> None:
    source = run / "source"
    source.mkdir()
    # Reading source in an editor must not make an unchanged runtime appear
    # modified. Swap/backup files are not imported, and previously made the
    # production-source comparison reject otherwise identical snapshots.
    ignored = shutil.ignore_patterns(
        "__pycache__", "*.pyc", ".venv", ".*.swp", ".*.swo", ".*.swx", "*~"
    )
    for relative in (
        "mlserver",
        "runtimes/onnx/mlserver_onnx",
        "benchmarking/queueing",
    ):
        shutil.copytree(REPO / relative, source / relative, ignore=ignored)
    files = {
        str(path.relative_to(source)): digest(path)
        for path in source.rglob("*")
        if path.is_file()
    }
    publish(run / "source-hashes.json", files)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--phase",
        choices=("preflight", "smoke", "tune", "profile", "stages", "cuda"),
        default="preflight",
    )
    parser.add_argument("--bundle", type=Path, default=DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--user", default="codex")
    parser.add_argument("--protocol", choices=("rest", "grpc", "both"), default="both")
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument(
        "--adapter",
        choices=("stock", "buffers", "worker-json", "compact"),
        default="stock",
    )
    parser.add_argument("--transport", choices=("queue", "zmq"), default="queue")
    parser.add_argument(
        "--engine",
        choices=("run", "binding", "cuda-graph", "run-blocking", "cuda-graph-blocking"),
        default="run",
    )
    parser.add_argument("--metadata-only", action="store_true")
    parser.add_argument("--buffer-inject", action="store_true")
    parser.add_argument(
        "--allow-unprivileged-cuda",
        action="store_true",
        help="CUDA trace qualification only; no verified resource limits",
    )
    parser.add_argument("--concurrency", type=int, default=16)
    parser.add_argument("--clients", type=int, choices=(2, 4), default=2)
    parser.add_argument("--requests", type=int, default=32)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--capture", choices=("cpu", "gil"), default="cpu")
    args = parser.parse_args()
    if args.workers < 1 or args.threads < 0 or args.concurrency < 1:
        parser.error("Workers/concurrency must be positive; threads must be >= 0")
    if args.metadata_only and args.adapter not in ("buffers", "compact"):
        parser.error("Metadata-copy experiment requires numeric input buffers")
    if args.buffer_inject and args.adapter not in ("buffers", "compact"):
        parser.error("Direct injection requires numeric input buffers")
    if args.metadata_only and args.buffer_inject:
        parser.error("Metadata-only and direct injection are separate experiments")
    active_clients = min(args.clients, args.concurrency)
    if args.concurrency % active_clients:
        parser.error("Concurrency must divide evenly across active load clients")
    if args.requests < args.concurrency or args.requests % args.concurrency:
        parser.error("Pilot requests must be >= concurrency and divisible by it")
    if not math.isfinite(args.seconds) or args.seconds <= 0:
        parser.error("Measurement duration must be finite and positive")
    if args.allow_unprivileged_cuda and args.phase != "cuda":
        parser.error("Unprivileged CUDA qualification requires --phase cuda")
    qualification = args.phase == "cuda" and args.allow_unprivileged_cuda
    if (
        args.phase not in ("preflight", "smoke", "stages")
        and not qualification
        and os.geteuid() != 0
    ):
        parser.error(
            "Tuning/profiling require root for verified resource limits and perf"
        )
    if sys.version_info[:2] != (3, 12):
        parser.error(
            "Use the pinned serving environment's Python 3.12, not host Python"
        )
    args.bundle, args.store = args.bundle.resolve(), args.store.resolve()
    args.python = args.python.expanduser().absolute()
    # Child inference and client processes run as the normal user even when
    # the collector is root. A root shell's umask 077 must not hide snapshots,
    # client specs, or start gates from those processes.
    os.umask(0o022)
    manifest = json.loads((args.bundle / "manifest.json").read_text())
    if digest(args.bundle / "model" / "model.onnx") != manifest["onnx"]["sha256"]:
        raise RuntimeError("RF-DETR model hash mismatch")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    args.store.mkdir(parents=True, exist_ok=True)
    run = args.store / f"run-{stamp}-{os.getpid()}"
    run.mkdir(mode=0o755)
    budget = automatic_budget()
    previous.validate_budget(budget)
    inventory = {
        "tools": gpu_tools.capabilities(),
        "gpu": gpu_tools.gpu_snapshot(),
        "machine": previous.machine_state(),
        "budget": budget.__dict__,
        "root": os.geteuid() == 0,
        "phase": args.phase,
        "arguments": {key: str(value) for key, value in vars(args).items()},
    }
    publish(run / "PREFLIGHT.json", inventory)
    shutil.copy2(args.bundle / "manifest.json", run / "model-manifest.json")
    print(f"Output: {run}", flush=True)
    if args.phase == "preflight":
        print(json.dumps(inventory["tools"], indent=2), flush=True)
        return
    freeze(run)
    study = Study(args, run, budget, inventory["gpu"]["gpus"][0]["uuid"])
    if "4070" not in inventory["gpu"]["gpus"][0]["name"]:
        raise RuntimeError("This initial study is qualified for the local RTX 4070")
    protocols = ("rest", "grpc") if args.protocol == "both" else (args.protocol,)
    selected = Variant(
        workers=args.workers,
        threads=args.threads or None,
        adapter=args.adapter,
        transport=args.transport,
        engine=args.engine,
        metadata_only=args.metadata_only,
        buffer_inject=args.buffer_inject,
    )
    variants = [selected]
    if args.phase == "tune":
        variants = [
            replace(selected, workers=1, threads=None),
            *[
                replace(selected, workers=w, threads=t)
                for w in (1, 2, 4)
                for t in (1, 2, 4)
            ],
        ]
    try:
        if args.phase == "profile" and args.capture == "gil":
            import gpu_perf

            gpu_perf.self_test(args.python, run, study.environment())
        results: list[dict[str, Any]] = []
        requested_phase = args.phase
        for protocol in protocols:
            args.protocol = protocol
            for variant in variants:
                passes = [requested_phase]
                if requested_phase in ("profile", "stages", "cuda"):
                    passes = ["control-before", requested_phase, "control-after"]
                for role in passes:
                    args.phase = (
                        "smoke" if role.startswith("control-") else requested_phase
                    )
                    row = run_case(study, variant, len(results))
                    row["role"] = role
                    results.append(row)
                    print(
                        f"{protocol} {variant.name} {role}: {row['rps']:.2f} rps, "
                        f"p95 {row['latency_ms']['p95']:.2f} ms",
                        flush=True,
                    )
        args.phase = requested_phase
        publish(
            run / "SUMMARY.json",
            {
                "phase": args.phase,
                "results": results,
                "resource_limits_enforced": os.geteuid() == 0,
                "qualification_only": qualification and os.geteuid() != 0,
                "scope": "single RTX4070, fixed RF-DETR FP32/B1, no adaptive batching",
                "note": (
                    "Initial baseline/screening; repeated final before/after "
                    "study is a later phase"
                ),
            },
        )
        print(f"Complete: {run / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        publish(
            run / "FAILED.json", {"type": type(error).__name__, "message": str(error)}
        )
        raise


if __name__ == "__main__":
    main()
