"""Synthetic SQLite coverage tests; no Nsight process or CUDA work is performed."""

from contextlib import closing
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

import gpu_cuda_summary as summary


class SummaryTests(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.case = Path(directory.name)
        self.database = self.case / "cuda-timeline.sqlite"
        self.output = self.case / "cuda-summary.json"

    def create_database(self) -> None:
        with closing(sqlite3.connect(self.database)) as connection:
            connection.executescript(
                "CREATE TABLE CUPTI_ACTIVITY_KIND_KERNEL (start INTEGER, end INTEGER);"
                "INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL VALUES (1, 2);"
                "CREATE TABLE CUPTI_ACTIVITY_KIND_MEMCPY (start INTEGER, end INTEGER);"
                "INSERT INTO CUPTI_ACTIVITY_KIND_MEMCPY VALUES (3, 4);"
                "CREATE TABLE NVTX_EVENTS "
                "(start INTEGER, end INTEGER, text TEXT, textId INTEGER);"
                "INSERT INTO NVTX_EVENTS VALUES (10, 20, "
                "'onnx.run.inclusive|trace=sample|message=1', NULL);"
                "INSERT INTO NVTX_EVENTS VALUES (20, 30, 'other.stage', NULL);"
                "CREATE TABLE StringIds (id INTEGER PRIMARY KEY, value TEXT);"
                "INSERT INTO StringIds VALUES "
                "(7, 'onnx.run.inclusive|trace=sample|message=2');"
            )

    def execute(self, statement: str) -> None:
        with closing(sqlite3.connect(self.database)) as connection:
            connection.executescript(statement)

    def rejected(self, message: str) -> None:
        before = self.database.read_bytes()
        with self.assertRaisesRegex(RuntimeError, message):
            summary.collect(self.case)
        self.assertEqual(self.database.read_bytes(), before)
        self.assertFalse(self.output.exists())

    def test_direct_text_counts_full_capture_without_touching_database(self) -> None:
        self.create_database()
        before = self.database.read_bytes()
        result = summary.collect(self.case)
        self.assertEqual(self.database.read_bytes(), before)
        self.assertEqual(json.loads(self.output.read_text()), result)
        self.assertEqual(result["database"], str(self.database))
        self.assertEqual(result["kernel_row_count"], 1)
        self.assertEqual(result["kernel_rows"], {"CUPTI_ACTIVITY_KIND_KERNEL": 1})
        self.assertEqual(result["memcpy_rows"], {"CUPTI_ACTIVITY_KIND_MEMCPY": 1})
        self.assertEqual(result["nvtx_row_count"], 2)
        self.assertEqual(result["onnx_nvtx_matching_count"], 1)
        self.assertEqual(result["onnx_nvtx_completed_count"], 1)
        self.assertEqual(result["tables"]["StringIds"], ["id", "value"])
        self.assertIn("startup", result["capture_scope"])
        self.assertIn("no steady-state GPU durations", result["timing_scope"])
        self.assertFalse((self.case / "cuda-summary.partial").exists())

    def test_text_id_resolves_when_direct_text_is_null_or_empty(self) -> None:
        self.create_database()
        self.execute(
            "UPDATE NVTX_EVENTS SET text=NULL, textId=7 WHERE start=10;"
            "INSERT INTO NVTX_EVENTS VALUES (30, 40, '', 7);"
        )
        result = summary.collect(self.case)
        self.assertEqual(result["onnx_nvtx_matching_count"], 2)
        self.assertEqual(result["onnx_nvtx_completed_count"], 2)

    def test_text_id_only_schema_and_concurrent_kernel_variant(self) -> None:
        self.create_database()
        self.execute(
            "ALTER TABLE CUPTI_ACTIVITY_KIND_KERNEL "
            "RENAME TO CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL;"
            "ALTER TABLE NVTX_EVENTS DROP COLUMN text;"
            "UPDATE NVTX_EVENTS SET textId=7 WHERE start=10;"
            "DROP TABLE CUPTI_ACTIVITY_KIND_MEMCPY;"
        )
        result = summary.collect(self.case)
        self.assertEqual(
            result["kernel_rows"], {"CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL": 1}
        )
        self.assertEqual(result["memcpy_rows"], {})
        self.assertEqual(result["onnx_nvtx_completed_count"], 1)

    def test_direct_text_without_string_table_is_supported(self) -> None:
        self.create_database()
        self.execute("DROP TABLE StringIds;")
        self.assertEqual(summary.collect(self.case)["onnx_nvtx_completed_count"], 1)

    def test_missing_or_empty_kernel_activity_is_rejected(self) -> None:
        for statement in (
            "DELETE FROM CUPTI_ACTIVITY_KIND_KERNEL;",
            "DROP TABLE CUPTI_ACTIVITY_KIND_KERNEL;",
        ):
            with self.subTest(statement=statement):
                self.create_database()
                self.execute(statement)
                self.rejected("Missing/empty CUDA kernel")
                self.database.unlink()

    def test_missing_or_unsupported_nvtx_schema_is_rejected(self) -> None:
        for statement in (
            "DROP TABLE NVTX_EVENTS;",
            "ALTER TABLE NVTX_EVENTS RENAME COLUMN end TO unsupported_end;",
            "ALTER TABLE NVTX_EVENTS DROP COLUMN text;"
            "ALTER TABLE NVTX_EVENTS DROP COLUMN textId;",
            "ALTER TABLE StringIds RENAME COLUMN value TO unsupported_value;",
        ):
            with self.subTest(statement=statement):
                self.create_database()
                self.execute(statement)
                self.rejected("NVTX_EVENTS|NVTX labels|StringIds schema")
                self.database.unlink()

    def test_empty_missing_or_incomplete_onnx_markers_are_rejected(self) -> None:
        for statement in (
            "DELETE FROM NVTX_EVENTS;",
            "UPDATE NVTX_EVENTS SET text='other.stage';",
            "UPDATE NVTX_EVENTS SET text='not.onnx.run.inclusive';",
            "UPDATE NVTX_EVENTS SET start=NULL WHERE start=10;",
            "UPDATE NVTX_EVENTS SET end=NULL WHERE start=10;",
            "UPDATE NVTX_EVENTS SET end=9 WHERE start=10;",
            "INSERT INTO NVTX_EVENTS VALUES (30, NULL, 'onnx.run.inclusive', NULL);",
        ):
            with self.subTest(statement=statement):
                self.create_database()
                self.execute(statement)
                self.rejected("Missing/incomplete onnx.run.inclusive")
                self.database.unlink()

    def test_missing_or_invalid_database_has_actionable_error(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "verify nsys export succeeded"):
            summary.collect(self.case)
        self.assertFalse(self.database.exists())
        self.database.write_bytes(b"not a SQLite export")
        self.rejected("verify nsys export succeeded")


if __name__ == "__main__":
    unittest.main()
