"""Session integration tests use fake sessions; no CUDA or model is initialized."""

import functools
import gc
import os
from types import SimpleNamespace
import sys
from typing import Any
import unittest
from unittest.mock import Mock, patch
import weakref

import numpy as np

import gpu_engine as engine


def session(graph: bool = True) -> Mock:
    result = Mock()
    result.get_inputs.return_value = [SimpleNamespace(shape=[1, 3, 2, 2])]
    result.get_provider_options.return_value = {
        "CUDAExecutionProvider": {
            "enable_cuda_graph": "1" if graph else "0",
            "use_tf32": "1",
        }
    }
    return result


class ProxyTests(unittest.TestCase):
    def proxy(self, selected: str = "cuda-graph") -> tuple:
        loaded = session(selected.startswith("cuda-graph"))
        runner = Mock(input_name="input", names=["dets", "labels"], binding=object())
        with patch.object(engine, "Runner", return_value=runner):
            proxy = engine.SessionProxy(loaded, selected, {})
        return loaded, runner, proxy

    def test_output_selection_order_and_session_metadata_are_preserved(self) -> None:
        loaded, runner, proxy = self.proxy()
        values = {"dets": np.zeros((1, 4)), "labels": np.ones((1, 91))}
        runner.return_value = values
        tensor = np.zeros((1, 3, 2, 2), np.float32)
        outputs = proxy.run(["labels", "dets"], {"input": tensor})
        self.assertIs(outputs[0], values["labels"])
        self.assertIs(outputs[1], values["dets"])
        runner.assert_called_once_with(tensor)
        self.assertIs(proxy.get_inputs, loaded.get_inputs)
        self.assertEqual(engine.receipt(proxy)["variant"], "cuda-graph")
        loaded.disable_fallback.assert_called_once_with()

    def test_invalid_feeds_options_and_outputs_cannot_reuse_a_stale_input(self) -> None:
        _, runner, proxy = self.proxy()
        valid = np.zeros((1, 3, 2, 2), np.float32)
        for feed in (
            {},
            {"other": valid},
            {"input": valid.astype(np.float64)},
            {"input": valid.reshape(3, 2, 2)},
            {"input": valid[..., ::-1]},
        ):
            with self.subTest(feed=tuple(feed)):
                with self.assertRaises(ValueError):
                    proxy.run(None, feed)
        with self.assertRaisesRegex(ValueError, "RunOptions"):
            proxy.run(None, {"input": valid}, run_options=object())
        with self.assertRaisesRegex(ValueError, "Unknown"):
            proxy.run(["unknown"], {"input": valid})
        runner.assert_not_called()

    def test_blocking_ordinary_run_keeps_existing_run_options(self) -> None:
        loaded, runner, proxy = self.proxy("run-blocking")
        names, feed, options = ["dets"], {"input": np.zeros(1)}, object()
        self.assertIs(proxy.run(names, feed, options), loaded.run.return_value)
        loaded.run.assert_called_once_with(names, feed, run_options=options)
        runner.assert_not_called()

    def test_mismatched_provider_settings_are_rejected_before_binding(self) -> None:
        with patch.object(engine, "Runner") as runner:
            with self.assertRaisesRegex(RuntimeError, "CUDA options"):
                engine.SessionProxy(session(False), "cuda-graph", {})
            runner.assert_not_called()


class InstallationTests(unittest.IsolatedAsyncioTestCase):
    async def test_wait_policy_precedes_session_creation_and_install_is_idempotent(
        self,
    ) -> None:
        events = []
        loaded_session = session()

        class Model:
            name = "rfdetr-small"
            _model: Any = None

            async def load(self) -> bool:
                events.append("load-session")
                self._model = loaded_session
                return True

        def configure() -> dict:
            events.append("set-flags")
            return {"library": "/fixed/libcudart.so.12", "before_session_flags": 4}

        selected = {"MLSERVER_GPU_ENGINE": "cuda-graph-blocking"}
        with (
            patch.dict(os.environ, selected),
            patch.dict(
                sys.modules, {"mlserver_onnx": SimpleNamespace(OnnxModel=Model)}
            ),
            patch.object(engine, "configure_blocking_sync", side_effect=configure),
            patch.object(engine, "cuda_flags", return_value=4) as read,
            patch.object(engine, "Runner", return_value=Mock(binding=object())),
        ):
            engine.install()
            original = Model.load

            @functools.wraps(original)
            async def traced(model):
                return await original(model)

            setattr(Model, "load", traced)
            engine.install()
            self.assertIs(Model.load, traced)
            model = Model()
            self.assertTrue(await model.load())
            self.assertEqual(events, ["set-flags", "load-session"])
            read.assert_called_once_with("/fixed/libcudart.so.12")
            self.assertEqual(
                engine.receipt(model._model)["wait_policy"]["after_session_flags"], 4
            )
            # Unloading drops the sole owner of the session proxy and buffers;
            # the installation wrapper must not retain previously loaded models.
            reference = weakref.ref(model._model)
            model._model = None
            gc.collect()
            self.assertIsNone(reference())
            os.environ["MLSERVER_GPU_ENGINE"] = "run"
            with self.assertRaisesRegex(RuntimeError, "cannot change"):
                engine.install()


if __name__ == "__main__":
    unittest.main()
