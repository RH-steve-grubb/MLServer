"""Fixed-count REST/raw-gRPC load client for the RF-DETR GPU study.

Payload preparation, warm-up, and response correctness checks are outside the
measured loop. The loop reads complete response bodies, but never decodes JSON
or protobuf. Successful results require every admitted request to drain.
"""

import argparse
import asyncio
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
from typing import Any

import aiohttp
import grpc
import numpy as np

RPC_METHOD = "/inference.GRPCInferenceService/ModelInfer"
MAX_MESSAGE_BYTES = 32 * 1024 * 1024


@dataclass(frozen=True)
class Response:
    status: str
    body_bytes: int
    successful: bool = True


@dataclass
class Measurements:
    requested_start_ns: int
    actual_start_ns: int
    drained_ns: int = 0
    client_cpu_seconds: float = 0.0
    requests_attempted: int = 0
    total_drained: int = 0
    response_bytes_received: int = 0
    status_counts: dict[str, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)


Sender = Callable[[], Awaitable[Response]]


def positive_integer(value: Any, name: str, minimum: int = 1) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def request_distribution(requests: int, concurrency: int) -> list[int]:
    positive_integer(concurrency, "concurrency")
    positive_integer(requests, "requests", concurrency)
    quotient, remainder = divmod(requests, concurrency)
    return [quotient + int(index < remainder) for index in range(concurrency)]


def validate_spec(spec: dict[str, Any]) -> dict[str, Any]:
    result = dict(spec)
    if result.get("protocol") not in ("rest", "grpc"):
        raise ValueError("protocol must be 'rest' or 'grpc'")
    result["concurrency"] = positive_integer(result.get("concurrency"), "concurrency")
    result["requests"] = positive_integer(
        result.get("requests"), "requests", result["concurrency"]
    )
    result["warmup_requests"] = positive_integer(
        result.get("warmup_requests", 0), "warmup_requests", 0
    )
    timeout = result.get("timeout_seconds", 120)
    if (
        isinstance(timeout, bool)
        or not isinstance(timeout, (int, float))
        or not math.isfinite(timeout)
        or timeout <= 0
    ):
        raise ValueError("timeout_seconds must be finite and positive")
    result["timeout_seconds"] = float(timeout)
    result["start_ns"] = positive_integer(result.get("start_ns", 0), "start_ns", 0)
    if not isinstance(result.get("bundle"), (str, Path)):
        raise ValueError("bundle must be an existing absolute directory")
    bundle = Path(result["bundle"])
    if not bundle.is_absolute() or not bundle.is_dir():
        raise ValueError("bundle must be an existing absolute directory")
    result["bundle"] = str(bundle)
    result["host"] = result.get("host", "127.0.0.1")
    if not isinstance(result["host"], str) or not result["host"]:
        raise ValueError("host must be a nonempty string")
    port_name = "http_port" if result["protocol"] == "rest" else "grpc_port"
    port = positive_integer(result.get(port_name), port_name)
    if port > 65535:
        raise ValueError(f"{port_name} must be <= 65535")
    return result


def payload_for(spec: dict[str, Any]) -> bytes:
    name = "request.json" if spec["protocol"] == "rest" else "request.grpc.pb"
    payload = (Path(spec["bundle"]) / "sample" / name).read_bytes()
    if not payload:
        raise ValueError(f"Empty prepared payload: {name}")
    return payload


def publish(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


async def wait_for_start(spec: dict[str, Any]) -> int:
    start = spec["start_ns"]
    if spec.get("start_file"):
        path = Path(spec["start_file"])
        deadline = time.monotonic() + spec["timeout_seconds"]
        while not path.exists():
            if time.monotonic() >= deadline:
                raise TimeoutError(f"Start gate did not appear: {path}")
            await asyncio.sleep(0.01)
        start = positive_integer(json.loads(path.read_text())["start_ns"], "start_ns")
    if not start:
        start = time.monotonic_ns()
    while time.monotonic_ns() < start:
        await asyncio.sleep((start - time.monotonic_ns()) / 1e9)
    return start


@asynccontextmanager
async def transport(spec: dict[str, Any], payload: bytes) -> AsyncIterator[Sender]:
    host = spec["host"]
    timeout = spec["timeout_seconds"]
    if spec["protocol"] == "rest":
        connector = aiohttp.TCPConnector(
            limit=spec["concurrency"], limit_per_host=spec["concurrency"]
        )
        async with aiohttp.ClientSession(
            connector=connector,
            timeout=aiohttp.ClientTimeout(total=timeout),
            auto_decompress=False,
        ) as session:
            url = f"http://{host}:{spec['http_port']}/v2/models/rfdetr-small/infer"

            async def send_rest() -> Response:
                async with session.post(
                    url,
                    data=payload,
                    headers={
                        "Content-Type": "application/json",
                        "Accept-Encoding": "identity",
                    },
                    allow_redirects=False,
                ) as response:
                    body = await response.read()
                    return Response(
                        str(response.status), len(body), response.status == 200
                    )

            yield send_rest
        return
    options = [
        ("grpc.max_send_message_length", max(MAX_MESSAGE_BYTES, len(payload) + 1024)),
        ("grpc.max_receive_message_length", MAX_MESSAGE_BYTES),
    ]
    async with grpc.aio.insecure_channel(
        f"{host}:{spec['grpc_port']}", options=options
    ) as channel:
        # Pass serialized protobuf bytes unchanged; grpc.aio handles framing.
        # Its default None serializers/deserializers preserve byte buffers.
        # As with HTTP, first connection setup belongs to warm-up when requested
        # and otherwise to the first measured request, not a gRPC-only preflight.
        method = channel.unary_unary(
            RPC_METHOD, request_serializer=None, response_deserializer=None
        )

        async def send_grpc() -> Response:
            body = await method(payload, timeout=timeout)
            return Response("OK", len(body))

        yield send_grpc


async def run_batch(
    send: Sender, requests: int, concurrency: int, start_ns: int
) -> tuple[Measurements, np.ndarray]:
    counts = request_distribution(requests, concurrency)
    measured = Measurements(start_ns, time.monotonic_ns())
    cpu_before = time.process_time_ns()
    samples: list[float] = []

    async def worker(count: int) -> None:
        for _ in range(count):
            if measured.errors:
                return
            measured.requests_attempted += 1
            began = time.monotonic_ns()
            try:
                response = await send()
            except Exception as error:
                measured.errors.append(f"{type(error).__name__}: {str(error)[:1000]}")
                return
            elapsed = time.monotonic_ns() - began
            samples.append(elapsed / 1e6)
            measured.total_drained += 1
            measured.response_bytes_received += response.body_bytes
            measured.status_counts[response.status] = (
                measured.status_counts.get(response.status, 0) + 1
            )
            if not response.successful or response.body_bytes <= 0:
                measured.errors.append(
                    f"Invalid response status/body: {response.status}"
                )
                return

    # Request errors stop new admissions, but other already-in-flight requests
    # finish normally. A fixed-duration cutoff must not cancel outstanding work.
    await asyncio.gather(*(worker(count) for count in counts))
    measured.drained_ns = time.monotonic_ns()
    measured.client_cpu_seconds = (time.process_time_ns() - cpu_before) / 1e9
    return measured, np.asarray(samples, dtype=np.float64)


def result_for(
    spec: dict[str, Any], measured: Measurements, latencies: np.ndarray
) -> dict[str, Any]:
    if measured.errors:
        raise RuntimeError("Request errors: " + "; ".join(measured.errors))
    expected = spec["requests"]
    if (
        measured.requests_attempted != expected
        or measured.total_drained != expected
        or len(latencies) != expected
        or sum(measured.status_counts.values()) != expected
        or set(measured.status_counts)
        != ({"200"} if spec["protocol"] == "rest" else {"OK"})
    ):
        raise ValueError("Fixed-count requests did not all drain")
    if not (
        0
        < measured.requested_start_ns
        <= measured.actual_start_ns
        < measured.drained_ns
    ):
        raise ValueError("Invalid monotonic measurement window")
    duration = (measured.drained_ns - measured.actual_start_ns) / 1e9
    if (
        not np.isfinite(latencies).all()
        or np.any(latencies < 0)
        or float(latencies.max()) > duration * 1000 + 1e-6
        or not math.isfinite(measured.client_cpu_seconds)
        or measured.client_cpu_seconds < 0
    ):
        raise ValueError("Invalid latency/CPU accounting")
    return {
        "pid": os.getpid(),
        "protocol": spec["protocol"],
        "concurrency": spec["concurrency"],
        "requests": expected,
        "requests_attempted": measured.requests_attempted,
        "total_drained": measured.total_drained,
        "errors": [],
        "status_counts": measured.status_counts,
        "requested_start_ns": measured.requested_start_ns,
        "actual_start_ns": measured.actual_start_ns,
        "drained_ns": measured.drained_ns,
        "start_lateness_ns": measured.actual_start_ns - measured.requested_start_ns,
        "duration_seconds": duration,
        "client_cpu_seconds": measured.client_cpu_seconds,
        "response_bytes_received": measured.response_bytes_received,
        "rps": expected / duration,
        "latency_ms": {
            "mean": float(latencies.mean()),
            "p50": float(np.percentile(latencies, 50)),
            "p95": float(np.percentile(latencies, 95)),
            "p99": float(np.percentile(latencies, 99)),
            "max": float(latencies.max()),
        },
        "latency_file": "latencies.npy",
        "measurement": "fixed-count-complete-drain",
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
    }


async def measure(spec: dict[str, Any], output: Path) -> dict[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    if any(
        (output / name).exists()
        for name in ("ready.json", "result.json", "FAILED.json")
    ):
        raise FileExistsError(f"Refusing stale client output directory: {output}")
    phase = "preparation"
    try:
        checked = validate_spec(spec)
        payload = payload_for(checked)
        digest = hashlib.sha256(payload).hexdigest()
        async with transport(checked, payload) as send:
            warmup = checked["warmup_requests"]
            if warmup:
                phase = "warmup"
                warmed, _ = await run_batch(
                    send,
                    warmup,
                    min(warmup, checked["concurrency"]),
                    time.monotonic_ns(),
                )
                if warmed.errors or warmed.total_drained != warmup:
                    raise RuntimeError(
                        "Warm-up requests failed: " + "; ".join(warmed.errors)
                    )
            publish(
                output / "ready.json",
                {
                    "pid": os.getpid(),
                    "protocol": checked["protocol"],
                    "concurrency": checked["concurrency"],
                    "requests": checked["requests"],
                    "warmup_requests": warmup,
                    "request_body_bytes": len(payload),
                    "request_sha256": digest,
                    "ready_ns": time.monotonic_ns(),
                },
            )
            phase = "start gate"
            start = await wait_for_start(checked)
            phase = "measurement"
            measured, latencies = await run_batch(
                send, checked["requests"], checked["concurrency"], start
            )
        np.save(output / "latencies.npy", latencies, allow_pickle=False)
        result = result_for(checked, measured, latencies)
        result.update(
            request_body_bytes=len(payload),
            request_sha256=digest,
            request_bytes_sent=len(payload) * measured.requests_attempted,
            warmup_requests=warmup,
            byte_accounting="application payloads only; excludes transport framing",
            event_loop=type(asyncio.get_running_loop()).__module__
            + "."
            + type(asyncio.get_running_loop()).__name__,
        )
        publish(output / "result.json", result)
        return result
    except Exception as error:
        publish(
            output / "FAILED.json",
            {
                "status": "failed",
                "phase": phase,
                "pid": os.getpid(),
                "error": f"{type(error).__name__}: {error}",
            },
        )
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text())
    result = asyncio.run(measure(spec, args.output))
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
