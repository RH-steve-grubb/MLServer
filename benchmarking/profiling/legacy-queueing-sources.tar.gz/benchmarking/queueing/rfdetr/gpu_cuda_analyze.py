"""Read-only, measured-request CUDA accounting for the fixed RF-DETR study.

Python and Nsight clock origins are aligned by matching recorded NVTX range
IDs/labels to their Python brackets. Runtime correlation IDs are scoped by
process before linking device work; full-capture startup totals are excluded.
"""

import argparse
from bisect import bisect_right
from collections import Counter, defaultdict
from contextlib import closing
import json
from pathlib import Path
import sqlite3
from typing import Any

_TID_MASK = (1 << 24) - 1
_GRAPH_LAUNCHES = {"cudaGraphLaunch", "cuGraphLaunch"}


def _launch_kind(operation: str) -> str | None:
    if operation in {"cudaLaunchKernel", "cudaLaunchKernelExC", "cuLaunchKernel"}:
        return "kernel"
    if operation in {"cudaMemcpy", "cudaMemcpyAsync"}:
        return "memcpy"
    if operation in {"cudaMemset", "cudaMemsetAsync"}:
        return "memset"
    return None


def _distribution(values: list[int]) -> dict[str, Any]:
    ordered = sorted(values)
    if not ordered:
        return {"count": 0, "total_ns": 0}
    return {
        "count": len(ordered),
        "total_ns": sum(ordered),
        "min_ns": ordered[0],
        "max_ns": ordered[-1],
        "mean_ns": sum(ordered) / len(ordered),
        **{
            f"p{percent}_ns": ordered[int((len(ordered) - 1) * percent / 100)]
            for percent in (50, 95, 99)
        },
    }


def _union(intervals: list[tuple[int, int]]) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    for start, end in sorted(intervals):
        if end < start:
            raise RuntimeError("Reversed CUDA/NVTX interval")
        if end == start:
            continue
        if result and start <= result[-1][1]:
            result[-1] = result[-1][0], max(end, result[-1][1])
        else:
            result.append((start, end))
    return result


def _duration(intervals: list[tuple[int, int]]) -> int:
    return sum(end - start for start, end in intervals)


def _overlap(intervals: list[tuple[int, int]]) -> int:
    edges: Counter[int] = Counter()
    for start, end in intervals:
        edges[start] += 1
        edges[end] -= 1
    previous, active, duration = 0, 0, 0
    for stamp, change in sorted(edges.items()):
        if active >= 2:
            duration += stamp - previous
        active += change
        previous = stamp
    return duration


def _markers(
    connection: sqlite3.Connection, case: Path, result: dict[str, Any]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    processes = dict(connection.execute("SELECT globalPid, pid FROM PROCESSES"))
    indexed = {}
    for start, end, tid, range_id, label in connection.execute(
        "SELECT n.start, n.end, n.globalTid, n.rangeId, "
        "COALESCE(NULLIF(n.text, ''), s.value) FROM NVTX_EVENTS n "
        "LEFT JOIN StringIds s ON n.textId = s.id"
    ):
        # This is the same global ID layout used by NVIDIA's installed
        # nvtx_kern_sum.py report. Cross-check its process against PROCESSES.
        global_pid = tid & ~_TID_MASK
        pid = (tid >> 24) & _TID_MASK
        if processes.get(global_pid) != pid:
            raise RuntimeError("NVTX global thread/process ID is not in PROCESSES")
        key = pid, range_id, label
        if key in indexed:
            raise RuntimeError("Duplicate NVTX range identity")
        indexed[key] = start, end, tid, global_pid
    markers = []
    lower, upper = [], []
    expected_pids = {int(pid) for pid in result["stage_capture"]["processes"]}
    paths = list((case / "stages").glob("stages-*.json"))
    if {int(path.stem.split("-")[-1]) for path in paths} != expected_pids:
        raise RuntimeError("Missing or unexpected stage capture process")
    for path in paths:
        capture = json.loads(path.read_text())
        if capture["format_version"] not in (1, 2):
            raise RuntimeError("Unsupported stage capture version")
        if capture["overflow_records"] or capture["record_count"] != len(
            capture["records"]
        ):
            raise RuntimeError("Incomplete stage capture")
        for row in capture["records"]:
            inside = (
                result["requested_start_ns"]
                <= row["start_ns"]
                <= row["end_ns"]
                <= result["drained_ns"]
            )
            if not inside:
                if (
                    row["start_ns"] < result["drained_ns"]
                    and row["end_ns"] > result["requested_start_ns"]
                ):
                    raise RuntimeError("Stage crosses measured request window")
                continue
            if row["pid"] != capture["pid"] or not row["succeeded"]:
                raise RuntimeError("Failed or misattributed Python stage")
            key = row["pid"], row["nvtx_range_id"], row["nvtx_label"]
            if not row["nvtx_range_id"] or key not in indexed:
                raise RuntimeError(
                    f"Measured Python stage has no matching NVTX range: {key}"
                )
            start, end, tid, global_pid = indexed[key]
            if end is None or start > end or (tid & _TID_MASK) != row["tid"]:
                raise RuntimeError("Incomplete NVTX range or thread mismatch")
            # Python samples start after nvtxRangeStart returns and end before
            # nvtxRangeEnd is called. Their difference brackets the clock offset.
            lower.append(row["end_ns"] - end)
            upper.append(row["start_ns"] - start)
            markers.append(
                dict(
                    row,
                    nsys_start=start,
                    nsys_end=end,
                    global_tid=tid,
                    global_pid=global_pid,
                )
            )
    if not markers or max(lower) > min(upper):
        raise RuntimeError(
            "Python/Nsight marker brackets have no consistent clock offset"
        )
    low, high = max(lower), min(upper)
    return markers, {
        "method": "Intersection of matched NVTX/Python start/end brackets",
        "matched_stage_ranges": len(markers),
        "python_minus_nsight_offset_low_ns": low,
        "python_minus_nsight_offset_high_ns": high,
        "offset_interval_width_ns": high - low,
        "selected_offset_ns": (low + high) // 2,
        "boundary_max_error_ns": (high - low + 1) // 2,
    }


def _runtime(
    connection: sqlite3.Connection, markers: list[dict[str, Any]]
) -> tuple[
    dict[tuple[int, int], tuple[dict[str, Any], str]], dict[str, dict[str, int]]
]:
    ranges: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in markers:
        if row["stage"] == "onnx.run.inclusive":
            ranges[row["global_tid"]].append(row)
    starts = {}
    for tid, rows in ranges.items():
        rows.sort(key=lambda row: row["nsys_start"])
        if any(a["nsys_end"] > b["nsys_start"] for a, b in zip(rows, rows[1:])):
            raise RuntimeError("Overlapping ONNX runs on one native thread")
        starts[tid] = [row["nsys_start"] for row in rows]
    indexed = {}
    operations: dict[str, str] = {}
    apis: dict[str, dict[str, int]] = {}
    for start, end, tid, correlation, name in connection.execute(
        "SELECT r.start,r.end,r.globalTid,r.correlationId,s.value "
        "FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON r.nameId=s.id"
    ):
        if tid not in ranges:
            continue
        index = bisect_right(starts[tid], start) - 1
        if index < 0 or start >= ranges[tid][index]["nsys_end"]:
            continue
        request = ranges[tid][index]
        if end < start or end > request["nsys_end"]:
            raise RuntimeError("CUDA runtime call crosses its ONNX NVTX range")
        key = request["global_pid"], correlation
        if correlation is None or key in indexed:
            raise RuntimeError(
                "Missing or duplicate process-scoped CUDA correlation ID"
            )
        operation = name.split("_v", 1)[0]
        # Share operation strings across the many ordinary launch records.
        operation = operations.setdefault(operation, operation)
        indexed[key] = request, operation
        api = apis.setdefault(name, {"calls": 0, "summed_wall_ns": 0})
        api["calls"] += 1
        api["summed_wall_ns"] += end - start
    return indexed, apis


def _graph_templates(connection: sqlite3.Connection, pids: set[int]) -> dict:
    """Derive executable-node manifests independently of replay activity rows.

    Nsight records source-node creation inside captured launching APIs. Graph
    instantiation then records cloned node IDs with originalGraphNodeId links.
    Structural allocation/event nodes also exist, so all creation records are
    not equivalent to kernel/copy/memset work. Propagate only independently
    identified executable kinds into each instantiated graph's manifest.
    """
    processes = dict(connection.execute("SELECT globalPid,pid FROM PROCESSES"))
    runtimes: dict[int, list[tuple]] = defaultdict(list)
    for start, end, tid, correlation, name in connection.execute(
        "SELECT r.start,r.end,r.globalTid,r.correlationId,s.value "
        "FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON r.nameId=s.id"
    ):
        if tid is not None and tid & ~_TID_MASK in pids:
            runtimes[tid].append((start, end, correlation, name.split("_v", 1)[0]))
    for rows in runtimes.values():
        rows.sort()
    starts = {tid: [row[0] for row in rows] for tid, rows in runtimes.items()}
    created = set()
    kinds: dict[tuple[int, int], str] = {}
    clones: dict[tuple[int, int], tuple] = {}
    for start, end, tid, node, original in connection.execute(
        "SELECT n.start,n.end,n.globalTid,n.graphNodeId,n.originalGraphNodeId "
        "FROM CUDA_GRAPH_NODE_EVENTS n JOIN StringIds s ON n.nameId=s.id "
        "WHERE s.value='Graph Node Creation'"
    ):
        if tid is None or tid & ~_TID_MASK not in pids:
            continue
        global_pid = tid & ~_TID_MASK
        if processes.get(global_pid) != (tid >> 24) & _TID_MASK:
            raise RuntimeError("CUDA graph node process is not in PROCESSES")
        index = bisect_right(starts.get(tid, []), start) - 1
        if index < 0:
            raise RuntimeError("CUDA graph creation has no enclosing runtime API")
        runtime_start, runtime_end, correlation, operation = runtimes[tid][index]
        if not runtime_start <= start <= end <= runtime_end or node is None:
            raise RuntimeError("CUDA graph creation crosses its runtime API")
        key = global_pid, node
        created.add(key)
        kind = _launch_kind(operation)
        if (
            original is None
            and kind is None
            and operation not in {"cudaMallocAsync", "cudaFreeAsync"}
            and not operation.startswith(("cudaGraphInstantiate", "cuGraphInstantiate"))
        ):
            # These are the structural-node APIs in the qualified RF-DETR
            # capture. Unknown source kinds cannot safely be called non-work.
            raise RuntimeError(
                f"Unsupported CUDA graph source creation API: {operation}"
            )
        if original is None and kind is not None:
            if key in kinds and kinds[key] != kind:
                raise RuntimeError("Conflicting CUDA graph source-node kinds")
            kinds[key] = kind
        elif original is not None:
            template = (
                (global_pid, correlation)
                if operation.startswith(("cudaGraphInstantiate", "cuGraphInstantiate"))
                else None
            )
            value = (global_pid, original), template
            if key in clones and clones[key] != value:
                raise RuntimeError("Conflicting CUDA graph clone identities")
            clones[key] = value
    if any(original not in created for original, _ in clones.values()):
        raise RuntimeError("CUDA graph clone source creation is missing")
    while True:
        changed = False
        for node, (original, _) in clones.items():
            if original not in kinds:
                continue
            if node in kinds and kinds[node] != kinds[original]:
                raise RuntimeError("Conflicting CUDA graph cloned-node kinds")
            if node not in kinds:
                kinds[node] = kinds[original]
                changed = True
        if not changed:
            break
    templates: dict[tuple[int, int], dict[int, str]] = defaultdict(dict)
    for node, (_, template) in clones.items():
        if template is not None and node in kinds:
            templates[template][node[1]] = kinds[node]
    if not templates:
        raise RuntimeError("CUDA graph has no independent executable-node template")
    return dict(templates)


def _activities(
    connection: sqlite3.Connection,
    correlations: dict,
    window: tuple[int, int],
    uncertainty: int,
) -> list[dict[str, Any]]:
    tables = {
        name
        for name, in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    if not {"CUPTI_ACTIVITY_KIND_MEMCPY", "CUPTI_ACTIVITY_KIND_MEMSET"} <= tables:
        raise RuntimeError("Missing fixed-workload CUDA copy/memset activity tables")
    selected = []
    for table, kind in (
        ("CUPTI_ACTIVITY_KIND_KERNEL", "kernel"),
        ("CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL", "kernel"),
        ("CUPTI_ACTIVITY_KIND_MEMCPY", "memcpy"),
        ("CUPTI_ACTIVITY_KIND_MEMSET", "memset"),
    ):
        if table not in tables:
            continue
        extra = ",copyKind,bytes" if kind == "memcpy" else ",NULL,0"
        columns = {row[1] for row in connection.execute(f"PRAGMA table_info({table})")}
        node = "graphNodeId" if "graphNodeId" in columns else "NULL"
        graph = "graphId" if "graphId" in columns else "NULL"
        for (
            start,
            end,
            global_pid,
            correlation,
            device,
            copy_kind,
            size,
            node_id,
            graph_id,
        ) in connection.execute(
            f"SELECT start,end,globalPid,correlationId,deviceId{extra},"
            f"{node},{graph} FROM {table}"
        ):
            if any(
                start < edge + uncertainty and end > edge - uncertainty
                for edge in window
            ):
                raise RuntimeError(
                    "CUDA activity lies in an uncertain clock-alignment boundary"
                )
            runtime = correlations.get((global_pid, correlation))
            request = runtime[0] if runtime is not None else None
            inside = window[0] <= start <= end <= window[1]
            intersects = start < window[1] and end > window[0]
            if not intersects and request is None:
                continue
            if not inside or request is None:
                raise RuntimeError(
                    "Unattributed CUDA activity or work crossing measured window"
                )
            if start < request["nsys_start"] or end > request["nsys_end"]:
                raise RuntimeError(
                    "Device work falls outside the synchronous ONNX call"
                )
            selected.append(
                {
                    "start": start,
                    "end": end,
                    "device": device,
                    "kind": kind,
                    "copy_kind": copy_kind,
                    "bytes": size,
                    "pid": request["pid"],
                    "message_id": request["message_id"],
                    "global_pid": global_pid,
                    "correlation_id": correlation,
                    "graph_node_id": node_id,
                    "graph_id": graph_id,
                }
            )
    if not selected or len({row["device"] for row in selected}) != 1:
        raise RuntimeError("Expected nonempty activity on exactly one study GPU")
    return selected


def _match_graph(rows: list[dict], templates: dict, nodes: dict) -> tuple:
    identities = {nodes.get((row["global_pid"], row["graph_node_id"])) for row in rows}
    if len(identities) != 1 or None in identities:
        raise RuntimeError("CUDA graph replay has unknown or mixed executable nodes")
    template = identities.pop()
    expected = Counter(templates[template].items())
    actual = Counter((row["graph_node_id"], row["kind"]) for row in rows)
    if actual != expected:
        raise RuntimeError("CUDA graph executable-node activity coverage mismatch")
    graph_ids = {row["graph_id"] for row in rows if row["kind"] == "kernel"}
    if len(graph_ids) != 1 or None in graph_ids:
        raise RuntimeError("CUDA graph replay has missing or mixed graph IDs")
    return template, graph_ids.pop()


def _launch_coverage(
    connection: sqlite3.Connection,
    correlations: dict,
    activities: list[dict],
    result: dict,
) -> tuple[Counter, dict]:
    graph_pids = {
        key[0]
        for key, (_, operation) in correlations.items()
        if operation in _GRAPH_LAUNCHES
    }
    templates = _graph_templates(connection, graph_pids) if graph_pids else {}
    nodes: dict[tuple[int, int], tuple[int, int]] = {}
    for template, manifest in templates.items():
        for node in manifest:
            key = template[0], node
            if key in nodes and nodes[key] != template:
                raise RuntimeError("CUDA executable node belongs to multiple graphs")
            nodes[key] = template
    grouped: dict[tuple[int, int], list[dict]] = defaultdict(list)
    for row in activities:
        grouped[row["global_pid"], row["correlation_id"]].append(row)
    expected: Counter[str] = Counter()
    ordinary: Counter[str] = Counter()
    graph_calls: Counter[str] = Counter()
    used: dict[tuple[int, int], dict[str, Any]] = {}
    for key, (request, operation) in correlations.items():
        rows = grouped.get(key, [])
        if operation in _GRAPH_LAUNCHES:
            template, graph_id = _match_graph(rows, templates, nodes)
            counts = Counter(templates[template].values())
            if template in used and used[template]["graph_id"] != graph_id:
                raise RuntimeError("CUDA executable graph ID changed between replays")
            record = used.setdefault(
                template,
                {
                    "pid": request["pid"],
                    "instantiate_correlation_id": template[1],
                    "graph_id": graph_id,
                    "node_counts": dict(counts),
                    "replays": 0,
                },
            )
            record["replays"] += 1
            graph_calls[request["message_id"]] += 1
            expected.update(counts)
            continue
        kind = _launch_kind(operation)
        if kind is None and not rows:
            continue
        if (
            kind is None
            or len(rows) != 1
            or rows[0]["kind"] != kind
            or rows[0]["graph_node_id"] is not None
        ):
            raise RuntimeError("CUDA launching API/device activity count mismatch")
        ordinary[operation] += 1
        expected[kind] += 1
    if expected != Counter(row["kind"] for row in activities):
        raise RuntimeError("CUDA launching API/device activity count mismatch")
    if result.get("engine") in ("cuda-graph", "cuda-graph-blocking"):
        messages = {row["message_id"] for row, _ in correlations.values()}
        if set(graph_calls) != messages or any(n != 1 for n in graph_calls.values()):
            raise RuntimeError("Expected exactly one CUDA graph launch per request")
    return expected, {
        "ordinary_launching_api_counts": dict(ordinary),
        "graph_launch_api_calls": sum(graph_calls.values()),
        "graph_replay_templates": [used[key] for key in sorted(used)],
        "matched_launch_counts_unit": "Device activities, including graph nodes",
    }


def _summaries(rows: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        kind = row["kind"]
        if kind == "memcpy":
            kind += f"_{row['copy_kind']}"
        grouped[kind].append(row)
    return {
        name: {
            "count": len(events),
            "summed_ns": sum(row["end"] - row["start"] for row in events),
            "active_union_ns": _duration(
                _union([(row["start"], row["end"]) for row in events])
            ),
            "bytes": sum(row["bytes"] for row in events),
        }
        for name, events in grouped.items()
    }


def _analyze(connection: sqlite3.Connection, case: Path) -> dict[str, Any]:
    result = json.loads((case / "result.json").read_text())
    if not result["stage_capture"]["valid"]:
        raise RuntimeError("Stage capture must be validated before CUDA attribution")
    markers, alignment = _markers(connection, case, result)
    offset = alignment["selected_offset_ns"]
    window = result["requested_start_ns"] - offset, result["drained_ns"] - offset
    correlations, apis = _runtime(connection, markers)
    activities = _activities(
        connection, correlations, window, alignment["boundary_max_error_ns"]
    )
    runs = [row for row in markers if row["stage"] == "onnx.run.inclusive"]
    indexed = {row["message_id"]: row for row in runs}
    if (
        None in indexed
        or len(indexed) != result["total_drained"]
        or len(runs) != len(indexed)
    ):
        raise RuntimeError("Missing or duplicate measured ONNX request IDs")
    workers = {
        int(pid)
        for pid, row in result["stage_capture"]["processes"].items()
        if row["role"] == "worker"
    }
    if {row["pid"] for row in runs} != workers:
        raise RuntimeError("ONNX NVTX coverage does not include every inference worker")
    by_message: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in activities:
        by_message[row["message_id"]].append(row)
    if set(by_message) != set(indexed):
        raise RuntimeError("Some measured requests have no correlated CUDA work")
    request_metrics = []
    for message, run in indexed.items():
        rows = by_message[message]
        request_metrics.append(
            {
                "message_id": message,
                "pid": run["pid"],
                "onnx_python_wall_ns": run["wall_ns"],
                "onnx_thread_cpu_ns": run["thread_cpu_ns"],
                "nsys_onnx_start_ns": run["nsys_start"],
                "nsys_onnx_end_ns": run["nsys_end"],
                "activity": _summaries(rows),
                "gpu_active_union_ns": _duration(
                    _union([(r["start"], r["end"]) for r in rows])
                ),
                "gpu_first_start_ns": min(r["start"] for r in rows),
                "gpu_last_end_ns": max(r["end"] for r in rows),
            }
        )
    kernel_counts = {
        row["activity"].get("kernel", {}).get("count", 0) for row in request_metrics
    }
    if 0 in kernel_counts or len(kernel_counts) != 1:
        raise RuntimeError(
            "Fixed-input requests have missing or inconsistent kernel counts"
        )
    # Uniform kernel counts alone cannot detect systematic loss. Ordinary APIs
    # require one matching activity; graph replays require every independently
    # identified executable node, with no duplicate, missing or substituted IDs.
    expected_activity, launch_coverage = _launch_coverage(
        connection, correlations, activities, result
    )
    intervals = [(row["start"], row["end"]) for row in activities]
    active = _union(intervals)
    busy = _duration(active)
    duration = window[1] - window[0]
    onnx_union = _duration(
        _union([(row["nsys_start"], row["nsys_end"]) for row in runs])
    )
    interior = [b[0] - a[1] for a, b in zip(active, active[1:])]
    diagnostics = [
        dict(zip(("severity", "text", "global_pid"), row))
        for row in connection.execute(
            "SELECT severity,text,globalPid FROM DIAGNOSTIC_EVENT WHERE severity >= 2"
        )
    ]
    copy_kinds = dict(connection.execute("SELECT id,label FROM ENUM_CUDA_MEMCPY_OPER"))
    return {
        "valid": True,
        "case": str(case),
        "protocol": result["protocol"],
        "request_count": result["total_drained"],
        "clock_alignment": alignment,
        "nsys_measured_window": {
            "start_ns": window[0],
            "end_ns": window[1],
            "duration_ns": duration,
        },
        "coverage": {
            "worker_pids": sorted(workers),
            "matched_request_count": len(indexed),
            "correlated_runtime_calls": len(correlations),
            "kernel_count_per_request": next(iter(kernel_counts)),
            "matched_launch_counts": dict(expected_activity),
            **launch_coverage,
            "diagnostic_warnings": diagnostics,
        },
        "device_activity": {
            "active_union_ns": busy,
            "no_traced_activity_ns": duration - busy,
            "active_fraction": busy / duration,
            "summed_activity_ns": _duration(intervals),
            "overlap_excess_ns": _duration(intervals) - busy,
            "time_with_multiple_activities_ns": _overlap(intervals),
            "by_kind": _summaries(activities),
            "copy_kind_labels": copy_kinds,
        },
        "gaps": {
            "interior": _distribution(interior),
            "leading_ns": active[0][0] - window[0],
            "trailing_ns": window[1] - active[-1][1],
            "interior_over_1ms": _distribution(
                [gap for gap in interior if gap > 1_000_000]
            ),
        },
        "host_onnx": {
            "run_union_ns": onnx_union,
            "no_run_outstanding_ns": duration - onnx_union,
            "traced_idle_inside_run_union_ns": onnx_union - busy,
            "request_wall": _distribution([row["wall_ns"] for row in runs]),
        },
        "runtime_apis": apis,
        "request_metrics": request_metrics,
        "interpretation": (
            "Activity is the union of this application's recorded kernels, "
            "copies and memsets; it is not SM occupancy or proof the whole "
            "device was idle. Nested API wall times "
            "must not be summed as CPU time. Profiled throughput is diagnostic only."
            " Per-node CUDA graph tracing adds capture overhead."
        ),
    }


def analyze(case: Path) -> dict[str, Any]:
    """Return measured-only CUDA accounting without modifying the case or database."""
    case = case.resolve()
    database = case / "cuda-timeline.sqlite"
    try:
        with closing(
            sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
        ) as connection:
            return _analyze(connection, case)
    except sqlite3.Error as error:
        raise RuntimeError(
            f"Cannot analyze supported Nsight SQLite schema: {error}"
        ) from error


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    summary = json.dumps(analyze(args.case), indent=2, allow_nan=False) + "\n"
    if args.output:
        with args.output.open("x") as destination:
            destination.write(summary)
        print(args.output)
    else:
        print(summary, end="")


if __name__ == "__main__":
    main()
