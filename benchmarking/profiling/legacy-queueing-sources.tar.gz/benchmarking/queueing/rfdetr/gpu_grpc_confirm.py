"""Confirm gRPC client topology and diagnose the serial REST transport tradeoff.

One frozen source and one environment serve every variant. Repeated gRPC
trials are unprofiled; bracketed captures diagnose gRPC and serial REST work.
"""

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

import gpu_baseline as baseline
import gpu_transport_compare as transport

study = baseline.study
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-confirm-20261026"
VARIANTS = (
    ("stock-queue", "stock", "queue"),
    ("compact-queue", "compact", "queue"),
    ("compact-zmq", "compact", "zmq"),
)


def _options(configuration: dict, clients: int, seconds: float) -> list[str]:
    selected = transport.options(
        configuration, configuration["concurrency"], seconds, clients
    )
    # The shared transport helper deliberately defaults to compact. This plan
    # also needs a stock baseline at the same two-worker/two-thread settings.
    selected[selected.index("--adapter") + 1] = configuration["adapter"]
    return selected


def _check(row: dict, configuration: dict, clients: int) -> None:
    if any(row.get(key) != value for key, value in configuration.items()):
        raise RuntimeError("Confirmation result serving configuration mismatch")
    if len(row.get("clients", [])) != min(clients, configuration["concurrency"]):
        raise RuntimeError("Confirmation result client count mismatch")
    if not math.isfinite(row["rps"]) or row["rps"] <= 0:
        raise RuntimeError("Confirmation result has invalid throughput")


def execute(plan: baseline.Plan, reference: dict) -> dict[str, Any]:
    fixed = {"protocol": "grpc", "concurrency": 16, **reference["fixed"]["grpc"]}
    repeats = []
    for repeat in range(plan.args.repeats):
        # Rotate variants through every position, and alternate topology order
        # rather than collecting all two-client trials before four-client ones.
        start = repeat % len(VARIANTS)
        variants = VARIANTS[start:] + VARIANTS[:start]
        for clients in (2, 4) if repeat % 2 == 0 else (4, 2):
            for label, adapter, backend in variants:
                configuration = {**fixed, "adapter": adapter, "transport": backend}
                summary, path = plan.run(
                    f"grpc-r{repeat}-clients{clients}-{label}",
                    [
                        "--phase",
                        "smoke",
                        *_options(configuration, clients, plan.args.repeat_seconds),
                    ],
                )
                rows = summary.get("results", [])
                if len(rows) != 1 or rows[0].get("profiled") is not False:
                    raise RuntimeError(
                        "Confirmation repeats require one unprofiled trial"
                    )
                _check(rows[0], configuration, clients)
                repeats.append(
                    {
                        "round": repeat,
                        "clients": clients,
                        "variant": label,
                        "summary": str(path),
                        "result": rows[0],
                    }
                )
                study.publish(plan.directory / "REPEATS.json", repeats)
    grpc = {**fixed, "adapter": "compact", "transport": "zmq"}
    rest = {
        "protocol": "rest",
        "concurrency": 1,
        "adapter": "compact",
        **reference["fixed"]["rest"],
    }
    targets = (
        ("grpc-clients4-compact-zmq", grpc, 4, ("cpu", "gil", "stages", "cuda")),
        ("rest-c1-compact-queue", {**rest, "transport": "queue"}, 2, ("cpu", "stages")),
        ("rest-c1-compact-zmq", {**rest, "transport": "zmq"}, 2, ("cpu", "stages")),
    )
    captures: dict[str, dict] = {}
    for label, configuration, clients, names in targets:
        captures[label] = {
            "configuration": configuration,
            "requested_clients": clients,
            "active_clients": min(clients, configuration["concurrency"]),
            "passes": {},
        }
        for name in names:
            phase = (
                ["--phase", "profile", "--capture", name]
                if name in ("cpu", "gil")
                else ["--phase", name]
            )
            summary, path = plan.run(
                f"{label}-{name}",
                [*phase, *_options(configuration, clients, plan.args.seconds)],
            )
            rows = summary.get("results", [])
            if [row.get("role") for row in rows] != [
                "control-before",
                phase[1],
                "control-after",
            ] or [row.get("profiled") for row in rows] != [False, True, False]:
                raise RuntimeError(
                    "Confirmation capture requires before/after controls"
                )
            for row in rows:
                _check(row, configuration, clients)
            captures[label]["passes"][name] = str(path)
            study.publish(plan.directory / "CAPTURES.json", captures)
    return {
        "purpose": "gRPC topology confirmation and serial REST diagnostics",
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "reference": reference,
        "repeats": repeats,
        "captures": captures,
        "interpretation": (
            "gRPC repeats hold workers2, threads2 and concurrency16 fixed. "
            "Each client process owns one channel. More clients change channel count, "
            "per-process concurrency and native gRPC scheduling within one CPU budget. "
            "A gain with low client CPU does not establish a CPU ceiling. "
            "Stock/Queue, compact/Queue and compact/ZeroMQ rotate position each round. "
            "REST captures hold workers8, threads2 and concurrency1 fixed to diagnose "
            "the existing serial transport regression. Profile timings are diagnostic."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=transport.DEFAULT_REFERENCE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    if (
        os.geteuid() != 0
        or args.repeats < 1
        or any(
            not math.isfinite(value) or value <= 0
            for value in (args.seconds, args.repeat_seconds)
        )
    ):
        parser.error("Run as root with positive repeats and finite positive durations")
    args.without_cuda, args.concurrency = False, 16
    args.reference, args.bundle, args.store = (
        path.resolve() for path in (args.reference, args.bundle, args.store)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"confirm-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"Confirmation output: {directory}", flush=True)
    try:
        reference = transport.load_reference(args.reference)
        study.publish(directory / "REFERENCE.json", reference)
        inventory = transport.environment_inventory(reference)
        study.publish(directory / "ENVIRONMENT.json", inventory)
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if manifest["onnx"]["sha256"] != reference["model_sha256"]:
            raise RuntimeError("Confirmation model differs from the reference")
        tools = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", tools)
        if not tools["perf"]["available"] or not tools["nsys"]["available"]:
            raise RuntimeError("Working perf and Nsight Systems are required")
        study.freeze(directory)
        result = execute(plan, reference)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
