"""Autonomous root-run compact-adapter screening, matched repeats and diagnostics.

Repeated timings are unprofiled trials; short screening selects provisional worker
settings. Captures diagnose the remaining bottlenecks and are not speedup data.
"""

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
from statistics import median
import sys
from typing import Any

import gpu_baseline as baseline

study = baseline.study
DEFAULT_BASELINE = Path(
    "/home/codex/mlserver-durable-store/rfdetr-gpu-master-study-20261026/"
    "plan-20261026T162855482978Z-197949/SUMMARY.json"
)
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-experiments-20261026"


def choose_winners(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    expected = {(1, None), *((w, t) for w in (1, 2, 4, 8) for t in (1, 2, 4))}
    if len(rows) != 26:
        raise RuntimeError("Compact screening requires all 26 rows")
    winners = {}
    for protocol in ("rest", "grpc"):
        candidates = [row for row in rows if row.get("protocol") == protocol]
        if (
            len(candidates) != 13
            or {(row.get("workers"), row.get("threads")) for row in candidates}
            != expected
        ):
            raise RuntimeError(
                f"Incomplete/duplicate {protocol} compact configurations"
            )
        for row in candidates:
            if (
                row.get("adapter") != "compact"
                or row.get("profiled") is not False
                or not math.isfinite(row["rps"])
                or row["rps"] <= 0
            ):
                raise RuntimeError(f"Invalid compact screening result for {protocol}")
        winner = max(candidates, key=lambda row: row["rps"])
        winners[protocol] = dict(winner)
        winners[protocol]["provisional"] = True
        winners[protocol]["client_headroom_needs_confirmation"] = winner.get(
            "client_headroom_needs_confirmation", False
        )
    return winners


def options(
    configuration: dict[str, Any], concurrency: int, seconds: float
) -> list[str]:
    """Make every serving selector explicit, including the original thread default."""
    values = {
        "protocol": configuration["protocol"],
        "adapter": configuration["adapter"],
        "workers": configuration["workers"],
        "threads": configuration["threads"] or 0,
        "clients": 2,
        "concurrency": concurrency,
        "requests": math.ceil(32 / concurrency) * concurrency,
        "seconds": seconds,
    }
    return [item for key, value in values.items() for item in (f"--{key}", str(value))]


def eight_worker_guard(plan: baseline.Plan) -> None:
    snapshot = study.gpu_tools.gpu_snapshot()
    gpu = snapshot["gpus"][0]
    free = None
    if gpu["memory_total_mib"] is not None and gpu["memory_used_mib"] is not None:
        free = gpu["memory_total_mib"] - gpu["memory_used_mib"]
    active = [
        row
        for row in snapshot["compute_processes"]
        if row["gpu_uuid"] == gpu["uuid"]
        and row.get("process_name") != study.DISPLAY_PROCESS
    ]
    allowed = "4070" in gpu["name"] and free is not None and free >= 8192 and not active
    study.publish(
        plan.directory / "EIGHT_WORKER_GPU_GUARD.json",
        {
            "snapshot": snapshot,
            "free_mib": free,
            "allowed": allowed,
            "allowed_display_process": study.DISPLAY_PROCESS,
            "reason": "Require idle RTX4070 and >=8 GiB free; "
            "prior four-worker peak was about 3 GiB. "
            "This is a conservative planning guard, not a GPU memory allocation limit.",
        },
    )
    if not allowed:
        raise RuntimeError(
            "Eight-worker sweep requires idle RTX4070 and at least 8 GiB free VRAM"
        )


def client_control(
    plan: baseline.Plan, winner: dict[str, Any], repeats: list[dict[str, Any]]
) -> dict[str, Any]:
    """Check client headroom without using the control to select a new winner."""
    reference = median(
        row["result"]["rps"]
        for row in repeats
        if row["concurrency"] == 16
        and all(
            row["result"][key] == winner[key]
            for key in ("protocol", "adapter", "workers", "threads")
        )
    )
    selected = options(winner, 16, plan.args.seconds)
    selected[selected.index("--clients") + 1] = "4"
    summary, path = plan.run(
        f"{winner['protocol']}-compact-client-control",
        ["--phase", "smoke", *selected],
    )
    rows = summary.get("results", [])
    if (
        len(rows) != 1
        or rows[0].get("profiled") is not False
        or any(
            rows[0].get(key) != winner[key]
            for key in ("protocol", "adapter", "workers", "threads")
        )
        or rows[0].get("concurrency") != 16
    ):
        raise RuntimeError("Four-client control configuration mismatch")
    row = rows[0]
    ratio = row["rps"] / reference
    return {
        "summary": str(path),
        "result": row,
        "two_client_repeat_median_rps": reference,
        "four_to_two_rps_ratio": ratio,
        "needs_confirmation": bool(
            row.get("client_headroom_needs_confirmation")
            or ratio > 1.05
            or any(
                client["client_cpu_seconds"] / client["duration_seconds"] > 0.8
                for client in row.get("clients", [])
            )
        ),
    }


def execute(plan: baseline.Plan) -> dict[str, Any]:
    reference = json.loads(plan.args.baseline.read_text())
    stock = reference["winners"]
    if reference.get("python") != str(plan.python) or set(stock) != {"rest", "grpc"}:
        raise RuntimeError(
            "Baseline must have both protocol winners and the same serving Python"
        )
    for winner in stock.values():
        if winner["workers"] not in (1, 2, 4) or winner["threads"] not in (
            None,
            1,
            2,
            4,
        ):
            raise RuntimeError("Unsupported baseline worker/thread configuration")
    study.publish(plan.directory / "baseline-summary.json", reference)
    qualification = {}
    small = options(
        {"protocol": "both", "adapter": "compact", "workers": 1, "threads": 1}, 2, 1
    )
    small[small.index("--requests") + 1] = "4"
    for name, phase in (
        ("stages", ["--phase", "stages"]),
        ("cuda", ["--phase", "cuda"]),
        ("gil", ["--phase", "profile", "--capture", "gil"]),
    ):
        _, path = plan.run(f"qualification-{name}", [*phase, *small])
        qualification[name] = str(path)
    common = options(
        {"protocol": "both", "adapter": "compact", "workers": 1, "threads": 1},
        16,
        plan.args.seconds,
    )
    tuning, path = plan.run("compact-tune", ["--phase", "tune", *common])
    tuning_paths = [str(path)]
    rows = list(tuning["results"])
    eight_worker_guard(plan)
    for threads in (1, 2, 4):
        selected = options(
            {
                "protocol": "both",
                "adapter": "compact",
                "workers": 8,
                "threads": threads,
            },
            16,
            plan.args.seconds,
        )
        extension, path = plan.run(
            f"compact-w8-t{threads}", ["--phase", "smoke", *selected]
        )
        rows.extend(extension["results"])
        tuning_paths.append(str(path))
    winners = choose_winners(rows)
    study.publish(plan.directory / "WINNERS.json", winners)
    repeats = []
    captures = {}
    client_controls = {}
    for protocol, winner in winners.items():
        matched = {
            "protocol": protocol,
            "workers": stock[protocol]["workers"],
            "threads": stock[protocol]["threads"],
        }
        variants = [
            ("stock", {**matched, "adapter": "stock"}),
            ("compact", {**matched, "adapter": "compact"}),
        ]
        if (winner["workers"], winner["threads"]) != (
            matched["workers"],
            matched["threads"],
        ):
            variants.append(("compact-tuned", winner))
        for concurrency in (1, 16):
            for repeat in range(plan.args.repeats):
                order = variants if repeat % 2 == 0 else list(reversed(variants))
                for label, configuration in order:
                    summary, path = plan.run(
                        f"{protocol}-c{concurrency}-r{repeat}-{label}",
                        [
                            "--phase",
                            "smoke",
                            *options(
                                configuration, concurrency, plan.args.repeat_seconds
                            ),
                        ],
                    )
                    measured = summary.get("results", [])
                    if len(measured) != 1 or measured[0].get("profiled") is not False:
                        raise RuntimeError(
                            "Repeated timing requires one unprofiled result"
                        )
                    row = measured[0]
                    if (
                        any(
                            row.get(key) != configuration[key]
                            for key in ("protocol", "adapter", "workers", "threads")
                        )
                        or row.get("concurrency") != concurrency
                    ):
                        raise RuntimeError("Repeated timing configuration mismatch")
                    repeats.append(
                        {
                            "label": label,
                            "round": repeat,
                            "concurrency": concurrency,
                            "summary": str(path),
                            "result": row,
                        }
                    )
                    study.publish(plan.directory / "REPEATS.json", repeats)
        client_controls[protocol] = client_control(plan, winner, repeats)
        study.publish(plan.directory / "CLIENT_CONTROLS.json", client_controls)
        paths = {}
        for name, phase in (
            ("cpu", ["--phase", "profile", "--capture", "cpu"]),
            ("gil", ["--phase", "profile", "--capture", "gil"]),
            ("stages", ["--phase", "stages"]),
            ("cuda", ["--phase", "cuda"]),
        ):
            _, path = plan.run(
                f"{protocol}-compact-{name}",
                [*phase, *options(winner, 16, plan.args.seconds)],
            )
            paths[name] = str(path)
        captures[protocol] = paths
    return {
        "purpose": "Compact screening, matched unprofiled repeats and diagnostics",
        "baseline": str(plan.args.baseline),
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "qualification": qualification,
        "tuning": tuning_paths,
        "winners": winners,
        "repeats": repeats,
        "captures": captures,
        "client_controls": client_controls,
        "host_conditions": "User reports audit disabled and Firefox closed; "
        "harness does not change host settings.",
        "interpretation": "Short tuning winners are provisional. Compare repeated "
        "unprofiled stock/compact rows at equal worker/thread settings. "
        "Compact-tuned rows include tuning effects. "
        "Profile RPS is diagnostic, not final speedup evidence. "
        "Remaining REST bottlenecks still require analysis "
        "before the final study/report.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    if os.geteuid() != 0 or sys.version_info[:2] != (3, 12):
        parser.error("Run as root with the pinned serving environment's Python 3.12")
    if args.repeats < 1 or any(
        not math.isfinite(s) or s <= 0 for s in (args.seconds, args.repeat_seconds)
    ):
        parser.error("Repeat count and finite measurement durations must be positive")
    args.without_cuda, args.concurrency = False, 16
    args.bundle, args.store, args.baseline = (
        p.resolve() for p in (args.bundle, args.store, args.baseline)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"experiment-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"Experiment output: {directory}", flush=True)
    try:
        capabilities = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", capabilities)
        if any(
            not capabilities.get(name, {}).get("available") for name in ("nsys", "perf")
        ):
            raise RuntimeError(
                "Working Nsight Systems and perf are required; "
                "repair unavailable tools before this experiment"
            )
        study.freeze(directory)
        study.publish(directory / "SUMMARY.json", execute(plan))
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
