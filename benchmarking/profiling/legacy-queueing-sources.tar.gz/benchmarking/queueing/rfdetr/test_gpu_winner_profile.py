"""Winner-profile plan tests mock children, tools, root identity and source freeze."""

import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import gpu_winner_profile as driver


def production() -> dict[str, str]:
    return {f"mlserver/fixture-{index}.py": f"hash-{index}" for index in range(102)}


def prior() -> dict:
    return {
        "model_sha256": hashlib.sha256(b"model").hexdigest(),
        "python": "/old/python",
    }


class WinnerTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        args = argparse.Namespace(
            bundle=self.root,
            user="codex",
            seconds=10.0,
            repeat_seconds=15.0,
            repeats=3,
            without_cuda=False,
            concurrency=16,
        )
        self.plan = driver.baseline.Plan(args, self.root, Path("/transport/python"))

    def child(self, label: str, options: list[str]) -> tuple[dict, Path]:
        self.assertNotIn("--metadata-only", options)
        values = dict(zip(options[::2], options[1::2]))
        configuration = {
            **driver.SELECTED,
            "engine": values["--engine"],
            "concurrency": int(values["--concurrency"]),
        }
        clients = min(2, configuration["concurrency"])
        row = {**configuration, "clients": [{}] * clients, "rps": 100.0}
        phase = values["--phase"]
        roles = (
            [("smoke", False)]
            if phase == "smoke"
            else [("control-before", False), (phase, True), ("control-after", False)]
        )
        return {
            "results": [
                {**row, "role": name, "profiled": profiled} for name, profiled in roles
            ]
        }, self.root / label / "SUMMARY.json"

    def reference_summary(self) -> dict:
        snapshot = self.root / "prior/source"
        snapshot.mkdir(parents=True, exist_ok=True)
        (snapshot.parent / "source-hashes.json").write_text(json.dumps(production()))
        configurations = {
            "run": {**driver.SELECTED, "engine": "run"},
            "cuda-graph-blocking": driver.SELECTED,
            "cuda-graph": {**driver.SELECTED, "engine": "cuda-graph"},
        }
        repeats = []
        for name in ("run", "cuda-graph-blocking"):
            for repeat in range(3):
                row = {
                    **configurations[name],
                    "clients": [{}, {}],
                    "role": "smoke",
                    "profiled": False,
                    "rps": 100.0,
                }
                repeats.append(
                    {
                        "block": "increments",
                        "variant": name,
                        "round": repeat,
                        "requested_clients": 2,
                        "summary": f"/prior/{name}/{repeat}/SUMMARY.json",
                        "result": row,
                    }
                )
        return {
            "configurations": configurations,
            "repeats": repeats,
            "reference": prior(),
            "source_snapshot": str(snapshot),
        }

    def test_validates_explicit_winner_and_all_three_previous_no_metadata_trials(
        self,
    ) -> None:
        path = self.root / "reference.json"
        path.write_text(json.dumps(self.reference_summary()))
        checked = driver.load_reference(path)
        self.assertEqual(checked["production_hashes"], production())
        self.assertEqual(
            set(checked["verified_repeat_summaries"]), {"run", "cuda-graph-blocking"}
        )
        for change in ("missing", "duplicate", "metadata", "profiled", "selected"):
            summary = self.reference_summary()
            if change == "missing":
                summary["repeats"].pop()
            elif change == "duplicate":
                summary["repeats"][-1]["round"] = 0
            elif change == "selected":
                summary["configurations"]["cuda-graph-blocking"] = {
                    **driver.SELECTED,
                    "metadata_only": True,
                }
            else:
                summary["repeats"][-1]["result"][
                    "metadata_only" if change == "metadata" else "profiled"
                ] = True
            path.write_text(json.dumps(summary))
            with self.subTest(change=change), self.assertRaises(RuntimeError):
                driver.load_reference(path)

    def test_six_serial_trials_then_four_winner_bracketed_profiles(self) -> None:
        with patch.object(self.plan, "run", side_effect=self.child) as run:
            result = driver.execute(self.plan, {"verified": True})
        self.assertEqual(run.call_count, 10)
        self.assertEqual(len(result["serial_repeats"]), 6)
        self.assertEqual(
            [r["variant"] for r in result["serial_repeats"]],
            [
                "run",
                "cuda-graph-blocking",
                "cuda-graph-blocking",
                "run",
                "run",
                "cuda-graph-blocking",
            ],
        )
        self.assertTrue(
            all(
                r["active_clients"] == 1 and r["requested_clients"] == 2
                for r in result["serial_repeats"]
            )
        )
        cases = 0
        for call in run.call_args_list:
            options = dict(zip(call.args[1][::2], call.args[1][1::2]))
            self.assertEqual(
                (
                    options["--workers"],
                    options["--threads"],
                    options["--adapter"],
                    options["--transport"],
                    options["--clients"],
                ),
                ("2", "2", "compact", "zmq", "2"),
            )
            serial = options["--phase"] == "smoke"
            self.assertEqual(options["--concurrency"], "1" if serial else "16")
            self.assertEqual(options["--seconds"], "15.0" if serial else "10.0")
            if not serial:
                self.assertEqual(options["--engine"], "cuda-graph-blocking")
            cases += 1 if serial else 3
        self.assertEqual(cases, 18)
        self.assertEqual(set(result["captures"]), {"cpu", "gil", "stages", "cuda"})
        self.assertEqual(len(json.loads((self.root / "REPEATS.json").read_text())), 6)

    def test_missing_capture_controls_fail_after_preserving_serial_repeats(
        self,
    ) -> None:
        def child(label: str, options: list[str]) -> tuple[dict, Path]:
            summary, path = self.child(label, options)
            if label == "gil":
                summary["results"] = summary["results"][1:]
            return summary, path

        with patch.object(self.plan, "run", side_effect=child):
            with self.assertRaises(RuntimeError):
                driver.execute(self.plan, {})
        self.assertEqual(len(json.loads((self.root / "REPEATS.json").read_text())), 6)
        self.assertEqual(
            set(json.loads((self.root / "CAPTURES.json").read_text())), {"cpu"}
        )

    def test_main_freezes_once_and_rejects_production_changes_before_work(self) -> None:
        (self.root / "model").mkdir()
        (self.root / "model/model.onnx").write_bytes(b"model")
        (self.root / "manifest.json").write_text(
            json.dumps({"onnx": {"sha256": prior()["model_sha256"]}})
        )
        selected = {"prior_reference": prior(), "production_hashes": production()}
        arguments = [
            "winner",
            "--bundle",
            str(self.root),
            "--store",
            str(self.root / "runs"),
        ]

        def freeze(path: Path) -> None:
            (path / "source-hashes.json").write_text(json.dumps(production()))

        with patch.object(sys, "argv", arguments), patch.object(
            driver.os, "geteuid", return_value=0
        ), patch.object(driver, "load_reference", return_value=selected), patch.object(
            driver.transport, "environment_inventory", return_value={"verified": True}
        ) as inventory, patch.object(
            driver.study.gpu_tools,
            "capabilities",
            return_value={"perf": {"available": True}, "nsys": {"available": True}},
        ), patch.object(
            driver.study, "freeze", side_effect=freeze
        ) as frozen, patch.object(
            driver, "execute", return_value={"complete": True}
        ) as execute:
            driver.main()
        frozen.assert_called_once()
        inventory.assert_called_once_with(prior())
        self.assertEqual(execute.call_args.args[0].python, Path(sys.executable))
        wrong = copy.deepcopy(selected)
        wrong["production_hashes"]["mlserver/fixture-0.py"] = "different"
        with patch.object(sys, "argv", arguments), patch.object(
            driver.os, "geteuid", return_value=0
        ), patch.object(driver, "load_reference", return_value=wrong), patch.object(
            driver.transport, "environment_inventory", return_value={"verified": True}
        ), patch.object(
            driver.study.gpu_tools,
            "capabilities",
            return_value={"perf": {"available": True}, "nsys": {"available": True}},
        ), patch.object(
            driver.study, "freeze", side_effect=freeze
        ), patch.object(
            driver, "execute"
        ) as execute:
            with self.assertRaisesRegex(RuntimeError, "Production source differs"):
                driver.main()
        execute.assert_not_called()
        self.assertEqual(
            len(list((self.root / "runs").glob("profile-*/FAILED.json"))), 1
        )


if __name__ == "__main__":
    unittest.main()
