"""Compare the selected gRPC winner with direct raw-buffer injection.

Screening is eight short unprofiled calls by default. Formal root trials retain
the same model, environment, CUDA engine, workers, transport and client budget.
Only the protobuf-to-input injection path changes.
"""

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

import gpu_baseline as baseline
import gpu_engine_compare as engine
import gpu_transport_compare as transport
import gpu_winner_profile as winner

study = baseline.study
DEFAULT_REFERENCE = Path(
    "/home/codex/mlserver-durable-store/rfdetr-gpu-winner-profile-20261026/"
    "profile-20261026T221843259232Z-419811/SUMMARY.json"
)
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-inject-compare-20261026"
FIXED = {**winner.SELECTED, "buffer_inject": False}


def options(configuration: dict, clients: int, seconds: float) -> list[str]:
    selected = engine.options(configuration, clients, seconds)
    if configuration["buffer_inject"]:
        selected.append("--buffer-inject")
    return selected


def receipts(case: Path, configuration: dict, legacy: bool = False) -> list[int]:
    front = json.loads((case / "receipts/frontend.json").read_text())
    workers = [
        json.loads(path.read_text())
        for path in sorted((case / "receipts").glob("worker-*.json"))
    ]
    pids = [row["pid"] for row in [front, *workers]]
    if len(workers) != configuration["workers"] or len(set(pids)) != len(pids):
        raise RuntimeError("Missing, duplicate or restarted inference worker PIDs")
    expected = {
        key: configuration[key]
        for key in ("adapter", "transport", "engine", "metadata_only", "buffer_inject")
    }
    expected.update(
        zmq_installed=True, adapter_installed={"buffers": True, "worker_json": True}
    )
    for row in [front, *workers]:
        for key, value in expected.items():
            actual = (
                row.get(key, False)
                if legacy and key == "buffer_inject"
                else row.get(key)
            )
            if actual != value or isinstance(value, bool) and actual is not value:
                raise RuntimeError(f"Actual injection/engine receipt mismatch: {key}")
    variant = study.Variant(
        **{
            key: configuration[key]
            for key in (
                "workers",
                "threads",
                "adapter",
                "transport",
                "engine",
                "metadata_only",
                "buffer_inject",
            )
        }
    )
    for row in workers:
        if row.get("intra_op_threads") != configuration["threads"]:
            raise RuntimeError("Actual worker thread count differs from comparison")
        study.validate_engine(row, variant)
    return pids


def load_reference(path: Path) -> dict[str, Any]:
    summary = json.loads(path.read_text())
    if summary.get("selected_configuration") != winner.SELECTED:
        raise RuntimeError("Reference is not the selected no-metadata gRPC winner")
    if set(summary.get("captures", {})) != {"cpu", "gil", "stages", "cuda"}:
        raise RuntimeError("Reference winner captures are incomplete")
    cuda = json.loads(Path(summary["captures"]["cuda"]).read_text())
    rows = engine.check(cuda, winner.SELECTED, 2, "cuda")
    measured = rows[1]
    if not measured.get("stage_capture", {}).get("valid"):
        raise RuntimeError("Reference CUDA stage capture is invalid")
    case = Path(measured["cuda_timeline"]["database"]).parent
    actual_pids = receipts(case, FIXED, legacy=True)
    hashes = winner.production(
        json.loads(
            (Path(summary["source_snapshot"]).parent / "source-hashes.json").read_text()
        )
    )
    if len(hashes) != 102:
        raise RuntimeError("Reference production source manifest is incomplete")
    prior = summary["reference"]["prior_reference"]
    if prior.get("fixed", {}).get("grpc") != {"workers": 2, "threads": 2}:
        raise RuntimeError("Reference gRPC worker configuration differs")
    return {
        "source_summary": str(path),
        "python": summary["python"],
        "prior_reference": prior,
        "production_hashes": hashes,
        "verified_cuda_summary": summary["captures"]["cuda"],
        "verified_receipt_pids": actual_pids,
    }


def run(
    plan: baseline.Plan, label: str, configuration: dict, command: list[str]
) -> tuple[list[dict], Path]:
    summary, path = plan.run(label, command)
    phase = command[command.index("--phase") + 1]
    clients = int(command[command.index("--clients") + 1])
    rows = engine.check(summary, configuration, clients, phase)
    if not plan.args.screen and summary.get("resource_limits_enforced") is not True:
        raise RuntimeError("Formal comparison requires verified root resource limits")
    cases = sorted(path.parent.glob("case-*/result.json"))
    if len(cases) != len(rows):
        raise RuntimeError("Missing comparison case records")
    for record, row in zip(cases, rows):
        if row.get("buffer_inject") is not configuration["buffer_inject"]:
            raise RuntimeError("Injection result boolean differs from selection")
        saved = json.loads(record.read_text())
        # gpu_study assigns the bracket role after saving the case result.
        if saved != {key: value for key, value in row.items() if key != "role"}:
            raise RuntimeError("Summary differs from its saved case result")
        receipts(record.parent, configuration)
    return rows, path


def execute(plan: baseline.Plan, reference: dict) -> dict[str, Any]:
    repeats = []
    variants = (("copy", FIXED), ("inject", {**FIXED, "buffer_inject": True}))
    concurrencies = (16,) if plan.args.screen else (1, 16)
    for repeat in range(plan.args.repeats):
        ordered = variants if repeat % 2 == 0 else tuple(reversed(variants))
        blocks = concurrencies if repeat % 2 == 0 else tuple(reversed(concurrencies))
        for concurrency in blocks:
            for label, selected in ordered:
                configuration = {**selected, "concurrency": concurrency}
                rows, path = run(
                    plan,
                    f"r{repeat}-c{concurrency}-{label}",
                    configuration,
                    [
                        "--phase",
                        "smoke",
                        *options(configuration, 2, plan.args.repeat_seconds),
                    ],
                )
                repeats.append(
                    {
                        "round": repeat,
                        "variant": label,
                        "concurrency": concurrency,
                        "requested_clients": 2,
                        "active_clients": min(2, concurrency),
                        "summary": str(path),
                        "result": rows[0],
                    }
                )
                study.publish(plan.directory / "REPEATS.json", repeats)
    controls, captures = {}, {}
    if not plan.args.screen:
        for label, configuration in variants:
            rows, path = run(
                plan,
                f"clients4-{label}",
                configuration,
                [
                    "--phase",
                    "smoke",
                    *options(configuration, 4, plan.args.repeat_seconds),
                ],
            )
            controls[label] = {
                "requested_clients": 4,
                "summary": str(path),
                "result": rows[0],
            }
            study.publish(plan.directory / "CLIENT_CONTROLS.json", controls)
        injected = variants[1][1]
        for name in ("cpu", "gil", "stages", "cuda"):
            command = (
                ["--phase", "profile", "--capture", name]
                if name in ("cpu", "gil")
                else ["--phase", name]
            )
            _, path = run(
                plan,
                f"inject-{name}",
                injected,
                [*command, *options(injected, 2, plan.args.seconds)],
            )
            captures[name] = str(path)
            study.publish(plan.directory / "CAPTURES.json", captures)
    return {
        "purpose": "Fixed gRPC winner versus direct raw-buffer injection",
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "reference": reference,
        "fixed_configuration": FIXED,
        "screening_only": plan.args.screen,
        "resource_budget_verified": not plan.args.screen,
        "resource_scope": (
            "Screening only; nonroot execution has no verified cgroup budget; "
            "no formal capacity claim"
            if plan.args.screen
            else "Root-enforced common server/client CPU and memory budget"
        ),
        "expected_child_calls": (
            2 * plan.args.repeats if plan.args.screen else 4 * plan.args.repeats + 6
        ),
        "expected_server_cases": (
            2 * plan.args.repeats if plan.args.screen else 4 * plan.args.repeats + 14
        ),
        "repeats": repeats,
        "client_controls": controls,
        "captures": captures,
        "interpretation": (
            "Only raw-buffer injection changes. Both paths retain compact NumPy "
            "IPC, ZeroMQ, CUDA Graph/blocking, FP32/B1, two workers/two threads "
            "and metadata-only disabled. Profiles are bracketed diagnostics; "
            "compare unprofiled repeats at the same concurrency/client topology. "
            "C1 has one active client; C16 has two, or four in controls. "
            "This study tests gRPC, not REST."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--screen", action="store_true")
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float)
    parser.add_argument("--repeats", type=int)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    args.repeats = (
        args.repeats if args.repeats is not None else (4 if args.screen else 3)
    )
    args.repeat_seconds = (
        args.repeat_seconds
        if args.repeat_seconds is not None
        else (5 if args.screen else 20)
    )
    if (
        not args.screen
        and os.geteuid() != 0
        or args.repeats < 1
        or any(
            not math.isfinite(value) or value <= 0
            for value in (args.seconds, args.repeat_seconds)
        )
    ):
        parser.error(
            "Formal mode requires root; use positive repeats and finite "
            "positive durations"
        )
    args.without_cuda, args.concurrency = False, 16
    args.reference, args.bundle, args.store = (
        path.resolve() for path in (args.reference, args.bundle, args.store)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"inject-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"gRPC injection comparison output: {directory}", flush=True)
    try:
        reference = load_reference(args.reference)
        study.publish(directory / "REFERENCE.json", reference)
        if Path(reference["python"]).resolve() != Path(sys.executable).resolve():
            raise RuntimeError("Use the exact verified winner Python environment")
        prior = reference["prior_reference"]
        study.publish(
            directory / "ENVIRONMENT.json", transport.environment_inventory(prior)
        )
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if (
            manifest["onnx"]["sha256"] != prior["model_sha256"]
            or study.digest(args.bundle / "model/model.onnx") != prior["model_sha256"]
        ):
            raise RuntimeError("Injection comparison model differs from reference")
        tools = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", tools)
        if not args.screen and (
            not tools["perf"]["available"] or not tools["nsys"]["available"]
        ):
            raise RuntimeError("Formal mode requires working perf and Nsight Systems")
        study.freeze(directory)
        hashes = winner.production(
            json.loads((directory / "source-hashes.json").read_text())
        )
        if hashes != reference["production_hashes"]:
            raise RuntimeError("Production source differs from the verified winner")
        study.publish(
            directory / "SOURCE.json",
            {
                "source_snapshot": str(directory / "source"),
                "production_file_count": len(hashes),
                "reference_production_matched": True,
            },
        )
        study.publish(
            directory / "SCOPE.json",
            {
                "screening_only": args.screen,
                "resource_budget_verified": not args.screen,
                "profiles": [] if args.screen else ["cpu", "gil", "stages", "cuda"],
            },
        )
        result = execute(plan, reference)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
