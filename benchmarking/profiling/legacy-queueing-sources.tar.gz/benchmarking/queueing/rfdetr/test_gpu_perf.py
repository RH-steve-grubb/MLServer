"""Perf collector tests never attach, install probes, or start model workloads."""

from contextlib import contextmanager
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import gpu_perf

EVENTS = {
    "test:take_in_0": "take_in",
    "test:take_out_0": "take_out",
    "test:cond_in_0": "cond_in",
    "test:cond_out_0": "cond_out",
}
LOAD = {"requested_start_ns": 1_000_000_000, "drained_ns": 2_000_000_000}


def event(pid: int, role: str, time: str) -> str:
    return f" {pid}/{pid + 1} {time}: test:{role}_0:\n"


def acquisition(pid: int, contended: bool = False) -> str:
    lines = event(pid, "take_in", "1.100000000")
    if contended:
        lines += event(pid, "cond_in", "1.110000000")
        lines += event(pid, "cond_out", "1.120000000")
    return lines + event(pid, "take_out", "1.130000000")


class AnalysisTests(unittest.TestCase):
    def analyze(self, trace: str, warning: str = "") -> dict:
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            (directory / "events.txt").write_text(trace)
            (directory / "events.log").write_text(warning)
            (directory / "perf.log").write_text("")
            return gpu_perf._analyze(
                directory, EVENTS, [10, 20], gpu_perf._window(LOAD)
            )

    def test_processes_have_independent_gil_accounting(self) -> None:
        result = self.analyze(acquisition(10, True) + acquisition(20))
        self.assertTrue(result["valid"])
        first, second = result["processes"]
        self.assertEqual(first["pid"], 10)
        self.assertEqual(first["acquisition"]["count"], 1)
        self.assertEqual(first["acquisitions_with_condition_wait"], 1)
        self.assertEqual(first["condition_wait_thread_ms"], 10)
        self.assertEqual(second["pid"], 20)
        self.assertEqual(second["acquisitions_with_condition_wait"], 0)
        self.assertEqual(second["condition_wait_thread_ms"], 0)
        json.dumps(result, allow_nan=False)

    def test_lost_events_invalidate_all_processes(self) -> None:
        for trace, warning in (
            ("PERF_RECORD_LOST 3\n", ""),
            ("", "Warning: lost 3 events\n"),
        ):
            with self.subTest(warning=warning):
                result = self.analyze(
                    acquisition(10) + acquisition(20) + trace, warning
                )
                self.assertFalse(result["valid"])
                for process in result["processes"]:
                    self.assertIsNone(process["condition_wait_thread_ms"])
                    self.assertTrue(process["lost_events_reported"])

    def test_unpaired_and_incomplete_calls_are_unknown_wait_time(self) -> None:
        for broken in (
            event(10, "take_out", "1.400000000"),
            event(10, "take_in", "1.400000000"),
            event(10, "take_in", "1.400000000")
            + event(10, "cond_out", "1.410000000")
            + event(10, "take_out", "1.420000000"),
        ):
            with self.subTest(broken=broken):
                result = self.analyze(acquisition(10) + acquisition(20) + broken)
                self.assertFalse(result["valid"])
                first, second = result["processes"]
                self.assertIsNone(first["condition_wait_thread_ms"])
                self.assertTrue(second["valid"])

    def test_unobserved_process_is_invalid_instead_of_zero(self) -> None:
        result = self.analyze(acquisition(10))
        self.assertFalse(result["valid"])
        self.assertIsNone(result["processes"][1]["condition_wait_thread_ms"])
        self.assertIn(
            "no complete GIL acquisitions inside the window",
            result["processes"][1]["invalid_reasons"],
        )

    def test_bad_known_probe_format_is_invalid(self) -> None:
        result = self.analyze(
            acquisition(10) + acquisition(20) + "unparsed test:take_in_0:\n"
        )
        self.assertFalse(result["valid"])
        self.assertEqual(result["malformed_probe_lines"], 1)

    def test_events_outside_window_and_other_processes_are_not_attributed(self) -> None:
        result = self.analyze(
            event(10, "take_out", "0.900000000")
            + acquisition(10)
            + acquisition(20)
            + acquisition(30, True)
        )
        self.assertTrue(result["valid"])
        self.assertEqual(result["ignored_other_process_events"], 4)
        self.assertEqual(result["processes"][0]["acquisition"]["count"], 1)


class CollectionTests(unittest.TestCase):
    @contextmanager
    def recording(self, pids, directory, probes):
        self.assertEqual(pids, "10,20")
        (directory / "perf.log").write_text("perf recorded\n")
        yield

    def decode(self, command, output):
        if command[1] == "script":
            self.assertIn("pid,tid,time,event", command)
            output.write_text(acquisition(10, True) + acquisition(20))
        else:
            self.assertIn("comm,tgid,pid,dso,symbol", command)
            self.assertEqual(command[-1], "1.000000000,2.000000000")
            output.write_text("CPU report\n")
        output.with_suffix(".log").write_text("")
        return ""

    @mock.patch.object(gpu_perf.legacy, "Probes")
    @mock.patch.object(gpu_perf.legacy, "mapped_images")
    def test_one_recording_uses_unique_union_of_worker_images(
        self, images, probes
    ) -> None:
        python = Path("/python")
        libc = Path("/libc.so.6")
        images.side_effect = [[python, libc], [python, libc]]
        probes.return_value.events = EVENTS
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            with mock.patch.object(
                gpu_perf.legacy, "recording", side_effect=self.recording
            ) as recording, mock.patch.object(
                gpu_perf, "_run", side_effect=self.decode
            ):
                result = gpu_perf.collect([20, 10, 20], directory, "gil", lambda: LOAD)
            probes.assert_called_once_with(sorted([python, libc]))
            recording.assert_called_once_with("10,20", directory, probes.return_value)
            self.assertTrue(result["valid"])
            self.assertEqual(result["pids"], [10, 20])
            self.assertEqual(json.loads((directory / "load.json").read_text()), LOAD)
            self.assertEqual(len(result["processes"]), 2)

    def test_cpu_pass_has_window_and_process_thread_columns(self) -> None:
        aliases = {
            "measurement_started_ns": 1_000_000_000,
            "measurement_drained_ns": 2_000_000_000,
        }
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            with mock.patch.object(
                gpu_perf.legacy, "recording", side_effect=self.recording
            ), mock.patch.object(
                gpu_perf, "_run", side_effect=self.decode
            ), mock.patch.object(
                gpu_perf.legacy, "Probes"
            ) as probes:
                result = gpu_perf.collect([10, 20], directory, "cpu", lambda: aliases)
            probes.assert_not_called()
            self.assertTrue(result["valid"])
            self.assertEqual(result["cpu_report"], "cpu-report.txt")
            self.assertEqual(result["warnings"], "perf recorded")

    @mock.patch.object(gpu_perf.legacy, "Probes")
    @mock.patch.object(gpu_perf.legacy, "mapped_images", return_value=[])
    def test_invalid_trace_is_preserved_then_rejected(self, images, probes) -> None:
        probes.return_value.events = EVENTS

        def decode(command, output):
            output.write_text(acquisition(10))
            output.with_suffix(".log").write_text("")
            return ""

        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            with mock.patch.object(
                gpu_perf.legacy, "recording", side_effect=self.recording
            ), mock.patch.object(gpu_perf, "_run", side_effect=decode):
                with self.assertRaisesRegex(RuntimeError, "Invalid GIL trace"):
                    gpu_perf.collect([10, 20], directory, "gil", lambda: LOAD)
            analysis = json.loads((directory / "analysis.json").read_text())
            self.assertFalse(analysis["valid"])
            self.assertIsNone(analysis["processes"][1]["condition_wait_thread_ms"])

    def test_rejects_invalid_target_kind_window_and_existing_capture(self) -> None:
        for pids, kind in (([], "cpu"), ([0], "cpu"), ([True], "cpu"), ([1], "x")):
            with self.subTest(pids=pids, kind=kind):
                with self.assertRaises(ValueError):
                    gpu_perf.collect(pids, Path("/not-created"), kind, lambda: LOAD)
        for load in ({}, {"requested_start_ns": 2, "drained_ns": 1}):
            with self.assertRaises(ValueError):
                gpu_perf._window(load)
        with tempfile.TemporaryDirectory() as folder:
            directory = Path(folder)
            (directory / "perf.data").write_text("previous capture")
            with self.assertRaises(FileExistsError):
                gpu_perf.collect([10], directory, "cpu", lambda: LOAD)

    @mock.patch.object(gpu_perf.legacy, "python_info")
    @mock.patch.object(gpu_perf.legacy, "self_test")
    def test_control_reuses_legacy_self_test_without_replacing_globals(
        self, control, python_info
    ) -> None:
        with tempfile.TemporaryDirectory() as folder:
            python = Path("/python3.12")
            directory = Path(folder)
            environment = {"EXAMPLE": "value"}
            gpu_perf.self_test(python, directory, environment)
            python_info.assert_called_once_with(python)
            args, destination = control.call_args.args
            self.assertEqual(args.python, python)
            self.assertEqual(args.env, environment)
            self.assertEqual(destination, directory)


if __name__ == "__main__":
    unittest.main()
