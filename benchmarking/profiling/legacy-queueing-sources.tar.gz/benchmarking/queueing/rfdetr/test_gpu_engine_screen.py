"""CPU-only engine-screen tests; all sessions, device buffers and telemetry mocked."""

import json
from pathlib import Path
import signal
import subprocess
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

import numpy as np

import gpu_engine_screen as screen


class DeviceValue:
    def __init__(self, array, events):
        self.array = np.array(array, copy=True)
        self.events = events

    def update_inplace(self, tensor):
        self.events.append("upload")
        self.array[:] = tensor


class Binding:
    def __init__(self, events):
        self.events = events
        self.inputs, self.outputs = {}, {}

    def bind_ortvalue_input(self, name, value):
        self.inputs[name] = value

    def bind_ortvalue_output(self, name, value):
        self.outputs[name] = value

    def synchronize_inputs(self):
        self.events.append("sync-input")

    def synchronize_outputs(self):
        self.events.append("sync-output")

    def copy_outputs_to_cpu(self):
        self.events.append("download")
        return [value.array.copy() for value in self.outputs.values()]


class Session:
    def __init__(self, events):
        self.events = events
        self.binding = Binding(events)
        self.providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        self.options = {}
        self.fallback_disabled = False

    def get_inputs(self):
        return [SimpleNamespace(name="input", shape=[2], type="tensor(float)")]

    def get_outputs(self):
        return [
            SimpleNamespace(name=name, shape=[2], type="tensor(float)")
            for name in ("dets", "labels")
        ]

    def io_binding(self):
        return self.binding

    def run(self, names, feed):
        self.events.append("ordinary-run")
        return [feed["input"].copy() for _ in names]

    def run_with_iobinding(self, binding):
        self.events.append("bound-run")
        for value in binding.outputs.values():
            value.array[:] = binding.inputs["input"].array

    def disable_fallback(self):
        self.fallback_disabled = True

    def get_providers(self):
        return self.providers

    def get_provider_options(self):
        return {"CUDAExecutionProvider": self.options}

    def get_session_options(self):
        return self.session_options


class BindingTests(unittest.TestCase):
    def runner(self, variant="binding"):
        events, allocations = [], []

        def allocate(array, *args):
            value = DeviceValue(array, events)
            allocations.append(value)
            return value

        values = SimpleNamespace(
            ortvalue_from_numpy=allocate,
            ortvalue_from_shape_and_type=lambda shape, dtype, *args: allocate(
                np.zeros(shape, dtype=dtype)
            ),
        )
        patcher = mock.patch.object(screen.ort, "OrtValue", values)
        patcher.start()
        self.addCleanup(patcher.stop)
        runner = screen.Runner(
            Session(events), variant, np.array([1, 2], dtype=np.float32)
        )
        return runner, events, allocations

    def test_every_call_uploads_current_input_and_reuses_all_device_buffers(self):
        runner, events, allocations = self.runner("cuda-graph")
        original = np.array([1, 2], dtype=np.float32)
        first = runner(original)
        original[:] = [3, 4]
        second = runner(original)
        third = runner(original[::-1].copy())
        self.assertEqual(len(allocations), 3)
        self.assertEqual(
            events, ["upload", "sync-input", "bound-run", "sync-output", "download"] * 3
        )
        np.testing.assert_array_equal(first["dets"], [1, 2])
        np.testing.assert_array_equal(second["dets"], [3, 4])
        np.testing.assert_array_equal(third["dets"], [4, 3])

    def test_timing_brackets_upload_run_sync_and_output_download(self):
        runner, events, allocations = self.runner()
        clock = 0

        def tick():
            nonlocal clock
            clock += 100
            events.append("clock")
            return clock

        with mock.patch.object(
            screen.time, "perf_counter_ns", side_effect=tick
        ), mock.patch.object(
            screen.time, "process_time_ns", side_effect=[10, 20]
        ), mock.patch.object(
            screen.time, "monotonic_ns", side_effect=[1000, 2000]
        ):
            measured, last = screen.measure(
                runner, np.array([5, 6], dtype=np.float32), 5e-7
            )
        self.assertEqual(measured["calls"], 2)
        self.assertEqual(measured["measurement_started_ns"], 1000)
        self.assertEqual(measured["measurement_drained_ns"], 2000)
        self.assertEqual(events.count("upload"), 2)
        self.assertEqual(events.count("download"), 2)
        for index, event in enumerate(events):
            if event == "upload":
                self.assertEqual(events[index - 1], "clock")
            if event == "download":
                self.assertEqual(events[index + 1], "clock")
        np.testing.assert_array_equal(last["labels"], [5, 6])

    def test_graph_blocking_still_uses_persistent_binding_and_fresh_upload(self):
        runner, events, allocations = self.runner("cuda-graph-blocking")
        actual = runner(np.array([9, 8], np.float32))
        self.assertEqual(len(allocations), 3)
        self.assertEqual(
            events, ["upload", "sync-input", "bound-run", "sync-output", "download"]
        )
        np.testing.assert_array_equal(actual["dets"], [9, 8])

    @mock.patch.object(screen, "compare_detections")
    @mock.patch.object(screen, "decoded", side_effect=lambda value, size: value)
    def test_mirrored_input_catches_stale_graph_contents(self, decode, compare):
        tensors = {
            "original": np.array([1, 2], np.float32),
            "mirrored": np.array([2, 1], np.float32),
        }
        expected = {
            name: {key: tensor.copy() for key in ("dets", "labels")}
            for name, tensor in tensors.items()
        }
        stale = mock.Mock(return_value=expected["original"])
        with self.assertRaisesRegex(screen.IncorrectOutput, "Numerical mismatch"):
            screen.verify(stale, tensors, expected, [640, 480])
        self.assertEqual(stale.call_count, 2)
        fresh = mock.Mock(
            side_effect=lambda tensor: {
                key: tensor.copy() for key in ("dets", "labels")
            }
        )
        screen.verify(fresh, tensors, expected, [640, 480])
        self.assertEqual(fresh.call_count, 3)

    @mock.patch.object(screen, "compare_detections", side_effect=ValueError("bad box"))
    @mock.patch.object(screen, "decoded", side_effect=lambda value, size: value)
    def test_detection_failure_is_an_incorrect_output(self, decode, compare):
        arrays = {name: np.array([1, 2], np.float32) for name in ("dets", "labels")}
        with self.assertRaisesRegex(screen.IncorrectOutput, "Detection mismatch"):
            screen.verify(
                mock.Mock(return_value=arrays),
                {"original": object(), "mirrored": object()},
                {"original": arrays, "mirrored": arrays},
                [640, 480],
            )


class WarmupTests(unittest.TestCase):
    def test_warmup_requires_both_one_second_and_five_completed_calls(self):
        for call_ns, expected_calls in ((100_000_000, 10), (400_000_000, 5)):
            with self.subTest(call_ns=call_ns):
                clock = 0

                def run(tensor):
                    nonlocal clock
                    clock += call_ns

                with mock.patch.object(
                    screen.time, "perf_counter_ns", side_effect=lambda: clock
                ):
                    result = screen.warmup(run, np.zeros(2, np.float32))
                self.assertEqual(result["warmup_calls"], expected_calls)
                self.assertEqual(result["warmup_ns"], expected_calls * call_ns)


class ProviderTests(unittest.TestCase):
    def test_variants_keep_fp32_tf32_and_change_only_their_requested_option(self):
        for variant in screen.VARIANTS:
            with self.subTest(variant=variant):
                configured = SimpleNamespace()
                entries = {}
                configured.add_session_config_entry = mock.Mock(
                    side_effect=lambda key, value: entries.update({key: value})
                )
                configured.get_session_config_entry = mock.Mock(
                    side_effect=lambda key: entries[key]
                )
                loaded = Session([])

                def create(model, **kwargs):
                    loaded.options = kwargs["provider_options"][0]
                    loaded.session_options = kwargs["sess_options"]
                    self.assertEqual(kwargs["providers"], ["CUDAExecutionProvider"])
                    return loaded

                with mock.patch.object(
                    screen.ort, "SessionOptions", return_value=configured
                ), mock.patch.object(
                    screen.ort, "InferenceSession", side_effect=create
                ), mock.patch.object(
                    screen,
                    "blocking_sync",
                    return_value=(object(), {"requested_flags": 4}),
                ) as blocking, mock.patch.object(
                    screen, "device_flags", return_value=12
                ) as flags:
                    result, information = screen.session(Path("model.onnx"), variant)
                self.assertIs(result, loaded)
                self.assertTrue(loaded.fallback_disabled)
                self.assertEqual(loaded.options["use_tf32"], "1")
                self.assertEqual(
                    loaded.options["enable_cuda_graph"],
                    "1" if screen.base_variant(variant) == "cuda-graph" else "0",
                )
                self.assertEqual(
                    loaded.options["prefer_nhwc"], "1" if variant == "nhwc" else "0"
                )
                self.assertEqual(
                    blocking.call_count, int(variant.endswith("-blocking"))
                )
                self.assertEqual(flags.call_count, int(variant.endswith("-blocking")))
                if variant.endswith("-blocking"):
                    self.assertEqual(
                        information["cuda_scheduling"]["after_session_flags"], 12
                    )
                else:
                    self.assertEqual(
                        information["cuda_scheduling"], {"policy": "unchanged"}
                    )
                self.assertEqual(
                    (configured.intra_op_num_threads, configured.inter_op_num_threads),
                    (2, 1),
                )
                configured.add_session_config_entry.assert_any_call(
                    "session.disable_cpu_ep_fallback", "1"
                )
                self.assertEqual(
                    information["session_options"]["config_entries"], entries
                )
                self.assertEqual(configured.get_session_config_entry.call_count, 3)

    def test_readback_rejects_an_unhonored_fallback_config(self):
        loaded = Session([])

        def create(model, **kwargs):
            loaded.options = kwargs["provider_options"][0]
            loaded.session_options = SimpleNamespace(
                get_session_config_entry=lambda key: "0"
            )
            return loaded

        with mock.patch.object(screen.ort, "InferenceSession", side_effect=create):
            with self.assertRaisesRegex(screen.UnsupportedVariant, "not honored"):
                screen.session(Path("model.onnx"), "run")


class CudaSchedulingTests(unittest.TestCase):
    def library(self, path, events):
        runtime = SimpleNamespace(
            cudaSetDeviceFlags=mock.Mock(
                side_effect=lambda flags: events.append("set") or 0
            ),
            cudaGetErrorString=mock.Mock(return_value=b"invalid flags"),
        )

        def get_flags(pointer):
            events.append("get")
            pointer._obj.value = 12
            return 0

        runtime.cudaGetDeviceFlags = mock.Mock(side_effect=get_flags)
        distribution = SimpleNamespace(
            version="12.9.79", locate_file=mock.Mock(return_value=path)
        )
        patches = (
            mock.patch.object(
                screen.metadata, "distribution", return_value=distribution
            ),
            mock.patch.object(screen.ctypes, "CDLL", return_value=runtime),
        )
        for patcher in patches:
            patcher.start()
            self.addCleanup(patcher.stop)
        return runtime

    def test_set_and_readback_precede_ort_and_session_readback_follows(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "libcudart.so.12"
            path.write_bytes(b"mock-only")
            events = []
            runtime = self.library(path, events)
            configured = screen.ort.SessionOptions()
            loaded = Session([])

            def create(model, **kwargs):
                events.append("session")
                loaded.options = kwargs["provider_options"][0]
                loaded.session_options = kwargs["sess_options"]
                return loaded

            with mock.patch.object(
                screen.ort, "SessionOptions", return_value=configured
            ), mock.patch.object(screen.ort, "InferenceSession", side_effect=create):
                _, information = screen.session(
                    Path("model.onnx"), "cuda-graph-blocking"
                )
            self.assertEqual(events, ["set", "get", "session", "get"])
            runtime.cudaSetDeviceFlags.assert_called_once_with(4)
            receipt = information["cuda_scheduling"]
            self.assertEqual(receipt["library"], str(path.resolve()))
            self.assertEqual(receipt["wheel_version"], "12.9.79")
            self.assertEqual(receipt["before_session_flags"], 12)
            self.assertEqual(receipt["after_session_flags"], 12)
            json.dumps(receipt)

    def test_cuda_error_and_missing_blocking_bit_are_not_silent_success(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "libcudart.so.12"
            path.write_bytes(b"mock-only")
            runtime = self.library(path, [])
            runtime.cudaSetDeviceFlags.side_effect = None
            runtime.cudaSetDeviceFlags.return_value = 1
            with self.assertRaisesRegex(
                screen.UnsupportedVariant, "CUDA 1: invalid flags"
            ):
                screen.configure_blocking_sync()
            runtime.cudaGetDeviceFlags.assert_not_called()
            runtime.cudaSetDeviceFlags.return_value = 0
            runtime.cudaGetDeviceFlags.side_effect = None
            runtime.cudaGetDeviceFlags.return_value = 0
            with self.assertRaisesRegex(screen.UnsupportedVariant, "not honored"):
                screen.configure_blocking_sync()
            runtime.cudaGetDeviceFlags.return_value = 1
            with self.assertRaisesRegex(
                screen.UnsupportedVariant, "cudaGetDeviceFlags failed"
            ):
                screen.configure_blocking_sync()

    def test_public_postload_readback_does_not_reset_policy(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "libcudart.so.12"
            path.write_bytes(b"mock-only")
            runtime = self.library(path, [])
            receipt = screen.configure_blocking_sync()
            self.assertEqual(screen.cuda_flags(receipt["library"]), 12)
            runtime.cudaSetDeviceFlags.assert_called_once_with(4)
            self.assertEqual(runtime.cudaGetDeviceFlags.call_count, 2)
            json.dumps(receipt)

    @mock.patch.object(
        screen, "blocking_sync", side_effect=screen.UnsupportedVariant("flag setup")
    )
    @mock.patch.object(screen.ort, "InferenceSession")
    def test_configuration_failure_prevents_any_ort_session(self, inference, blocking):
        with self.assertRaisesRegex(screen.UnsupportedVariant, "flag setup"):
            screen.session(Path("model.onnx"), "run-blocking")
        inference.assert_not_called()


class FailureTests(unittest.TestCase):
    def spec(self, folder):
        bundle = Path(folder) / "bundle"
        (bundle / "model").mkdir(parents=True)
        (bundle / "sample").mkdir()
        (bundle / "model/model.onnx").write_bytes(b"model-placeholder")
        np.save(
            bundle / "sample/input.npy",
            np.arange(3 * 512 * 512, dtype=np.float32).reshape(1, 3, 512, 512),
        )
        (bundle / "manifest.json").write_text(
            json.dumps(
                {
                    "sample": {"image_size_wh": [640, 480]},
                    "onnx": {
                        "outputs": [
                            {"name": key, "shape": [2]} for key in ("dets", "labels")
                        ]
                    },
                }
            )
        )
        (bundle / "reference").mkdir()
        (bundle / "reference/pytorch-detections.json").write_text("{}")
        output = Path(folder) / "case"
        output.mkdir()
        return {
            "variant": "cuda-graph",
            "output": str(output),
            "bundle": str(bundle),
            "model_sha256": screen.checksum(bundle / "model/model.onnx"),
            "input_sha256": screen.checksum(bundle / "sample/input.npy"),
            "seconds": 0.01,
        }

    @mock.patch.object(
        screen, "session", side_effect=screen.UnsupportedVariant("option unavailable")
    )
    def test_unsupported_session_is_preserved_without_performance_numbers(
        self, session
    ):
        with tempfile.TemporaryDirectory() as folder:
            spec = self.spec(folder)
            result = screen.run_case(spec)
            self.assertEqual(result["status"], "unsupported")
            self.assertEqual(result["phase"], "session")
            self.assertTrue(result["capability_check_failed"])
            self.assertNotIn("model_calls_per_second", result)
            saved = json.loads((Path(spec["output"]) / "result.json").read_text())
            self.assertIn("option unavailable", saved["error"])

    @mock.patch.object(screen, "session", return_value=(object(), {}))
    @mock.patch.object(screen, "Runner")
    def test_failed_first_capture_keeps_stage_and_error(self, runner, session):
        runner.return_value.side_effect = RuntimeError(
            "CUDA stream capture unsupported"
        )
        with tempfile.TemporaryDirectory() as folder:
            result = screen.run_case(self.spec(folder))
        self.assertEqual(result["phase"], "first_run_or_capture")
        self.assertTrue(result["capability_check_failed"])
        self.assertIn("capture unsupported", result["error"])

    @mock.patch.object(screen.os, "killpg")
    @mock.patch.object(screen.subprocess, "Popen")
    def test_crashed_subprocess_is_recorded_and_owned_group_is_cleaned(
        self, popen, kill
    ):
        process = mock.Mock(pid=12345, returncode=-11)
        popen.return_value = process
        with tempfile.TemporaryDirectory() as folder:
            spec = {"variant": "cuda-graph", "output": str(Path(folder) / "crash")}
            result = screen.launch(spec, Path("frozen.py"), {})
        self.assertEqual(result["status"], "crashed")
        self.assertEqual(result["returncode"], -11)
        self.assertNotIn("model_calls_per_second", result)
        self.assertTrue(popen.call_args.kwargs["start_new_session"])
        kill.assert_called_once_with(12345, signal.SIGKILL)
        self.assertEqual(
            process.wait.call_args_list, [mock.call(timeout=300), mock.call(timeout=10)]
        )

    @mock.patch.object(screen.os, "killpg")
    @mock.patch.object(screen.subprocess, "Popen")
    def test_timeout_kills_and_reaps_only_its_owned_group(self, popen, kill):
        process = mock.Mock(pid=12345, returncode=-9)
        process.wait.side_effect = [subprocess.TimeoutExpired("case", 300), -9]
        popen.return_value = process
        with tempfile.TemporaryDirectory() as folder:
            spec = {"variant": "cuda-graph", "output": str(Path(folder) / "timeout")}
            result = screen.launch(spec, Path("frozen.py"), {})
        self.assertEqual(result["status"], "timeout")
        self.assertNotIn("model_calls_per_second", result)
        kill.assert_called_once_with(12345, signal.SIGKILL)
        self.assertEqual(process.wait.call_count, 2)

    @mock.patch.object(screen.os, "killpg", side_effect=ProcessLookupError)
    @mock.patch.object(screen.subprocess, "Popen")
    def test_exited_worker_is_cleaned_even_with_result_and_crash_cannot_win(
        self, popen, kill
    ):
        for returncode in (0, -11):
            with self.subTest(
                returncode=returncode
            ), tempfile.TemporaryDirectory() as folder:

                def create(*args, **kwargs):
                    screen.study.publish(
                        Path(kwargs["cwd"]) / "result.json",
                        {
                            "variant": "binding",
                            "status": "ok",
                            "model_calls_per_second": 200,
                        },
                    )
                    return mock.Mock(pid=12345, returncode=returncode)

                popen.side_effect = create
                spec = {"variant": "binding", "output": str(Path(folder) / "done")}
                result = screen.launch(spec, Path("frozen.py"), {})
                self.assertEqual(result["status"], "ok" if not returncode else "failed")
                if returncode:
                    self.assertNotIn("model_calls_per_second", result)
                    self.assertEqual(
                        result["partial_result"]["model_calls_per_second"], 200
                    )
        self.assertEqual(kill.call_args_list, [mock.call(12345, signal.SIGKILL)] * 2)

    @mock.patch.object(screen, "session", return_value=(object(), {}))
    @mock.patch.object(screen, "Runner")
    def test_oracle_rejects_invalid_dtype_shape_or_nonfinite_arrays(
        self, runner, session
    ):
        good = {key: np.array([1, 2], np.float32) for key in ("dets", "labels")}
        invalid = (
            np.array([1, np.nan], np.float32),
            np.ones(2, np.float64),
            np.ones(3, np.float32),
        )
        for target in ("original", "mirrored"):
            for array in invalid:
                with self.subTest(target=target, dtype=array.dtype, shape=array.shape):
                    with tempfile.TemporaryDirectory() as folder:
                        spec = {**self.spec(folder), "oracle": True}
                        bad = {**good, "labels": array}
                        runner.return_value.side_effect = (
                            [bad, good] if target == "original" else [good, bad]
                        )
                        result = screen.run_case(spec)
                        self.assertEqual(result["status"], "incorrect")
                        self.assertFalse(
                            (Path(spec["output"]) / "original.npz").exists()
                        )
                        self.assertTrue(
                            (Path(spec["output"]) / "first-original.npz").exists()
                        )

    @mock.patch.object(screen, "session", return_value=(object(), {}))
    @mock.patch.object(screen, "Runner")
    def test_oracle_fixture_detection_failure_is_incorrect(self, runner, session):
        runner.return_value.side_effect = [
            {key: np.array([1, 2], np.float32) for key in ("dets", "labels")},
            {key: np.array([2, 1], np.float32) for key in ("dets", "labels")},
        ]
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(
            screen, "decoded", return_value={}
        ), mock.patch.object(
            screen, "compare_detections", side_effect=ValueError("fixture mismatch")
        ):
            result = screen.run_case({**self.spec(folder), "oracle": True})
        self.assertEqual(result["status"], "incorrect")
        self.assertIn("fixture mismatch", result["error"])

    @mock.patch.object(screen, "session", return_value=(object(), {}))
    @mock.patch.object(screen, "Runner")
    @mock.patch.object(screen, "measure")
    def test_semantic_match_keeps_raw_failure_and_preserves_both_actual_arrays(
        self, measure, runner, session
    ):
        actual = {key: np.array([3, 4], np.float32) for key in ("dets", "labels")}
        runner.return_value.return_value = actual
        with tempfile.TemporaryDirectory() as folder, mock.patch.object(
            screen, "decoded", return_value={}
        ), mock.patch.object(screen, "compare_detections"):
            spec = {**self.spec(folder), "variant": "nhwc"}
            reference = Path(folder) / "oracle"
            reference.mkdir()
            for name in ("original", "mirrored"):
                np.savez(
                    reference / f"{name}.npz",
                    **{key: np.array([1, 2], np.float32) for key in ("dets", "labels")},
                )
            spec["reference"] = str(reference)
            result = screen.run_case(spec)
            self.assertEqual(result["status"], "incorrect")
            self.assertIn("Numerical mismatch", result["error"])
            self.assertEqual(
                result["semantic_detection_parity"],
                {
                    "original": {"passed": True},
                    "mirrored": {"passed": True},
                },
            )
            for name in ("original", "mirrored"):
                with np.load(Path(spec["output"]) / f"first-{name}.npz") as saved:
                    np.testing.assert_array_equal(saved["dets"], actual["dets"])
            self.assertNotIn("model_calls_per_second", result)
        measure.assert_not_called()


class ControllerTests(unittest.TestCase):
    @mock.patch.object(screen, "launch")
    @mock.patch.object(screen.study, "freeze")
    @mock.patch.object(
        screen.gpu_tools,
        "gpu_snapshot",
        return_value={"gpus": [{"uuid": "GPU-fixed"}], "compute_processes": []},
    )
    def test_rotated_isolated_variants_use_frozen_code_and_continue_after_unsupported(
        self, snapshot, freeze, launch
    ):
        launch.side_effect = lambda spec, script, environment: {
            "variant": spec["variant"],
            "status": "unsupported" if spec["variant"] == "nhwc" else "ok",
        }
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "sample").mkdir()
            (root / "sample/input.npy").write_bytes(b"fixture")
            (root / "manifest.json").write_text('{"onnx":{"sha256":"fixed-model"}}')
            arguments = ["screen", "--bundle", folder, "--store", folder]
            with mock.patch.object(screen.sys, "argv", arguments):
                screen.main()
            self.assertEqual(launch.call_count, 13)
            freeze.assert_called_once()
            calls = launch.call_args_list
            self.assertTrue(calls[0].args[0]["oracle"])
            self.assertEqual(
                [call.args[0]["variant"] for call in calls[1:5]],
                list(screen.DEFAULT_VARIANTS),
            )
            self.assertEqual(
                [call.args[0]["variant"] for call in calls[5:9]],
                ["binding", "cuda-graph", "nhwc", "run"],
            )
            self.assertIn(
                "/source/benchmarking/queueing/rfdetr/gpu_engine_screen.py",
                str(calls[1].args[1]),
            )
            self.assertEqual(calls[1].args[2]["CUDA_VISIBLE_DEVICES"], "GPU-fixed")
            output = next(root.glob("screen-*"))
            saved = json.loads((output / "SUMMARY.json").read_text())
            self.assertEqual(len(saved["results"]), 12)
            self.assertEqual(
                sum(row["status"] == "unsupported" for row in saved["results"]), 3
            )

    @mock.patch.object(screen, "launch")
    @mock.patch.object(screen.study, "freeze")
    @mock.patch.object(
        screen.gpu_tools,
        "gpu_snapshot",
        return_value={"gpus": [{"uuid": "GPU-fixed"}], "compute_processes": []},
    )
    def test_explicit_factorial_variants_are_rotated_and_frozen_in_plan(
        self, snapshot, freeze, launch
    ):
        launch.side_effect = lambda spec, script, environment: {
            "variant": spec["variant"],
            "status": "ok",
        }
        selected = ["run", "cuda-graph", "run-blocking", "cuda-graph-blocking"]
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "sample").mkdir()
            (root / "sample/input.npy").write_bytes(b"fixture")
            (root / "manifest.json").write_text('{"onnx":{"sha256":"fixed-model"}}')
            arguments = [
                "screen",
                "--bundle",
                folder,
                "--store",
                folder,
                "--repeats",
                "4",
                "--variants",
                *selected,
            ]
            with mock.patch.object(screen.sys, "argv", arguments):
                screen.main()
            self.assertEqual(launch.call_count, 17)
            for repeat in range(4):
                calls = launch.call_args_list[1 + repeat * 4 : 5 + repeat * 4]
                self.assertEqual(
                    [call.args[0]["variant"] for call in calls],
                    selected[repeat:] + selected[:repeat],
                )
            plan = json.loads((next(root.glob("screen-*")) / "PLAN.json").read_text())
            self.assertEqual(plan["variants"], selected)
            freeze.assert_called_once()

    @mock.patch.object(screen, "launch")
    def test_unknown_or_duplicate_cli_variants_are_rejected(self, launch):
        for selected in (["unsupported"], ["run", "run"]):
            with self.subTest(selected=selected), mock.patch.object(
                screen.sys, "argv", ["screen", "--variants", *selected]
            ), mock.patch.object(screen.sys, "stderr"):
                with self.assertRaises(SystemExit) as error:
                    screen.main()
                self.assertEqual(error.exception.code, 2)
        launch.assert_not_called()


if __name__ == "__main__":
    unittest.main()
