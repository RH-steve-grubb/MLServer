"""GPU helper tests use mocked tools; no GPU workload or settings changes."""

import json
from pathlib import Path
import subprocess
import tempfile
import threading
from typing import Any
import unittest
from unittest import mock

import gpu_tools

GPU_CSV = "0, GPU-123, NVIDIA GeForce RTX 4070, 12282, 512, 63, 50, 120.5, 2520\n"
PROCESS_CSV = 'GPU-123, 1234, "/opt/study,python", 321\n'


def completed(output: str, returncode: int = 0) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess([], returncode, stdout=output, stderr="")


class CapabilitiesTests(unittest.TestCase):
    def versions(
        self, command: list[str], **kwargs: Any
    ) -> subprocess.CompletedProcess[str]:
        name = Path(command[0]).name
        versions = {
            "perf": "perf version 7.2.11\n",
            "nsys": "NVIDIA Nsight Systems version 2026.1.3.425\n",
            "ncu": (
                "NVIDIA (R) Nsight Compute Command Line Profiler\n"
                "Version 2026.2.1.5\n"
            ),
            "nvidia-smi": "NVIDIA-SMI version  : 615.71.10\n",
        }
        self.assertEqual(command[1:], ["--version"])
        return completed(versions[name])

    @mock.patch.object(
        gpu_tools.shutil, "which", side_effect=lambda name: f"/usr/bin/{name}"
    )
    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_real_versions_are_available(self, run, which) -> None:
        run.side_effect = self.versions
        result = gpu_tools.capabilities()
        self.assertTrue(result["perf"]["available"])
        self.assertTrue(result["nsys"]["available"])
        self.assertTrue(result["ncu"]["available"])
        self.assertEqual(result["nsys"]["version"], "2026.1.3.425")
        self.assertIsNone(result["nsight_repair_recommendation"])
        self.assertFalse(result["nsight_capture_options_verified"])
        json.dumps(result, allow_nan=False)

    @mock.patch.object(gpu_tools.shutil, "which", return_value=None)
    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_missing_profiler_payload_is_not_usable(self, run, which) -> None:
        def version(command, **kwargs):
            if Path(command[0]).name == "nsys":
                return completed(
                    "Error: Nsight Systems 2026.1.3 hasn't been installed", 1
                )
            return self.versions(command, **kwargs)

        run.side_effect = version
        result = gpu_tools.capabilities()
        self.assertFalse(result["cuda_timeline_available"])
        self.assertEqual(result["nsys"]["path"], "/usr/local/sbin/nsys")
        self.assertIn(
            "/usr/local/cuda-13.3/bin/nsys",
            [attempt["path"] for attempt in result["nsys"]["attempts"]],
        )
        self.assertEqual(result["nsys"]["attempts"][0]["returncode"], 1)
        self.assertIn("dnf --assumeno", result["nsight_repair_recommendation"])

    @mock.patch.object(gpu_tools.shutil, "which", return_value="/bad/nsys")
    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_working_fallback_can_replace_broken_path_entry(self, run, which) -> None:
        run.side_effect = [
            completed("missing payload", 1),
            completed("Nsight Systems version 2026.1.3"),
        ]
        result = gpu_tools._tool("nsys", ("/usr/local/cuda-13.3/bin/nsys",))
        self.assertTrue(result["available"])
        self.assertEqual(result["path"], "/usr/local/cuda-13.3/bin/nsys")
        self.assertEqual(len(result["attempts"]), 2)

    @mock.patch.object(gpu_tools.shutil, "which", return_value=None)
    @mock.patch.object(
        gpu_tools.subprocess, "run", side_effect=FileNotFoundError("missing")
    )
    def test_missing_executables_are_json_serializable(self, run, which) -> None:
        result = gpu_tools.capabilities()
        self.assertFalse(result["nsys"]["available"])
        self.assertIn("error", result["nsys"]["attempts"][0])
        json.dumps(result, allow_nan=False)


class SnapshotTests(unittest.TestCase):
    @mock.patch.object(gpu_tools.shutil, "which", return_value="/usr/bin/nvidia-smi")
    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_gpu_and_compute_client_csv(self, run, which) -> None:
        run.side_effect = [completed(GPU_CSV), completed(PROCESS_CSV)]
        result = gpu_tools.gpu_snapshot()
        gpu = result["gpus"][0]
        self.assertEqual(gpu["index"], 0)
        self.assertEqual(gpu["memory_total_mib"], 12282)
        self.assertEqual(gpu["power_draw_w"], 120.5)
        self.assertEqual(
            result["compute_processes"][0]["process_name"], "/opt/study,python"
        )
        self.assertGreater(result["monotonic_ns"], 0)
        self.assertGreaterEqual(result["collection_duration_ns"], 0)
        self.assertIn("clocks.current.sm", run.call_args_list[0].args[0][1])
        self.assertIn("--query-compute-apps=", run.call_args_list[1].args[0][1])
        json.dumps(result, allow_nan=False)

    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_unavailable_optional_numbers_and_no_clients(self, run) -> None:
        row = GPU_CSV.replace("120.5, 2520", "[Not Supported], N/A")
        run.side_effect = [completed(row), completed("")]
        result = gpu_tools.gpu_snapshot()
        self.assertIsNone(result["gpus"][0]["power_draw_w"])
        self.assertIsNone(result["gpus"][0]["sm_clock_mhz"])
        self.assertEqual(result["compute_processes"], [])

    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_invalid_csv_is_actionable(self, run) -> None:
        for output in ("0, GPU-123\n", GPU_CSV.replace("12282", "unknown")):
            with self.subTest(output=output):
                run.side_effect = [completed(output), completed("")]
                with self.assertRaisesRegex(RuntimeError, "nvidia-smi"):
                    gpu_tools.gpu_snapshot()

    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_driver_error_is_actionable(self, run) -> None:
        run.return_value = completed("couldn't communicate with NVIDIA driver", 9)
        with self.assertRaisesRegex(RuntimeError, "Verify GPU/driver access"):
            gpu_tools.gpu_snapshot()

    @mock.patch.object(gpu_tools.subprocess, "run")
    def test_no_gpus_is_not_a_successful_snapshot(self, run) -> None:
        run.return_value = completed("")
        with self.assertRaisesRegex(RuntimeError, "returned no GPUs"):
            gpu_tools.gpu_snapshot()


class SamplingTests(unittest.TestCase):
    def snapshot(self) -> dict:
        return {"monotonic_ns": 123, "gpus": [], "compute_processes": []}

    @mock.patch.object(gpu_tools, "gpu_snapshot")
    def test_context_stops_owned_thread_and_writes_jsonl(self, snapshot) -> None:
        sampled = threading.Event()
        owned = []
        real_thread = threading.Thread

        def make_thread(**kwargs):
            thread = real_thread(**kwargs)
            owned.append(thread)
            return thread

        def read():
            if threading.current_thread() is not threading.main_thread():
                sampled.set()
            return self.snapshot()

        snapshot.side_effect = read
        with tempfile.TemporaryDirectory() as folder:
            with mock.patch.object(
                gpu_tools.threading, "Thread", side_effect=make_thread
            ):
                with gpu_tools.sampling(Path(folder), interval=0.001) as path:
                    self.assertTrue(sampled.wait(timeout=1))
                    self.assertTrue(owned[0].is_alive())
                self.assertFalse(owned[0].is_alive())
            records = [json.loads(line) for line in path.read_text().splitlines()]
            self.assertGreaterEqual(len(records), 2)
            self.assertEqual(records[0]["monotonic_ns"], 123)

    @mock.patch.object(gpu_tools, "gpu_snapshot")
    def test_workload_exception_is_preserved_and_data_written(self, snapshot) -> None:
        snapshot.return_value = self.snapshot()
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(ValueError, "workload failure"):
                with gpu_tools.sampling(Path(folder)) as path:
                    raise ValueError("workload failure")
            self.assertEqual(len(path.read_text().splitlines()), 1)

    @mock.patch.object(gpu_tools, "gpu_snapshot")
    def test_sampling_failure_is_recorded_and_reported(self, snapshot) -> None:
        failed = threading.Event()

        def read():
            if threading.current_thread() is threading.main_thread():
                return self.snapshot()
            failed.set()
            raise RuntimeError("driver became unavailable")

        snapshot.side_effect = read
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(RuntimeError, "GPU telemetry failed"):
                with gpu_tools.sampling(Path(folder), interval=0.001) as path:
                    self.assertTrue(failed.wait(timeout=1))
            records = [json.loads(line) for line in path.read_text().splitlines()]
            self.assertIn("driver became unavailable", records[-1]["error"])

    @mock.patch.object(gpu_tools, "gpu_snapshot")
    def test_existing_capture_is_not_overwritten(self, snapshot) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "gpu-telemetry.jsonl"
            path.write_text("existing capture\n")
            with self.assertRaises(FileExistsError):
                with gpu_tools.sampling(Path(folder)):
                    self.fail("existing output should be refused")
            self.assertEqual(path.read_text(), "existing capture\n")
            snapshot.assert_not_called()

    def test_invalid_interval_is_rejected(self) -> None:
        for interval in (0, -1, float("nan"), float("inf")):
            with self.subTest(interval=interval):
                with self.assertRaises(ValueError):
                    with gpu_tools.sampling(Path("/not-created"), interval=interval):
                        self.fail("invalid interval must fail before creating output")


if __name__ == "__main__":
    unittest.main()
