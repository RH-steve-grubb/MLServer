"""Mocked transport-plan tests never create sockets or run model workloads."""

import argparse
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import tempfile
import unittest
from unittest import mock

import gpu_transport_compare as driver


def reference() -> dict:
    return {
        "summary": "/reference/SUMMARY.json",
        "python": "/old/bin/python",
        "python_version": "3.12.13",
        "worker_versions": {"onnxruntime-gpu": "1.23.2"},
        "model_sha256": "same-model",
        "fixed": {
            "rest": {"workers": 8, "threads": 2},
            "grpc": {"workers": 2, "threads": 2},
        },
    }


def plan(directory: Path) -> driver.baseline.Plan:
    args = argparse.Namespace(
        bundle=directory,
        user="codex",
        seconds=10.0,
        repeat_seconds=20.0,
        repeats=3,
        concurrency=16,
        without_cuda=False,
    )
    return driver.baseline.Plan(args, directory, Path("/new/bin/python"))


def values(options: list[str]) -> dict[str, str]:
    return dict(zip(options[::2], options[1::2]))


class OrchestrationTests(unittest.TestCase):
    def child(self, label, options):
        configured = values(options)
        rows = []
        if configured["--phase"] == "smoke":
            row = {
                key: configured[f"--{key}"]
                for key in ("protocol", "adapter", "transport")
            }
            row.update(
                {
                    key: int(configured[f"--{key}"])
                    for key in ("workers", "threads", "concurrency")
                }
            )
            row.update(
                profiled=False,
                rps=100.0,
                clients=[{"client_cpu_seconds": 0.1, "duration_seconds": 1.0}],
            )
            rows.append(row)
        return {"results": rows}, Path("/output") / label / "SUMMARY.json"

    def test_matched_selectors_abba_controls_and_all_profiles(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            current = plan(Path(folder))
            with mock.patch.object(current, "run", side_effect=self.child) as run:
                result = driver.execute(current, reference())
            self.assertEqual(run.call_count, 47)
            calls = run.call_args_list
            self.assertEqual(
                [call.args[0] for call in calls[:3]],
                [
                    "qualification-zmq-stages",
                    "qualification-zmq-cuda",
                    "qualification-zmq-gil",
                ],
            )
            self.assertEqual(
                [call.args[0] for call in calls[3:9]],
                [
                    "rest-c1-r0-queue",
                    "rest-c1-r0-zmq",
                    "rest-c1-r1-zmq",
                    "rest-c1-r1-queue",
                    "rest-c1-r2-queue",
                    "rest-c1-r2-zmq",
                ],
            )
            self.assertEqual(len(result["repeats"]), 24)
            for call in calls:
                configured = values(call.args[1])
                self.assertEqual(configured["--adapter"], "compact")
                self.assertIn(configured["--transport"], ("queue", "zmq"))
                if call.args[0].startswith("qualification"):
                    self.assertEqual(
                        (
                            configured["--protocol"],
                            configured["--workers"],
                            configured["--threads"],
                        ),
                        ("both", "1", "1"),
                    )
                    self.assertEqual(
                        (
                            configured["--concurrency"],
                            configured["--requests"],
                            configured["--seconds"],
                        ),
                        ("2", "4", "1"),
                    )
                else:
                    expected = reference()["fixed"][configured["--protocol"]]
                    self.assertEqual(int(configured["--workers"]), expected["workers"])
                    self.assertEqual(int(configured["--threads"]), expected["threads"])
                    if configured["--phase"] == "smoke":
                        self.assertEqual(configured["--seconds"], "20.0")
                    if "client-control" in call.args[0]:
                        self.assertEqual(
                            (configured["--clients"], configured["--concurrency"]),
                            ("4", "16"),
                        )
            for protocol in ("rest", "grpc"):
                for transport in ("queue", "zmq"):
                    self.assertEqual(
                        set(result["captures"][protocol][transport]),
                        {"cpu", "gil", "stages", "cuda"},
                    )
            self.assertNotIn("winners", result)
            self.assertEqual(
                len(json.loads((current.directory / "REPEATS.json").read_text())), 24
            )
            self.assertTrue((current.directory / "CLIENT_CONTROLS.json").exists())
            self.assertTrue((current.directory / "CAPTURES.json").exists())

    def test_failure_preserves_completed_repeats_and_propagates(self) -> None:
        def child(label, options):
            if label == "rest-c1-r0-zmq":
                raise RuntimeError("child failed")
            return self.child(label, options)

        with tempfile.TemporaryDirectory() as folder:
            current = plan(Path(folder))
            with mock.patch.object(current, "run", side_effect=child):
                with self.assertRaisesRegex(RuntimeError, "child failed"):
                    driver.execute(current, reference())
            rows = json.loads((current.directory / "REPEATS.json").read_text())
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["transport"], "queue")

    def test_client_control_flags_cpu_or_gain_without_selecting_transport(self) -> None:
        configuration = {
            "protocol": "grpc",
            "transport": "zmq",
            "workers": 2,
            "threads": 2,
        }
        repeated = [{"concurrency": 16, "result": {**configuration, "rps": 100.0}}] * 3
        for gain, cpu in ((106.0, 0.1), (100.0, 0.81)):
            with tempfile.TemporaryDirectory() as folder:
                current = plan(Path(folder))
                row = {
                    **configuration,
                    "adapter": "compact",
                    "profiled": False,
                    "concurrency": 16,
                    "rps": gain,
                    "clients": [{"client_cpu_seconds": cpu, "duration_seconds": 1.0}],
                }
                with mock.patch.object(
                    current, "run", return_value=({"results": [row]}, Path("/control"))
                ):
                    result = driver.client_control(current, configuration, repeated)
                self.assertTrue(result["needs_confirmation"])

    def test_wrong_transport_result_is_rejected(self) -> None:
        configuration = {
            "protocol": "rest",
            "transport": "queue",
            "workers": 8,
            "threads": 2,
        }
        row = {
            **configuration,
            "transport": "zmq",
            "adapter": "compact",
            "concurrency": 16,
            "rps": 1.0,
            "profiled": False,
        }
        with self.assertRaisesRegex(RuntimeError, "configuration"):
            driver.measured({"results": [row]}, configuration, 16)


class EnvironmentTests(unittest.TestCase):
    @mock.patch.object(driver.sysconfig, "get_config_var", return_value=0)
    @mock.patch.object(driver.importlib, "import_module")
    @mock.patch.object(driver.metadata, "distributions")
    @mock.patch.object(driver.metadata, "version")
    def test_new_interpreter_is_accepted_with_identical_common_versions(
        self, version, distributions, module, config
    ) -> None:
        version.side_effect = lambda name: {
            "onnxruntime-gpu": "1.23.2",
            "pyzmq": "27.2.0",
        }[name]
        original = SimpleNamespace(
            metadata={"Name": "onnxruntime-gpu"}, version="1.23.2"
        )
        extra = SimpleNamespace(metadata={"Name": "pyzmq"}, version="27.2.0")
        distributions.side_effect = [[original], [original, extra]]
        module.return_value.zmq_version.return_value = "4.3.5"
        with mock.patch.object(sys, "version_info", (3, 12)), mock.patch.object(
            sys, "version", "3.12.13 test"
        ), mock.patch.object(sys, "executable", "/new/bin/python"):
            result = driver.environment_inventory(reference())
        self.assertEqual(result["python"], "/new/bin/python")
        self.assertEqual(result["reference_python"], "/old/bin/python")
        self.assertEqual(result["libzmq"], "4.3.5")
        self.assertEqual(
            set(result["current_distributions"])
            - set(result["reference_distributions"]),
            {"pyzmq"},
        )
        self.assertEqual(
            distributions.call_args_list[0].kwargs["path"],
            ["/old/lib/python3.12/site-packages"],
        )
        module.assert_called_once_with("zmq")

    @mock.patch.object(driver.sysconfig, "get_config_var", return_value=0)
    @mock.patch.object(driver.metadata, "version", return_value="wrong")
    def test_receipt_dependency_mismatch_is_rejected(self, version, config) -> None:
        with mock.patch.object(sys, "version_info", (3, 12)), mock.patch.object(
            sys, "version", "3.12.13 test"
        ):
            with self.assertRaisesRegex(RuntimeError, "dependency mismatch"):
                driver.environment_inventory(reference())

    @mock.patch.object(driver.sysconfig, "get_config_var", return_value=0)
    @mock.patch.object(driver.metadata, "distributions")
    @mock.patch.object(driver.metadata, "version")
    def test_nonreceipt_dependency_drift_is_rejected(
        self, version, distributions, config
    ) -> None:
        version.side_effect = lambda name: {
            "onnxruntime-gpu": "1.23.2",
            "pyzmq": "27.2.0",
        }[name]
        common = SimpleNamespace(metadata={"Name": "common-lib"}, version="1")
        changed = SimpleNamespace(metadata={"Name": "common-lib"}, version="2")
        extra = SimpleNamespace(metadata={"Name": "pyzmq"}, version="27.2.0")
        distributions.side_effect = [[common], [changed, extra]]
        with mock.patch.object(sys, "version_info", (3, 12)), mock.patch.object(
            sys, "version", "3.12.13 test"
        ):
            with self.assertRaisesRegex(RuntimeError, "reference distributions"):
                driver.environment_inventory(reference())


class ReferenceTests(unittest.TestCase):
    def make_reference(self, root: Path) -> Path:
        winners, captures = {}, {}
        for protocol, fixed in reference()["fixed"].items():
            winner = {"protocol": protocol, "adapter": "compact", **fixed}
            winners[protocol] = winner
            child = root / protocol
            (child / "case" / "receipts").mkdir(parents=True)
            for index in range(fixed["workers"]):
                (child / "case" / "receipts" / f"worker-{index}.json").write_text(
                    json.dumps(
                        {
                            "python": "3.12.13 reference",
                            "adapter": "compact",
                            "adapter_installed": {"buffers": True, "worker_json": True},
                            "versions": reference()["worker_versions"],
                        }
                    )
                )
            (child / "model-manifest.json").write_text(
                json.dumps({"onnx": {"sha256": "same-model"}})
            )
            path = child / "SUMMARY.json"
            path.write_text(
                json.dumps(
                    {
                        "results": [
                            {
                                **winner,
                                "role": "cuda",
                                "cuda_timeline": {
                                    "database": str(
                                        child / "case" / "cuda-timeline.sqlite"
                                    )
                                },
                            }
                        ]
                    }
                )
            )
            captures[protocol] = {"cuda": str(path)}
        path = root / "SUMMARY.json"
        path.write_text(
            json.dumps(
                {"python": "/old/bin/python", "winners": winners, "captures": captures}
            )
        )
        return path

    def test_reference_binds_fixed_settings_and_frozen_worker_receipts(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = self.make_reference(Path(folder))
            result = driver.load_reference(path)
            self.assertEqual(result["fixed"], reference()["fixed"])
            self.assertEqual(result["model_sha256"], "same-model")
            self.assertEqual(len(result["worker_receipts"]), 10)

    def test_changed_reference_settings_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = self.make_reference(Path(folder))
            value = json.loads(path.read_text())
            value["winners"]["rest"]["workers"] = 4
            path.write_text(json.dumps(value))
            with self.assertRaisesRegex(RuntimeError, "fixed reference settings"):
                driver.load_reference(path)


class EntryPointTests(unittest.TestCase):
    @mock.patch.object(driver, "execute", return_value={"complete": True})
    @mock.patch.object(driver, "environment_inventory", return_value={})
    @mock.patch.object(driver, "load_reference", side_effect=lambda path: reference())
    @mock.patch.object(driver.study, "freeze")
    @mock.patch.object(
        driver.study.gpu_tools,
        "capabilities",
        return_value={"perf": {"available": True}, "nsys": {"available": True}},
    )
    @mock.patch.object(driver.os, "geteuid", return_value=0)
    def test_main_freezes_once_and_keeps_new_python_for_children(
        self, uid, capabilities, freeze, load_reference, inventory, execute
    ) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "manifest.json").write_text(
                json.dumps({"onnx": {"sha256": "same-model"}})
            )
            arguments = ["driver", "--store", folder, "--bundle", folder]
            with mock.patch.object(sys, "argv", arguments), mock.patch.object(
                sys, "executable", "/new/bin/python"
            ):
                driver.main()
            freeze.assert_called_once()
            current, selected = execute.call_args.args
            self.assertEqual(current.python, Path("/new/bin/python"))
            self.assertEqual(selected["python"], "/old/bin/python")
            directory = next(root.glob("transport-*"))
            self.assertTrue((directory / "SUMMARY.json").exists())
            self.assertTrue((directory / "ENVIRONMENT.json").exists())


if __name__ == "__main__":
    unittest.main()
