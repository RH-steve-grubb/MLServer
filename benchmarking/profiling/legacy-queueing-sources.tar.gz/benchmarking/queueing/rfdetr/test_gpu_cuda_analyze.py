"""Synthetic SQLite captures exercise attribution without any GPU or profiler."""

import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest

import gpu_cuda_analyze as analyzer


def global_pid(pid: int) -> int:
    return (1 << 48) | (pid << 24)


class AnalyzeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.case = Path(self.temporary.name)
        self.database = self.case / "cuda-timeline.sqlite"
        self.result = {
            "protocol": "rest",
            "total_drained": 2,
            "requested_start_ns": 1100,
            "drained_ns": 2100,
            "stage_capture": {
                "valid": True,
                "processes": {
                    "9": {"role": "frontend"},
                    "10": {"role": "worker"},
                    "20": {"role": "worker"},
                },
            },
        }
        (self.case / "result.json").write_text(json.dumps(self.result))
        (self.case / "stages").mkdir()
        connection = sqlite3.connect(self.database)
        connection.executescript(
            """
            CREATE TABLE PROCESSES(globalPid INTEGER, pid INTEGER, name TEXT);
            CREATE TABLE StringIds(id INTEGER, value TEXT);
            CREATE TABLE NVTX_EVENTS(start INTEGER, end INTEGER, globalTid INTEGER,
                rangeId INTEGER, text TEXT, textId INTEGER);
            CREATE TABLE CUPTI_ACTIVITY_KIND_RUNTIME(start INTEGER, end INTEGER,
                globalTid INTEGER, correlationId INTEGER, nameId INTEGER);
            CREATE TABLE CUPTI_ACTIVITY_KIND_KERNEL(start INTEGER, end INTEGER,
                globalPid INTEGER, correlationId INTEGER, deviceId INTEGER);
            CREATE TABLE CUPTI_ACTIVITY_KIND_MEMCPY(start INTEGER, end INTEGER,
                globalPid INTEGER, correlationId INTEGER, deviceId INTEGER,
                copyKind INTEGER, bytes INTEGER);
            CREATE TABLE CUPTI_ACTIVITY_KIND_MEMSET(start INTEGER, end INTEGER,
                globalPid INTEGER, correlationId INTEGER, deviceId INTEGER);
            CREATE TABLE DIAGNOSTIC_EVENT(severity INTEGER, text TEXT,
                globalPid INTEGER);
            CREATE TABLE ENUM_CUDA_MEMCPY_OPER(id INTEGER, label TEXT);
        """
        )
        connection.executemany(
            "INSERT INTO PROCESSES VALUES (?,?,?)",
            [(global_pid(pid), pid, "python") for pid in (9, 10, 20)],
        )
        connection.executemany(
            "INSERT INTO StringIds VALUES (?,?)",
            [
                (1, "cuLaunchKernel"),
                (2, "cudaMemcpyAsync_v3020"),
                (3, "cudaMemsetAsync_v3020"),
            ],
        )
        connection.executemany(
            "INSERT INTO ENUM_CUDA_MEMCPY_OPER VALUES (?,?)",
            [
                (1, "Host-to-Device"),
                (2, "Device-to-Host"),
            ],
        )
        for pid, message, start, end in ((10, "A", 200, 500), (20, "B", 600, 900)):
            label = f"onnx.run.inclusive|trace=None|message={message}"
            record = {
                "pid": pid,
                "tid": pid,
                "stage": "onnx.run.inclusive",
                "message_id": message,
                "succeeded": True,
                "nvtx_label": label,
                "nvtx_range_id": 1,
                "start_ns": start + 1002,
                "end_ns": end + 998,
                "wall_ns": end - start - 4,
                "thread_cpu_ns": end - start - 8,
            }
            self.write_stage(pid, [record])
            connection.execute(
                "INSERT INTO NVTX_EVENTS VALUES (?,?,?,?,?,NULL)",
                (start, end, global_pid(pid) | pid, 1, label),
            )
            connection.executemany(
                "INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME VALUES (?,?,?,?,?)",
                [
                    (start + 10, start + 11, global_pid(pid) | pid, 1, 1),
                    (start + 12, start + 13, global_pid(pid) | pid, 2, 2),
                ],
            )
            connection.execute(
                "INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL VALUES (?,?,?,?,0)",
                (start + 20, start + 120, global_pid(pid), 1),
            )
        self.write_stage(9, [])
        connection.execute(
            "INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME VALUES (214,215,?,3,3)",
            (global_pid(10) | 10,),
        )
        connection.executemany(
            "INSERT INTO CUPTI_ACTIVITY_KIND_MEMCPY VALUES (?,?,?,?,0,?,?)",
            [
                (310, 340, global_pid(10), 2, 1, 64),
                (725, 745, global_pid(20), 2, 2, 32),
            ],
        )
        connection.execute(
            "INSERT INTO CUPTI_ACTIVITY_KIND_MEMSET VALUES (340,350,?,3,0)",
            (global_pid(10),),
        )
        connection.commit()
        connection.close()

    def write_stage(self, pid: int, records: list[dict]) -> None:
        (self.case / "stages" / f"stages-{pid}.json").write_text(
            json.dumps(
                {
                    "format_version": 1,
                    "pid": pid,
                    "record_count": len(records),
                    "records": records,
                    "overflow_records": 0,
                }
            )
        )

    def alter(self, sql: str) -> None:
        with sqlite3.connect(self.database) as connection:
            connection.execute(sql)

    def graph(self) -> None:
        """Add capture-time source/clone metadata independent of replay rows."""
        self.result["engine"] = "cuda-graph"
        (self.case / "result.json").write_text(json.dumps(self.result))
        with sqlite3.connect(self.database) as connection:
            connection.executescript(
                """
                ALTER TABLE CUPTI_ACTIVITY_KIND_KERNEL ADD graphNodeId INTEGER;
                ALTER TABLE CUPTI_ACTIVITY_KIND_KERNEL ADD graphId INTEGER;
                ALTER TABLE CUPTI_ACTIVITY_KIND_MEMCPY ADD graphNodeId INTEGER;
                ALTER TABLE CUPTI_ACTIVITY_KIND_MEMSET ADD graphNodeId INTEGER;
                CREATE TABLE CUDA_GRAPH_NODE_EVENTS(start INTEGER, end INTEGER,
                    globalTid INTEGER, nameId INTEGER, graphNodeId INTEGER,
                    originalGraphNodeId INTEGER);
                INSERT INTO StringIds VALUES(100,'cudaGraphLaunch_v10000');
                INSERT INTO StringIds VALUES(101,'cudaGraphInstantiate_v12000');
                INSERT INTO StringIds VALUES(102,'cudaMallocAsync_v11020');
                INSERT INTO StringIds VALUES(103,'Graph Node Creation');
                UPDATE CUPTI_ACTIVITY_KIND_RUNTIME SET nameId=100 WHERE correlationId=1;
                UPDATE CUPTI_ACTIVITY_KIND_KERNEL SET graphNodeId=1001,graphId=7;
                """
            )
            for pid, start in ((10, 200), (20, 600)):
                tid = global_pid(pid) | pid
                for index, name in enumerate((1, 1, 2, 3, 102)):
                    began = 10 + index * 10
                    source = 101 + index
                    clone = 1001 + index
                    connection.execute(
                        "INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME VALUES(?,?,?,?,?)",
                        (began, began + 9, tid, 1001 + index, name),
                    )
                    connection.executemany(
                        "INSERT INTO CUDA_GRAPH_NODE_EVENTS VALUES(?,?,?,?,?,?)",
                        [
                            (began + 1, began + 1, tid, 103, source, None),
                            (70 + index, 70 + index, tid, 103, clone, None),
                            (80 + index, 80 + index, tid, 103, clone, source),
                        ],
                    )
                connection.execute(
                    "INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME VALUES(?,?,?,?,?)",
                    (60, 99, tid, 1100, 101),
                )
                connection.execute(
                    "INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL VALUES(?,?,?,?,?,?,?)",
                    (start + 130, start + 160, global_pid(pid), 1, 0, 1002, 7),
                )
                connection.execute(
                    "INSERT INTO CUPTI_ACTIVITY_KIND_MEMCPY VALUES(?,?,?,?,?,?,?,?)",
                    (start + 170, start + 180, global_pid(pid), 1, 0, 1, 16, 1003),
                )
                connection.execute(
                    "INSERT INTO CUPTI_ACTIVITY_KIND_MEMSET VALUES(?,?,?,?,?,?)",
                    (start + 181, start + 190, global_pid(pid), 1, 0, 1004),
                )

    def test_marker_alignment_process_scoping_and_union_not_sum(self) -> None:
        summary = analyzer.analyze(self.case)
        self.assertTrue(summary["valid"])
        self.assertEqual(summary["clock_alignment"]["selected_offset_ns"], 1000)
        self.assertEqual(summary["clock_alignment"]["offset_interval_width_ns"], 4)
        self.assertEqual(summary["nsys_measured_window"]["duration_ns"], 1000)
        self.assertEqual(summary["coverage"]["worker_pids"], [10, 20])
        self.assertEqual(summary["coverage"]["kernel_count_per_request"], 1)
        self.assertEqual(summary["device_activity"]["active_union_ns"], 250)
        self.assertEqual(summary["device_activity"]["summed_activity_ns"], 260)
        self.assertEqual(
            summary["device_activity"]["time_with_multiple_activities_ns"], 10
        )
        self.assertEqual(summary["device_activity"]["no_traced_activity_ns"], 750)
        self.assertEqual(summary["host_onnx"]["run_union_ns"], 600)
        self.assertEqual(summary["host_onnx"]["no_run_outstanding_ns"], 400)
        self.assertEqual(summary["host_onnx"]["traced_idle_inside_run_union_ns"], 350)
        by_message = {row["message_id"]: row for row in summary["request_metrics"]}
        self.assertEqual(by_message["A"]["activity"]["memcpy_1"]["bytes"], 64)
        self.assertEqual(by_message["B"]["activity"]["memcpy_2"]["bytes"], 32)
        self.assertEqual(summary["gaps"]["leading_ns"], 120)
        self.assertEqual(summary["gaps"]["trailing_ns"], 355)
        json.dumps(summary, allow_nan=False)

    def test_analysis_does_not_change_database_or_case(self) -> None:
        before = {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in self.case.iterdir()
            if path.is_file()
        }
        analyzer.analyze(self.case)
        after = {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in self.case.iterdir()
            if path.is_file()
        }
        self.assertEqual(before, after)

    def test_full_capture_warmup_activity_is_excluded(self) -> None:
        self.alter(
            "INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL "
            f"VALUES(1,10,{global_pid(10)},999,0)"
        )
        summary = analyzer.analyze(self.case)
        self.assertEqual(summary["device_activity"]["by_kind"]["kernel"]["count"], 2)

    def test_missing_nvtx_marker_is_rejected(self) -> None:
        self.alter("DELETE FROM NVTX_EVENTS WHERE start=200")
        with self.assertRaisesRegex(RuntimeError, "no matching NVTX"):
            analyzer.analyze(self.case)

    def test_same_field_layout_in_stage_version_two_is_supported(self) -> None:
        path = self.case / "stages" / "stages-20.json"
        capture = json.loads(path.read_text())
        capture["format_version"] = 2
        path.write_text(json.dumps(capture))
        self.assertTrue(analyzer.analyze(self.case)["valid"])

    def test_activity_in_uncertain_window_boundary_is_rejected(self) -> None:
        self.alter(
            "INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL "
            f"VALUES(99,101,{global_pid(10)},999,0)"
        )
        with self.assertRaisesRegex(RuntimeError, "uncertain clock-alignment"):
            analyzer.analyze(self.case)

    def test_inconsistent_python_clock_brackets_are_rejected(self) -> None:
        path = self.case / "stages" / "stages-20.json"
        capture = json.loads(path.read_text())
        capture["records"][0]["start_ns"] += 100
        capture["records"][0]["end_ns"] += 100
        path.write_text(json.dumps(capture))
        with self.assertRaisesRegex(RuntimeError, "no consistent clock offset"):
            analyzer.analyze(self.case)

    def test_unattributed_device_work_inside_window_is_rejected(self) -> None:
        self.alter(
            "INSERT INTO CUPTI_ACTIVITY_KIND_KERNEL "
            f"VALUES(400,420,{global_pid(10)},999,0)"
        )
        with self.assertRaisesRegex(RuntimeError, "Unattributed CUDA activity"):
            analyzer.analyze(self.case)

    def test_activity_outside_its_synchronous_run_is_rejected(self) -> None:
        self.alter("UPDATE CUPTI_ACTIVITY_KIND_KERNEL SET end=510 WHERE start=220")
        with self.assertRaisesRegex(RuntimeError, "outside the synchronous ONNX"):
            analyzer.analyze(self.case)

    def test_kernel_loss_cannot_be_reported_as_idle_time(self) -> None:
        self.alter("DELETE FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE start=620")
        with self.assertRaisesRegex(RuntimeError, "inconsistent kernel counts"):
            analyzer.analyze(self.case)

    def test_systematic_kernel_loss_is_detected_against_launch_api_counts(self) -> None:
        for pid, start in ((10, 216), (20, 616)):
            self.alter(
                "INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME "
                f"VALUES({start},{start + 1},{global_pid(pid) | pid},4,1)"
            )
        with self.assertRaisesRegex(RuntimeError, "launching API/device activity"):
            analyzer.analyze(self.case)

    def test_duplicate_runtime_correlation_within_process_is_rejected(self) -> None:
        self.alter(
            "INSERT INTO CUPTI_ACTIVITY_KIND_RUNTIME "
            f"VALUES(230,231,{global_pid(10) | 10},1,1)"
        )
        with self.assertRaisesRegex(RuntimeError, "duplicate process-scoped"):
            analyzer.analyze(self.case)

    def test_diagnostic_warnings_are_retained_with_measured_coverage(self) -> None:
        self.alter(
            "INSERT INTO DIAGNOSTIC_EVENT "
            "VALUES(2,'Not all NVTX events might have been collected',0)"
        )
        summary = analyzer.analyze(self.case)
        self.assertTrue(summary["valid"])
        self.assertEqual(len(summary["coverage"]["diagnostic_warnings"]), 1)

    def test_synchronous_binding_copies_require_matching_device_rows(self) -> None:
        self.alter("UPDATE StringIds SET value='cudaMemcpy_v3020' WHERE id=2")
        summary = analyzer.analyze(self.case)
        self.assertTrue(summary["valid"])
        self.assertEqual(summary["runtime_apis"]["cudaMemcpy_v3020"]["calls"], 2)
        self.assertEqual(
            summary["coverage"]["ordinary_launching_api_counts"]["cudaMemcpy"], 2
        )

    def test_ordinary_api_activity_mismatch_cannot_cancel_out_in_global_counts(
        self,
    ) -> None:
        self.alter(
            "UPDATE CUPTI_ACTIVITY_KIND_MEMCPY SET correlationId=3 WHERE start=310"
        )
        with self.assertRaisesRegex(RuntimeError, "launching API/device activity"):
            analyzer.analyze(self.case)

    def test_graph_replays_match_independent_typed_clone_manifests(self) -> None:
        self.graph()
        summary = analyzer.analyze(self.case)
        coverage = summary["coverage"]
        self.assertTrue(summary["valid"])
        self.assertEqual(coverage["graph_launch_api_calls"], 2)
        self.assertEqual(coverage["kernel_count_per_request"], 2)
        self.assertEqual(summary["runtime_apis"]["cudaGraphLaunch_v10000"]["calls"], 2)
        self.assertEqual(
            coverage["matched_launch_counts"], {"kernel": 4, "memcpy": 4, "memset": 3}
        )
        self.assertEqual(
            coverage["ordinary_launching_api_counts"],
            {"cudaMemcpyAsync": 2, "cudaMemsetAsync": 1},
        )
        templates = coverage["graph_replay_templates"]
        self.assertEqual({row["pid"] for row in templates}, {10, 20})
        for template in templates:
            self.assertEqual(template["replays"], 1)
            self.assertEqual(template["graph_id"], 7)
            self.assertEqual(
                template["node_counts"], {"kernel": 2, "memcpy": 1, "memset": 1}
            )

    def test_missing_copy_node_from_one_graph_replay_is_rejected(self) -> None:
        self.graph()
        self.alter(
            "DELETE FROM CUPTI_ACTIVITY_KIND_MEMCPY "
            f"WHERE graphNodeId=1003 AND globalPid={global_pid(10)}"
        )
        with self.assertRaisesRegex(RuntimeError, "executable-node activity coverage"):
            analyzer.analyze(self.case)

    def test_systematic_graph_kernel_loss_is_detected_using_creation_manifest(
        self,
    ) -> None:
        self.graph()
        self.alter("DELETE FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE graphNodeId=1002")
        with self.assertRaisesRegex(RuntimeError, "executable-node activity coverage"):
            analyzer.analyze(self.case)

    def test_duplicate_or_wrong_kind_graph_nodes_are_rejected(self) -> None:
        self.graph()
        self.alter(
            "UPDATE CUPTI_ACTIVITY_KIND_MEMCPY SET graphNodeId=1004 "
            "WHERE graphNodeId=1003"
        )
        with self.assertRaisesRegex(RuntimeError, "executable-node activity coverage"):
            analyzer.analyze(self.case)

    def test_duplicate_graph_node_activity_is_rejected(self) -> None:
        self.graph()
        self.alter(
            "INSERT INTO CUPTI_ACTIVITY_KIND_MEMCPY "
            "SELECT * FROM CUPTI_ACTIVITY_KIND_MEMCPY "
            f"WHERE graphNodeId=1003 AND globalPid={global_pid(10)}"
        )
        with self.assertRaisesRegex(RuntimeError, "executable-node activity coverage"):
            analyzer.analyze(self.case)

    def test_unknown_graph_node_ids_are_rejected(self) -> None:
        self.graph()
        self.alter(
            "UPDATE CUPTI_ACTIVITY_KIND_KERNEL SET graphNodeId=9999 "
            "WHERE graphNodeId=1002"
        )
        with self.assertRaisesRegex(RuntimeError, "unknown or mixed executable nodes"):
            analyzer.analyze(self.case)

    def test_graph_clone_links_are_scoped_to_their_process(self) -> None:
        self.graph()
        self.alter(
            "UPDATE CUDA_GRAPH_NODE_EVENTS "
            f"SET globalTid={global_pid(30) | 30} "
            f"WHERE globalTid={global_pid(10) | 10} AND originalGraphNodeId=101"
        )
        with self.assertRaisesRegex(RuntimeError, "unknown or mixed executable nodes"):
            analyzer.analyze(self.case)

    def test_unresolved_graph_clone_source_is_rejected(self) -> None:
        self.graph()
        self.alter(
            "UPDATE CUDA_GRAPH_NODE_EVENTS SET originalGraphNodeId=9999 "
            "WHERE originalGraphNodeId=101"
        )
        with self.assertRaisesRegex(RuntimeError, "clone source creation is missing"):
            analyzer.analyze(self.case)

    def test_unknown_graph_source_api_is_not_silently_treated_as_structural(
        self,
    ) -> None:
        self.graph()
        self.alter("INSERT INTO StringIds VALUES(104,'unsupportedGraphNodeAPI')")
        self.alter(
            "UPDATE CUPTI_ACTIVITY_KIND_RUNTIME SET nameId=104 WHERE correlationId=1002"
        )
        # Removing the matching replay rows must not make a partial manifest
        # appear complete, even though both requests retain uniform counts.
        self.alter("DELETE FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE graphNodeId=1002")
        with self.assertRaisesRegex(RuntimeError, "Unsupported CUDA graph source"):
            analyzer.analyze(self.case)

    def test_graph_without_node_tracing_is_rejected(self) -> None:
        self.graph()
        self.alter("UPDATE CUPTI_ACTIVITY_KIND_KERNEL SET graphNodeId=NULL")
        with self.assertRaisesRegex(RuntimeError, "unknown or mixed executable nodes"):
            analyzer.analyze(self.case)

    def test_missing_graph_creation_metadata_is_rejected(self) -> None:
        self.graph()
        self.alter("DROP TABLE CUDA_GRAPH_NODE_EVENTS")
        with self.assertRaisesRegex(RuntimeError, "supported Nsight SQLite schema"):
            analyzer.analyze(self.case)

    def test_graph_engine_requires_one_actual_graph_launch_per_request(self) -> None:
        self.result["engine"] = "cuda-graph"
        (self.case / "result.json").write_text(json.dumps(self.result))
        with self.assertRaisesRegex(RuntimeError, "exactly one CUDA graph launch"):
            analyzer.analyze(self.case)

    def test_blocking_graph_engine_cannot_claim_replay_for_ordinary_launches(
        self,
    ) -> None:
        self.result["engine"] = "cuda-graph-blocking"
        (self.case / "result.json").write_text(json.dumps(self.result))
        with self.assertRaisesRegex(RuntimeError, "exactly one CUDA graph launch"):
            analyzer.analyze(self.case)

    def test_graph_work_outside_its_synchronous_nvtx_range_is_rejected(self) -> None:
        self.graph()
        self.alter(
            "UPDATE CUPTI_ACTIVITY_KIND_MEMCPY SET end=501 "
            f"WHERE graphNodeId=1003 AND globalPid={global_pid(10)}"
        )
        with self.assertRaisesRegex(RuntimeError, "outside the synchronous ONNX"):
            analyzer.analyze(self.case)


if __name__ == "__main__":
    unittest.main()
