"""Root plan tests use synthetic summaries and never launch serving workloads."""

import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

import gpu_baseline


def tuning_summary() -> dict:
    variants = [(1, None), *[(w, t) for w in (1, 2, 4) for t in (1, 2, 4)]]
    return {
        "phase": "tune",
        "results": [
            {
                "protocol": protocol,
                "workers": workers,
                "threads": threads,
                "rps": float(index + 1),
                "latency_ms": {"p95": 1.0},
                "profiled": False,
            }
            for protocol in ("rest", "grpc")
            for index, (workers, threads) in enumerate(variants)
        ],
    }


def plan(folder: str, without_cuda: bool = False) -> gpu_baseline.Plan:
    args = argparse.Namespace(
        bundle=Path("/bundle"),
        user="codex",
        seconds=10.0,
        concurrency=16,
        without_cuda=without_cuda,
    )
    return gpu_baseline.Plan(args, Path(folder), Path("/serving-venv/bin/python"))


class SelectionTests(unittest.TestCase):
    def test_winner_per_protocol_is_explicitly_provisional(self) -> None:
        result = gpu_baseline.choose_winners(tuning_summary())
        self.assertEqual(set(result), {"rest", "grpc"})
        for winner in result.values():
            self.assertEqual((winner["workers"], winner["threads"]), (4, 4))
            self.assertTrue(winner["provisional"])

    def test_partial_duplicate_profiled_or_invalid_sweep_is_rejected(self) -> None:
        cases = []
        missing = tuning_summary()
        missing["results"].pop()
        cases.append(missing)
        duplicate = tuning_summary()
        duplicate["results"][0] = duplicate["results"][1]
        cases.append(duplicate)
        for key, value in (("profiled", True), ("rps", float("nan")), ("rps", 0)):
            altered = tuning_summary()
            altered["results"][0][key] = value
            cases.append(altered)
        for summary in cases:
            with self.subTest(summary=summary):
                with self.assertRaises(RuntimeError):
                    gpu_baseline.choose_winners(summary)


class ChildTests(unittest.TestCase):
    @mock.patch.object(gpu_baseline.subprocess, "run")
    def test_frozen_cli_same_python_explicit_store_and_output_forwarding(
        self, run
    ) -> None:
        def child(command, **kwargs):
            store = Path(command[command.index("--store") + 1])
            directory = store / "run-fresh"
            directory.mkdir()
            (directory / "SUMMARY.json").write_text(json.dumps({"phase": "tune"}))
            return subprocess.CompletedProcess(command, 0)

        run.side_effect = child
        with tempfile.TemporaryDirectory() as folder:
            current = plan(folder)
            summary, path = current.run("tune", ["--phase", "tune"])
            command = run.call_args.args[0]
            self.assertEqual(command[0], "/serving-venv/bin/python")
            self.assertEqual(
                Path(command[1]),
                Path(folder) / "source/benchmarking/queueing/rfdetr/gpu_study.py",
            )
            self.assertEqual(
                command[command.index("--python") + 1], "/serving-venv/bin/python"
            )
            self.assertEqual(summary["phase"], "tune")
            self.assertTrue(path.exists())
            self.assertNotIn("stdout", run.call_args.kwargs)
            self.assertNotIn("capture_output", run.call_args.kwargs)
            self.assertEqual(run.call_args.kwargs["cwd"], Path(folder))
            self.assertTrue(
                run.call_args.kwargs["env"]["PYTHONPATH"].startswith(
                    str(Path(folder) / "source")
                )
            )
            saved = json.loads((Path(folder) / "PLAN.json").read_text())
            self.assertEqual(saved["steps"][0]["status"], "complete")

    @mock.patch.object(gpu_baseline.subprocess, "run")
    def test_missing_or_multiple_child_runs_fail_without_accepting_old_summary(
        self, run
    ) -> None:
        def child(command, **kwargs):
            store = Path(command[command.index("--store") + 1])
            for name in ("run-one", "run-two"):
                directory = store / name
                directory.mkdir()
                (directory / "SUMMARY.json").write_text('{"phase":"tune"}')

        for side_effect in (None, child):
            with self.subTest(side_effect=side_effect):
                run.side_effect = side_effect
                with tempfile.TemporaryDirectory() as folder:
                    current = plan(folder)
                    with self.assertRaisesRegex(RuntimeError, "one fresh child"):
                        current.run("tune", ["--phase", "tune"])
                    saved = json.loads((Path(folder) / "PLAN.json").read_text())
                    self.assertEqual(saved["steps"][0]["status"], "failed")


class ExecutionTests(unittest.TestCase):
    def run_plan(self, current):
        def child(label, options):
            path = current.directory / label / "SUMMARY.json"
            if label == "tune":
                return tuning_summary(), path
            if label.endswith("client-control"):
                protocol = options[options.index("--protocol") + 1]
                return {"results": [{"protocol": protocol, "rps": 12.0}]}, path
            return {"results": []}, path

        with mock.patch.object(current, "run", side_effect=child) as run:
            result = gpu_baseline.execute(current)
        return result, run

    def test_complete_plan_qualifies_cuda_first_and_captures_both_protocols(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as folder:
            current = plan(folder)
            result, run = self.run_plan(current)
            calls = run.call_args_list
            self.assertEqual(calls[0].args[0], "cuda-qualification")
            qualification = calls[0].args[1]
            self.assertEqual(qualification[qualification.index("--seconds") + 1], "1")
            self.assertEqual(
                qualification[qualification.index("--concurrency") + 1], "2"
            )
            self.assertEqual(calls[1].args[0], "tune")
            self.assertFalse(result["gpu_timeline_pending"])
            self.assertEqual(run.call_count, 12)
            for protocol in ("rest", "grpc"):
                self.assertEqual(
                    set(result["captures"][protocol]),
                    {"client_control", "cpu", "gil", "stages", "cuda"},
                )
                self.assertTrue(
                    result["winners"][protocol]["client_headroom_needs_confirmation"]
                )
            for call in calls[2:]:
                options = call.args[1]
                self.assertEqual(options[options.index("--workers") + 1], "4")
                self.assertEqual(options[options.index("--threads") + 1], "4")
                clients = options[options.index("--clients") + 1]
                self.assertEqual(
                    clients, "4" if call.args[0].endswith("client-control") else "2"
                )

    def test_without_cuda_leaves_gpu_timeline_pending_and_runs_cpu_gil_stages(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as folder:
            current = plan(folder, without_cuda=True)
            result, run = self.run_plan(current)
            self.assertEqual(run.call_args_list[0].args[0], "tune")
            self.assertEqual(run.call_count, 9)
            self.assertTrue(result["gpu_timeline_pending"])
            self.assertIsNone(result["cuda_qualification"])
            self.assertFalse(any("cuda" in call.args[0] for call in run.call_args_list))


class PreflightTests(unittest.TestCase):
    def arguments(self, folder: str) -> list[str]:
        return ["gpu_baseline", "--store", folder, "--bundle", folder]

    @mock.patch.object(gpu_baseline.study, "freeze")
    @mock.patch.object(gpu_baseline.study.gpu_tools, "capabilities")
    @mock.patch.object(gpu_baseline.os, "geteuid", return_value=0)
    def test_missing_nsight_fails_before_sweep_and_records_actionable_error(
        self, uid, capabilities, freeze
    ) -> None:
        capabilities.return_value = {
            "nsys": {"available": False},
            "nsight_repair_recommendation": "repair RPM",
        }
        with tempfile.TemporaryDirectory() as folder:
            with mock.patch.object(
                sys, "argv", self.arguments(folder)
            ), mock.patch.object(gpu_baseline.sys, "version_info", (3, 12)):
                with self.assertRaisesRegex(
                    RuntimeError, "Nsight Systems is unavailable"
                ):
                    gpu_baseline.main()
            freeze.assert_not_called()
            directory = next(Path(folder).glob("plan-*"))
            failure = json.loads((directory / "FAILED.json").read_text())
            self.assertIn("--without-cuda", failure["message"])
            self.assertIn("repair RPM", failure["message"])

    @mock.patch.object(gpu_baseline, "execute", return_value={"complete": True})
    @mock.patch.object(gpu_baseline.study, "freeze")
    @mock.patch.object(gpu_baseline.study.gpu_tools, "capabilities")
    @mock.patch.object(gpu_baseline.os, "geteuid", return_value=0)
    def test_without_cuda_freezes_once_and_publishes_summary(
        self, uid, capabilities, freeze, execute
    ) -> None:
        capabilities.return_value = {
            "nsys": {"available": False},
            "perf": {"available": True},
        }
        with tempfile.TemporaryDirectory() as folder:
            arguments = self.arguments(folder) + ["--without-cuda"]
            with mock.patch.object(sys, "argv", arguments), mock.patch.object(
                gpu_baseline.sys, "version_info", (3, 12)
            ):
                gpu_baseline.main()
            freeze.assert_called_once()
            directory = next(Path(folder).glob("plan-*"))
            self.assertTrue((directory / "SUMMARY.json").exists())
            self.assertEqual(execute.call_args.args[0].python, Path(sys.executable))


if __name__ == "__main__":
    unittest.main()
