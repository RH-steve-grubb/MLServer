"""Worker JSON wiring tests mock installation and never start a model."""

import os
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest import mock

from mlserver import rest

import gpu_worker_json as adapter


class WorkerJsonTests(unittest.TestCase):
    def setUp(self) -> None:
        self.environment = mock.patch.dict(os.environ, {}, clear=True)
        self.environment.start()
        self.addCleanup(self.environment.stop)
        self.state = mock.patch.object(adapter, "_INSTALLED", False)
        self.state.start()
        self.addCleanup(self.state.stop)
        self.path = list(sys.path)
        self.addCleanup(lambda: sys.path.__setitem__(slice(None), self.path))
        self.events: list = []
        events = self.events

        class RestServer:
            def __init__(
                self, settings: object, data_plane: object, repository: object
            ):
                events.append(("original", settings, repository))
                self._data_plane = data_plane

        self.server_type = RestServer
        self.raw = SimpleNamespace(
            install=mock.Mock(side_effect=lambda: events.append("worker-installed")),
            install_routes=mock.Mock(
                side_effect=lambda *args: events.append(("routes", *args))
            ),
        )
        self.stages = ModuleType("gpu_stages")
        setattr(self.stages, "_INSTALLED", False)
        self.modules = mock.patch.dict(
            sys.modules,
            {"raw_worker": self.raw, "gpu_stages": self.stages},
        )
        self.modules.start()
        self.addCleanup(self.modules.stop)
        self.rest_type = mock.patch.object(rest, "RESTServer", RestServer)
        self.rest_type.start()
        self.addCleanup(self.rest_type.stop)

    def test_absent_and_other_adapters_change_nothing(self) -> None:
        original = self.server_type.__init__
        for mode in (None, "stock", "raw-grpc"):
            with self.subTest(mode=mode):
                if mode is not None:
                    os.environ["MLSERVER_GPU_ADAPTER"] = mode
                self.assertFalse(adapter.install())
                self.assertIs(self.server_type.__init__, original)
                self.raw.install.assert_not_called()
                self.assertNotIn("MLSERVER_QUEUE_JSON", os.environ)

    def test_installation_is_idempotent_for_both_target_modes(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "worker-json"
        self.assertTrue(adapter.install())
        initialized = self.server_type.__init__
        os.environ["MLSERVER_GPU_ADAPTER"] = "compact"
        self.assertTrue(adapter.install())
        self.assertIs(self.server_type.__init__, initialized)
        self.raw.install.assert_called_once_with()
        for key, value in adapter._SETTINGS.items():
            self.assertEqual(os.environ[key], value)
        self.assertIn(str(Path(adapter.__file__).resolve().parent.parent), sys.path)

    def test_routes_install_after_server_init_with_actual_registry(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "worker-json"
        adapter.install()
        registry, settings, repository = object(), object(), object()
        plane = SimpleNamespace(_model_registry=registry)
        server = self.server_type(settings, plane, repository)
        self.assertEqual(self.events[0], "worker-installed")
        self.assertEqual(self.events[1], ("original", settings, repository))
        self.assertEqual(self.events[2], ("routes", server, registry))
        self.raw.install_routes.assert_called_once_with(server, registry)

    def test_keyword_server_arguments_are_preserved(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "compact"
        adapter.install()
        registry = object()
        plane = SimpleNamespace(_model_registry=registry)
        server = self.server_type(
            settings="settings", data_plane=plane, repository="repository"
        )
        self.raw.install_routes.assert_called_once_with(server, registry)

    def test_conflicting_settings_fail_without_installation(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "worker-json"
        for key in adapter._SETTINGS:
            with self.subTest(key=key):
                with mock.patch.dict(os.environ, {key: "conflicting"}):
                    before = dict(os.environ)
                    with self.assertRaisesRegex(ValueError, key):
                        adapter.install()
                    self.assertEqual(dict(os.environ), before)
                    self.raw.install.assert_not_called()

    def test_explicit_zmq_transport_keeps_the_same_representation(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "compact"
        os.environ["MLSERVER_GPU_TRANSPORT"] = "zmq"
        os.environ["MLSERVER_QUEUE_TRANSPORT"] = "zmq"
        self.assertTrue(adapter.install())
        self.assertEqual(os.environ["MLSERVER_QUEUE_TRANSPORT"], "zmq")
        for key, value in adapter._SETTINGS.items():
            self.assertEqual(os.environ[key], value)
        self.raw.install.assert_called_once_with()

    def test_unknown_or_conflicting_transport_is_rejected(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "worker-json"
        for selected, queue_mode in (
            ("unsupported", "queue"),
            ("queue", "zmq"),
            ("zmq", "queue"),
        ):
            with self.subTest(selected=selected, queue_mode=queue_mode):
                with mock.patch.dict(
                    os.environ,
                    {
                        "MLSERVER_GPU_TRANSPORT": selected,
                        "MLSERVER_QUEUE_TRANSPORT": queue_mode,
                    },
                ):
                    before = dict(os.environ)
                    with self.assertRaises(ValueError):
                        adapter.install()
                    self.assertEqual(dict(os.environ), before)
                    self.raw.install.assert_not_called()

    def test_stage_instrumentation_cannot_be_replaced(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "worker-json"
        setattr(self.stages, "_INSTALLED", True)
        with self.assertRaisesRegex(RuntimeError, "before gpu_stages"):
            adapter.install()
        self.raw.install.assert_not_called()
        self.assertNotIn("MLSERVER_QUEUE_JSON", os.environ)

    def test_repeat_install_preserves_later_stage_wrapper(self) -> None:
        os.environ["MLSERVER_GPU_ADAPTER"] = "worker-json"
        adapter.install()
        setattr(self.stages, "_INSTALLED", True)
        self.assertTrue(adapter.install())
        self.raw.install.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
