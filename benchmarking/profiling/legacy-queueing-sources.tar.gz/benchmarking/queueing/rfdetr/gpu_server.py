"""Study-only launcher and spawn-safe configuration receipts for stock MLServer."""

import functools
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import sysconfig
import time
from typing import Any

from serve import serving_environment


def publish(path: Path, value: Any) -> None:
    temporary = path.with_suffix(".partial")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def identity() -> dict[str, Any]:
    import mlserver
    import mlserver_onnx
    from mlserver.grpc.converters import ModelInferRequestConverter
    import gpu_transport

    return {
        "pid": os.getpid(),
        "ppid": os.getppid(),
        "uid": os.geteuid(),
        "monotonic_ns": time.monotonic_ns(),
        "python": sys.version,
        "executable": sys.executable,
        "gil_enabled": True,
        "source": str(Path(mlserver.__file__).resolve()),
        "onnx_source": str(Path(mlserver_onnx.__file__).resolve()),
        "affinity": sorted(os.sched_getaffinity(0)),
        "cgroup": Path("/proc/self/cgroup").read_text(),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "adapter": os.environ.get("MLSERVER_GPU_ADAPTER", "stock"),
        "transport": os.environ.get("MLSERVER_GPU_TRANSPORT", "queue"),
        "engine": os.environ.get("MLSERVER_GPU_ENGINE", "run"),
        "metadata_only": bool(
            getattr(ModelInferRequestConverter.to_types, "_gpu_metadata_only", False)
        ),
        "buffer_inject": bool(
            getattr(ModelInferRequestConverter.to_types, "_gpu_buffer_inject", False)
        ),
        "zmq_installed": gpu_transport.installed(),
        "ipc_directory": os.environ.get("MLSERVER_QUEUE_ZMQ_DIR"),
        "adapter_installed": {
            "buffers": bool(
                getattr(ModelInferRequestConverter.to_types, "_gpu_buffers", False)
            ),
            "worker_json": bool(
                getattr(sys.modules.get("gpu_worker_json"), "_INSTALLED", False)
            ),
        },
    }


def install() -> None:
    location = os.environ.get("MLSERVER_GPU_RECEIPTS")
    if not location:
        return
    if sys.version_info[:2] != (3, 12) or sysconfig.get_config_var("Py_GIL_DISABLED"):
        raise RuntimeError("Study requires conventional CPython 3.12")
    os.environ.update(serving_environment())
    from mlserver_onnx import OnnxModel
    import gpu_transport

    gpu_transport.install()
    adapter = os.environ.get("MLSERVER_GPU_ADAPTER", "stock")
    if adapter in ("buffers", "compact"):
        import gpu_buffers

        gpu_buffers.install()
    if adapter in ("worker-json", "compact"):
        import gpu_worker_json

        gpu_worker_json.install()
    if adapter not in ("stock", "buffers", "worker-json", "compact"):
        raise ValueError(f"Unknown diagnostic adapter: {adapter}")
    import gpu_engine

    gpu_engine.install()
    if os.environ.get("MLSERVER_GPU_TRACE_DIR"):
        import gpu_stages

        gpu_stages.install()
    original = OnnxModel.load
    if getattr(original, "_gpu_receipt", False):
        return

    @functools.wraps(original)
    async def load(model: Any) -> bool:
        result = await original(model)
        options = model._model.get_session_options()
        extra = model.settings.parameters.extra
        providers = model._model.get_providers()
        if "CUDAExecutionProvider" not in providers:
            raise RuntimeError("Study refuses silent CPU-only fallback")
        if model.settings.max_batch_size or model.settings.max_batch_time:
            raise RuntimeError("Adaptive batching must remain disabled")
        publish(
            Path(location) / f"worker-{os.getpid()}.json",
            {
                **identity(),
                "providers": providers,
                "provider_options": model._model.get_provider_options(),
                "intra_op_threads": options.intra_op_num_threads,
                "inter_op_threads": options.inter_op_num_threads,
                "engine_receipt": gpu_engine.receipt(model._model),
                "session_options": {
                    "graph_optimization_level": str(options.graph_optimization_level),
                    "enable_cpu_mem_arena": options.enable_cpu_mem_arena,
                    "enable_mem_pattern": options.enable_mem_pattern,
                    "execution_mode": str(options.execution_mode),
                },
                "extra": extra,
                "versions": {
                    name: importlib.metadata.version(name)
                    for name in (
                        "onnxruntime-gpu",
                        "onnx",
                        "numpy",
                        "fastapi",
                        "pydantic",
                        "grpcio",
                        "uvicorn",
                        "orjson",
                    )
                },
            },
        )
        return result

    setattr(load, "_gpu_receipt", True)
    setattr(OnnxModel, "load", load)


# The spawn start method executes this file in each child. Installation must
# therefore happen outside the CLI guard, before the worker loads its model.
install()

if __name__ == "__main__":
    from mlserver.cli.main import root

    location = Path(os.environ["MLSERVER_GPU_RECEIPTS"])
    publish(location / "frontend.json", identity())
    root()
