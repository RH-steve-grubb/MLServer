/* Optional NVTX3 bridge for diagnostic captures; no CUDA context is created.
 * ID-based ranges may span Python await points and finish on another thread.
 */
#include <stdint.h>
#include <nvtx3/nvToolsExt.h>

uint64_t gpu_range_start(const char *name)
{
    return (uint64_t)nvtxRangeStartA(name);
}

void gpu_range_end(uint64_t range_id)
{
    nvtxRangeEnd((nvtxRangeId_t)range_id);
}
