"""Engine serving-plan tests mock all children and never perform GPU work."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from typing import Any
import unittest
from unittest.mock import patch

import gpu_engine_compare as driver


def values(options: list[str]) -> dict[str, str]:
    pairs = [x for x in options if x != "--metadata-only"]
    assert len(pairs) % 2 == 0
    return dict(zip(pairs[::2], pairs[1::2]))


def reference() -> dict:
    return {
        "fixed": {"grpc": {"workers": 2, "threads": 2}},
        "model_sha256": hashlib.sha256(b"fixed-model").hexdigest(),
        "python": "/original/python",
    }


class EnginePlanTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        args = argparse.Namespace(
            bundle=self.root,
            user="codex",
            seconds=10.0,
            repeat_seconds=20.0,
            repeats=3,
            without_cuda=False,
            concurrency=16,
        )
        self.plan = driver.baseline.Plan(args, self.root, Path("/transport/python"))

    def child(self, label: str, options: list[str]) -> tuple[dict, Path]:
        parsed = values(options)
        configuration: dict[str, Any] = {
            key: parsed[f"--{key}"]
            for key in ("protocol", "adapter", "transport", "engine")
        }
        configuration.update(
            {
                key: int(parsed[f"--{key}"])
                for key in ("workers", "threads", "concurrency")
            }
        )
        configuration["metadata_only"] = "--metadata-only" in options
        phase = parsed["--phase"]
        row = {
            **configuration,
            "clients": [{}]
            * min(int(parsed["--clients"]), configuration["concurrency"]),
            "rps": 100.0,
        }
        roles = (
            [("smoke", False)]
            if phase == "smoke"
            else [("control-before", False), (phase, True), ("control-after", False)]
        )
        return {
            "results": [
                {**row, "role": role, "profiled": profiled} for role, profiled in roles
            ]
        }, self.root / label / "SUMMARY.json"

    def test_complete_matrix_rotates_flags_topologies_and_fixed_settings(self) -> None:
        with patch.object(self.plan, "run", side_effect=self.child) as run:
            result = driver.execute(self.plan, reference())
        self.assertEqual(run.call_count, 37)
        self.assertEqual(len(result["repeats"]), 27)
        calls = run.call_args_list
        self.assertEqual(
            [c.args[0] for c in calls[:2]],
            ["qualification-combined-stages", "qualification-combined-cuda"],
        )
        for call in calls[:2]:
            parsed = values(call.args[1])
            self.assertEqual(
                (
                    parsed["--workers"],
                    parsed["--threads"],
                    parsed["--concurrency"],
                    parsed["--requests"],
                ),
                ("1", "2", "2", "4"),
            )
            self.assertEqual(parsed["--engine"], "cuda-graph-blocking")
            self.assertIn("--metadata-only", call.args[1])
        increments = [r for r in result["repeats"] if r["block"] == "increments"]
        labels = [c[0] for c in driver.CONFIGURATIONS]
        for repeat in range(3):
            rows = [r for r in increments if r["round"] == repeat]
            self.assertEqual(
                [r["variant"] for r in rows], labels[repeat:] + labels[:repeat]
            )
        counts = Counter((r["block"], r["variant"]) for r in result["repeats"])
        self.assertTrue(all(n == 3 for n in counts.values()))
        self.assertEqual(len(counts), 9)
        for repeat in range(3):
            order = [r["block"] for r in result["repeats"] if r["round"] == repeat]
            self.assertEqual(
                order,
                (
                    ["increments"] * 5 + ["clients4"] * 2 + ["serial"] * 2
                    if repeat % 2 == 0
                    else ["serial"] * 2 + ["clients4"] * 2 + ["increments"] * 5
                ),
            )
        for row in result["repeats"]:
            actual = row["result"]
            self.assertEqual(
                (
                    actual["protocol"],
                    actual["adapter"],
                    actual["transport"],
                    actual["workers"],
                    actual["threads"],
                ),
                ("grpc", "compact", "zmq", 2, 2),
            )
            self.assertEqual(
                actual["concurrency"], 1 if row["block"] == "serial" else 16
            )
            self.assertEqual(
                row["active_clients"],
                1 if row["block"] == "serial" else row["requested_clients"],
            )
            self.assertIs(actual["metadata_only"], row["variant"].endswith("-metadata"))
        cases = 0
        for call in calls:
            parsed = values(call.args[1])
            self.assertIn(
                parsed["--engine"],
                {"run", "run-blocking", "cuda-graph", "cuda-graph-blocking"},
            )
            self.assertEqual(
                parsed["--clients"], "4" if "-clients4-" in call.args[0] else "2"
            )
            self.assertEqual(
                int(parsed["--requests"]) % int(parsed["--concurrency"]), 0
            )
            cases += 1 if parsed["--phase"] == "smoke" else 3
        self.assertEqual(cases, 57)
        self.assertEqual(set(result["captures"]), {labels[0], labels[-1]})
        for capture in result["captures"].values():
            self.assertEqual(set(capture["passes"]), {"cpu", "gil", "stages", "cuda"})
        self.assertEqual(len(json.loads((self.root / "REPEATS.json").read_text())), 27)

    def test_selector_mismatch_or_profiled_repeat_stops_and_preserves_progress(
        self,
    ) -> None:
        for key, value in (
            ("engine", "run"),
            ("metadata_only", True),
            ("profiled", True),
            ("clients", []),
        ):

            def child(label: str, options: list[str]) -> tuple[dict, Path]:
                summary, path = self.child(label, options)
                if label == "r0-increments-run-blocking":
                    summary["results"][0][key] = value
                return summary, path

            with patch.object(self.plan, "run", side_effect=child):
                with self.assertRaises(RuntimeError):
                    driver.execute(self.plan, reference())
            saved = json.loads((self.root / "REPEATS.json").read_text())
            self.assertEqual(len(saved), 1)

    def test_cuda_qualification_and_profile_controls_cannot_be_omitted(self) -> None:
        for label in ("qualification-combined-cuda", "run-gil"):

            def child(name: str, options: list[str]) -> tuple[dict, Path]:
                summary, path = self.child(name, options)
                if name == label:
                    summary["results"] = summary["results"][1:]
                return summary, path

            with patch.object(self.plan, "run", side_effect=child):
                with self.assertRaisesRegex(RuntimeError, "bracketed captures"):
                    driver.execute(self.plan, reference())
            self.assertTrue((self.root / "QUALIFICATION.json").exists())

    def test_frozen_child_command_preserves_boolean_flag_and_failure(self) -> None:
        config = {
            "protocol": "grpc",
            "transport": "zmq",
            "workers": 2,
            "threads": 2,
            "concurrency": 16,
            "engine": "cuda-graph-blocking",
            "metadata_only": True,
        }
        selected = driver.options(config, 2, 20)

        def child(command: list[str], **kwargs: Any) -> None:
            store = Path(command[command.index("--store") + 1]) / "run-one"
            store.mkdir()
            (store / "SUMMARY.json").write_text('{"phase":"smoke"}')

        with patch.object(driver.baseline.subprocess, "run", side_effect=child) as run:
            self.plan.run("frozen", ["--phase", "smoke", *selected])
        command = run.call_args.args[0]
        self.assertEqual(
            command[:2],
            [
                str(self.plan.python),
                str(self.root / "source/benchmarking/queueing/rfdetr/gpu_study.py"),
            ],
        )
        self.assertEqual(command[-1], "--metadata-only")
        self.assertIn(
            str(self.root / "source"), run.call_args.kwargs["env"]["PYTHONPATH"]
        )
        with patch.object(
            driver.baseline.subprocess, "run", side_effect=RuntimeError("child failed")
        ):
            with self.assertRaisesRegex(RuntimeError, "child failed"):
                self.plan.run("failed", ["--phase", "smoke", *selected])
        self.assertEqual(
            json.loads((self.root / "PLAN.json").read_text())["steps"][-1]["status"],
            "failed",
        )

    def test_main_checks_reference_model_tools_and_freezes_once(self) -> None:
        (self.root / "model").mkdir()
        (self.root / "model/model.onnx").write_bytes(b"fixed-model")
        (self.root / "manifest.json").write_text(
            json.dumps({"onnx": {"sha256": reference()["model_sha256"]}})
        )
        arguments = [
            "gpu_engine_compare",
            "--bundle",
            str(self.root),
            "--store",
            str(self.root / "runs"),
        ]
        with patch.object(sys, "argv", arguments), patch.object(
            driver.os, "geteuid", return_value=0
        ), patch.object(
            driver.transport, "load_reference", return_value=reference()
        ), patch.object(
            driver.transport, "environment_inventory", return_value={"verified": True}
        ), patch.object(
            driver.study.gpu_tools,
            "capabilities",
            return_value={"perf": {"available": True}, "nsys": {"available": True}},
        ), patch.object(
            driver.study, "freeze"
        ) as freeze, patch.object(
            driver, "execute", return_value={"complete": True}
        ) as execute:
            driver.main()
        freeze.assert_called_once()
        current = execute.call_args.args[0]
        self.assertEqual(current.python, Path(sys.executable))
        self.assertEqual(
            (current.args.seconds, current.args.repeat_seconds, current.args.repeats),
            (10, 20, 3),
        )
        self.assertTrue((current.directory / "SUMMARY.json").exists())
        (self.root / "model/model.onnx").write_bytes(b"wrong-model")
        with patch.object(sys, "argv", arguments), patch.object(
            driver.os, "geteuid", return_value=0
        ), patch.object(
            driver.transport, "load_reference", return_value=reference()
        ), patch.object(
            driver.transport, "environment_inventory", return_value={"verified": True}
        ), patch.object(
            driver.study, "freeze"
        ) as freeze:
            with self.assertRaisesRegex(RuntimeError, "model differs"):
                driver.main()
        freeze.assert_not_called()
        self.assertEqual(
            len(list((self.root / "runs").glob("engine-*/FAILED.json"))), 1
        )


if __name__ == "__main__":
    unittest.main()
