"""GPU transport selection tests mock ZeroMQ installation and open no sockets."""

import json
import os
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest import mock

import gpu_transport as transport


class TransportTests(unittest.TestCase):
    def setUp(self) -> None:
        self.environment = mock.patch.dict(os.environ, {}, clear=True)
        self.environment.start()
        self.addCleanup(self.environment.stop)
        self.state = mock.patch.object(transport, "_INSTALLED", False)
        self.state.start()
        self.addCleanup(self.state.stop)
        self.register = mock.patch.object(transport.atexit, "register")
        self.registered = self.register.start()
        self.addCleanup(self.register.stop)
        self.finalizer = mock.patch.object(transport, "Finalize")
        self.finalized = self.finalizer.start()
        self.addCleanup(self.finalizer.stop)
        self.finalizer_state = mock.patch.object(transport, "_FINALIZER", None)
        self.finalizer_state.start()
        self.addCleanup(self.finalizer_state.stop)
        self.directory = tempfile.TemporaryDirectory(prefix="mgz-", dir="/tmp")
        self.addCleanup(self.directory.cleanup)
        self.path = list(sys.path)
        self.addCleanup(lambda: sys.path.__setitem__(slice(None), self.path))
        self.helper = SimpleNamespace(
            install=mock.Mock(),
            COUNTS={key: 0 for key in transport._COUNTERS},
            zmq=SimpleNamespace(
                pyzmq_version=lambda: "26.4.0", zmq_version=lambda: "4.3.5"
            ),
        )
        self.stages = ModuleType("gpu_stages")
        self.worker = ModuleType("gpu_worker_json")
        self.buffers = ModuleType("gpu_buffers")
        self.modules = mock.patch.dict(
            sys.modules,
            {
                "zmq_transport": self.helper,
                "gpu_stages": self.stages,
                "gpu_worker_json": self.worker,
                "gpu_buffers": self.buffers,
            },
        )
        self.modules.start()
        self.addCleanup(self.modules.stop)

    def select_zmq(self) -> None:
        os.environ["MLSERVER_GPU_TRANSPORT"] = "zmq"
        os.environ["MLSERVER_QUEUE_ZMQ_DIR"] = self.directory.name

    def test_queue_is_a_noop_and_receipt_is_not_inferred_from_environment(self) -> None:
        self.assertFalse(transport.install())
        self.assertFalse(transport.installed())
        self.assertEqual(dict(os.environ), {})
        os.environ["MLSERVER_GPU_TRANSPORT"] = "zmq"
        self.assertFalse(transport.installed())
        self.helper.install.assert_not_called()
        self.registered.assert_not_called()
        self.finalized.assert_not_called()

    def test_zmq_normalizes_flags_and_installs_once(self) -> None:
        self.select_zmq()
        self.assertTrue(transport.install())
        self.assertTrue(transport.installed())
        self.assertEqual(os.environ["MLSERVER_QUEUE_CODEC"], "pickle")
        self.assertEqual(os.environ["MLSERVER_QUEUE_TENSORS"], "list")
        self.assertEqual(os.environ["MLSERVER_QUEUE_TRANSPORT"], "zmq")
        self.assertIn(str(Path(transport.__file__).resolve().parent.parent), sys.path)
        setattr(self.stages, "_INSTALLED", True)
        setattr(self.worker, "_INSTALLED", True)
        self.assertTrue(transport.install())
        self.helper.install.assert_called_once_with()
        self.registered.assert_called_once_with(transport._safe_flush)
        self.finalized.assert_called_once_with(
            None, transport._safe_flush, exitpriority=10
        )

    def test_unknown_or_conflicting_modes_fail_before_mutation(self) -> None:
        self.select_zmq()
        for key, value in (
            ("MLSERVER_GPU_TRANSPORT", "unsupported"),
            ("MLSERVER_QUEUE_TRANSPORT", "queue"),
            ("MLSERVER_QUEUE_CODEC", "msgpack"),
            ("MLSERVER_QUEUE_TENSORS", "numpy"),
        ):
            with self.subTest(key=key):
                with mock.patch.dict(os.environ, {key: value}):
                    before = dict(os.environ)
                    with self.assertRaises(ValueError):
                        transport.install()
                    self.assertEqual(dict(os.environ), before)
                    self.helper.install.assert_not_called()

    def test_missing_relative_and_overlong_directories_fail_before_mutation(
        self,
    ) -> None:
        self.select_zmq()
        long_directory = Path(self.directory.name) / ("x" * 90)
        long_directory.mkdir()
        for location in (
            "",
            self.directory.name + "/missing",
            ".",
            str(long_directory),
        ):
            with self.subTest(location=location):
                os.environ["MLSERVER_QUEUE_ZMQ_DIR"] = location
                before = dict(os.environ)
                with self.assertRaises(ValueError):
                    transport.install()
                self.assertEqual(dict(os.environ), before)
                self.helper.install.assert_not_called()

    def test_late_install_cannot_replace_existing_adapters_or_tracing(self) -> None:
        self.select_zmq()
        for module in (self.stages, self.worker):
            with self.subTest(module=module.__name__):
                setattr(module, "_INSTALLED", True)
                with self.assertRaisesRegex(RuntimeError, "before"):
                    transport.install()
                setattr(module, "_INSTALLED", False)
        setattr(
            self.buffers,
            "ModelInferRequestConverter",
            SimpleNamespace(to_types=SimpleNamespace(_gpu_buffers=True)),
        )
        with self.assertRaisesRegex(RuntimeError, "before gpu_buffers"):
            transport.install()
        self.helper.install.assert_not_called()
        self.assertNotIn("MLSERVER_QUEUE_CODEC", os.environ)

    def test_installation_failure_does_not_claim_success(self) -> None:
        self.select_zmq()
        self.helper.install.side_effect = RuntimeError("installation failed")
        with self.assertRaisesRegex(RuntimeError, "installation failed"):
            transport.install()
        self.assertFalse(transport.installed())

    def test_installed_zmq_cannot_switch_to_queue(self) -> None:
        self.select_zmq()
        transport.install()
        os.environ["MLSERVER_GPU_TRANSPORT"] = "queue"
        os.environ["MLSERVER_QUEUE_TRANSPORT"] = "queue"
        with self.assertRaisesRegex(RuntimeError, "cannot switch"):
            transport.install()
        self.helper.install.assert_called_once_with()

    def test_exit_receipt_has_actual_versions_counters_and_atomic_write(self) -> None:
        self.select_zmq()
        os.environ["MLSERVER_GPU_RECEIPTS"] = self.directory.name
        transport.install()
        self.helper.COUNTS.update(sent=2, received=2, sent_bytes=20, received_bytes=40)
        with mock.patch.object(transport.os, "getpid", return_value=10):
            path = transport._flush()
        assert path is not None
        receipt = json.loads(path.read_text())
        self.assertEqual(receipt["pid"], 10)
        self.assertEqual(receipt["pyzmq_version"], "26.4.0")
        self.assertEqual(receipt["libzmq_version"], "4.3.5")
        self.assertEqual(receipt["counts"], self.helper.COUNTS)
        self.assertEqual(receipt["scope"], transport._SCOPE)
        self.assertFalse(path.with_suffix(".json.tmp").exists())
        self.helper.COUNTS["sent"] = 3
        self.assertEqual(receipt["counts"]["sent"], 2)

    def test_queue_never_writes_receipts(self) -> None:
        os.environ["MLSERVER_GPU_RECEIPTS"] = self.directory.name
        self.assertFalse(transport.install())
        self.assertIsNone(transport._flush())
        self.assertEqual(list(Path(self.directory.name).iterdir()), [])

    def test_flush_failure_is_reported_without_raising(self) -> None:
        with mock.patch.object(transport, "_flush", side_effect=OSError("disk full")):
            with mock.patch("sys.stderr") as stderr:
                transport._safe_flush()
                self.assertTrue(stderr.write.called)


class TransportReceiptTests(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory(prefix="mgz-receipts-", dir="/tmp")
        self.addCleanup(directory.cleanup)
        self.case = Path(directory.name)
        (self.case / "receipts").mkdir()
        self.server = {
            "frontend": {"pid": 10},
            "workers": [{"pid": 20}, {"pid": 30}],
        }
        self.receipts: dict = {}
        for pid, sent, received, sent_bytes, received_bytes in (
            (10, 5, 5, 50, 100),
            (20, 2, 2, 40, 20),
            (30, 3, 3, 60, 30),
        ):
            self.receipts[pid] = {
                "format_version": 1,
                "pid": pid,
                "transport": "zmq",
                "scope": transport._SCOPE,
                "pyzmq_version": "26.4.0",
                "libzmq_version": "4.3.5",
                "counts": {
                    "sent": sent,
                    "received": received,
                    "sent_bytes": sent_bytes,
                    "received_bytes": received_bytes,
                    "encode_ns": 1,
                    "decode_ns": 2,
                },
            }
        self.write()

    def write(self) -> None:
        for pid, receipt in self.receipts.items():
            path = self.case / "receipts" / f"transport-{pid}.json"
            path.write_text(json.dumps(receipt))

    def collect(self) -> dict:
        self.write()
        return transport.collect(self.case, self.server)

    def test_complete_counts_and_byte_conservation(self) -> None:
        result = self.collect()
        self.assertTrue(result["valid"])
        self.assertEqual(result["requests"], 5)
        self.assertEqual(result["request_bytes"], 50)
        self.assertEqual(result["response_bytes"], 100)
        self.assertEqual(set(result["processes"]), {"10", "20", "30"})
        self.assertTrue((self.case / "transport-summary.json").exists())

    def test_missing_extra_and_incomplete_files_fail(self) -> None:
        path = self.case / "receipts" / "transport-20.json"
        path.unlink()
        with self.assertRaisesRegex(RuntimeError, "PIDs"):
            transport.collect(self.case, self.server)
        self.write()
        extra = path.with_suffix(".json.tmp")
        extra.write_text("{}")
        with self.assertRaisesRegex(RuntimeError, "PIDs"):
            self.collect()

    def test_wrong_identity_and_missing_versions_fail(self) -> None:
        for field, value in (
            ("pid", 999),
            ("transport", "queue"),
            ("format_version", 2),
            ("pyzmq_version", ""),
            ("libzmq_version", None),
            ("scope", "measured only"),
        ):
            with self.subTest(field=field):
                original = self.receipts[20][field]
                self.receipts[20][field] = value
                with self.assertRaisesRegex(RuntimeError, "identity"):
                    self.collect()
                self.receipts[20][field] = original

    def test_count_and_byte_conservation_failures_are_rejected(self) -> None:
        for pid, field in (
            (10, "sent"),
            (20, "received"),
            (10, "sent_bytes"),
            (10, "received_bytes"),
            (20, "sent_bytes"),
            (30, "received_bytes"),
        ):
            with self.subTest(pid=pid, field=field):
                self.receipts[pid]["counts"][field] += 1
                with self.assertRaises(RuntimeError):
                    self.collect()
                self.receipts[pid]["counts"][field] -= 1

    def test_idle_worker_and_invalid_counter_values_fail(self) -> None:
        counts = self.receipts[20]["counts"]
        counts.update(sent=0, received=0)
        with self.assertRaisesRegex(RuntimeError, "worker"):
            self.collect()
        counts.update(sent=2, received=2)
        for value in (-1, "2", True):
            with self.subTest(value=value):
                counts["encode_ns"] = value
                with self.assertRaisesRegex(RuntimeError, "counters"):
                    self.collect()


if __name__ == "__main__":
    unittest.main()
