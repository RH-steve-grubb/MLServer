"""Root-run Queue/ZeroMQ comparison with fixed compact serving configurations.

Both transports use the invoking environment and one frozen source snapshot.
Repeated unprofiled trials estimate performance; captures explain mechanisms.
"""

import argparse
from datetime import datetime, timezone
import importlib
import importlib.metadata as metadata
import json
import math
import os
from pathlib import Path
from statistics import median
import sys
import sysconfig
from typing import Any

import gpu_baseline as baseline

study = baseline.study
DEFAULT_REFERENCE = Path(
    "/home/codex/mlserver-durable-store/rfdetr-gpu-experiments-20261026/"
    "experiment-20261026T172753323335Z-244775/SUMMARY.json"
)
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-transport-20261026"


def load_reference(path: Path) -> dict[str, Any]:
    """Bind fixed settings and package versions to completed reference receipts."""
    summary = json.loads(path.read_text())
    expected = {"rest": (8, 2), "grpc": (2, 2)}
    if set(summary["winners"]) != set(expected):
        raise RuntimeError("Reference must contain both compact protocol winners")
    versions, python_versions, model_hashes, receipts = [], set(), set(), []
    fixed = {}
    for protocol, settings in expected.items():
        winner = summary["winners"][protocol]
        if (
            winner.get("adapter") != "compact"
            or (winner["workers"], winner["threads"]) != settings
        ):
            raise RuntimeError(f"Unexpected fixed reference settings for {protocol}")
        fixed[protocol] = {"workers": settings[0], "threads": settings[1]}
        child = Path(summary["captures"][protocol]["cuda"])
        rows = [
            row
            for row in json.loads(child.read_text())["results"]
            if row["role"] == "cuda"
        ]
        if len(rows) != 1 or any(
            rows[0].get(key) != winner[key]
            for key in ("protocol", "adapter", "workers", "threads")
        ):
            raise RuntimeError("Reference CUDA pass does not match fixed settings")
        case = Path(rows[0]["cuda_timeline"]["database"]).parent
        paths = list((case / "receipts").glob("worker-*.json"))
        if len(paths) != settings[0]:
            raise RuntimeError("Reference worker receipts are incomplete")
        for receipt in paths:
            row = json.loads(receipt.read_text())
            if row["adapter"] != "compact" or row["adapter_installed"] != {
                "buffers": True,
                "worker_json": True,
            }:
                raise RuntimeError("Reference compact adapter receipt mismatch")
            versions.append(row["versions"])
            python_versions.add(row["python"].split()[0])
            receipts.append(str(receipt))
        model_hashes.add(
            json.loads((child.parent / "model-manifest.json").read_text())["onnx"][
                "sha256"
            ]
        )
    if (
        any(item != versions[0] for item in versions)
        or len(python_versions) != 1
        or len(model_hashes) != 1
    ):
        raise RuntimeError("Inconsistent reference Python, packages, or model")
    return {
        "summary": str(path),
        "python": summary["python"],
        "fixed": fixed,
        "python_version": python_versions.pop(),
        "worker_versions": versions[0],
        "model_sha256": model_hashes.pop(),
        "worker_receipts": receipts,
    }


def environment_inventory(reference: dict[str, Any]) -> dict[str, Any]:
    """Check package parity without requiring equal old/new interpreter paths."""
    if (
        sys.implementation.name != "cpython"
        or sys.version_info[:2] != (3, 12)
        or sysconfig.get_config_var("Py_GIL_DISABLED")
    ):
        raise RuntimeError("Transport study requires conventional CPython 3.12")
    if sys.version.split()[0] != reference["python_version"]:
        raise RuntimeError("Reference and invoking Python patch versions differ")
    for name, version in reference["worker_versions"].items():
        if metadata.version(name) != version:
            raise RuntimeError(f"Reference worker dependency mismatch: {name}")
    if (
        metadata.version("onnxruntime-gpu") != "1.23.2"
        or metadata.version("pyzmq") != "27.2.0"
    ):
        raise RuntimeError("Require ONNX Runtime GPU 1.23.2 and pyzmq 27.2.0")
    packages = []
    for python in (Path(reference["python"]), Path(sys.executable)):
        site = python.parent.parent / "lib/python3.12/site-packages"
        found = {
            item.metadata["Name"].lower().replace("_", "-"): item.version
            for item in metadata.distributions(path=[str(site)])
        }
        if not found:
            raise RuntimeError(f"Cannot inventory serving environment {site}")
        packages.append(found)
    original, current = packages
    if any(current.get(name) != version for name, version in original.items()) or set(
        current
    ) - set(original) != {"pyzmq"}:
        raise RuntimeError(
            "New environment must retain all reference distributions and add only pyzmq"
        )
    zmq = importlib.import_module("zmq")
    return {
        "python": str(sys.executable),
        "python_version": sys.version,
        "reference_python": reference["python"],
        "gil_enabled": True,
        "receipt_versions": reference["worker_versions"],
        "reference_distributions": original,
        "current_distributions": current,
        "pyzmq": metadata.version("pyzmq"),
        "libzmq": zmq.zmq_version(),
    }


def options(
    configuration: dict, concurrency: int, seconds: float, clients: int = 2
) -> list[str]:
    values = {
        "protocol": configuration["protocol"],
        "adapter": "compact",
        "transport": configuration["transport"],
        "workers": configuration["workers"],
        "threads": configuration["threads"],
        "clients": clients,
        "concurrency": concurrency,
        "requests": math.ceil(32 / concurrency) * concurrency,
        "seconds": seconds,
    }
    return [item for key, value in values.items() for item in (f"--{key}", str(value))]


def measured(summary: dict, configuration: dict, concurrency: int) -> dict:
    rows = summary.get("results", [])
    if (
        len(rows) != 1
        or rows[0].get("profiled") is not False
        or rows[0].get("adapter") != "compact"
        or rows[0].get("concurrency") != concurrency
    ):
        raise RuntimeError("Expected one matched unprofiled compact transport result")
    row = rows[0]
    if (
        any(row.get(key) != value for key, value in configuration.items())
        or not math.isfinite(row["rps"])
        or row["rps"] <= 0
    ):
        raise RuntimeError("Transport result configuration or throughput mismatch")
    return row


def client_control(
    plan: baseline.Plan, configuration: dict, repeats: list[dict]
) -> dict:
    selected = [
        row["result"]
        for row in repeats
        if row["concurrency"] == 16
        and all(row["result"].get(key) == value for key, value in configuration.items())
    ]
    if len(selected) != plan.args.repeats:
        raise RuntimeError("Missing two-client repeats for transport control")
    reference = median(row["rps"] for row in selected)
    summary, path = plan.run(
        f"{configuration['protocol']}-{configuration['transport']}-client-control",
        ["--phase", "smoke", *options(configuration, 16, plan.args.repeat_seconds, 4)],
    )
    row = measured(summary, configuration, 16)
    ratio = row["rps"] / reference
    needs_confirmation = ratio > 1.05 or any(
        item.get("client_headroom_needs_confirmation")
        or any(
            client["client_cpu_seconds"] / client["duration_seconds"] > 0.8
            for client in item.get("clients", [])
        )
        for item in [*selected, row]
    )
    return {
        "summary": str(path),
        "result": row,
        "two_client_repeat_median_rps": reference,
        "four_to_two_rps_ratio": ratio,
        "needs_confirmation": bool(needs_confirmation),
    }


def execute(plan: baseline.Plan, reference: dict) -> dict[str, Any]:
    qualification = {}
    small = options(
        {"protocol": "both", "transport": "zmq", "workers": 1, "threads": 1}, 2, 1
    )
    small[small.index("--requests") + 1] = "4"
    for name, phase in (
        ("stages", ["--phase", "stages"]),
        ("cuda", ["--phase", "cuda"]),
        ("gil", ["--phase", "profile", "--capture", "gil"]),
    ):
        _, path = plan.run(f"qualification-zmq-{name}", [*phase, *small])
        qualification[name] = str(path)
        study.publish(plan.directory / "QUALIFICATION.json", qualification)
    repeats: list[dict] = []
    controls: dict[str, dict] = {}
    captures: dict[str, dict] = {}
    for protocol in ("rest", "grpc"):
        fixed = {"protocol": protocol, **reference["fixed"][protocol]}
        for concurrency in (1, 16):
            for repeat in range(plan.args.repeats):
                order = ("queue", "zmq") if repeat % 2 == 0 else ("zmq", "queue")
                for transport in order:
                    configuration = {**fixed, "transport": transport}
                    summary, path = plan.run(
                        f"{protocol}-c{concurrency}-r{repeat}-{transport}",
                        [
                            "--phase",
                            "smoke",
                            *options(
                                configuration, concurrency, plan.args.repeat_seconds
                            ),
                        ],
                    )
                    repeats.append(
                        {
                            "transport": transport,
                            "round": repeat,
                            "concurrency": concurrency,
                            "summary": str(path),
                            "result": measured(summary, configuration, concurrency),
                        }
                    )
                    study.publish(plan.directory / "REPEATS.json", repeats)
        controls[protocol], captures[protocol] = {}, {}
        for transport in ("queue", "zmq"):
            configuration = {**fixed, "transport": transport}
            controls[protocol][transport] = client_control(plan, configuration, repeats)
            study.publish(plan.directory / "CLIENT_CONTROLS.json", controls)
            captures[protocol][transport] = {}
            for name, phase in (
                ("cpu", ["--phase", "profile", "--capture", "cpu"]),
                ("gil", ["--phase", "profile", "--capture", "gil"]),
                ("stages", ["--phase", "stages"]),
                ("cuda", ["--phase", "cuda"]),
            ):
                _, path = plan.run(
                    f"{protocol}-{transport}-{name}",
                    [*phase, *options(configuration, 16, plan.args.seconds)],
                )
                captures[protocol][transport][name] = str(path)
                study.publish(plan.directory / "CAPTURES.json", captures)
    return {
        "purpose": "Fixed compact Queue versus ZeroMQ comparison",
        "reference": reference,
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "qualification": qualification,
        "repeats": repeats,
        "client_controls": controls,
        "captures": captures,
        "fixed_configurations": reference["fixed"],
        "interpretation": "Both transports use the same environment, model, payload, "
        "worker/thread settings and compact adapter. Alternating repeats estimate "
        "performance; profiling has before/after controls and is diagnostic only. "
        "Client-control flags require follow-up, not automatic transport selection.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    if (
        os.geteuid() != 0
        or args.repeats < 1
        or any(
            not math.isfinite(value) or value <= 0
            for value in (args.seconds, args.repeat_seconds)
        )
    ):
        parser.error("Run as root with positive repeats and finite positive durations")
    args.without_cuda, args.concurrency = False, 16
    args.reference, args.bundle, args.store = (
        p.resolve() for p in (args.reference, args.bundle, args.store)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"transport-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"Transport study output: {directory}", flush=True)
    try:
        reference = load_reference(args.reference)
        study.publish(directory / "REFERENCE.json", reference)
        study.publish(directory / "ENVIRONMENT.json", environment_inventory(reference))
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if manifest["onnx"]["sha256"] != reference["model_sha256"]:
            raise RuntimeError("Transport study model differs from reference")
        tools = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", tools)
        if not tools["perf"]["available"] or not tools["nsys"]["available"]:
            raise RuntimeError(
                "Actual perf and Nsight Systems executables must work before collection"
            )
        study.freeze(directory)
        result = execute(plan, reference)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
