"""Mocked orchestration tests; never start clients, models or GPU workloads."""

import argparse
import json
from pathlib import Path
import sys
import tempfile
from typing import Any
import unittest
from unittest.mock import Mock, patch

import gpu_experiment as experiment


def screening_rows() -> list[dict[str, Any]]:
    variants = [(1, None), *[(w, t) for w in (1, 2, 4, 8) for t in (1, 2, 4)]]
    return [
        {
            "protocol": protocol,
            "workers": workers,
            "threads": threads,
            "adapter": "compact",
            "profiled": False,
            "rps": float(index + 1),
            "latency_ms": {"p95": 1.0},
        }
        for protocol in ("rest", "grpc")
        for index, (workers, threads) in enumerate(variants)
    ]


def parsed(options: list[str]) -> dict[str, str]:
    return dict(zip((item.removeprefix("--") for item in options[::2]), options[1::2]))


class ExperimentTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.directory = self.root / "experiment"
        self.directory.mkdir()
        self.baseline = self.root / "baseline.json"
        self.baseline.write_text(
            json.dumps(
                {
                    "python": "/pinned/python3.12",
                    "winners": {
                        "rest": {"workers": 4, "threads": 2},
                        "grpc": {"workers": 2, "threads": 1},
                    },
                }
            )
        )
        args = argparse.Namespace(
            baseline=self.baseline,
            bundle=Path("/prepared/bundle"),
            user="codex",
            seconds=10.0,
            repeat_seconds=20.0,
            repeats=3,
            concurrency=16,
            without_cuda=False,
        )
        self.plan = experiment.baseline.Plan(
            args, self.directory, Path("/pinned/python3.12")
        )

    @staticmethod
    def snapshot() -> dict[str, Any]:
        return {
            "gpus": [
                {
                    "uuid": "GPU-test",
                    "name": "RTX 4070",
                    "memory_total_mib": 12288,
                    "memory_used_mib": 1000,
                }
            ],
            "compute_processes": [],
        }

    def fake_run(self, label: str, options: list[str]) -> tuple[dict[str, Any], Path]:
        selected = parsed(options)
        rows = screening_rows()
        if label == "compact-tune":
            result = [row for row in rows if row["workers"] != 8]
        elif label.startswith("compact-w8-"):
            result = [
                row
                for row in rows
                if row["workers"] == 8 and row["threads"] == int(selected["threads"])
            ]
        elif "-r" in label or label.endswith("client-control"):
            self.assertTrue((self.directory / "WINNERS.json").exists())
            result = [
                {
                    "protocol": selected["protocol"],
                    "adapter": selected["adapter"],
                    "workers": int(selected["workers"]),
                    "threads": int(selected["threads"]) or None,
                    "concurrency": int(selected["concurrency"]),
                    "profiled": False,
                    "rps": 10.0,
                }
            ]
        else:
            result = []
        return {"results": result}, self.directory / "steps" / label / "SUMMARY.json"

    def execute(self) -> tuple[dict[str, Any], Mock]:
        with (
            patch.object(self.plan, "run", side_effect=self.fake_run) as run,
            patch.object(
                experiment.study.gpu_tools, "gpu_snapshot", return_value=self.snapshot()
            ),
        ):
            result = experiment.execute(self.plan)
        return result, run

    def test_selection_requires_all_26_rows_with_13_per_protocol(self) -> None:
        winners = experiment.choose_winners(screening_rows())
        for winner in winners.values():
            self.assertEqual((winner["workers"], winner["threads"]), (8, 4))
            self.assertTrue(winner["provisional"])
        variants = []
        missing = screening_rows()
        missing.pop()
        variants.append(missing)
        duplicate = screening_rows()
        duplicate[0] = duplicate[1]
        variants.append(duplicate)
        for key, value in (
            ("adapter", "stock"),
            ("profiled", True),
            ("rps", float("nan")),
            ("rps", 0),
        ):
            changed = screening_rows()
            changed[0][key] = value
            variants.append(changed)
        for rows in variants:
            with self.subTest(rows=rows):
                with self.assertRaises(RuntimeError):
                    experiment.choose_winners(rows)

    def test_complete_plan_qualifies_then_screens_and_repeats_matching_configs(
        self,
    ) -> None:
        before = self.baseline.read_bytes()
        result, run = self.execute()
        self.assertEqual(self.baseline.read_bytes(), before)
        calls = run.call_args_list
        self.assertEqual(
            [call.args[0] for call in calls[:4]],
            [
                "qualification-stages",
                "qualification-cuda",
                "qualification-gil",
                "compact-tune",
            ],
        )
        for call in calls[:3]:
            selected = parsed(call.args[1])
            self.assertEqual(
                (
                    selected["workers"],
                    selected["threads"],
                    selected["concurrency"],
                    selected["requests"],
                    selected["seconds"],
                ),
                ("1", "1", "2", "4", "1"),
            )
        self.assertEqual(len(result["tuning"]), 4)
        self.assertEqual(run.call_count, 53)
        self.assertEqual(len(result["repeats"]), 36)
        self.assertEqual(
            json.loads((self.directory / "REPEATS.json").read_text()), result["repeats"]
        )
        cases = 0
        for call in calls:
            selected = parsed(call.args[1])
            control = call.args[0].endswith("client-control")
            self.assertEqual(selected["clients"], "4" if control else "2")
            if control:
                self.assertEqual(selected["concurrency"], "16")
                self.assertEqual(selected["seconds"], "10.0")
            self.assertEqual(
                int(selected["requests"]) % int(selected["concurrency"]), 0
            )
            multiplier = 2 if selected["protocol"] == "both" else 1
            cases += (
                20
                if selected["phase"] == "tune"
                else multiplier * (1 if selected["phase"] == "smoke" else 3)
            )
            self.assertEqual(
                selected["adapter"],
                "stock" if call.args[0].endswith("-stock") else "compact",
            )
        self.assertEqual(cases, 106)
        for protocol in ("rest", "grpc"):
            for concurrency in (1, 16):
                groups = [
                    [
                        row
                        for row in result["repeats"]
                        if row["result"]["protocol"] == protocol
                        and row["concurrency"] == concurrency
                        and row["round"] == index
                    ]
                    for index in range(3)
                ]
                self.assertEqual(
                    [[row["label"] for row in group] for group in groups],
                    [
                        ["stock", "compact", "compact-tuned"],
                        ["compact-tuned", "compact", "stock"],
                        ["stock", "compact", "compact-tuned"],
                    ],
                )
                for group in groups:
                    matched = [
                        row["result"]
                        for row in group
                        if row["label"] != "compact-tuned"
                    ]
                    self.assertEqual(
                        [(row["workers"], row["threads"]) for row in matched],
                        [(4, 2)] * 2 if protocol == "rest" else [(2, 1)] * 2,
                    )
            self.assertEqual(
                set(result["captures"][protocol]), {"cpu", "gil", "stages", "cuda"}
            )
            control = result["client_controls"][protocol]
            self.assertFalse(control["needs_confirmation"])
            self.assertEqual(control["four_to_two_rps_ratio"], 1)
            self.assertTrue(control["summary"].endswith("client-control/SUMMARY.json"))

    def test_equal_tuned_config_does_not_duplicate_compact_variant(self) -> None:
        chosen = experiment.choose_winners(screening_rows())
        for protocol, winner in chosen.items():
            winner.update(json.loads(self.baseline.read_text())["winners"][protocol])
        with patch.object(experiment, "choose_winners", return_value=chosen):
            result, run = self.execute()
        self.assertEqual(len(result["repeats"]), 24)
        self.assertEqual(run.call_count, 41)
        self.assertNotIn("compact-tuned", {row["label"] for row in result["repeats"]})

    def test_vram_guard_records_why_and_rejects_busy_small_or_unknown_gpu(self) -> None:
        for change in (
            {"memory_used_mib": 5000},
            {"memory_total_mib": None},
            {"name": "other GPU"},
        ):
            state = self.snapshot()
            state["gpus"][0].update(change)
            with patch.object(
                experiment.study.gpu_tools, "gpu_snapshot", return_value=state
            ):
                with self.assertRaisesRegex(RuntimeError, "8 GiB"):
                    experiment.eight_worker_guard(self.plan)
            self.assertFalse(
                json.loads(
                    (self.directory / "EIGHT_WORKER_GPU_GUARD.json").read_text()
                )["allowed"]
            )
        for name in (None, "/usr/bin/python3", "kwin_wayland", "/tmp/kwin_wayland"):
            with self.subTest(process_name=name):
                state = self.snapshot()
                state["compute_processes"] = [
                    {"gpu_uuid": "GPU-test", "pid": 99, "process_name": name}
                ]
                with patch.object(
                    experiment.study.gpu_tools, "gpu_snapshot", return_value=state
                ):
                    with self.assertRaises(RuntimeError):
                        experiment.eight_worker_guard(self.plan)

    def test_vram_guard_permits_only_known_display_path_and_preserves_telemetry(
        self,
    ) -> None:
        state = self.snapshot()
        state["compute_processes"] = [
            {
                "gpu_uuid": "GPU-test",
                "pid": 99,
                "process_name": experiment.study.DISPLAY_PROCESS,
            }
        ]
        with patch.object(
            experiment.study.gpu_tools, "gpu_snapshot", return_value=state
        ):
            experiment.eight_worker_guard(self.plan)
        result = json.loads(
            (self.directory / "EIGHT_WORKER_GPU_GUARD.json").read_text()
        )
        self.assertTrue(result["allowed"])
        self.assertEqual(result["snapshot"], state)

    def test_client_controls_flag_rate_gain_cpu_pressure_without_ranking(self) -> None:
        winner = {"protocol": "grpc", "adapter": "compact", "workers": 8, "threads": 4}
        repeats = [{"concurrency": 16, "result": {**winner, "rps": 10.0}}]
        for extra in (
            {"rps": 10.6},
            {
                "rps": 10.0,
                "clients": [{"client_cpu_seconds": 0.81, "duration_seconds": 1.0}],
            },
            {"rps": 10.0, "client_headroom_needs_confirmation": True},
        ):
            original = dict(winner)
            row = {**winner, "concurrency": 16, "profiled": False, **extra}
            with patch.object(
                self.plan,
                "run",
                return_value=({"results": [row]}, self.root / "SUMMARY.json"),
            ):
                result = experiment.client_control(self.plan, winner, repeats)
            self.assertTrue(result["needs_confirmation"])
            self.assertEqual(winner, original)
        with patch.object(self.plan, "run", side_effect=RuntimeError("failed control")):
            with self.assertRaisesRegex(RuntimeError, "failed control"):
                experiment.client_control(self.plan, winner, repeats)
        invalid = {**winner, "concurrency": 16, "profiled": True, "rps": 10}
        with patch.object(
            self.plan,
            "run",
            return_value=({"results": [invalid]}, self.root / "SUMMARY.json"),
        ):
            with self.assertRaisesRegex(RuntimeError, "control configuration mismatch"):
                experiment.client_control(self.plan, winner, repeats)

    def test_control_reference_uses_only_matching_two_client_repeat_median(
        self,
    ) -> None:
        winner = {"protocol": "grpc", "adapter": "compact", "workers": 8, "threads": 4}
        repeats = [
            {"concurrency": 16, "result": {**winner, "rps": rate}}
            for rate in (10.0, 20.0, 30.0)
        ]
        for key, value in (
            ("protocol", "rest"),
            ("adapter", "stock"),
            ("workers", 4),
            ("threads", 2),
        ):
            repeats.append(
                {"concurrency": 16, "result": {**winner, key: value, "rps": 1000}}
            )
        repeats.append({"concurrency": 1, "result": {**winner, "rps": 1000}})
        row = {**winner, "concurrency": 16, "profiled": False, "rps": 21.0}
        with patch.object(
            self.plan,
            "run",
            return_value=({"results": [row]}, self.root / "SUMMARY.json"),
        ):
            result = experiment.client_control(self.plan, winner, repeats)
        self.assertEqual(result["two_client_repeat_median_rps"], 20)
        self.assertEqual(result["four_to_two_rps_ratio"], 1.05)
        self.assertFalse(result["needs_confirmation"])

    def test_invalid_baseline_fails_before_any_child_is_started(self) -> None:
        reference = json.loads(self.baseline.read_text())
        reference["python"] = "/another/python"
        self.baseline.write_text(json.dumps(reference))
        with patch.object(self.plan, "run") as run:
            with self.assertRaisesRegex(RuntimeError, "same serving Python"):
                experiment.execute(self.plan)
        run.assert_not_called()

    def test_repeated_trials_reject_profiled_or_mismatched_child_results(self) -> None:
        for change in ({"profiled": True}, {"workers": 99}, {"concurrency": 99}):

            def child(label: str, options: list[str]) -> tuple[dict[str, Any], Path]:
                result, path = self.fake_run(label, options)
                if "-r" in label:
                    result["results"][0].update(change)
                return result, path

            with (
                patch.object(self.plan, "run", side_effect=child),
                patch.object(
                    experiment.study.gpu_tools,
                    "gpu_snapshot",
                    return_value=self.snapshot(),
                ),
            ):
                with self.assertRaisesRegex(RuntimeError, "Repeated timing"):
                    experiment.execute(self.plan)

    def test_plan_child_uses_frozen_source_and_explicit_adapter(self) -> None:
        def child(command: list[str], **kwargs: Any) -> None:
            store = Path(command[command.index("--store") + 1])
            (store / "run-one").mkdir()
            (store / "run-one" / "SUMMARY.json").write_text('{"phase":"smoke"}')

        selected = experiment.options(
            {"protocol": "grpc", "adapter": "compact", "workers": 8, "threads": None},
            16,
            20,
        )
        with patch.object(
            experiment.baseline.subprocess, "run", side_effect=child
        ) as run:
            self.plan.run("frozen", ["--phase", "smoke", *selected])
        command = run.call_args.args[0]
        self.assertEqual(command[0], str(self.plan.python))
        self.assertEqual(
            Path(command[1]),
            self.directory / "source/benchmarking/queueing/rfdetr/gpu_study.py",
        )
        self.assertEqual(command[command.index("--threads") + 1], "0")
        self.assertEqual(command[command.index("--adapter") + 1], "compact")
        self.assertIn(
            str(self.directory / "source"), run.call_args.kwargs["env"]["PYTHONPATH"]
        )

    def test_main_freezes_once_and_requires_actual_tool_availability(self) -> None:
        arguments = [
            "gpu_experiment",
            "--store",
            str(self.root / "runs"),
            "--baseline",
            str(self.baseline),
            "--bundle",
            str(self.root),
        ]
        with (
            patch.object(sys, "argv", arguments),
            patch.object(experiment.os, "geteuid", return_value=0),
            patch.object(experiment.sys, "version_info", (3, 12)),
            patch.object(
                experiment.study.gpu_tools,
                "capabilities",
                return_value={"nsys": {"available": True}, "perf": {"available": True}},
            ),
            patch.object(experiment.study, "freeze") as freeze,
            patch.object(
                experiment, "execute", return_value={"complete": True}
            ) as execute,
        ):
            experiment.main()
        freeze.assert_called_once()
        plan = execute.call_args.args[0]
        self.assertFalse(plan.args.without_cuda)
        self.assertEqual(
            (
                plan.args.seconds,
                plan.args.repeat_seconds,
                plan.args.repeats,
                plan.args.concurrency,
            ),
            (10, 20, 3, 16),
        )
        self.assertEqual(plan.python, Path(sys.executable))
        self.assertTrue((plan.directory / "SUMMARY.json").exists())
        arguments[2] = str(self.root / "failed-runs")
        with (
            patch.object(sys, "argv", arguments),
            patch.object(experiment.os, "geteuid", return_value=0),
            patch.object(experiment.sys, "version_info", (3, 12)),
            patch.object(
                experiment.study.gpu_tools,
                "capabilities",
                return_value={"perf": {"available": True}},
            ),
            patch.object(experiment.study, "freeze") as freeze,
        ):
            with self.assertRaisesRegex(RuntimeError, "Nsight Systems and perf"):
                experiment.main()
        freeze.assert_not_called()
        failure = next((self.root / "failed-runs").glob("experiment-*/FAILED.json"))
        self.assertIn("Nsight", json.loads(failure.read_text())["message"])


if __name__ == "__main__":
    unittest.main()
