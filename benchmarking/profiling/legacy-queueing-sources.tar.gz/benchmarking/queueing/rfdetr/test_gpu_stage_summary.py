"""Measured-window stage validation uses synthetic records, never a model."""

import json
from pathlib import Path
import tempfile
import unittest

import gpu_stage_summary as summary


class SummaryTests(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.case = Path(directory.name)
        (self.case / "stages").mkdir()
        self.server = {"frontend": {"pid": 10}, "workers": [{"pid": 20}]}
        self.result = {
            "protocol": "rest",
            "requested_start_ns": 100,
            "drained_ns": 300,
            "total_drained": 1,
        }
        self.captures: dict = {}
        self.populate("rest")

    def row(self, pid: int, stage: str) -> dict:
        worker = pid == 20
        start, end = (150, 170) if worker else (120, 200)
        return {
            "pid": pid,
            "tid": pid,
            "stage": stage,
            "start_ns": start,
            "end_ns": end,
            "wall_ns": end - start,
            "thread_cpu_ns": None,
            "trace_id": None if worker else "10:1",
            "message_id": "internal-1",
            "succeeded": True,
        }

    def populate(self, protocol: str, adapter: str = "stock", version: int = 1) -> None:
        self.result["protocol"] = protocol
        self.result["adapter"] = adapter
        frontend, worker = summary._expected(self.result, version)
        expected = {10: frontend, 20: worker}
        for pid, stages in expected.items():
            records = [
                self.row(pid, stage)
                for stage, count in stages.items()
                for _ in range(count)
            ]
            warmup = {**records[0], "start_ns": 10, "end_ns": 20, "wall_ns": 10}
            records.append(warmup)
            self.captures[pid] = {
                "format_version": version,
                "pid": pid,
                "record_count": len(records),
                "overflow_records": 0,
                "collector_append_wall_ns": 10,
                "records": records,
            }
        self.write()

    def write(self) -> None:
        for pid, capture in self.captures.items():
            (self.case / "stages" / f"stages-{pid}.json").write_text(
                json.dumps(capture)
            )

    def collect(self) -> dict:
        self.write()
        return summary.collect(self.case, self.result, self.server)

    def test_rest_excludes_warmup_and_preserves_raw(self) -> None:
        self.result.pop("adapter")  # Legacy results do not have this field.
        before = (self.case / "stages" / "stages-20.json").read_bytes()
        result = self.collect()
        self.assertTrue(result["valid"])
        self.assertEqual(result["matched_message_ids"], 1)
        self.assertEqual(result["processes"]["20"]["excluded_record_count"], 1)
        self.assertEqual(
            result["processes"]["20"]["stages"]["numpy.output_lists"]["wall"]["count"],
            2,
        )
        self.assertEqual((self.case / "stages" / "stages-20.json").read_bytes(), before)
        self.assertTrue((self.case / "stage-summary.json").exists())

    def test_grpc_validates_both_raw_outputs(self) -> None:
        self.populate("grpc")
        result = self.collect()
        self.assertEqual(
            result["processes"]["10"]["stages"]["grpc.raw_pack"]["wall"]["count"], 2
        )

    def test_wrong_pid_files_fail(self) -> None:
        (self.case / "stages" / "stages-30.json").write_text("{}")
        with self.assertRaisesRegex(RuntimeError, "PIDs"):
            self.collect()

    def test_missing_capture_fails(self) -> None:
        (self.case / "stages" / "stages-20.json").unlink()
        with self.assertRaisesRegex(RuntimeError, "PIDs"):
            summary.collect(self.case, self.result, self.server)

    def test_overflow_and_failed_records_fail(self) -> None:
        for alteration in ("overflow", "exception"):
            with self.subTest(alteration=alteration):
                self.populate("rest")
                if alteration == "overflow":
                    self.captures[20]["overflow_records"] = 1
                else:
                    self.captures[20]["records"][0]["succeeded"] = False
                with self.assertRaises(RuntimeError):
                    self.collect()

    def test_missing_stage_and_mismatched_ids_fail(self) -> None:
        for alteration in ("stage", "message", "trace", "duplicates"):
            with self.subTest(alteration=alteration):
                self.populate("rest")
                if alteration == "stage":
                    self.captures[20]["records"][0]["stage"] = "unexpected"
                elif alteration == "message":
                    self.captures[20]["records"][0]["message_id"] = "wrong"
                elif alteration == "trace":
                    self.captures[10]["records"][0]["trace_id"] = "wrong"
                else:
                    self.result["total_drained"] = 2
                    for capture in self.captures.values():
                        capture["records"] += capture["records"][:-1]
                        capture["record_count"] = len(capture["records"])
                with self.assertRaises(RuntimeError):
                    self.collect()
                self.result["total_drained"] = 1

    def test_crossing_measurement_boundary_fails(self) -> None:
        row = self.captures[10]["records"][0]
        row.update(start_ns=90, wall_ns=row["end_ns"] - 90)
        with self.assertRaisesRegex(RuntimeError, "crosses"):
            self.collect()

    def test_zero_nvtx_id_is_reported_without_claiming_capture(self) -> None:
        self.captures[20]["records"][0]["nvtx_range_id"] = 0
        result = self.collect()
        self.assertEqual(result["processes"]["20"]["nvtx_zero_ids"], 1)

    def test_version_two_stock_and_buffers_rest_retain_two_body_calls(self) -> None:
        for adapter in ("stock", "buffers"):
            with self.subTest(adapter=adapter):
                self.populate("rest", adapter, 2)
                result = self.collect()
                self.assertEqual(result["capture_format_version"], 2)
                self.assertEqual(result["adapter"], adapter)
                self.assertEqual(
                    result["processes"]["10"]["stages"]["rest.body.inclusive"]["wall"][
                        "count"
                    ],
                    2,
                )

    def test_worker_json_rest_moves_dataplane_and_json_work_to_worker(self) -> None:
        for adapter in ("worker-json", "compact"):
            with self.subTest(adapter=adapter):
                self.populate("rest", adapter, 2)
                result = self.collect()
                frontend = result["processes"]["10"]["stages"]
                worker = result["processes"]["20"]["stages"]
                self.assertEqual(
                    set(frontend),
                    {
                        "rest.route.inclusive",
                        "rest.body.inclusive",
                        "dispatch.wait.inclusive",
                    },
                )
                for name in (
                    "dataplane.infer.inclusive",
                    "worker.json.decode.inclusive",
                    "worker.json.encode.inclusive",
                ):
                    self.assertEqual(worker[name]["wall"]["count"], 1)

    def test_buffers_grpc_omits_raw_unpack_and_worker_json_grpc_retains_it(
        self,
    ) -> None:
        for adapter in ("stock", "buffers", "worker-json", "compact"):
            with self.subTest(adapter=adapter):
                self.populate("grpc", adapter, 2)
                result = self.collect()
                frontend = result["processes"]["10"]["stages"]
                self.assertEqual(
                    "grpc.raw_unpack" in frontend, adapter in ("stock", "worker-json")
                )
                self.assertNotIn(
                    "worker.json.decode.inclusive", result["processes"]["20"]["stages"]
                )

    def test_inconsistent_versions_and_unknown_adapters_fail(self) -> None:
        self.captures[20]["format_version"] = 2
        with self.assertRaisesRegex(RuntimeError, "Inconsistent"):
            self.collect()
        self.populate("rest")
        self.result["adapter"] = "unknown"
        with self.assertRaisesRegex(RuntimeError, "Unknown stage adapter"):
            self.collect()

    def test_optimized_adapter_cannot_claim_legacy_instrumentation(self) -> None:
        self.result["adapter"] = "worker-json"
        with self.assertRaisesRegex(RuntimeError, "format 2"):
            self.collect()

    def test_missing_new_body_and_worker_json_spans_fail(self) -> None:
        for adapter, pid, stage in (
            ("stock", 10, "rest.body.inclusive"),
            ("worker-json", 20, "worker.json.decode.inclusive"),
            ("worker-json", 20, "worker.json.encode.inclusive"),
            ("worker-json", 20, "dataplane.infer.inclusive"),
        ):
            with self.subTest(adapter=adapter, stage=stage):
                self.populate("rest", adapter, 2)
                capture = self.captures[pid]
                capture["records"] = [
                    row for row in capture["records"] if row["stage"] != stage
                ]
                capture["record_count"] = len(capture["records"])
                with self.assertRaisesRegex(RuntimeError, "count mismatch"):
                    self.collect()

    def test_extra_worker_spans_must_have_matching_message_and_containment(
        self,
    ) -> None:
        for field, value in (("message_id", "wrong"), ("pid", 30), ("start_ns", 140)):
            with self.subTest(field=field):
                self.populate("rest", "worker-json", 2)
                row = next(
                    row
                    for row in self.captures[20]["records"]
                    if row["stage"] == "worker.json.decode.inclusive"
                )
                row[field] = value
                row["wall_ns"] = row["end_ns"] - row["start_ns"]
                with self.assertRaises(RuntimeError):
                    self.collect()


if __name__ == "__main__":
    unittest.main()
