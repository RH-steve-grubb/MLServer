"""Autonomous root-run baseline, tuning, and hotspot capture plan.

Every child invocation uses the same Python and frozen source. Winners from
the first screening sweep are provisional, not final before/after evidence.
"""

import argparse
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from typing import Any

import gpu_study as study


@dataclass
class Plan:
    args: argparse.Namespace
    directory: Path
    python: Path
    steps: list[dict[str, Any]] = field(default_factory=list)

    def record(self) -> None:
        study.publish(
            self.directory / "PLAN.json",
            {
                "python": str(self.python),
                "source": str(self.directory / "source"),
                "bundle": str(self.args.bundle),
                "user": self.args.user,
                "seconds": self.args.seconds,
                "concurrency": self.args.concurrency,
                "gpu_timeline_pending": self.args.without_cuda,
                "steps": self.steps,
                "scope": "single GPU, RF-DETR FP32/B1, CPython 3.12 with GIL",
                "settings_changes": "none",
            },
        )

    def run(self, label: str, options: list[str]) -> tuple[dict[str, Any], Path]:
        store = self.directory / "steps" / label
        store.mkdir(parents=True, exist_ok=False)
        source = self.directory / "source"
        harness = source / "benchmarking" / "queueing" / "rfdetr"
        command = [
            str(self.python),
            str(harness / "gpu_study.py"),
            "--python",
            str(self.python),
            "--bundle",
            str(self.args.bundle),
            "--store",
            str(store),
            "--user",
            self.args.user,
            *options,
        ]
        entry: dict[str, Any] = {
            "label": label,
            "command": command,
            "status": "running",
        }
        self.steps.append(entry)
        self.record()
        environment = {
            key: value
            for key, value in os.environ.items()
            if not key.startswith(("MLSERVER_", "PYTHON"))
        }
        environment.update(
            PYTHONDONTWRITEBYTECODE="1",
            PYTHONUNBUFFERED="1",
            PYTHONPATH=os.pathsep.join(
                [str(source), str(source / "runtimes" / "onnx"), str(harness)]
            ),
        )
        print(f"Starting {label}; child store: {store}", flush=True)
        try:
            # Inherit stdout/stderr so long captures remain visible. The child
            # owns its servers, scopes, clients, and exception cleanup.
            subprocess.run(command, cwd=self.directory, env=environment, check=True)
            runs = sorted(store.glob("run-*"))
            if len(runs) != 1:
                raise RuntimeError(f"Expected one fresh child run in {store}")
            summary_path = runs[0] / "SUMMARY.json"
            summary = json.loads(summary_path.read_text())
            expected_phase = options[options.index("--phase") + 1]
            if summary.get("phase") != expected_phase:
                raise RuntimeError(f"Child summary phase mismatch in {summary_path}")
        except BaseException:
            entry["status"] = "failed"
            self.record()
            raise
        entry.update(status="complete", summary=str(summary_path))
        self.record()
        return summary, summary_path


def choose_winners(summary: dict[str, Any]) -> dict[str, dict[str, Any]]:
    rows = summary.get("results", [])
    if len(rows) != 20:
        raise RuntimeError("Initial tune sweep must contain all 20 configurations")
    winners = {}
    expected = {(1, None), *((w, t) for w in (1, 2, 4) for t in (1, 2, 4))}
    for protocol in ("rest", "grpc"):
        candidates = [row for row in rows if row.get("protocol") == protocol]
        seen = {(row.get("workers"), row.get("threads")) for row in candidates}
        if len(candidates) != 10 or seen != expected:
            raise RuntimeError(
                f"Incomplete or duplicate {protocol} tuning configurations"
            )
        for row in candidates:
            if row.get("profiled") or not math.isfinite(row["rps"]) or row["rps"] <= 0:
                raise RuntimeError(
                    f"Invalid unprofiled screening result for {protocol}"
                )
        winner = max(candidates, key=lambda row: row["rps"])
        winners[protocol] = {
            "protocol": protocol,
            "workers": winner["workers"],
            "threads": winner["threads"],
            "screening_rps": winner["rps"],
            "screening_latency_ms": winner["latency_ms"],
            "provisional": True,
            "client_headroom_needs_confirmation": winner.get(
                "client_headroom_needs_confirmation", False
            ),
        }
    return winners


def execute(plan: Plan) -> dict[str, Any]:
    qualification = None
    if not plan.args.without_cuda:
        _, path = plan.run(
            "cuda-qualification",
            [
                "--phase",
                "cuda",
                "--protocol",
                "both",
                "--seconds",
                "1",
                "--concurrency",
                "2",
                "--requests",
                "4",
                "--workers",
                "1",
                "--threads",
                "2",
            ],
        )
        qualification = str(path)
    concurrency = plan.args.concurrency
    # gpu_study requires fixed request totals divisible by concurrency. This is
    # only its pilot count; the measured count is sized from that pilot's RPS.
    requests = max(1, math.ceil(32 / concurrency)) * concurrency
    common = [
        "--seconds",
        str(plan.args.seconds),
        "--concurrency",
        str(concurrency),
        "--requests",
        str(requests),
    ]
    tuning, tuning_path = plan.run(
        "tune", ["--phase", "tune", "--protocol", "both", "--clients", "2", *common]
    )
    winners = choose_winners(tuning)
    # Save the selection before expensive captures, including when a later
    # phase fails. The complete child measurements remain alongside this file.
    study.publish(plan.directory / "WINNERS.json", winners)
    captures = {}
    for protocol, winner in winners.items():
        selected = [
            "--protocol",
            protocol,
            "--workers",
            str(winner["workers"]),
            "--threads",
            str(winner["threads"] or 0),
            *common,
        ]
        control, control_path = plan.run(
            f"{protocol}-client-control",
            ["--phase", "smoke", "--clients", "4", *selected],
        )
        control_rows = control.get("results", [])
        if len(control_rows) != 1 or control_rows[0].get("protocol") != protocol:
            raise RuntimeError(f"Invalid matched-client control summary for {protocol}")
        control_rps = control_rows[0]["rps"]
        winner["four_client_control"] = str(control_path)
        winner["four_client_control_rps"] = control_rps
        winner["four_client_to_screening_rps_ratio"] = (
            control_rps / winner["screening_rps"]
        )
        winner["client_headroom_needs_confirmation"] |= bool(
            control_rows[0].get("client_headroom_needs_confirmation")
            or control_rps > 1.05 * winner["screening_rps"]
        )
        study.publish(plan.directory / "WINNERS.json", winners)
        paths = {"client_control": str(control_path)}
        phases = [
            ("cpu", ["--phase", "profile", "--capture", "cpu"]),
            ("gil", ["--phase", "profile", "--capture", "gil"]),
            ("stages", ["--phase", "stages"]),
        ]
        if not plan.args.without_cuda:
            phases.append(("cuda", ["--phase", "cuda"]))
        for name, options in phases:
            _, path = plan.run(
                f"{protocol}-{name}", [*options, "--clients", "2", *selected]
            )
            paths[name] = str(path)
        captures[protocol] = paths
    return {
        "purpose": "Initial GPU serving baseline and diagnostic evidence",
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "tuning": str(tuning_path),
        "cuda_qualification": qualification,
        "gpu_timeline_pending": plan.args.without_cuda,
        "winners": winners,
        "captures": captures,
        "interpretation": (
            "Winners are provisional screening results. Capture throughput is "
            "diagnostic only; repeated final before/after measurements follow "
            "hotspot analysis and implementation."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=study.DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--concurrency", type=int, default=16)
    parser.add_argument("--user", default="codex")
    parser.add_argument("--without-cuda", action="store_true")
    args = parser.parse_args()
    if os.geteuid() != 0 or sys.version_info[:2] != (3, 12):
        parser.error("Run as root with the pinned serving environment's Python 3.12")
    if not math.isfinite(args.seconds) or args.seconds <= 0:
        parser.error("Measurement seconds must be finite and positive")
    if args.concurrency < 4 or args.concurrency % 4:
        parser.error(
            "Concurrency must be >= 4 and divisible by four for client controls"
        )
    os.umask(0o022)
    args.bundle = args.bundle.resolve()
    args.store = args.store.resolve()
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"plan-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"Plan output: {directory}", flush=True)
    try:
        capabilities = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", capabilities)
        if not args.without_cuda and not capabilities["nsys"]["available"]:
            raise RuntimeError(
                "Nsight Systems is unavailable. Repair its payload before this plan, "
                "or explicitly use --without-cuda to leave the GPU timeline pending. "
                + str(capabilities.get("nsight_repair_recommendation", ""))
            )
        if not capabilities.get("perf", {}).get("available"):
            raise RuntimeError("A working perf executable is required before this plan")
        study.freeze(directory)
        result = execute(plan)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
