"""Opt-in reuse of the earlier worker JSON adapter for the RF-DETR study.

Install before gpu_stages so its worker span encloses parsing, inference, and
response encoding. IPC transport and model/version routing remain shared
with the original diagnostic; no alternate HTTP framework is introduced.
"""

from functools import wraps
import os
from pathlib import Path
import sys
from typing import Any

_INSTALLED = False
_SETTINGS = {
    "MLSERVER_QUEUE_JSON": "full",
    "MLSERVER_QUEUE_CODEC": "pickle",
    "MLSERVER_QUEUE_TENSORS": "list",
}


def install() -> bool:
    """Enable worker JSON only for the selected GPU study representation."""
    global _INSTALLED
    if os.environ.get("MLSERVER_GPU_ADAPTER") not in ("worker-json", "compact"):
        return False
    transport = os.environ.get("MLSERVER_GPU_TRANSPORT", "queue")
    if transport not in ("queue", "zmq"):
        raise ValueError(f"Unknown GPU transport: {transport}")
    settings = {**_SETTINGS, "MLSERVER_QUEUE_TRANSPORT": transport}
    for key, expected in settings.items():
        if os.environ.get(key, expected) != expected:
            raise ValueError(f"Worker JSON requires {key}={expected}")
    if _INSTALLED:
        return True
    stages = sys.modules.get("gpu_stages")
    if stages is not None and getattr(stages, "_INSTALLED", False):
        raise RuntimeError("Install worker JSON before gpu_stages")

    # Directly executed and frozen harnesses start with the rfdetr directory on
    # sys.path. Its parent contains the shared, spawn-importable raw_worker.
    queueing = str(Path(__file__).resolve().parent.parent)
    if queueing not in sys.path:
        sys.path.insert(0, queueing)
    import raw_worker
    from mlserver.rest import RESTServer

    os.environ.update(settings)
    raw_worker.install()
    original = RESTServer.__init__

    @wraps(original)
    def initialized(self: Any, *args: Any, **kwargs: Any) -> None:
        original(self, *args, **kwargs)
        raw_worker.install_routes(self, self._data_plane._model_registry)

    setattr(RESTServer, "__init__", initialized)
    _INSTALLED = True
    return True
