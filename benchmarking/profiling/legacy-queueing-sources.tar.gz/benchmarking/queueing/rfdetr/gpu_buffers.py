"""Opt-in RF-DETR gRPC experiment: preserve numeric buffers through queue IPC.

This is a benchmark adapter, not a generic TensorData representation change.
Only the known FP32 raw-input path is altered; normal worker NumPy decoding
still copies/reshapes the array before the unchanged ONNX runtime sees it.
"""

from collections.abc import Callable
from contextvars import ContextVar
import functools
import math
import os

import numpy as np

from mlserver.codecs.utils import InputOrOutput
from mlserver.grpc import converters
from mlserver.grpc import dataplane_pb2 as pb
from mlserver.grpc.converters import ModelInferRequestConverter
from mlserver.types import InferenceRequest, TensorData

_RAW_INPUTS: ContextVar[tuple[bytes, ...] | None] = ContextVar(
    "gpu_buffer_inject_inputs", default=None
)


def _install_inject() -> None:
    original = converters.inject_raw
    if getattr(original, "_gpu_buffer_inject", False):
        return

    @functools.wraps(original)
    def inject_raw(
        elems: list[InputOrOutput], raw_contents: list[bytes]
    ) -> list[InputOrOutput]:
        raw_inputs = _RAW_INPUTS.get()
        if raw_inputs is None:
            return original(elems, raw_contents)
        # convert() validated these inputs before entering the scoped seam.
        # This wrapper stays installed; no request swaps a global function.
        for elem, raw in zip(elems, raw_inputs):
            elem.data = TensorData.model_construct(root=np.frombuffer(raw, dtype="<f4"))
        return elems

    setattr(inject_raw, "_gpu_buffer_inject", True)
    setattr(converters, "inject_raw", inject_raw)


def _call_original(
    request: pb.ModelInferRequest,
    original: Callable[[pb.ModelInferRequest], InferenceRequest],
    raw_inputs: tuple[bytes, ...] | None = None,
) -> InferenceRequest:
    if raw_inputs is None and _RAW_INPUTS.get() is None:
        return original(request)
    # Clear an outer request's context for fallback/control calls. Tokens also
    # restore a nested caller's buffers after successful or exceptional returns.
    token = _RAW_INPUTS.set(raw_inputs)
    try:
        return original(request)
    finally:
        _RAW_INPUTS.reset(token)


def convert(
    request: pb.ModelInferRequest,
    original: Callable[[pb.ModelInferRequest], InferenceRequest],
    metadata_only: bool = False,
    buffer_inject: bool = False,
) -> InferenceRequest:
    """Preserve supported raw FP32 inputs, delegating every other case unchanged."""
    if metadata_only and buffer_inject:
        raise ValueError("metadata_only and buffer_inject are mutually exclusive")
    if request.model_name != "rfdetr-small" or not request.inputs:
        return _call_original(request, original)
    # Protobuf byte fields may materialize Python buffers on access. Retain
    # them once in the new mode so validation and conversion use the same bytes.
    raw_contents = (
        tuple(request.raw_input_contents)
        if metadata_only or buffer_inject
        else request.raw_input_contents
    )
    if len(raw_contents) != len(request.inputs):
        return _call_original(request, original)
    for tensor, raw in zip(request.inputs, raw_contents):
        if (
            tensor.datatype != "FP32"
            or tensor.contents.ListFields()
            or any(dimension < 0 for dimension in tensor.shape)
            or math.prod(tensor.shape) * 4 != len(raw)
        ):
            return _call_original(request, original)

    if buffer_inject:
        _install_inject()
        return _call_original(request, original, tuple(raw_contents))

    # Both modes delegate metadata semantics to the original converter. The
    # opt-in constructor excludes raw data before copying, avoiding the large
    # CopyFrom allocation which the original comparison path retains.
    if metadata_only:
        metadata = pb.ModelInferRequest(
            **{
                field.name: value
                for field, value in request.ListFields()
                if field.name != "raw_input_contents"
            }
        )
    else:
        metadata = pb.ModelInferRequest()
        metadata.CopyFrom(request)
        metadata.ClearField("raw_input_contents")
    converted = _call_original(metadata, original)
    for converted_tensor, raw in zip(converted.inputs, raw_contents):
        converted_tensor.data = TensorData.model_construct(
            root=np.frombuffer(raw, dtype="<f4")
        )
    return converted


def install() -> None:
    """Install once only when the study launcher explicitly selects this adapter."""
    if os.environ.get("MLSERVER_GPU_ADAPTER") not in ("buffers", "compact"):
        return
    selected = os.environ.get("MLSERVER_GPU_METADATA_ONLY", "0")
    if selected not in ("0", "1"):
        raise ValueError("MLSERVER_GPU_METADATA_ONLY must be 0 or 1")
    metadata_only = selected == "1"
    inject = os.environ.get("MLSERVER_GPU_BUFFER_INJECT", "0")
    if inject not in ("0", "1"):
        raise ValueError("MLSERVER_GPU_BUFFER_INJECT must be 0 or 1")
    buffer_inject = inject == "1"
    if metadata_only and buffer_inject:
        raise ValueError("Metadata-only and buffer-inject modes are mutually exclusive")
    original = ModelInferRequestConverter.__dict__["to_types"].__func__
    if getattr(original, "_gpu_buffers", False):
        if getattr(original, "_gpu_metadata_only", False) != metadata_only:
            raise RuntimeError("Cannot change metadata-copy mode after installation")
        if getattr(original, "_gpu_buffer_inject", False) != buffer_inject:
            raise RuntimeError("Cannot change buffer-injection mode after installation")
        # functools.wraps propagates these markers through stage decorators.
        # Keep that decorated callable in place on subsequent installation.
        return
    if buffer_inject:
        _install_inject()

    @functools.wraps(original)
    def to_types(
        cls: type[ModelInferRequestConverter], pb_object: pb.ModelInferRequest
    ) -> InferenceRequest:
        return convert(
            pb_object, lambda value: original(cls, value), metadata_only, buffer_inject
        )

    setattr(to_types, "_gpu_buffers", True)
    setattr(to_types, "_gpu_metadata_only", metadata_only)
    setattr(to_types, "_gpu_buffer_inject", buffer_inject)
    setattr(ModelInferRequestConverter, "to_types", classmethod(to_types))
