"""Isolated model-only CUDA screening; results are not REST/gRPC throughput.

Keep the existing RF-DETR model, FP32 inputs/outputs and TF32 policy. Compare
ordinary Run, persistent I/O binding, CUDA graph replay, and NHWC preference.
Optional blocking-sync variants test a CPU-wait policy without changing kernels.
"""

import argparse
import ctypes
from datetime import datetime, timezone
import importlib.metadata as metadata
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import sysconfig
import time
import traceback
from typing import Any

import numpy as np
import onnxruntime as ort

import gpu_tools
from prepare import checksum, compare_detections
from serve import serving_environment
import gpu_study as study
from validate import decoded

DEFAULT_VARIANTS = ("run", "binding", "cuda-graph", "nhwc")
VARIANTS = DEFAULT_VARIANTS + ("run-blocking", "cuda-graph-blocking")
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-engine-screen-20261026"


class UnsupportedVariant(RuntimeError):
    pass


class IncorrectOutput(RuntimeError):
    pass


def base_variant(variant: str) -> str:
    if variant not in VARIANTS:
        raise ValueError(f"Unknown variant: {variant}")
    return variant.removesuffix("-blocking")


def cuda_check(runtime: Any, status: int, operation: str) -> None:
    if status:
        description = runtime.cudaGetErrorString(status)
        detail = description.decode(errors="replace") if description else "unknown"
        raise UnsupportedVariant(f"{operation} failed: CUDA {status}: {detail}")


def device_flags(runtime: Any) -> int:
    flags = ctypes.c_uint()
    cuda_check(
        runtime, runtime.cudaGetDeviceFlags(ctypes.byref(flags)), "cudaGetDeviceFlags"
    )
    # CUDA may also return the implicit MapHost flag. Only the three scheduling
    # bits determine blocking/yield/spin behavior; do not demand exact equality.
    if flags.value & 7 != 4:
        raise UnsupportedVariant(f"Blocking sync was not honored: flags={flags.value}")
    return flags.value


def cuda_runtime(path: Path) -> Any:
    try:
        runtime = ctypes.CDLL(str(path.resolve(strict=True)))
        runtime.cudaSetDeviceFlags.argtypes = [ctypes.c_uint]
        runtime.cudaSetDeviceFlags.restype = ctypes.c_int
        runtime.cudaGetDeviceFlags.argtypes = [ctypes.POINTER(ctypes.c_uint)]
        runtime.cudaGetDeviceFlags.restype = ctypes.c_int
        runtime.cudaGetErrorString.argtypes = [ctypes.c_int]
        runtime.cudaGetErrorString.restype = ctypes.c_char_p
    except (OSError, AttributeError) as error:
        raise UnsupportedVariant(
            f"CUDA runtime unavailable at {path}: {error}"
        ) from error
    return runtime


def cuda_flags(library: str) -> int:
    """Read and validate blocking scheduling after serving/session setup."""
    return device_flags(cuda_runtime(Path(library)))


def blocking_sync() -> tuple[Any, dict]:
    """Set this isolated process's device policy before ORT creates its session.

    CUDA 12 documents scheduling bits and the implicit MapHost bit here:
    https://docs.nvidia.com/cuda/archive/12.9.1/cuda-runtime-api/group__CUDART__DEVICE.html
    """
    distribution = metadata.distribution("nvidia-cuda-runtime-cu12")
    path = Path(
        str(distribution.locate_file("nvidia/cuda_runtime/lib/libcudart.so.12"))
    )
    runtime = cuda_runtime(path)
    cuda_check(runtime, runtime.cudaSetDeviceFlags(4), "cudaSetDeviceFlags(4)")
    return runtime, {
        "library": str(path.resolve()),
        "wheel_version": distribution.version,
        "requested_flags": 4,
        "before_session_flags": device_flags(runtime),
        "scope": "Current CUDA device/context in this isolated worker process",
    }


def configure_blocking_sync() -> dict:
    """JSON receipt for the same policy used by the opt-in serving adapter."""
    _, information = blocking_sync()
    return information


def session(model: Path, variant: str) -> tuple[Any, dict[str, Any]]:
    ordinary = base_variant(variant)
    runtime, scheduling = (
        blocking_sync()
        if variant.endswith("-blocking")
        else (None, {"policy": "unchanged"})
    )
    options = ort.SessionOptions()
    options.intra_op_num_threads, options.inter_op_num_threads = 2, 1
    options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    options.enable_cpu_mem_arena = options.enable_mem_pattern = True
    entries = {
        "session.intra_op.allow_spinning": "0",
        "session.inter_op.allow_spinning": "0",
        "session.disable_cpu_ep_fallback": "1",
    }
    for key, value in entries.items():
        options.add_session_config_entry(key, value)
    requested = {
        "device_id": "0",
        "use_tf32": "1",
        "enable_cuda_graph": "1" if ordinary == "cuda-graph" else "0",
        "prefer_nhwc": "1" if ordinary == "nhwc" else "0",
    }
    loaded = ort.InferenceSession(
        str(model),
        sess_options=options,
        providers=["CUDAExecutionProvider"],
        provider_options=[requested],
    )
    loaded.disable_fallback()
    providers = loaded.get_providers()
    if not providers or providers[0] != "CUDAExecutionProvider":
        raise UnsupportedVariant(f"CUDA initialization failed: {providers}")
    actual = loaded.get_provider_options()
    if any(
        actual["CUDAExecutionProvider"].get(key) != value
        for key, value in requested.items()
    ):
        raise UnsupportedVariant(f"CUDA options were not honored: {actual}")
    active = loaded.get_session_options()
    active_entries = {key: active.get_session_config_entry(key) for key in entries}
    if active_entries != entries:
        raise UnsupportedVariant(
            f"Session config entries were not honored: {active_entries}"
        )
    fixed = (
        "intra_op_num_threads",
        "inter_op_num_threads",
        "graph_optimization_level",
        "execution_mode",
        "enable_cpu_mem_arena",
        "enable_mem_pattern",
    )
    if any(getattr(active, key) != getattr(options, key) for key in fixed):
        raise UnsupportedVariant("Fixed session settings were not honored")
    if runtime is not None:
        scheduling["after_session_flags"] = device_flags(runtime)
    return loaded, {
        "cuda_scheduling": scheduling,
        "providers": providers,
        "provider_options": actual,
        "requested_cuda_options": requested,
        "session_options": {
            "intra_op_threads": active.intra_op_num_threads,
            "inter_op_threads": active.inter_op_num_threads,
            "graph_optimization_level": str(active.graph_optimization_level),
            "execution_mode": str(active.execution_mode),
            "enable_cpu_mem_arena": active.enable_cpu_mem_arena,
            "enable_mem_pattern": active.enable_mem_pattern,
            "config_entries": active_entries,
        },
        "fallback_policy": (
            "CPU registration is allowed; session.disable_cpu_ep_fallback=1 "
            "forbids assigning nodes to CPU"
        ),
    }


class Runner:
    def __init__(self, loaded: Any, variant: str, tensor: np.ndarray) -> None:
        variant = base_variant(variant)
        self.session = loaded
        inputs, outputs = loaded.get_inputs(), loaded.get_outputs()
        if (
            len(inputs) != 1
            or inputs[0].shape != list(tensor.shape)
            or inputs[0].type != "tensor(float)"
        ):
            raise UnsupportedVariant("Expected one fixed-shape FP32 model input")
        if {item.name for item in outputs} != {"dets", "labels"}:
            raise UnsupportedVariant("Expected both RF-DETR outputs")
        self.input_name = inputs[0].name
        self.names = [item.name for item in outputs]
        self.binding = None
        self.device_input = None
        self.device_outputs = []
        if variant in ("binding", "cuda-graph"):
            self.binding = loaded.io_binding()
            self.device_input = ort.OrtValue.ortvalue_from_numpy(tensor, "cuda", 0)
            self.binding.bind_ortvalue_input(self.input_name, self.device_input)
            for item in outputs:
                if item.type != "tensor(float)" or not all(
                    isinstance(d, int) and d > 0 for d in item.shape
                ):
                    raise UnsupportedVariant("I/O binding requires fixed FP32 outputs")
                value = ort.OrtValue.ortvalue_from_shape_and_type(
                    item.shape, np.float32, "cuda", 0
                )
                self.device_outputs.append(value)
                self.binding.bind_ortvalue_output(item.name, value)

    def __call__(self, tensor: np.ndarray) -> dict[str, np.ndarray]:
        if self.binding is None:
            values = self.session.run(self.names, {self.input_name: tensor})
        else:
            # Capture/replay reads these same device addresses. Refresh their
            # contents even when the caller reuses the same host array object.
            if self.device_input is None:
                raise RuntimeError("Persistent input buffer is missing")
            self.device_input.update_inplace(tensor)
            self.binding.synchronize_inputs()
            self.session.run_with_iobinding(self.binding)
            self.binding.synchronize_outputs()
            # Downloads belong to end-to-end model timing, not validation.
            values = self.binding.copy_outputs_to_cpu()
        return dict(zip(self.names, values))


def validate_outputs(actual: dict, shapes: dict) -> None:
    """Validate oracle arrays too, before they become numerical references."""
    if set(actual) != set(shapes):
        raise IncorrectOutput("Missing model outputs")
    for name, shape in shapes.items():
        value = actual[name]
        if (
            not isinstance(value, np.ndarray)
            or value.dtype != np.float32
            or tuple(value.shape) != tuple(shape)
            or not np.isfinite(value).all()
        ):
            raise IncorrectOutput(f"Invalid FP32 output shape or values: {name}")


def check_outputs(actual: dict, expected: dict) -> None:
    validate_outputs(actual, {name: value.shape for name, value in expected.items()})
    for name, target in expected.items():
        try:
            np.testing.assert_allclose(
                actual[name], target, rtol=1e-3, atol=1e-3, equal_nan=False
            )
        except AssertionError as error:
            raise IncorrectOutput(f"Numerical mismatch: {name}: {error}") from error


def check_detections(expected: dict, actual: dict) -> None:
    try:
        compare_detections(expected, actual)
    except ValueError as error:
        raise IncorrectOutput(f"Detection mismatch: {error}") from error


def detection_parity(actual: dict, expected: dict, size: list[int]) -> dict:
    """Diagnostic only: matching decoded detections cannot waive raw checks."""
    try:
        validate_outputs(actual, {key: value.shape for key, value in expected.items()})
        check_detections(decoded(expected, size), decoded(actual, size))
    except Exception as error:
        return {
            "passed": False,
            "error_type": type(error).__name__,
            "error": str(error),
        }
    return {"passed": True}


def verify(runner: Any, tensors: dict, expected: dict, size: list[int]) -> None:
    for name in ("original", "mirrored", "original"):
        actual = runner(tensors[name])
        check_outputs(actual, expected[name])
        check_detections(decoded(expected[name], size), decoded(actual, size))


def warmup(runner: Any, tensor: np.ndarray) -> dict:
    began, calls = time.perf_counter_ns(), 0
    while calls < 5 or time.perf_counter_ns() - began < 1_000_000_000:
        runner(tensor)
        calls += 1
    return {"warmup_calls": calls, "warmup_ns": time.perf_counter_ns() - began}


def measure(runner: Any, tensor: np.ndarray, seconds: float) -> tuple[dict, dict]:
    latencies = []
    measurement_started_ns = time.monotonic_ns()
    began, cpu = time.perf_counter_ns(), time.process_time_ns()
    deadline = began + int(seconds * 1e9)
    last = None
    while time.perf_counter_ns() < deadline:
        start = time.perf_counter_ns()
        last = runner(tensor)
        latencies.append(time.perf_counter_ns() - start)
    ended, cpu_ended = time.perf_counter_ns(), time.process_time_ns()
    measurement_drained_ns = time.monotonic_ns()
    if not latencies or last is None:
        raise RuntimeError("No completed model calls in measured window")
    return {
        "calls": len(latencies),
        "measurement_started_ns": measurement_started_ns,
        "measurement_drained_ns": measurement_drained_ns,
        "duration_seconds": (ended - began) / 1e9,
        "model_calls_per_second": len(latencies) * 1e9 / (ended - began),
        "process_cpu_seconds": (cpu_ended - cpu) / 1e9,
        "process_cpu_scope": "Includes in-process telemetry sampler bookkeeping; "
        "excludes nvidia-smi child CPU. Includes CUDA host wait CPU time, which "
        "may involve busy-waiting; this metric alone does not establish spinning.",
        "latency_ms": {
            "mean": float(np.mean(latencies) / 1e6),
            **{f"p{p}": float(np.percentile(latencies, p) / 1e6) for p in (50, 95, 99)},
        },
        "latencies_ns": latencies,
    }, last


def run_case(spec: dict) -> dict[str, Any]:
    output, bundle = Path(spec["output"]), Path(spec["bundle"])
    result: dict[str, Any] = {
        "variant": spec["variant"],
        "status": "failed",
        "phase": "input",
        "pid": os.getpid(),
        "uid": os.geteuid(),
        "python": sys.version,
        "executable": sys.executable,
        "affinity": sorted(os.sched_getaffinity(0)),
        "versions": {
            name: metadata.version(name)
            for name in ("onnxruntime-gpu", "onnx", "numpy")
        },
    }
    try:
        if (
            checksum(bundle / "model/model.onnx") != spec["model_sha256"]
            or checksum(bundle / "sample/input.npy") != spec["input_sha256"]
        ):
            raise RuntimeError("Immutable model or input hash mismatch")
        original = np.load(bundle / "sample/input.npy", allow_pickle=False)
        if original.dtype != np.float32 or original.shape != (1, 3, 512, 512):
            raise ValueError("Expected the prepared normalized FP32/B1 input")
        tensors = {
            "original": original,
            "mirrored": np.ascontiguousarray(original[..., ::-1]),
        }
        if np.array_equal(tensors["original"], tensors["mirrored"]):
            raise IncorrectOutput("Mirrored input is not distinct")
        result["phase"] = "session"
        began = time.perf_counter_ns()
        loaded, information = session(bundle / "model/model.onnx", spec["variant"])
        result.update(information, session_startup_ns=time.perf_counter_ns() - began)
        result["phase"] = "binding_setup"
        began = time.perf_counter_ns()
        runner = Runner(loaded, spec["variant"], original)
        result["binding_setup_ns"] = time.perf_counter_ns() - began
        result["phase"] = "first_run_or_capture"
        began = time.perf_counter_ns()
        first = runner(original)
        result["first_run_or_capture_ns"] = time.perf_counter_ns() - began
        result["phase"] = "first_output_save"
        np.savez(output / "first-original.npz", **first)
        manifest = json.loads((bundle / "manifest.json").read_text())
        size = manifest["sample"]["image_size_wh"]
        shapes = {item["name"]: item["shape"] for item in manifest["onnx"]["outputs"]}
        result["phase"] = "correctness"
        if spec.get("oracle"):
            expected = {"original": first, "mirrored": runner(tensors["mirrored"])}
            np.savez(output / "first-mirrored.npz", **expected["mirrored"])
            for values in expected.values():
                validate_outputs(values, shapes)
            fixture = json.loads(
                (bundle / "reference/pytorch-detections.json").read_text()
            )
            check_detections(fixture, decoded(first, size))
            if all(
                np.allclose(
                    expected["original"][name],
                    expected["mirrored"][name],
                    rtol=1e-3,
                    atol=1e-3,
                )
                for name in first
            ):
                raise IncorrectOutput(
                    "Oracle outputs cannot distinguish the changed input"
                )
            for name, values in expected.items():
                np.savez(output / f"{name}.npz", **values)
            result.update(status="ok", phase="oracle_complete")
        else:
            expected = {}
            for name in tensors:
                with np.load(
                    Path(spec["reference"]) / f"{name}.npz", allow_pickle=False
                ) as archive:
                    expected[name] = {key: archive[key] for key in archive.files}
                validate_outputs(expected[name], shapes)
            # Preserve both actual outputs even when the first raw comparison
            # fails, so query ordering can be investigated without relaxing it.
            mirror = runner(tensors["mirrored"])
            np.savez(output / "first-mirrored.npz", **mirror)
            result["semantic_detection_parity"] = {
                name: detection_parity(values, expected[name], size)
                for name, values in (("original", first), ("mirrored", mirror))
            }
            check_outputs(first, expected["original"])
            verify(runner, tensors, expected, size)
            result["correctness_sequence"] = ["original", "mirrored", "original"]
            result["phase"] = "warmup"
            result.update(warmup(runner, original))
            result["phase"] = "measurement"
            with gpu_tools.sampling(output):
                measured, last = measure(runner, original, spec["seconds"])
            np.save(output / "latencies-ns.npy", measured.pop("latencies_ns"))
            check_outputs(last, expected["original"])
            result.update(measured, status="ok", phase="complete")
    except Exception as error:
        result.update(
            status=(
                "unsupported"
                if isinstance(error, UnsupportedVariant)
                else "incorrect" if isinstance(error, IncorrectOutput) else "failed"
            ),
            capability_check_failed=base_variant(spec["variant"]) == "cuda-graph"
            and result["phase"] in ("session", "binding_setup", "first_run_or_capture"),
            error_type=type(error).__name__,
            error=str(error),
            traceback=traceback.format_exc(),
        )
    study.publish(output / "result.json", result)
    return result


def launch(spec: dict, script: Path, environment: dict[str, str]) -> dict:
    output = Path(spec["output"])
    output.mkdir()
    study.publish(output / "spec.json", spec)
    with (output / "worker.log").open("w") as log:
        process = subprocess.Popen(
            [sys.executable, str(script), "--worker-spec", str(output / "spec.json")],
            env=environment,
            cwd=output,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            try:
                process.wait(timeout=300)
            except subprocess.TimeoutExpired:
                result = {
                    "variant": spec["variant"],
                    "status": "timeout",
                    "error": "Isolated case exceeded 300 seconds",
                }
            else:
                path = output / "result.json"
                if path.exists():
                    result = json.loads(path.read_text())
                    if process.returncode and result["status"] == "ok":
                        result = {
                            "variant": spec["variant"],
                            "status": "failed",
                            "error": f"Child exit {process.returncode}",
                            "partial_result": result,
                        }
                else:
                    result = {
                        "variant": spec["variant"],
                        "status": "crashed",
                        "returncode": process.returncode,
                    }
        finally:
            # The worker owns this new session. A sampler child can outlive a
            # crashed/exited worker, so clean the group even after wait succeeds.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=10)
    study.publish(output / "result.json", result)
    return {**result, "output": str(output)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=4)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument(
        "--variants", nargs="+", choices=VARIANTS, default=DEFAULT_VARIANTS
    )
    parser.add_argument("--worker-spec", type=Path)
    args = parser.parse_args()
    if args.worker_spec:
        result = run_case(json.loads(args.worker_spec.read_text()))
        raise SystemExit(0 if result["status"] == "ok" else 1)
    if (
        sys.version_info[:2] != (3, 12)
        or sys.implementation.name != "cpython"
        or sysconfig.get_config_var("Py_GIL_DISABLED")
        or metadata.version("onnxruntime-gpu") != "1.23.2"
    ):
        parser.error("Use the pinned CPython3.12/ONNX Runtime GPU1.23.2 environment")
    if args.repeats < 1 or not math.isfinite(args.seconds) or args.seconds <= 0:
        parser.error("Repeat count and finite duration must be positive")
    if len(set(args.variants)) != len(args.variants):
        parser.error("Select each variant at most once")
    variants = tuple(args.variants)
    args.bundle, args.store = args.bundle.resolve(), args.store.resolve()
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"screen-{stamp}-{os.getpid()}"
    directory.mkdir()
    print(f"Model-only screen: {directory}", flush=True)
    manifest = json.loads((args.bundle / "manifest.json").read_text())
    common = {
        "bundle": str(args.bundle),
        "model_sha256": manifest["onnx"]["sha256"],
        "input_sha256": checksum(args.bundle / "sample/input.npy"),
        "seconds": args.seconds,
    }
    snapshot = gpu_tools.gpu_snapshot()
    if any(
        row["process_name"] != study.DISPLAY_PROCESS
        for row in snapshot["compute_processes"]
    ):
        raise RuntimeError("Another compute process is using the GPU")
    study.freeze(directory)
    source = directory / "source"
    harness = source / "benchmarking/queueing/rfdetr"
    script = harness / "gpu_engine_screen.py"
    environment = {
        key: value
        for key, value in serving_environment().items()
        if not key.startswith(("MLSERVER_", "PYTHON"))
    }
    environment.update(
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONUNBUFFERED="1",
        CUDA_VISIBLE_DEVICES=snapshot["gpus"][0]["uuid"],
        PYTHONPATH=os.pathsep.join(
            [str(source), str(source / "runtimes/onnx"), str(harness)]
        ),
    )
    study.publish(
        directory / "PLAN.json",
        {
            **common,
            "python": sys.executable,
            "source_snapshot": str(source),
            "variants": variants,
            "repeats": args.repeats,
            "initial_gpu_snapshot": snapshot,
            "scope": "Model-only serial calls with transfers; REST/gRPC is excluded",
        },
    )
    rows = []
    try:
        oracle = launch(
            {
                **common,
                "oracle": True,
                "variant": "run",
                "output": str(directory / "oracle"),
            },
            script,
            environment,
        )
        if oracle["status"] != "ok":
            raise RuntimeError(
                "Ordinary-run CUDA oracle failed; inspect oracle/result.json"
            )
        for repeat in range(args.repeats):
            offset = repeat % len(variants)
            for variant in variants[offset:] + variants[:offset]:
                result = launch(
                    {
                        **common,
                        "reference": str(directory / "oracle"),
                        "variant": variant,
                        "output": str(directory / f"r{repeat}-{variant}"),
                    },
                    script,
                    environment,
                )
                rows.append({"round": repeat, **result})
                study.publish(directory / "RESULTS.json", rows)
                print(f"Round {repeat} {variant}: {result['status']}", flush=True)
        study.publish(
            directory / "SUMMARY.json",
            {
                "results": rows,
                "scope": "Model-only screening; failed variants supply no timing. "
                "Startup, capture, correctness and warmup are excluded. "
                "Timed calls include fresh H2D, Run/replay, synchronization "
                "and output D2H. No REST/gRPC gain is established.",
            },
        )
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
