"""Qualify exported Nsight coverage without comparing unrelated clock domains."""

from contextlib import closing
import json
from pathlib import Path
import sqlite3
from typing import Any


def _identifier(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _inspect(connection: sqlite3.Connection) -> dict[str, Any]:
    tables = {
        name: [
            row[1]
            for row in connection.execute(f"PRAGMA table_info({_identifier(name)})")
        ]
        for (name,) in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
    }
    counts = {
        name: connection.execute(
            f"SELECT COUNT(*) FROM {_identifier(name)}"
        ).fetchone()[0]
        for name in tables
        if name
        in ("CUPTI_ACTIVITY_KIND_KERNEL", "CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL")
        or name.startswith("CUPTI_ACTIVITY_KIND_MEMCPY")
    }
    kernels = {name: count for name, count in counts.items() if "KERNEL" in name}
    if not sum(kernels.values()):
        raise RuntimeError(
            "Missing/empty CUDA kernel activity; re-capture with --trace=cuda,nvtx"
        )
    columns = tables.get("NVTX_EVENTS", [])
    if not {"start", "end"} <= set(columns):
        raise RuntimeError(
            "NVTX_EVENTS lacks supported start/end columns; inspect the export schema"
        )
    labels = ['n."text"'] if "text" in columns else []
    join = ""
    if "textId" in columns and "StringIds" in tables:
        if not {"id", "value"} <= set(tables["StringIds"]):
            raise RuntimeError(
                "Unsupported StringIds schema; expected id/value columns"
            )
        join = ' LEFT JOIN "StringIds" AS s ON n."textId" = s."id"'
        labels.append('s."value"')
    if not labels:
        raise RuntimeError(
            "Cannot resolve NVTX labels; expected text or textId/StringIds.value"
        )
    label = "COALESCE(" + ", ".join(f"NULLIF({item}, '')" for item in labels) + ", '')"
    matching, complete = connection.execute(
        "SELECT COUNT(*), COALESCE(SUM(CASE WHEN "
        "typeof(n.\"start\") = 'integer' AND typeof(n.\"end\") = 'integer' "
        'AND n."end" >= n."start" THEN 1 ELSE 0 END), 0) '
        f'FROM "NVTX_EVENTS" AS n{join} '
        f"WHERE {label} = ? OR {label} LIKE ?",
        ("onnx.run.inclusive", "onnx.run.inclusive|%"),
    ).fetchone()
    if not matching or matching != complete:
        raise RuntimeError(
            "Missing/incomplete onnx.run.inclusive NVTX ranges; "
            "check the marker bridge, "
            "--trace=cuda,nvtx and capture shutdown"
        )
    return {
        "tables": tables,
        "kernel_rows": kernels,
        "kernel_row_count": sum(kernels.values()),
        "memcpy_rows": {
            name: count for name, count in counts.items() if "MEMCPY" in name
        },
        "nvtx_row_count": connection.execute(
            'SELECT COUNT(*) FROM "NVTX_EVENTS"'
        ).fetchone()[0],
        "onnx_nvtx_matching_count": matching,
        "onnx_nvtx_completed_count": complete,
        "capture_scope": (
            "Full server lifetime, including startup, warmup, pilot "
            "and measured requests."
        ),
        "timing_scope": (
            "Coverage counts only. Nsight timestamps have not been correlated "
            "with Python "
            "monotonic time; no steady-state GPU durations or utilization are inferred."
        ),
    }


def collect(case: Path) -> dict[str, Any]:
    """Validate a read-only Nsight export and publish its coverage summary."""
    database = (case / "cuda-timeline.sqlite").resolve()
    try:
        with closing(
            sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
        ) as connection:
            summary = _inspect(connection)
    except sqlite3.Error as error:
        raise RuntimeError(
            f"Cannot inspect Nsight SQLite export {database}: {error}; "
            "verify nsys export succeeded and the schema is supported"
        ) from error
    summary["database"] = str(database)
    destination = case / "cuda-summary.json"
    temporary = destination.with_suffix(".partial")
    with temporary.open("x") as output:
        output.write(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    temporary.replace(destination)
    return summary
