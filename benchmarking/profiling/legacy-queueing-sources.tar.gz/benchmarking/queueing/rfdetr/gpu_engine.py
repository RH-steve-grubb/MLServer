"""Opt-in CUDA execution experiments for the fixed RF-DETR serving study.

The model and codecs remain unchanged. A worker-owned session proxy retains
device buffers, refreshes each request and returns ordinary CPU NumPy outputs.
"""

import functools
import os
from typing import Any

import numpy as np

from gpu_engine_screen import Runner, base_variant, configure_blocking_sync, cuda_flags

ENGINES = ("run", "binding", "cuda-graph", "run-blocking", "cuda-graph-blocking")


class SessionProxy:
    def __init__(self, session: Any, engine: str, wait: dict) -> None:
        self._session = session
        self._base = base_variant(engine)
        self._shape = tuple(session.get_inputs()[0].shape)
        options = session.get_provider_options().get("CUDAExecutionProvider", {})
        expected_graph = "1" if self._base == "cuda-graph" else "0"
        if (
            options.get("enable_cuda_graph") != expected_graph
            or options.get("use_tf32") != "1"
        ):
            raise RuntimeError("Serving CUDA options differ from the selected engine")
        session.disable_fallback()
        self._runner = Runner(session, self._base, np.zeros(self._shape, np.float32))
        self._gpu_engine_receipt = {
            "variant": engine,
            "installed": True,
            "bound_device_buffers": self._runner.binding is not None,
            "input_shape": list(self._shape),
            "wait_policy": wait,
        }

    def __getattr__(self, name: str) -> Any:
        return getattr(self._session, name)

    def run(
        self, output_names: list[str] | None, input_feed: dict, run_options: Any = None
    ) -> list[np.ndarray]:
        # The ordinary blocking-sync variant changes only the CUDA wait policy.
        if self._base == "run":
            return self._session.run(output_names, input_feed, run_options=run_options)
        if run_options is not None:
            raise ValueError(
                "This fixed binding experiment requires default RunOptions"
            )
        if set(input_feed) != {self._runner.input_name}:
            raise ValueError("This experiment requires the fixed RF-DETR input")
        tensor = input_feed[self._runner.input_name]
        if (
            not isinstance(tensor, np.ndarray)
            or tensor.shape != self._shape
            or tensor.dtype != np.float32
            or not tensor.flags.c_contiguous
        ):
            raise ValueError(
                "This experiment requires contiguous fixed-shape FP32 input"
            )
        names = self._runner.names if output_names is None else output_names
        if any(name not in self._runner.names for name in names):
            raise ValueError("Unknown RF-DETR output requested")
        values = self._runner(tensor)
        return [values[name] for name in names]


def receipt(session: Any) -> dict:
    """Read through any tracing proxy without claiming installation from env."""
    return getattr(
        session, "_gpu_engine_receipt", {"variant": "run", "installed": False}
    )


def install() -> None:
    """Wrap model loading before tracing, retaining buffers only in the session."""
    engine = os.environ.get("MLSERVER_GPU_ENGINE", "run")
    if engine not in ENGINES:
        raise ValueError(f"Unknown serving engine experiment: {engine}")
    from mlserver_onnx import OnnxModel

    original = OnnxModel.load
    installed = getattr(original, "_gpu_engine", None)
    if installed is not None:
        if installed != engine:
            raise RuntimeError("A loaded process cannot change its engine experiment")
        return
    if engine == "run":
        return

    @functools.wraps(original)
    async def load(model: Any) -> bool:
        if model.name != "rfdetr-small":
            raise ValueError("This engine experiment is restricted to RF-DETR Small")
        # The CUDA scheduling policy must be selected before ORT creates the
        # worker's context. These flags affect this process, not the host GPU.
        wait = configure_blocking_sync() if engine.endswith("-blocking") else {}
        loaded = await original(model)
        if not loaded:
            return loaded
        if wait:
            wait["after_session_flags"] = cuda_flags(wait["library"])
        model._model = SessionProxy(model._model, engine, wait)
        return loaded

    setattr(load, "_gpu_engine", engine)
    setattr(OnnxModel, "load", load)
