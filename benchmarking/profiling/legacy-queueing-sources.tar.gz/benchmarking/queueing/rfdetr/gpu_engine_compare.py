"""Root-run gRPC engine comparison beyond the existing compact ZeroMQ design.

Keep RF-DETR FP32, Python, dependencies and serving resources fixed. Separate
CUDA Graph, blocking synchronization and optional input-metadata copy changes.
Repeated serving trials are unprofiled; bracketed captures diagnose their costs.
"""

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

import gpu_baseline as baseline
import gpu_transport_compare as transport

study = baseline.study
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-engine-serving-20261026"
CONFIGURATIONS = (
    ("run", "run", False),
    ("run-blocking", "run-blocking", False),
    ("cuda-graph", "cuda-graph", False),
    ("cuda-graph-blocking", "cuda-graph-blocking", False),
    ("cuda-graph-blocking-metadata", "cuda-graph-blocking", True),
)


def options(configuration: dict, clients: int, seconds: float) -> list[str]:
    selected = transport.options(
        configuration, configuration["concurrency"], seconds, clients
    )
    selected.extend(["--engine", configuration["engine"]])
    if configuration["metadata_only"]:
        selected.append("--metadata-only")
    return selected


def check(
    summary: dict, configuration: dict, clients: int, phase: str = "smoke"
) -> list[dict]:
    rows = summary.get("results", [])
    roles = (
        ["smoke"] if phase == "smoke" else ["control-before", phase, "control-after"]
    )
    profiled = [False] if phase == "smoke" else [False, True, False]
    if [row.get("role") for row in rows] != roles or [
        row.get("profiled") for row in rows
    ] != profiled:
        raise RuntimeError(
            "Engine study requires matched unprofiled trials or bracketed captures"
        )
    for row in rows:
        if (
            any(row.get(key) != value for key, value in configuration.items())
            or row.get("metadata_only") is not configuration["metadata_only"]
            or len(row.get("clients", [])) != min(clients, configuration["concurrency"])
            or not math.isfinite(row["rps"])
            or row["rps"] <= 0
        ):
            raise RuntimeError(
                "Engine result configuration, client count or throughput mismatch"
            )
    return rows


def execute(plan: baseline.Plan, reference: dict) -> dict[str, Any]:
    if reference["fixed"]["grpc"] != {"workers": 2, "threads": 2}:
        raise RuntimeError(
            "Engine comparison requires fixed two-worker/two-thread gRPC"
        )
    fixed = {
        "protocol": "grpc",
        "adapter": "compact",
        "transport": "zmq",
        "workers": 2,
        "threads": 2,
        "concurrency": 16,
    }
    configurations = [
        (label, {**fixed, "engine": engine, "metadata_only": metadata})
        for label, engine, metadata in CONFIGURATIONS
    ]
    qualification = {}
    small = {**configurations[-1][1], "workers": 1, "concurrency": 2}
    selected = options(small, 2, 1)
    selected[selected.index("--requests") + 1] = "4"
    for phase in ("stages", "cuda"):
        summary, path = plan.run(
            f"qualification-combined-{phase}", ["--phase", phase, *selected]
        )
        check(summary, small, 2, phase)
        qualification[phase] = str(path)
        study.publish(plan.directory / "QUALIFICATION.json", qualification)

    repeats = []
    endpoints = (configurations[0], configurations[-1])
    for repeat in range(plan.args.repeats):
        start = repeat % len(configurations)
        rotated = configurations[start:] + configurations[:start]
        pairs = endpoints if repeat % 2 == 0 else tuple(reversed(endpoints))
        blocks = [
            ("increments", 2, 16, rotated),
            ("clients4", 4, 16, pairs),
            ("serial", 2, 1, pairs),
        ]
        if repeat % 2:
            blocks.reverse()
        for block, clients, concurrency, variants in blocks:
            for label, variant in variants:
                configuration = {**variant, "concurrency": concurrency}
                summary, path = plan.run(
                    f"r{repeat}-{block}-{label}",
                    [
                        "--phase",
                        "smoke",
                        *options(configuration, clients, plan.args.repeat_seconds),
                    ],
                )
                (row,) = check(summary, configuration, clients)
                repeats.append(
                    {
                        "round": repeat,
                        "block": block,
                        "variant": label,
                        "requested_clients": clients,
                        "active_clients": min(clients, concurrency),
                        "summary": str(path),
                        "result": row,
                    }
                )
                study.publish(plan.directory / "REPEATS.json", repeats)
    captures: dict[str, dict] = {}
    for label, configuration in endpoints:
        captures[label] = {
            "configuration": configuration,
            "requested_clients": 2,
            "passes": {},
        }
        for name in ("cpu", "gil", "stages", "cuda"):
            command = (
                ["--phase", "profile", "--capture", name]
                if name in ("cpu", "gil")
                else ["--phase", name]
            )
            summary, path = plan.run(
                f"{label}-{name}",
                [*command, *options(configuration, 2, plan.args.seconds)],
            )
            check(summary, configuration, 2, command[1])
            captures[label]["passes"][name] = str(path)
            study.publish(plan.directory / "CAPTURES.json", captures)
    return {
        "purpose": "Engine and metadata-copy increments beyond compact gRPC/ZeroMQ",
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "reference": reference,
        "configurations": dict(configurations),
        "qualification": qualification,
        "repeats": repeats,
        "captures": captures,
        "interpretation": (
            "Fixed RF-DETR FP32/B1, CPython 3.12, original ONNX Runtime "
            "and compact/ZeroMQ representation. No TensorRT or precision change. "
            "Five increments rotate each round; baseline and combined also repeat "
            "with four clients at C16 and requested two clients at C1 "
            "(one active client). Client/channel topology remains within the same "
            "resource budget. Separate engine effects from the optional metadata-copy "
            "change. Profile throughput is diagnostic, not final speedup evidence."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=transport.DEFAULT_REFERENCE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    if (
        os.geteuid() != 0
        or args.repeats < 1
        or any(
            not math.isfinite(s) or s <= 0 for s in (args.seconds, args.repeat_seconds)
        )
    ):
        parser.error("Run as root with positive repeats and finite positive durations")
    args.without_cuda, args.concurrency = False, 16
    args.reference, args.bundle, args.store = (
        p.resolve() for p in (args.reference, args.bundle, args.store)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"engine-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"Engine serving study output: {directory}", flush=True)
    try:
        reference = transport.load_reference(args.reference)
        study.publish(directory / "REFERENCE.json", reference)
        study.publish(
            directory / "ENVIRONMENT.json", transport.environment_inventory(reference)
        )
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if (
            manifest["onnx"]["sha256"] != reference["model_sha256"]
            or study.digest(args.bundle / "model/model.onnx")
            != reference["model_sha256"]
        ):
            raise RuntimeError("Engine comparison model differs from reference")
        tools = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", tools)
        if not tools["perf"]["available"] or not tools["nsys"]["available"]:
            raise RuntimeError("Working perf and Nsight Systems are required")
        study.freeze(directory)
        result = execute(plan, reference)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
