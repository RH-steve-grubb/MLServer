"""Opt-in, buffered host-stage timing for the RF-DETR GPU investigation.

Call ``install()`` before constructing MLServer. With MLSERVER_GPU_TRACE_DIR
unset, this module changes nothing. Captures are diagnostic runs only: spans can
nest, async spans have no per-request CPU accounting, and ORT Run wall time is
not device-kernel time. Multiprocessing feeder serialization is left to perf.
"""

import atexit
from collections import defaultdict
from contextvars import ContextVar
import ctypes
from functools import wraps
import inspect
from itertools import count
import json
import math
from multiprocessing.util import Finalize
import os
from pathlib import Path
import sys
import threading
import time
from typing import Any, Callable

_MESSAGE_ID: ContextVar[str | None] = ContextVar("gpu_stage_message_id", default=None)
_TRACE_ID: ContextVar[str | None] = ContextVar("gpu_stage_trace_id", default=None)
_TRACE_SEQUENCE = count()
_BUFFER: Any = None
_INSTALLED = False
_PATCHES: list[tuple[Any, str, Any]] = []
_FINALIZER: Any = None
_NVTX: Any = None


class _Buffer:
    def __init__(self, directory: Path, limit: int):
        self.directory = directory
        self.limit = limit
        self.pid = os.getpid()
        self.records: list[dict[str, Any]] = []
        self.dropped = 0
        self.append_wall_ns = 0
        self.lock = threading.Lock()

    def append(self, record: dict[str, Any]) -> None:
        started = time.perf_counter_ns()
        with self.lock:
            if len(self.records) < self.limit:
                self.records.append(record)
            else:
                self.dropped += 1
            self.append_wall_ns += time.perf_counter_ns() - started

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            records = list(self.records)
            dropped = self.dropped
            append_wall_ns = self.append_wall_ns
        return {
            "format_version": 2,
            "pid": self.pid,
            "record_limit": self.limit,
            "record_count": len(records),
            "overflow_records": dropped,
            "collector_append_wall_ns": append_wall_ns,
            "clock": "perf_counter_ns; thread_time_ns only for synchronous spans",
            "nvtx_library": os.environ.get("MLSERVER_GPU_NVTX_LIBRARY"),
            "semantics": {
                "nested_spans_overlap": True,
                "async_spans_include_wait_and_other_coroutines": True,
                "onnx_run_includes_host_submission_transfers_and_device_wait": True,
                "feeder_pickle_instrumented": False,
                "unprofiled_runs_must_unset_trace_directory": True,
            },
            "stages": summarize(records),
            "records": records,
        }


def _current_buffer() -> Any:
    global _BUFFER, _FINALIZER
    if _BUFFER is not None and _BUFFER.pid != os.getpid():
        # Workers use spawn, but avoid inheriting parent records or a possibly
        # locked threading.Lock if an embedding application chooses fork.
        _BUFFER = _Buffer(_BUFFER.directory, _BUFFER.limit)
        _FINALIZER = Finalize(None, _safe_flush, exitpriority=10)
    return _BUFFER


def _begin(stage: str, synchronous: bool) -> dict[str, Any]:
    record: dict[str, Any] = {
        "pid": os.getpid(),
        "tid": threading.get_native_id(),
        "stage": stage,
        "trace_id": _TRACE_ID.get(),
        "message_id": _MESSAGE_ID.get(),
    }
    if _NVTX is not None:
        label = f"{stage}|trace={record['trace_id']}|message={record['message_id']}"
        record["nvtx_label"] = label
        record["nvtx_range_id"] = int(_NVTX.gpu_range_start(label.encode("utf-8")))
    # Exclude marker API overhead from the host-stage timer. NVTX endpoints
    # surround these timestamps but are not a device-clock timing substitute.
    record["start_ns"] = time.perf_counter_ns()
    record["_cpu_start_ns"] = time.thread_time_ns() if synchronous else None
    return record


def _end(record: dict[str, Any], succeeded: bool) -> None:
    cpu_started = record.pop("_cpu_start_ns")
    record["thread_cpu_ns"] = (
        time.thread_time_ns() - cpu_started if cpu_started is not None else None
    )
    record["end_ns"] = time.perf_counter_ns()
    record["wall_ns"] = record["end_ns"] - record["start_ns"]
    record["succeeded"] = succeeded
    if "nvtx_range_id" in record:
        _NVTX.gpu_range_end(record["nvtx_range_id"])
    buffer = _current_buffer()
    if buffer is not None:
        buffer.append(record)


def _sync(stage: str, function: Callable) -> Callable:
    @wraps(function)
    def measured(*args: Any, **kwargs: Any) -> Any:
        record = _begin(stage, synchronous=True)
        succeeded = False
        try:
            result = function(*args, **kwargs)
            succeeded = True
            return result
        finally:
            _end(record, succeeded)

    return measured


def _async(stage: str, function: Callable) -> Callable:
    @wraps(function)
    async def measured(*args: Any, **kwargs: Any) -> Any:
        record = _begin(stage, synchronous=False)
        succeeded = False
        try:
            result = await function(*args, **kwargs)
            succeeded = True
            return result
        finally:
            _end(record, succeeded)

    return measured


def _replace(owner: Any, name: str, replacement: Any) -> None:
    _PATCHES.append((owner, name, inspect.getattr_static(owner, name)))
    setattr(owner, name, replacement)


def _patch_sync(owner: Any, name: str, stage: str) -> None:
    descriptor = inspect.getattr_static(owner, name)
    if isinstance(descriptor, classmethod):
        replacement: Any = classmethod(_sync(stage, descriptor.__func__))
    elif isinstance(descriptor, staticmethod):
        replacement = staticmethod(_sync(stage, descriptor.__func__))
    else:
        replacement = _sync(stage, descriptor)
    _replace(owner, name, replacement)


def _scope_message(owner: Any, name: str, stage: str) -> None:
    original = getattr(owner, name)
    measured = _async(stage, original)
    message_parameter = list(inspect.signature(original).parameters)[1]

    @wraps(original)
    async def scoped(self: Any, *args: Any, **kwargs: Any) -> Any:
        message = args[0] if args else kwargs.get(message_parameter)
        message_id = getattr(message, "id", None)
        token = _MESSAGE_ID.set(str(message_id) if message_id is not None else None)
        try:
            return await measured(self, *args, **kwargs)
        finally:
            _MESSAGE_ID.reset(token)

    _replace(owner, name, scoped)


def _frontend(stage: str, function: Callable) -> Callable:
    measured = _async(stage, function)

    @wraps(function)
    async def scoped(*args: Any, **kwargs: Any) -> Any:
        token = _TRACE_ID.set(f"{os.getpid()}:{next(_TRACE_SEQUENCE)}")
        try:
            return await measured(*args, **kwargs)
        finally:
            _TRACE_ID.reset(token)

    return scoped


def _patch_routes(owner: Any) -> None:
    original = owner.get_route_handler

    @wraps(original)
    def get_route_handler(self: Any) -> Callable:
        handler = original(self)
        if self.path.endswith("/infer"):
            return _frontend("rest.route.inclusive", handler)
        return handler

    _replace(owner, "get_route_handler", get_route_handler)


class _SessionProxy:
    def __init__(self, session: Any):
        self._session = session
        self._run = _sync("onnx.run.inclusive", session.run)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._session, name)

    def run(self, *args: Any, **kwargs: Any) -> Any:
        return self._run(*args, **kwargs)


def _load_nvtx() -> Any:
    filename = os.environ.get("MLSERVER_GPU_NVTX_LIBRARY")
    if not filename:
        return None
    # CDLL releases the GIL around calls. Keep it during these short markers
    # so a capture does not invent additional GIL contention of its own.
    library = ctypes.PyDLL(str(Path(filename).resolve()))
    library.gpu_range_start.argtypes = [ctypes.c_char_p]
    library.gpu_range_start.restype = ctypes.c_uint64
    library.gpu_range_end.argtypes = [ctypes.c_uint64]
    library.gpu_range_end.restype = None
    return library


def _patch_model_load(owner: Any) -> None:
    original = owner.load

    @wraps(original)
    async def loaded(self: Any) -> Any:
        result = await original(self)
        if result and self._model is not None:
            if not isinstance(self._model, _SessionProxy):
                self._model = _SessionProxy(self._model)
        return result

    _replace(owner, "load", loaded)


async def _worker_install(model: Any) -> Any:
    # This picklable hook executes before model.load in each spawned worker.
    # Parent-process monkeypatches alone do not survive multiprocessing spawn.
    install()
    return model


def _patch_worker_bootstrap(owner: Any) -> None:
    original = owner.__init__
    signature = inspect.signature(original)

    @wraps(original)
    def initialized(*args: Any, **kwargs: Any) -> Any:
        arguments = signature.bind(*args, **kwargs)
        arguments.apply_defaults()
        hooks = list(arguments.arguments["on_worker_load"])
        if _worker_install not in hooks:
            hooks.insert(0, _worker_install)
        arguments.arguments["on_worker_load"] = hooks
        return original(*arguments.args, **arguments.kwargs)

    _replace(owner, "__init__", initialized)


def _patch_worker_exit(owner: Any) -> None:
    original = owner.coro_run

    @wraps(original)
    async def coro_run(self: Any) -> Any:
        try:
            return await original(self)
        finally:
            _safe_flush()

    _replace(owner, "coro_run", coro_run)


def install() -> bool:
    """Install diagnostic wrappers and a spawn-safe worker hook when opted in."""
    global _BUFFER, _INSTALLED, _FINALIZER, _NVTX
    directory = os.environ.get("MLSERVER_GPU_TRACE_DIR")
    if not directory:
        return False
    if _INSTALLED:
        _current_buffer()
        return True
    limit = int(os.environ.get("MLSERVER_GPU_TRACE_MAX_RECORDS", "100000"))
    if limit <= 0:
        raise ValueError("MLSERVER_GPU_TRACE_MAX_RECORDS must be positive")

    from mlserver import raw
    from mlserver.codecs import numpy as numpy_codec
    from mlserver.grpc.converters import (
        ModelInferRequestConverter,
        ModelInferResponseConverter,
    )
    from mlserver.grpc.servicers import InferenceServicer
    from mlserver.handlers.dataplane import DataPlane
    from mlserver.parallel.dispatcher import Dispatcher
    from mlserver.parallel.registry import InferencePoolRegistry
    from mlserver.parallel.worker import Worker
    from mlserver.rest.app import APIRoute
    from mlserver.rest.requests import Request
    from mlserver.rest.responses import Response
    from mlserver_onnx import OnnxModel

    _NVTX = _load_nvtx()
    _BUFFER = _Buffer(Path(directory), limit)
    start = len(_PATCHES)
    try:
        for owner, name, stage in (
            (ModelInferRequestConverter, "to_types", "grpc.request_conversion"),
            (ModelInferResponseConverter, "from_types", "grpc.response_conversion"),
            (raw, "unpack", "grpc.raw_unpack"),
            (raw, "pack", "grpc.raw_pack"),
            (numpy_codec, "_to_ndarray", "numpy.input"),
            (numpy_codec, "_encode_data", "numpy.output_lists"),
            (OnnxModel, "_prepare_inputs", "onnx.prepare_inputs.inclusive"),
            (OnnxModel, "_get_model_outputs", "onnx.outputs.inclusive"),
            (Response, "render", "rest.render"),
        ):
            _patch_sync(owner, name, stage)
        _replace(Request, "json", _async("rest.json.inclusive", Request.json))
        # FastAPI awaits body() before json(); measuring only json() hides
        # receive/admission stalls. A later cached body() call is also retained.
        _replace(Request, "body", _async("rest.body.inclusive", Request.body))
        _replace(
            DataPlane, "infer", _async("dataplane.infer.inclusive", DataPlane.infer)
        )
        _replace(
            InferenceServicer,
            "ModelInfer",
            _frontend("grpc.handler.inclusive", InferenceServicer.ModelInfer),
        )
        _scope_message(Dispatcher, "dispatch_request", "dispatch.wait.inclusive")
        _scope_message(Worker, "_process_request", "worker.request.inclusive")
        _patch_routes(APIRoute)
        _patch_model_load(OnnxModel)
        _patch_worker_bootstrap(InferencePoolRegistry)
        _patch_worker_exit(Worker)
        if os.environ.get("MLSERVER_GPU_ADAPTER") in ("worker-json", "compact"):
            import raw_worker

            _patch_sync(raw_worker, "parse_body", "worker.json.decode.inclusive")
            _patch_sync(raw_worker, "encode_response", "worker.json.encode.inclusive")
    except BaseException:
        for owner, name, original in reversed(_PATCHES[start:]):
            setattr(owner, name, original)
        del _PATCHES[start:]
        _BUFFER = None
        raise
    _INSTALLED = True
    atexit.register(_safe_flush)
    _FINALIZER = Finalize(None, _safe_flush, exitpriority=10)
    return True


def _distribution(values: list[int]) -> dict[str, Any]:
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    result = {
        "count": len(values),
        "total_ns": sum(values),
        "min_ns": ordered[0],
        "max_ns": ordered[-1],
        "mean_ns": sum(values) / len(values),
    }
    for percentile in (50, 95, 99):
        index = math.ceil(len(values) * percentile / 100) - 1
        result[f"p{percentile}_ns"] = ordered[index]
    return result


def summarize(records: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize inclusive distributions; never infer percentages by summing them."""
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        grouped[record["stage"]].append(record)
    return {
        stage: {
            "wall": _distribution([row["wall_ns"] for row in rows]),
            "thread_cpu": _distribution(
                [
                    row["thread_cpu_ns"]
                    for row in rows
                    if row["thread_cpu_ns"] is not None
                ]
            ),
            "failed_count": sum(not row["succeeded"] for row in rows),
        }
        for stage, rows in grouped.items()
    }


def flush() -> Path | None:
    """Atomically write this process's bounded capture and stage distributions."""
    buffer = _current_buffer()
    if buffer is None:
        return None
    buffer.directory.mkdir(parents=True, exist_ok=True)
    destination = buffer.directory / f"stages-{buffer.pid}.json"
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(buffer.snapshot(), separators=(",", ":")))
    temporary.replace(destination)
    return destination


def _safe_flush() -> None:
    try:
        flush()
    except Exception as exc:
        # A diagnostic write failure must not replace an application exception.
        # The collector also verifies that every expected PID produced a trace.
        try:
            print(f"GPU stage trace flush failed: {exc}", file=sys.stderr)
        except Exception:
            pass
