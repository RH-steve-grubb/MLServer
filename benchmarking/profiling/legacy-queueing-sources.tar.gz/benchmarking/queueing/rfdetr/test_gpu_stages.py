"""Stage-adapter tests use fake sessions and mocked handlers, never CUDA."""

import asyncio
import json
import os
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

import gpu_stages as stages


class StageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.original_buffer = stages._BUFFER
        self.original_nvtx = stages._NVTX
        self.patch_start = len(stages._PATCHES)
        stages._BUFFER = stages._Buffer(Path(self.directory.name), 100)
        stages._NVTX = None
        self.addCleanup(self.restore)

    def restore(self) -> None:
        for owner, name, original in reversed(stages._PATCHES[self.patch_start :]):
            setattr(owner, name, original)
        del stages._PATCHES[self.patch_start :]
        stages._BUFFER = self.original_buffer
        stages._NVTX = self.original_nvtx

    def test_install_without_environment_changes_nothing(self) -> None:
        with mock.patch.dict(os.environ, {}, clear=True):
            self.assertFalse(stages.install())
        self.assertEqual(len(stages._PATCHES), self.patch_start)

    def test_sync_preserves_return_and_exception(self) -> None:
        result = object()
        wrapped = stages._sync("sync", lambda: result)
        self.assertIs(wrapped(), result)
        error = ValueError("sentinel")

        def failed() -> None:
            raise error

        with self.assertRaises(ValueError) as raised:
            stages._sync("failure", failed)()
        self.assertIs(raised.exception, error)
        records = stages._BUFFER.records
        self.assertTrue(records[0]["succeeded"])
        self.assertFalse(records[1]["succeeded"])
        self.assertIsInstance(records[0]["thread_cpu_ns"], int)

    def test_async_cpu_is_not_charged_across_await(self) -> None:
        async def function() -> str:
            await asyncio.sleep(0)
            return "value"

        result = asyncio.run(stages._async("async", function)())
        self.assertEqual(result, "value")
        self.assertIsNone(stages._BUFFER.records[0]["thread_cpu_ns"])

    def test_async_cancellation_is_preserved(self) -> None:
        async def cancelled() -> None:
            raise asyncio.CancelledError()

        with self.assertRaises(asyncio.CancelledError):
            asyncio.run(stages._async("cancel", cancelled)())
        self.assertFalse(stages._BUFFER.records[0]["succeeded"])

    def test_classmethod_and_staticmethod_binding_are_preserved(self) -> None:
        class Converter:
            @classmethod
            def convert(cls, value: object) -> tuple:
                return cls, value

            @staticmethod
            def fixed(value: object) -> object:
                return value

        stages._patch_sync(Converter, "convert", "classmethod")
        stages._patch_sync(Converter, "fixed", "staticmethod")
        marker = object()
        self.assertEqual(Converter.convert(marker), (Converter, marker))
        self.assertIs(Converter.fixed(marker), marker)

    def test_worker_context_is_scoped_and_reset(self) -> None:
        class Worker:
            async def process(self, request: object) -> object:
                return stages._sync("inside", lambda: stages._MESSAGE_ID.get())()

        stages._scope_message(Worker, "process", "worker")
        result = asyncio.run(Worker().process(SimpleNamespace(id="internal-id")))
        self.assertEqual(result, "internal-id")
        self.assertIsNone(stages._MESSAGE_ID.get())
        self.assertTrue(
            all(row["message_id"] == "internal-id" for row in stages._BUFFER.records)
        )
        result = asyncio.run(Worker().process(request=SimpleNamespace(id="keyword-id")))
        self.assertEqual(result, "keyword-id")

    def test_session_proxy_forwards_without_changing_results(self) -> None:
        class Session:
            metadata = "metadata"

            def run(self, names: object, inputs: object) -> object:
                return inputs

        session = stages._SessionProxy(Session())
        marker = object()
        self.assertEqual(session.metadata, "metadata")
        self.assertIs(session.run(["output"], marker), marker)
        self.assertEqual(stages._BUFFER.records[-1]["stage"], "onnx.run.inclusive")

    def test_worker_bootstrap_preserves_existing_hooks_and_arguments(self) -> None:
        existing = object()

        class Registry:
            def __init__(self, settings: object, on_worker_load: tuple = ()):
                self.settings = settings
                self.hooks = on_worker_load

        stages._patch_worker_bootstrap(Registry)
        marker = object()
        registry = Registry(marker, (existing,))
        self.assertIs(registry.settings, marker)
        self.assertEqual(registry.hooks, [stages._worker_install, existing])

    def test_worker_exit_flush_does_not_mask_failure(self) -> None:
        error = RuntimeError("worker failure")

        class Worker:
            async def coro_run(self) -> None:
                raise error

        stages._patch_worker_exit(Worker)
        with mock.patch.object(stages, "flush", side_effect=OSError("disk full")):
            with mock.patch("sys.stderr"):
                with self.assertRaises(RuntimeError) as raised:
                    asyncio.run(Worker().coro_run())
        self.assertIs(raised.exception, error)

    def test_buffer_limit_and_atomic_flush(self) -> None:
        stages._BUFFER.limit = 1
        for _ in range(3):
            stages._sync("limited", lambda: None)()
        path = stages.flush()
        assert path is not None
        data = json.loads(path.read_text())
        self.assertEqual(data["record_count"], 1)
        self.assertEqual(data["overflow_records"], 2)
        self.assertEqual(data["stages"]["limited"]["wall"]["count"], 1)
        self.assertTrue(data["semantics"]["nested_spans_overlap"])
        self.assertFalse(path.with_suffix(".json.tmp").exists())

    def test_frontend_trace_bridges_to_internal_message(self) -> None:
        class Dispatcher:
            async def dispatch(self, message: object) -> None:
                return None

        dispatcher = Dispatcher()
        stages._scope_message(Dispatcher, "dispatch", "dispatch")

        async def route() -> None:
            await dispatcher.dispatch(SimpleNamespace(id="message-1"))

        asyncio.run(stages._frontend("route", route)())
        dispatch, route_record = stages._BUFFER.records
        self.assertEqual(dispatch["message_id"], "message-1")
        self.assertEqual(dispatch["trace_id"], route_record["trace_id"])
        self.assertIsNone(stages._TRACE_ID.get())

    def test_nvtx_id_range_closes_on_async_exception(self) -> None:
        library = mock.Mock()
        library.gpu_range_start.return_value = 42
        stages._NVTX = library

        async def failed() -> None:
            await asyncio.sleep(0)
            raise ValueError("original")

        token = stages._MESSAGE_ID.set("message-42")
        try:
            with self.assertRaisesRegex(ValueError, "original"):
                asyncio.run(stages._async("nvtx-stage", failed)())
        finally:
            stages._MESSAGE_ID.reset(token)
        library.gpu_range_start.assert_called_once()
        label = library.gpu_range_start.call_args.args[0].decode("utf-8")
        self.assertIn("nvtx-stage", label)
        self.assertIn("message=message-42", label)
        library.gpu_range_end.assert_called_once_with(42)
        self.assertEqual(stages._BUFFER.records[0]["nvtx_range_id"], 42)
        self.assertIsNone(stages._BUFFER.records[0]["thread_cpu_ns"])


if __name__ == "__main__":
    unittest.main()
