"""Mocked study-control tests; never start a model, client, GPU, or subprocess."""

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from typing import Any
import unittest
from unittest.mock import MagicMock, patch

import gpu_study as study


class BudgetTests(unittest.TestCase):
    @staticmethod
    def siblings(path: Path) -> str:
        cpu = int(path.parts[-3][3:])
        return f"{cpu % 4},{cpu % 4 + 4}\n"

    def test_budget_reserves_whole_physical_cores(self) -> None:
        with (
            patch.object(study.os, "sched_getaffinity", return_value=set(range(8))),
            patch.object(Path, "read_text", autospec=True, side_effect=self.siblings),
        ):
            budget = study.automatic_budget()
        self.assertEqual(budget.server, "0,1,4,5")
        self.assertEqual(budget.client, "2,3,6,7")
        self.assertEqual(budget.memory, 16 * 1024**3)
        self.assertFalse(study.previous.cpus(budget.server) & {2, 3, 6, 7})

    def test_budget_respects_restricted_logical_cpu_affinity(self) -> None:
        # A core can expose only one SMT sibling inside a restricted cpuset.
        with (
            patch.object(study.os, "sched_getaffinity", return_value={0, 1, 6, 7}),
            patch.object(Path, "read_text", autospec=True, side_effect=self.siblings),
        ):
            budget = study.automatic_budget()
        self.assertEqual(budget.server, "0,1")
        self.assertEqual(budget.client, "6,7")

    def test_insufficient_physical_cores_are_rejected(self) -> None:
        with (
            patch.object(
                study.os, "sched_getaffinity", return_value={0, 1, 2, 4, 5, 6}
            ),
            patch.object(Path, "read_text", autospec=True, side_effect=self.siblings),
        ):
            with self.assertRaisesRegex(RuntimeError, "four physical cores"):
                study.automatic_budget()

    def test_variant_names_preserve_stock_thread_default(self) -> None:
        self.assertEqual(study.Variant(1, None).name, "stock-w1-tdefault")
        self.assertEqual(study.Variant(4, 2).name, "stock-w4-t2")
        self.assertEqual(study.Variant(4, 2, "compact").name, "compact-w4-t2")
        self.assertEqual(
            study.Variant(4, 2, "compact", "zmq").name, "compact-zmq-w4-t2"
        )


class StudyTests(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        bundle = self.root / "bundle"
        (bundle / "sample").mkdir(parents=True)
        (bundle / "sample" / "request.json").write_bytes(b"REST fixture")
        (bundle / "sample" / "request.grpc.pb").write_bytes(b"gRPC fixture")
        args = argparse.Namespace(
            bundle=bundle,
            python=Path("/pinned/python3.12"),
            user="study-user",
            protocol="rest",
            requests=32,
            concurrency=8,
            clients=2,
        )
        self.study = study.Study(
            args=args,
            run=self.root / "run",
            budget=study.previous.Budget(server="0-3", client="4-7", memory=4096),
            gpu_uuid="GPU-test-uuid",
        )

    def test_freeze_hashes_runtime_source_but_excludes_editor_artifacts(self) -> None:
        repository = self.root / "checkout"
        for name in (
            "mlserver",
            "runtimes/onnx/mlserver_onnx",
            "benchmarking/queueing",
        ):
            folder = repository / name
            folder.mkdir(parents=True)
            (folder / "example.py").write_text("value = 1\n")
            for temporary in (".example.py.swp", ".example.py.swo", "example.py~"):
                (folder / temporary).write_bytes(b"editor state")
        destination = self.root / "snapshot"
        destination.mkdir()
        with patch.object(study, "REPO", repository):
            study.freeze(destination)
        hashes = json.loads((destination / "source-hashes.json").read_text())
        self.assertEqual(len(hashes), 3)
        self.assertTrue(all(name.endswith("example.py") for name in hashes))
        for name, expected in hashes.items():
            captured = destination / "source" / name
            self.assertEqual(captured.read_text(), "value = 1\n")
            self.assertEqual(study.digest(captured), expected)

    def test_gpu_guard_allows_known_display_but_rejects_competing_inference(
        self,
    ) -> None:
        display = {
            "gpu_uuid": self.study.gpu_uuid,
            "process_name": study.DISPLAY_PROCESS,
            "pid": 1,
        }
        snapshot = {"compute_processes": [display]}
        with patch.object(study.gpu_tools, "gpu_snapshot", return_value=snapshot):
            self.assertIs(study.require_idle_gpu(self.study), snapshot)
            snapshot["compute_processes"].append(
                {**display, "pid": 2, "process_name": "/other/inference"}
            )
            with self.assertRaisesRegex(RuntimeError, "Unrelated compute"):
                study.require_idle_gpu(self.study)

    def test_environment_uses_frozen_source_and_selected_gpu(self) -> None:
        environment = {
            "PATH": "/usr/bin",
            "MLSERVER_PARALLEL_WORKERS": "99",
            "MLSERVER_GPU_TRACE_DIR": "/stale/trace",
            "PYTHONPATH": "/mutable/checkout",
            "PYTHONHOME": "/wrong/python",
            "CUDA_VISIBLE_DEVICES": "0,1",
            "OMP_NUM_THREADS": "99",
            "NVIDIA_TF32_OVERRIDE": "0",
        }
        with patch.dict(os.environ, environment, clear=True):
            actual = self.study.environment()
        source = self.study.run / "source"
        self.assertEqual(actual["PATH"], "/usr/bin")
        self.assertEqual(
            actual["PYTHONPATH"].split(os.pathsep),
            [
                str(source),
                str(source / "runtimes" / "onnx"),
                str(self.study.harness),
            ],
        )
        self.assertEqual(
            {
                key: value
                for key, value in actual.items()
                if key.startswith("MLSERVER_")
            },
            {
                "MLSERVER_GPU_ADAPTER": "stock",
                "MLSERVER_GPU_TRANSPORT": "queue",
                "MLSERVER_GPU_ENGINE": "run",
                "MLSERVER_GPU_METADATA_ONLY": "0",
                "MLSERVER_GPU_BUFFER_INJECT": "0",
            },
        )
        self.assertNotIn("PYTHONHOME", actual)
        self.assertNotIn("OMP_NUM_THREADS", actual)
        self.assertNotIn("NVIDIA_TF32_OVERRIDE", actual)
        self.assertEqual(actual["PYTHONDONTWRITEBYTECODE"], "1")
        self.assertEqual(actual["PYTHONUNBUFFERED"], "1")
        self.assertEqual(actual["CUDA_VISIBLE_DEVICES"], self.study.gpu_uuid)

    def configured(self, variant: study.Variant) -> tuple[dict, dict]:
        connections = [MagicMock(), MagicMock()]
        connections[0].getsockname.return_value = ("127.0.0.1", 18080)
        connections[1].getsockname.return_value = ("127.0.0.1", 18081)
        case = self.root / variant.name
        with patch.object(study.socket, "socket", side_effect=connections):
            ports = study.configure(self.study, case, variant)
        self.assertEqual(ports, (18080, 18081))
        for connection in connections:
            connection.bind.assert_called_once_with(("127.0.0.1", 0))
            connection.close.assert_called_once_with()
        repository = case / "repository"
        model = json.loads(
            (repository / "rfdetr-small" / "model-settings.json").read_text()
        )
        settings = json.loads((repository / "settings.json").read_text())
        return model, settings

    def test_stock_settings_keep_native_thread_defaults(self) -> None:
        from mlserver.settings import Settings

        model, settings = self.configured(study.Variant(1, None))
        # MLServer ignores unknown settings. Reject stale branch-specific
        # controls here so a benchmark cannot silently claim to apply them.
        self.assertFalse(set(settings) - set(Settings.model_fields))
        self.assertEqual(model["implementation"], "mlserver_onnx.OnnxModel")
        self.assertEqual(model["max_batch_size"], 0)
        self.assertEqual(model["max_batch_time"], 0)
        self.assertEqual(
            model["parameters"]["uri"],
            str(self.study.args.bundle / "model" / "model.onnx"),
        )
        self.assertEqual(
            model["parameters"]["extra"],
            {
                "providers": ["CUDAExecutionProvider", "CPUExecutionProvider"],
                "provider_options": [{"device_id": 0}, {}],
            },
        )
        self.assertEqual(settings["parallel_workers"], 1)
        self.assertEqual(settings["host"], "127.0.0.1")
        self.assertEqual(settings["http_port"], 18080)
        self.assertEqual(settings["grpc_port"], 18081)
        self.assertFalse(settings["access_log"])
        self.assertFalse(settings["gzip_enabled"])
        self.assertIsNone(settings["metrics_endpoint"])
        self.assertEqual(settings["grpc_max_message_length"], 64 * 1024**2)

    def test_tuned_settings_change_threads_and_disable_spinning(self) -> None:
        model, settings = self.configured(study.Variant(4, 2))
        extra = model["parameters"]["extra"]
        self.assertEqual(
            extra["session_options"],
            {"intra_op_num_threads": 2, "inter_op_num_threads": 1},
        )
        self.assertEqual(
            extra["session_config_entries"],
            {
                "session.intra_op.allow_spinning": "0",
                "session.inter_op.allow_spinning": "0",
            },
        )
        self.assertEqual(settings["parallel_workers"], 4)
        self.assertEqual(model["max_batch_size"], 0)

    def test_engine_provider_selection_and_receipt_must_agree(self) -> None:
        variant = study.Variant(2, 2, "compact", "zmq", "cuda-graph-blocking")
        model, _ = self.configured(variant)
        cuda = model["parameters"]["extra"]["provider_options"][0]
        self.assertEqual(cuda["enable_cuda_graph"], "1")
        self.assertEqual(cuda["use_tf32"], "1")
        proof = {
            "engine_receipt": {
                "variant": variant.engine,
                "installed": True,
                "bound_device_buffers": True,
                "input_shape": [1, 3, 512, 512],
                "wait_policy": {
                    "requested_flags": 4,
                    "before_session_flags": 12,
                    "after_session_flags": 12,
                },
            },
            "provider_options": {"CUDAExecutionProvider": cuda},
        }
        study.validate_engine(proof, variant)
        for field, invalid in (
            ("variant", "run"),
            ("installed", False),
            ("bound_device_buffers", False),
            ("input_shape", [1, 3, 1, 1]),
            ("wait_policy", {"requested_flags": 4, "after_session_flags": 0}),
        ):
            with self.subTest(field=field):
                bad = copy.deepcopy(proof)
                bad["engine_receipt"][field] = invalid
                with self.assertRaises(RuntimeError):
                    study.validate_engine(bad, variant)

    def test_root_drops_to_normal_user_without_changing_arguments(self) -> None:
        command = ["/pinned/python3.12", "gpu_load.py", "--output", "/case"]
        with patch.object(study.os, "geteuid", return_value=0):
            self.assertEqual(
                study.normal_user_command(self.study, command),
                ["runuser", "-u", "study-user", "--", *command],
            )
        with patch.object(study.os, "geteuid", return_value=1234):
            self.assertEqual(study.normal_user_command(self.study, command), command)

    def test_socket_directory_is_short_owned_and_removed_after_failure(self) -> None:
        self.study.args.transport = "zmq"
        identity = SimpleNamespace(pw_uid=1234, pw_gid=5678)
        with (
            patch.object(study.os, "geteuid", return_value=0),
            patch.object(study.pwd, "getpwnam", return_value=identity),
            patch.object(study.os, "chown") as chown,
        ):
            with self.assertRaisesRegex(RuntimeError, "workload failure"):
                with study.ipc_directory(self.study) as directory:
                    self.assertIsNotNone(directory)
                    assert directory is not None
                    self.assertTrue(directory.is_dir())
                    self.assertLess(len(str(directory / "q-000000000000.sock")), 100)
                    chown.assert_called_once_with(directory, 1234, 5678)
                    raise RuntimeError("workload failure")
            self.assertFalse(directory.exists())

    def test_unprivileged_cuda_is_explicit_and_cannot_enable_perf_collection(
        self,
    ) -> None:
        with (
            patch.object(study.os, "geteuid", return_value=4337),
            patch.object(sys, "stderr"),
        ):
            for arguments in (
                ["study", "--phase", "cuda"],
                ["study", "--phase", "profile", "--allow-unprivileged-cuda"],
            ):
                with (
                    self.subTest(arguments=arguments),
                    patch.object(sys, "argv", arguments),
                ):
                    with self.assertRaises(SystemExit):
                        study.main()
            with (
                patch.object(
                    sys,
                    "argv",
                    ["study", "--phase", "cuda", "--allow-unprivileged-cuda"],
                ),
                patch.object(
                    Path, "read_text", side_effect=RuntimeError("read-manifest")
                ),
                patch.object(study.gpu_tools, "gpu_snapshot") as snapshot,
            ):
                # Admission reaches manifest loading, without launching anything.
                with self.assertRaisesRegex(RuntimeError, "read-manifest"):
                    study.main()
                snapshot.assert_not_called()

    def test_queue_requires_no_socket_directory(self) -> None:
        with patch.object(study.tempfile, "TemporaryDirectory") as temporary:
            with study.ipc_directory(self.study) as directory:
                self.assertIsNone(directory)
            temporary.assert_not_called()

    def receipt(self) -> dict[str, Any]:
        source = self.study.run / "source"
        return {
            "uid": 1234,
            "affinity": [0, 1, 2, 3],
            "source": str(source / "mlserver" / "__init__.py"),
            "onnx_source": str(
                source / "runtimes" / "onnx" / "mlserver_onnx" / "__init__.py"
            ),
            "executable": str(self.study.args.python),
            "gil_enabled": True,
            "cuda_visible_devices": self.study.gpu_uuid,
            "adapter": "stock",
            "transport": "queue",
            "engine": "run",
            "metadata_only": False,
            "buffer_inject": False,
            "zmq_installed": False,
            "adapter_installed": {"buffers": False, "worker_json": False},
        }

    def test_identity_rejects_wrong_user_source_runtime_or_resources(self) -> None:
        with patch.object(
            study.pwd, "getpwnam", return_value=SimpleNamespace(pw_uid=1234)
        ):
            study.validate_identity(self.study, self.receipt())
            for key, value in (
                ("uid", 0),
                ("affinity", [0, 1]),
                ("source", "/mutable/mlserver/__init__.py"),
                ("onnx_source", "/mutable/mlserver_onnx/__init__.py"),
                ("executable", "/usr/bin/python3"),
                ("gil_enabled", False),
                ("cuda_visible_devices", "0"),
                ("adapter", "compact"),
                ("transport", "zmq"),
                ("engine", "cuda-graph"),
                ("metadata_only", True),
                ("buffer_inject", True),
                ("zmq_installed", True),
                ("adapter_installed", {"buffers": True, "worker_json": False}),
            ):
                with self.subTest(key=key):
                    receipt = self.receipt()
                    receipt[key] = value
                    with self.assertRaisesRegex(RuntimeError, key):
                        study.validate_identity(self.study, receipt)

    def rows(self, groups: list[list[int]], start_ns: int) -> list[dict[str, Any]]:
        count = min(self.study.args.concurrency, self.study.args.clients)
        filename = (
            "request.json" if self.study.args.protocol == "rest" else "request.grpc.pb"
        )
        payload = (self.study.args.bundle / "sample" / filename).read_bytes()
        return [
            {
                "protocol": self.study.args.protocol,
                "requests": self.study.args.requests // count,
                "total_drained": self.study.args.requests // count,
                "concurrency": self.study.args.concurrency // count,
                "requested_start_ns": start_ns,
                "cpu_affinity": sorted(group),
                "request_sha256": hashlib.sha256(payload).hexdigest(),
                "errors": [],
                "start_lateness_ns": 1_000_000,
            }
            for group in groups[:count]
        ]

    def test_client_validation_matches_effective_client_count_and_protocol(
        self,
    ) -> None:
        for protocol in ("rest", "grpc"):
            for clients, concurrency in ((2, 8), (2, 1), (4, 8), (4, 2)):
                with self.subTest(
                    protocol=protocol, clients=clients, concurrency=concurrency
                ):
                    self.study.args.protocol = protocol
                    self.study.args.clients = clients
                    self.study.args.concurrency = concurrency
                    groups = [[cpu] for cpu in range(4, 4 + clients)]
                    rows = self.rows(groups, 100_000_000)
                    with patch.object(
                        study.previous, "client_sets", return_value=groups
                    ):
                        study.validate_clients(self.study, rows, 100_000_000)

    def test_client_validation_rejects_mismatched_control_and_jitter(self) -> None:
        groups = [[4, 6], [5, 7]]
        start_ns = 100_000_000
        rows = self.rows(groups, start_ns)
        with patch.object(study.previous, "client_sets", return_value=groups):
            with self.assertRaisesRegex(RuntimeError, "client count"):
                study.validate_clients(self.study, rows[:1], start_ns)
            for key, value in (
                ("protocol", "grpc"),
                ("requests", 15),
                ("total_drained", 15),
                ("concurrency", 3),
                ("requested_start_ns", start_ns + 1),
                ("cpu_affinity", [4]),
                ("request_sha256", "wrong fixture"),
                ("errors", ["failed request"]),
                ("start_lateness_ns", -1),
                ("start_lateness_ns", 50_000_001),
            ):
                with self.subTest(key=key, value=value):
                    invalid = copy.deepcopy(rows)
                    invalid[0][key] = value
                    with self.assertRaises(RuntimeError):
                        study.validate_clients(self.study, invalid, start_ns)


if __name__ == "__main__":
    unittest.main()
