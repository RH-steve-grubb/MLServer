"""Load-client accounting and mocked transport tests; no network/GPU work."""

from contextlib import asynccontextmanager
import asyncio
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np

import gpu_load as load


class AccountingTests(unittest.TestCase):
    def test_fixed_count_distribution_is_exact(self) -> None:
        self.assertEqual(load.request_distribution(10, 3), [4, 3, 3])
        self.assertEqual(load.request_distribution(3, 3), [1, 1, 1])
        for requests, concurrency in ((2, 3), (0, 1), (4, 0), (True, 1)):
            with self.subTest(requests=requests, concurrency=concurrency):
                with self.assertRaises(ValueError):
                    load.request_distribution(requests, concurrency)

    def measured(self) -> load.Measurements:
        return load.Measurements(
            requested_start_ns=1_000_000_000,
            actual_start_ns=1_001_000_000,
            drained_ns=2_001_000_000,
            client_cpu_seconds=0.2,
            requests_attempted=3,
            total_drained=3,
            response_bytes_received=300,
            status_counts={"200": 3},
        )

    def test_result_accounts_full_drain_and_clock(self) -> None:
        result = load.result_for(
            {"protocol": "rest", "requests": 3, "concurrency": 2},
            self.measured(),
            np.array([10.0, 20.0, 30.0]),
        )
        self.assertEqual(result["total_drained"], 3)
        self.assertEqual(result["rps"], 3)
        self.assertEqual(result["start_lateness_ns"], 1_000_000)
        self.assertEqual(result["latency_ms"]["mean"], 20)
        self.assertEqual(result["response_bytes_received"], 300)

    def test_incomplete_counts_errors_and_bad_clock_are_rejected(self) -> None:
        mutations = (
            ("requests_attempted", 2),
            ("total_drained", 2),
            ("status_counts", {"500": 3}),
            ("errors", ["request failed"]),
            ("actual_start_ns", 999_000_000),
            ("drained_ns", 1_001_000_000),
            ("client_cpu_seconds", float("nan")),
        )
        for name, value in mutations:
            with self.subTest(name=name):
                measured = self.measured()
                setattr(measured, name, value)
                with self.assertRaises((ValueError, RuntimeError)):
                    load.result_for(
                        {"protocol": "rest", "requests": 3, "concurrency": 2},
                        measured,
                        np.array([10.0, 20.0, 30.0]),
                    )

    def test_bad_latency_samples_are_rejected(self) -> None:
        for values in ([10.0, 20.0], [10.0, -1.0, 30.0], [0, 20.0, float("nan")]):
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    load.result_for(
                        {"protocol": "rest", "requests": 3, "concurrency": 2},
                        self.measured(),
                        np.array(values),
                    )

    def test_payload_selection_and_spec_validation(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "sample").mkdir()
            (root / "sample" / "request.json").write_bytes(b"json fixture")
            (root / "sample" / "request.grpc.pb").write_bytes(b"protobuf fixture")
            for protocol, expected in (
                ("rest", b"json fixture"),
                ("grpc", b"protobuf fixture"),
            ):
                spec = load.validate_spec(
                    {
                        "protocol": protocol,
                        "bundle": str(root),
                        "http_port": 18080,
                        "grpc_port": 18081,
                        "requests": 4,
                        "concurrency": 2,
                    }
                )
                self.assertEqual(load.payload_for(spec), expected)
                self.assertEqual(spec["warmup_requests"], 0)
                self.assertEqual(spec["host"], "127.0.0.1")
                self.assertEqual(spec["timeout_seconds"], 120)
                for key, value in (
                    ("requests", 1),
                    ("concurrency", False),
                    ("protocol", "http"),
                    ("bundle", "relative"),
                    ("timeout_seconds", float("inf")),
                    ("timeout_seconds", 0),
                    ("start_ns", -1),
                ):
                    with self.subTest(key=key, value=value):
                        with self.assertRaises(ValueError):
                            load.validate_spec(dict(spec, **{key: value}))


class MeasurementTests(unittest.IsolatedAsyncioTestCase):
    async def test_rest_transport_reads_body_without_decoding(self) -> None:
        response = MagicMock()
        response.status = 200
        response.read = AsyncMock(return_value=b"raw response")
        response.__aenter__ = AsyncMock(return_value=response)
        response.__aexit__ = AsyncMock(return_value=False)
        session = MagicMock()
        session.__aenter__ = AsyncMock(return_value=session)
        session.__aexit__ = AsyncMock(return_value=False)
        session.post.return_value = response
        spec = {
            "protocol": "rest",
            "host": "127.0.0.1",
            "http_port": 18080,
            "concurrency": 2,
            "timeout_seconds": 120,
        }
        with patch.object(load.aiohttp, "TCPConnector"):
            with patch.object(
                load.aiohttp, "ClientSession", return_value=session
            ) as made:
                async with load.transport(spec, b"prepared request") as send:
                    result = await send()
        self.assertFalse(made.call_args.kwargs["auto_decompress"])
        session.post.assert_called_once_with(
            "http://127.0.0.1:18080/v2/models/rfdetr-small/infer",
            data=b"prepared request",
            headers={
                "Content-Type": "application/json",
                "Accept-Encoding": "identity",
            },
            allow_redirects=False,
        )
        response.read.assert_awaited_once()
        response.json.assert_not_called()
        self.assertEqual(result, load.Response("200", len(b"raw response")))

    async def test_grpc_transport_preserves_raw_serialized_bytes(self) -> None:
        channel = MagicMock()
        channel.__aenter__ = AsyncMock(return_value=channel)
        channel.__aexit__ = AsyncMock(return_value=False)
        method = AsyncMock(return_value=b"raw protobuf response")
        channel.unary_unary.return_value = method
        spec = {
            "protocol": "grpc",
            "host": "127.0.0.1",
            "grpc_port": 18081,
            "timeout_seconds": 120,
        }
        with patch.object(load.grpc.aio, "insecure_channel", return_value=channel):
            async with load.transport(spec, b"prepared protobuf") as send:
                result = await send()
        channel.unary_unary.assert_called_once_with(
            load.RPC_METHOD, request_serializer=None, response_deserializer=None
        )
        method.assert_awaited_once_with(b"prepared protobuf", timeout=120)
        self.assertEqual(result, load.Response("OK", len(b"raw protobuf response")))

    async def test_measure_reuses_payload_and_excludes_warmup(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "sample").mkdir()
            payload = b"prepared fixture"
            (root / "sample" / "request.json").write_bytes(payload)
            output = root / "client"
            calls = []

            @asynccontextmanager
            async def transport(spec, body):
                self.assertIsInstance(body, bytes)
                self.assertEqual(body, payload)

                async def send():
                    calls.append(body)
                    return load.Response("200", 100)

                yield send

            spec = {
                "protocol": "rest",
                "bundle": str(root),
                "http_port": 18080,
                "requests": 5,
                "concurrency": 2,
                "warmup_requests": 3,
            }
            with patch.object(load, "transport", transport):
                result = await load.measure(spec, output)
            self.assertEqual(len(calls), 8)
            self.assertTrue(all(body is calls[0] for body in calls))
            self.assertEqual(result["total_drained"], 5)
            self.assertEqual(result["request_bytes_sent"], 5 * len(payload))
            self.assertEqual(result["response_bytes_received"], 500)
            self.assertEqual(np.load(output / "latencies.npy").shape, (5,))
            self.assertEqual(json.loads((output / "result.json").read_text()), result)
            self.assertEqual(
                json.loads((output / "ready.json").read_text())["warmup_requests"], 3
            )
            self.assertFalse((output / "FAILED.json").exists())
            with self.assertRaises(FileExistsError):
                await load.measure(spec, output)

    async def test_request_failure_never_publishes_success(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "sample").mkdir()
            (root / "sample" / "request.json").write_bytes(b"fixture")

            @asynccontextmanager
            async def transport(spec, body):
                async def send():
                    return load.Response("503", 10, False)

                yield send

            spec = {
                "protocol": "rest",
                "bundle": str(root),
                "http_port": 18080,
                "requests": 5,
                "concurrency": 2,
            }
            output = root / "client"
            with patch.object(load, "transport", transport):
                with self.assertRaisesRegex(RuntimeError, "503"):
                    await load.measure(spec, output)
            self.assertFalse((output / "result.json").exists())
            failure = json.loads((output / "FAILED.json").read_text())
            self.assertEqual(failure["phase"], "measurement")
            self.assertNotIn("rps", failure)

    async def test_batch_drains_already_inflight_requests_after_failure(self) -> None:
        entered = 0
        completed = 0
        ready = asyncio.Event()

        async def send():
            nonlocal entered, completed
            entered += 1
            index = entered
            if entered == 2:
                ready.set()
            await ready.wait()
            completed += 1
            return load.Response("503" if index == 1 else "200", 10, index != 1)

        measured, _ = await load.run_batch(send, 10, 2, time.monotonic_ns())
        self.assertTrue(measured.errors)
        self.assertEqual(entered, completed)
        self.assertLess(entered, 10)

    async def test_gate_is_read_after_ready_and_before_measurement(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "sample").mkdir()
            (root / "sample" / "request.grpc.pb").write_bytes(b"raw protobuf")
            gate = root / "go.json"
            output = root / "client"
            expected_start = time.monotonic_ns() + 1_000_000

            @asynccontextmanager
            async def transport(spec, body):
                async def send():
                    self.assertTrue((output / "ready.json").is_file())
                    return load.Response("OK", 114000)

                yield send

            async def gated_start(spec):
                self.assertTrue((output / "ready.json").is_file())
                load.publish(gate, {"start_ns": expected_start})
                return await original(spec)

            original = load.wait_for_start
            spec = {
                "protocol": "grpc",
                "bundle": str(root),
                "grpc_port": 18081,
                "requests": 2,
                "concurrency": 2,
                "start_file": str(gate),
            }
            with patch.object(load, "transport", transport):
                with patch.object(load, "wait_for_start", gated_start):
                    result = await load.measure(spec, output)
            self.assertEqual(result["requested_start_ns"], expected_start)
            self.assertGreaterEqual(result["actual_start_ns"], expected_start)


if __name__ == "__main__":
    unittest.main()
