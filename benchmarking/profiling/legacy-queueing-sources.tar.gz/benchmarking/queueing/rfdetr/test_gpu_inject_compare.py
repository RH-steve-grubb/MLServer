"""Injection driver tests mock children, source freeze, tools and GPU receipts."""

import argparse
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import gpu_inject_compare as driver


def values(command: list[str]) -> dict[str, str]:
    pairs = [value for value in command if value != "--buffer-inject"]
    return dict(zip(pairs[::2], pairs[1::2]))


def production() -> dict[str, str]:
    return {f"mlserver/fixture-{i}.py": f"hash-{i}" for i in range(102)}


class InjectionTests(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        args = argparse.Namespace(
            bundle=self.root,
            user="codex",
            screen=False,
            seconds=10.0,
            repeat_seconds=20.0,
            repeats=3,
            without_cuda=False,
            concurrency=16,
        )
        self.plan = driver.baseline.Plan(args, self.root, Path(sys.executable))

    def receipts(self, case: Path, configuration: dict) -> None:
        folder = case / "receipts"
        folder.mkdir()
        common = {
            key: configuration[key]
            for key in (
                "adapter",
                "transport",
                "engine",
                "metadata_only",
                "buffer_inject",
            )
        }
        common.update(
            zmq_installed=True, adapter_installed={"buffers": True, "worker_json": True}
        )
        (folder / "frontend.json").write_text(json.dumps({**common, "pid": 100}))
        for pid in (101, 102):
            record = {
                **common,
                "pid": pid,
                "intra_op_threads": 2,
                "provider_options": {
                    "CUDAExecutionProvider": {"enable_cuda_graph": "1", "use_tf32": "1"}
                },
                "engine_receipt": {
                    "variant": "cuda-graph-blocking",
                    "installed": True,
                    "bound_device_buffers": True,
                    "input_shape": [1, 3, 512, 512],
                    "wait_policy": {
                        "requested_flags": 4,
                        "before_session_flags": 12,
                        "after_session_flags": 12,
                    },
                },
            }
            (folder / f"worker-{pid}.json").write_text(json.dumps(record))

    def child(self, label: str, command: list[str]) -> tuple[dict, Path]:
        parsed = values(command)
        configuration = {
            **driver.FIXED,
            "concurrency": int(parsed["--concurrency"]),
            "buffer_inject": "--buffer-inject" in command,
        }
        phase = parsed["--phase"]
        roles = (
            [("smoke", False)]
            if phase == "smoke"
            else [("control-before", False), (phase, True), ("control-after", False)]
        )
        run = self.root / label
        run.mkdir()
        rows = []
        for index, (role, profiled) in enumerate(roles):
            row = {
                **configuration,
                "profiled": profiled,
                "rps": 100.0,
                "clients": [{}]
                * min(int(parsed["--clients"]), configuration["concurrency"]),
            }
            case = run / f"case-{index:03}-grpc"
            case.mkdir()
            (case / "result.json").write_text(json.dumps(row))
            self.receipts(case, configuration)
            rows.append({**row, "role": role})
        return {
            "results": rows,
            "resource_limits_enforced": not self.plan.args.screen,
        }, run / "SUMMARY.json"

    def test_options_change_only_explicit_injection_flag(self) -> None:
        old = driver.options(driver.FIXED, 2, 5)
        new = driver.options({**driver.FIXED, "buffer_inject": True}, 2, 5)
        self.assertEqual(new, old + ["--buffer-inject"])
        self.assertNotIn("--metadata-only", new)
        self.assertEqual(values(new)["--engine"], "cuda-graph-blocking")

    def test_screen_is_eight_alternating_unprofiled_c16_calls(self) -> None:
        self.plan.args.screen = True
        self.plan.args.repeats, self.plan.args.repeat_seconds = 4, 5.0
        with patch.object(self.plan, "run", side_effect=self.child) as run:
            result = driver.execute(self.plan, {})
        self.assertEqual(run.call_count, 8)
        self.assertEqual(
            [row["variant"] for row in result["repeats"]],
            ["copy", "inject", "inject", "copy"] * 2,
        )
        self.assertTrue(result["screening_only"])
        self.assertFalse(result["resource_budget_verified"])
        self.assertEqual(result["captures"], {})
        self.assertEqual(result["client_controls"], {})
        for call in run.call_args_list:
            parsed = values(call.args[1])
            self.assertEqual(
                (
                    parsed["--phase"],
                    parsed["--clients"],
                    parsed["--concurrency"],
                    parsed["--seconds"],
                ),
                ("smoke", "2", "16", "5.0"),
            )

    def test_formal_has_twelve_trials_two_controls_four_bracketed_profiles(
        self,
    ) -> None:
        with patch.object(self.plan, "run", side_effect=self.child) as run:
            result = driver.execute(self.plan, {})
        self.assertEqual(run.call_count, 18)
        self.assertEqual(len(result["repeats"]), 12)
        self.assertEqual(result["expected_server_cases"], 26)
        counts = Counter(
            (row["variant"], row["concurrency"]) for row in result["repeats"]
        )
        self.assertEqual(set(counts.values()), {3})
        self.assertEqual(set(result["client_controls"]), {"copy", "inject"})
        self.assertEqual(set(result["captures"]), {"cpu", "gil", "stages", "cuda"})
        cases = 0
        for call in run.call_args_list:
            parsed = values(call.args[1])
            self.assertEqual(
                (
                    parsed["--workers"],
                    parsed["--threads"],
                    parsed["--adapter"],
                    parsed["--transport"],
                ),
                ("2", "2", "compact", "zmq"),
            )
            self.assertNotIn("--metadata-only", call.args[1])
            if parsed["--phase"] != "smoke":
                self.assertIn("--buffer-inject", call.args[1])
            cases += 1 if parsed["--phase"] == "smoke" else 3
        self.assertEqual(cases, 26)
        self.assertEqual(len(json.loads((self.root / "REPEATS.json").read_text())), 12)

    def test_wrong_actual_boolean_or_extra_worker_stops_before_recording_trial(
        self,
    ) -> None:
        for change in ("boolean", "worker"):
            location = self.root / change
            location.mkdir()
            original = self.root
            self.root = location

            def child(label: str, command: list[str]) -> tuple[dict, Path]:
                summary, path = self.child(label, command)
                if label == "r0-c1-inject":
                    receipt = path.parent / "case-000-grpc/receipts/worker-101.json"
                    record = json.loads(receipt.read_text())
                    if change == "boolean":
                        record["buffer_inject"] = False
                        receipt.write_text(json.dumps(record))
                    else:
                        (receipt.parent / "worker-103.json").write_text(
                            json.dumps({**record, "pid": 103})
                        )
                return summary, path

            with patch.object(self.plan, "run", side_effect=child), self.assertRaises(
                RuntimeError
            ):
                driver.execute(self.plan, {})
            self.assertEqual(
                len(json.loads((original / "REPEATS.json").read_text())), 1
            )
            self.root = original

    def test_formal_rejects_unverified_budget(self) -> None:
        summary, path = self.child(
            "budget", ["--phase", "smoke", *driver.options(driver.FIXED, 2, 20)]
        )
        summary["resource_limits_enforced"] = False
        with patch.object(self.plan, "run", return_value=(summary, path)):
            with self.assertRaisesRegex(RuntimeError, "root resource limits"):
                driver.run(
                    self.plan,
                    "budget",
                    driver.FIXED,
                    ["--phase", "smoke", *driver.options(driver.FIXED, 2, 20)],
                )

    def reference(self) -> Path:
        config = {**driver.FIXED}
        command = ["--phase", "cuda", *driver.options(config, 2, 1)]
        cuda, path = self.child("reference-cuda", command)
        measured = cuda["results"][1]
        measured.update(
            stage_capture={"valid": True},
            cuda_timeline={
                "database": str(path.parent / "case-001-grpc/cuda-timeline.sqlite")
            },
        )
        path.write_text(json.dumps(cuda))
        # The established reference predates the new selector field.
        for receipt in (path.parent / "case-001-grpc/receipts").glob("*.json"):
            record = json.loads(receipt.read_text())
            record.pop("buffer_inject")
            receipt.write_text(json.dumps(record))
        source = self.root / "reference/source"
        source.mkdir(parents=True)
        (source.parent / "source-hashes.json").write_text(json.dumps(production()))
        prior = {
            "fixed": {"grpc": {"workers": 2, "threads": 2}},
            "model_sha256": hashlib.sha256(b"model").hexdigest(),
        }
        summary = {
            "selected_configuration": driver.winner.SELECTED,
            "captures": {key: str(path) for key in ("cpu", "gil", "stages", "cuda")},
            "reference": {"prior_reference": prior},
            "python": sys.executable,
            "source_snapshot": str(source),
        }
        target = self.root / "reference.json"
        target.write_text(json.dumps(summary))
        return target

    def test_reference_walks_original_inventory_and_checks_actual_winner(self) -> None:
        path = self.reference()
        checked = driver.load_reference(path)
        self.assertEqual(checked["production_hashes"], production())
        self.assertEqual(checked["verified_receipt_pids"], [100, 101, 102])
        self.assertIn("model_sha256", checked["prior_reference"])
        original = json.loads(path.read_text())
        wrong = copy.deepcopy(original)
        wrong["selected_configuration"]["metadata_only"] = True
        path.write_text(json.dumps(wrong))
        with self.assertRaisesRegex(RuntimeError, "selected no-metadata"):
            driver.load_reference(path)

    def test_screen_main_freezes_once_and_does_not_require_profiling_tools(
        self,
    ) -> None:
        self.main_check(screen=True)

    def test_source_mismatch_writes_failed_without_running_children(self) -> None:
        self.main_check(screen=True, source_match=False)

    def main_check(self, screen: bool, source_match: bool = True) -> None:
        (self.root / "model").mkdir()
        (self.root / "model/model.onnx").write_bytes(b"model")
        digest = hashlib.sha256(b"model").hexdigest()
        (self.root / "manifest.json").write_text(
            json.dumps({"onnx": {"sha256": digest}})
        )
        reference = {
            "python": sys.executable,
            "prior_reference": {"model_sha256": digest},
            "production_hashes": production(),
        }

        def freeze(path: Path) -> None:
            hashes = production()
            if not source_match:
                hashes["mlserver/fixture-0.py"] = "changed"
            (path / "source-hashes.json").write_text(json.dumps(hashes))

        argv = [
            "inject",
            "--bundle",
            str(self.root),
            "--store",
            str(self.root / "runs"),
        ]
        if screen:
            argv.append("--screen")
        with patch.object(sys, "argv", argv), patch.object(
            driver.os, "geteuid", return_value=4337
        ), patch.object(driver, "load_reference", return_value=reference), patch.object(
            driver.transport, "environment_inventory", return_value={"verified": True}
        ) as inventory, patch.object(
            driver.study.gpu_tools,
            "capabilities",
            return_value={"perf": {"available": False}, "nsys": {"available": False}},
        ), patch.object(
            driver.study, "freeze", side_effect=freeze
        ) as frozen, patch.object(
            driver, "execute", return_value={"done": True}
        ) as execute:
            if source_match:
                driver.main()
            else:
                with self.assertRaisesRegex(RuntimeError, "Production source differs"):
                    driver.main()
        frozen.assert_called_once()
        inventory.assert_called_once_with(reference["prior_reference"])
        if not source_match:
            execute.assert_not_called()
            failed = list((self.root / "runs").glob("inject-*/FAILED.json"))
            self.assertEqual(len(failed), 1)
            self.assertIn("Production source differs", failed[0].read_text())
            return
        args = execute.call_args.args[0].args
        self.assertEqual((args.screen, args.repeats, args.repeat_seconds), (True, 4, 5))
        output = execute.call_args.args[0].directory
        self.assertTrue((output / "SOURCE.json").exists())
        self.assertTrue((output / "SUMMARY.json").exists())

    def test_formal_nonroot_and_nonfinite_screen_duration_are_rejected(self) -> None:
        for extra in ([], ["--screen", "--repeat-seconds", "nan"]):
            with patch.object(sys, "argv", ["inject", *extra]), patch.object(
                driver.os, "geteuid", return_value=4337
            ):
                with self.assertRaises(SystemExit):
                    driver.main()


if __name__ == "__main__":
    unittest.main()
