"""CPU-only fresh-input qualification tests; servers and HTTP are mocked."""

import argparse
from contextlib import contextmanager
import copy
import io
import json
from pathlib import Path
import tempfile
from typing import Any, Iterator
import unittest
from unittest.mock import patch

import numpy as np

import gpu_rest_fresh_inputs as driver


class FreshInputTests(unittest.TestCase):
    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.bundle, self.oracle = self.root / "bundle", self.root / "oracle"
        (self.bundle / "sample").mkdir(parents=True)
        (self.bundle / "model").mkdir()
        self.oracle.mkdir()
        (self.bundle / "model/model.onnx").write_bytes(b"immutable-model")
        tensor = np.arange(3 * 512 * 512, dtype=np.float32).reshape(1, 3, 512, 512)
        np.save(self.bundle / "sample/input.npy", tensor * 1e-6)
        self.spec = {
            "oracle": True,
            "variant": "run",
            "model_sha256": driver.study.digest(self.bundle / "model/model.onnx"),
            "input_sha256": driver.study.digest(self.bundle / "sample/input.npy"),
        }
        self.receipt = {"status": "ok", "phase": "oracle_complete"}
        self.expected = {
            name: {
                key: np.full(shape, number, dtype=np.float32)
                for key, shape in driver.SHAPES.items()
            }
            for number, name in enumerate(("original", "mirrored"))
        }
        self.write_oracle()

    def write_oracle(self) -> None:
        (self.oracle / "spec.json").write_text(json.dumps(self.spec))
        (self.oracle / "result.json").write_text(json.dumps(self.receipt))
        for name, outputs in self.expected.items():
            np.savez(self.oracle / f"{name}.npz", **outputs)

    def response(self, name: str, identifier: str) -> dict[str, Any]:
        return {
            "id": identifier,
            "outputs": [
                {
                    "name": key,
                    "datatype": "FP32",
                    "shape": list(value.shape),
                    "data": value.reshape(-1).tolist(),
                }
                for key, value in self.expected[name].items()
            ],
        }

    def test_fixture_binds_hashes_and_distinct_contiguous_mirror(self) -> None:
        fixture = driver.fixtures(self.bundle, self.oracle)
        original, mirrored = fixture["tensors"].values()
        np.testing.assert_array_equal(mirrored, original[..., ::-1])
        self.assertTrue(mirrored.flags.c_contiguous)
        self.assertFalse(np.array_equal(original, mirrored))
        self.assertEqual(fixture["hashes"]["model_sha256"], self.spec["model_sha256"])
        self.assertEqual(len(fixture["hashes"]["oracle"]), 4)

    def test_fixture_rejects_unverified_or_mismatched_inputs(self) -> None:
        for key, value in (
            ("oracle", False),
            ("variant", "cuda-graph"),
            ("model_sha256", "wrong"),
            ("input_sha256", "wrong"),
        ):
            with self.subTest(key=key):
                changed = {**self.spec, key: value}
                (self.oracle / "spec.json").write_text(json.dumps(changed))
                with self.assertRaisesRegex(RuntimeError, "identity mismatch"):
                    driver.fixtures(self.bundle, self.oracle)
        self.write_oracle()
        self.receipt["status"] = "failed"
        self.write_oracle()
        with self.assertRaisesRegex(RuntimeError, "identity mismatch"):
            driver.fixtures(self.bundle, self.oracle)

    def test_invalid_or_indistinguishable_oracle_is_rejected(self) -> None:
        for replacement in (
            np.zeros((1, 2), dtype=np.float32),
            np.full(driver.SHAPES["dets"], np.nan, dtype=np.float32),
            np.zeros(driver.SHAPES["dets"], dtype=np.float64),
        ):
            with self.subTest(dtype=replacement.dtype, shape=replacement.shape):
                values = {**self.expected["mirrored"], "dets": replacement}
                np.savez(self.oracle / "mirrored.npz", **values)
                with self.assertRaisesRegex(ValueError, "Invalid immutable oracle"):
                    driver.fixtures(self.bundle, self.oracle)
        np.savez(self.oracle / "mirrored.npz", **self.expected["original"])
        with self.assertRaisesRegex(ValueError, "cannot distinguish"):
            driver.fixtures(self.bundle, self.oracle)

    def test_response_requires_id_shape_finiteness_and_raw_numerical_agreement(
        self,
    ) -> None:
        valid = self.response("original", "request-id")
        self.assertEqual(
            driver.check_response(valid, self.expected["original"], "request-id"),
            {"dets": 0.0, "labels": 0.0},
        )
        for fault in ("id", "duplicate", "datatype", "shape", "nan", "stale"):
            with self.subTest(fault=fault):
                value = copy.deepcopy(valid)
                if fault == "id":
                    value["id"] = "wrong"
                elif fault == "duplicate":
                    value["outputs"][1]["name"] = "dets"
                elif fault == "datatype":
                    value["outputs"][0]["datatype"] = "FP64"
                elif fault == "shape":
                    value["outputs"][0]["shape"] = [1200]
                else:
                    value["outputs"][0]["data"][0] = np.nan if fault == "nan" else 1.0
                with self.assertRaises((ValueError, AssertionError)):
                    driver.check_response(
                        value, self.expected["original"], "request-id"
                    )

    def test_rest_sends_normalized_fp32_numbers_and_requests_both_outputs(self) -> None:
        response = io.BytesIO(b'{"id":"test","outputs":[]}')
        tensor = np.array([[[[1.25, -2.5]]]], dtype=np.float32)
        with patch.object(
            driver.urllib.request, "urlopen", return_value=response
        ) as call:
            driver.request(12345, tensor, "test")
        sent = call.call_args.args[0]
        body = json.loads(sent.data)
        self.assertEqual(
            body["inputs"],
            [
                {
                    "name": "input",
                    "datatype": "FP32",
                    "shape": [1, 1, 1, 2],
                    "data": [1.25, -2.5],
                }
            ],
        )
        self.assertEqual(body["outputs"], [{"name": "dets"}, {"name": "labels"}])
        self.assertEqual(call.call_args.kwargs["timeout"], 120)

    def test_exact_sequence_and_variant_args_are_independent_with_no_extra_inference(
        self,
    ) -> None:
        args = argparse.Namespace(
            user="codex",
            engine="run",
            phase="stages",
            metadata_only=False,
            buffer_inject=False,
        )
        base = driver.study.Study(args, self.root, None, "gpu-test")
        fixture = {
            "tensors": {"original": np.array([1]), "mirrored": np.array([2])},
            "expected": self.expected,
        }
        events, selections, inputs = [], [], []

        @contextmanager
        def serving(selected: Any, case: Path, variant: Any) -> Iterator[dict]:
            selections.append(selected)
            self.assertEqual((variant.workers, variant.threads), (8, 2))
            self.assertEqual((variant.adapter, variant.transport), ("compact", "zmq"))
            self.assertEqual(selected.args.engine, variant.engine)
            self.assertFalse(selected.args.metadata_only or selected.args.buffer_inject)
            events.append("open")
            yield {"http_port": 12345}
            events.append("closed")

        def request(port: int, tensor: np.ndarray, identifier: str) -> dict:
            self.assertEqual(port, 12345)
            name = "original" if tensor[0] == 1 else "mirrored"
            inputs.append(name)
            return self.response(name, identifier)

        def proof(case: Path, server: dict, phases: list[dict]) -> dict:
            self.assertEqual(events[-1], "closed")
            self.assertEqual(
                [phase["input"] for phase in phases],
                ["original", "mirrored", "original"],
            )
            self.assertEqual([len(phase["responses"]) for phase in phases], [8, 8, 8])
            return {"matched_requests": 24}

        with patch.object(driver.study, "serving", serving), patch.object(
            driver, "request", request
        ), patch.object(driver, "worker_proof", proof), patch.object(
            driver.study, "load", side_effect=AssertionError("load")
        ), patch.object(
            driver.study, "run_case", side_effect=AssertionError("benchmark")
        ):
            results = driver.execute(base, fixture)
        self.assertEqual(
            inputs, (["original"] * 8 + ["mirrored"] * 8 + ["original"] * 8) * 2
        )
        self.assertEqual([result["engine"] for result in results], list(driver.ENGINES))
        self.assertEqual([result["requests"] for result in results], [24, 24])
        self.assertIsNot(selections[0].args, selections[1].args)
        self.assertIsNot(selections[0].args, base.args)
        self.assertEqual(base.args.engine, "run")

    def test_worker_proof_requires_one_request_per_phase_on_every_receipt(self) -> None:
        case = self.root / "case"
        (case / "stages").mkdir(parents=True)
        phases = [{"start_ns": start, "end_ns": start + 10} for start in (10, 30, 50)]
        workers = [{"pid": pid} for pid in range(100, 108)]
        records = [
            {
                "stage": "worker.request.inclusive",
                "start_ns": phase["start_ns"] + 1,
                "end_ns": phase["end_ns"] - 1,
            }
            for phase in phases
        ]
        for worker in workers:
            path = case / "stages" / f"stages-{worker['pid']}.json"
            path.write_text(json.dumps({"records": records}))
        server = {"workers": workers}
        with patch.object(
            driver.stages, "collect", return_value={"matched_message_ids": 24}
        ) as collect:
            proof = driver.worker_proof(case, server, phases)
            self.assertEqual(len(proof["workers"]), 8)
            self.assertEqual(collect.call_args.args[1]["total_drained"], 24)
            path = case / "stages/stages-107.json"
            for bad in (records[:2], records + [records[0]], [records[0]] * 3):
                path.write_text(json.dumps({"records": bad}))
                with self.assertRaisesRegex(RuntimeError, "coverage failed"):
                    driver.worker_proof(case, server, phases)
            with self.assertRaisesRegex(RuntimeError, "eight distinct"):
                driver.worker_proof(case, {"workers": workers[:-1]}, phases)


if __name__ == "__main__":
    unittest.main()
