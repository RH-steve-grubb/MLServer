"""Short CPU/GIL diagnostic passes for an already-running serving process tree.

Capture every selected process in one perf session. GIL accounting stays per
process because each process has an independent lock. Final throughput runs
must run without these probes or CPU stack sampling.
"""

import argparse
from collections.abc import Callable
import importlib
import json
from pathlib import Path
import re
import subprocess
import sys
from typing import Any

if __package__:
    legacy = importlib.import_module("..gil_profile", __package__)
else:
    # These harnesses also run directly from their own directory.
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    legacy = importlib.import_module("gil_profile")

# perf prints the selected pid,tid fields as TGID/TID, not two columns.
_EVENT_LINE = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s+(\d+)\.(\d{1,9}):\s+(\S+):\s*$")


def _window(load: dict[str, Any]) -> Any:
    started = load.get("requested_start_ns", load.get("measurement_started_ns"))
    drained = load.get("drained_ns", load.get("measurement_drained_ns"))
    if not isinstance(started, int) or not isinstance(drained, int):
        raise ValueError("Workload must return monotonic start/drained nanoseconds")
    return legacy.Window(started, drained)


def _run(command: list[str], output: Path) -> str:
    with output.open("w") as destination:
        result = subprocess.run(
            command,
            stdout=destination,
            stderr=subprocess.PIPE,
            text=True,
            timeout=120,
        )
    output.with_suffix(".log").write_text(result.stderr)
    if result.returncode:
        raise RuntimeError(
            f"perf decode/report failed; inspect {output.with_suffix('.log')}: "
            + result.stderr[-2000:]
        )
    return result.stderr


def _analyze(
    directory: Path, events: dict[str, str], targets: list[int], window: Any
) -> dict[str, Any]:
    analyses = {pid: legacy.TraceAnalysis(window) for pid in targets}
    counts = dict.fromkeys(targets, 0)
    lost = False
    malformed = 0
    ignored = 0
    with (directory / "events.txt").open() as source:
        for line in source:
            if "LOST" in line.upper():
                lost = True
            match = _EVENT_LINE.match(line)
            if match is None:
                # A known probe event with an unrecognized line format is
                # missing evidence, even if other lines decoded successfully.
                malformed += int(any(event + ":" in line for event in events))
                continue
            pid_text, tid_text, seconds, fraction, event = match.groups()
            if event not in events:
                continue
            pid = int(pid_text)
            if pid not in analyses:
                ignored += 1
                continue
            stamp = int(seconds) * 10**9 + int(fraction.ljust(9, "0"))
            analyses[pid].feed(int(tid_text), stamp, events[event])
            counts[pid] += 1
    warnings = (directory / "events.log").read_text() + (
        directory / "perf.log"
    ).read_text()
    lost |= "LOST" in warnings.upper()
    processes = []
    for pid, analysis in analyses.items():
        result = analysis.finish()
        reasons = []
        if lost:
            reasons.append("perf reported lost events")
        if malformed:
            reasons.append("probe events had an unrecognized perf script format")
        if result["unmatched_events"]:
            reasons.append("unpaired acquisition/condition events inside the window")
        if result["open_acquisitions"] or result["open_condition_waits"]:
            reasons.append("recording stopped with unfinished calls")
        if not result["acquisition"]["count"]:
            reasons.append("no complete GIL acquisitions inside the window")
        result.update(
            pid=pid,
            parsed_events=counts[pid],
            lost_events_reported=lost,
            valid=not reasons,
            invalid_reasons=reasons,
        )
        if reasons:
            # Keep counts for diagnosis. Incomplete intervals have unknown
            # duration; they must never be reported as zero contention.
            result["condition_wait_thread_ms"] = None
            for thread in result["threads"]:
                thread["condition_wait_ms"] = None
        processes.append(result)
    return {
        "processes": processes,
        "valid": all(process["valid"] for process in processes),
        "warnings": warnings.strip(),
        "malformed_probe_lines": malformed,
        "ignored_other_process_events": ignored,
    }


def collect(
    pids: list[int], directory: Path, kind: str, workload: Callable[[], dict]
) -> dict[str, Any]:
    """Capture only selected live processes around one measured workload."""
    if kind not in ("cpu", "gil"):
        raise ValueError("Profile kind must be cpu or gil")
    if not pids or any(type(pid) is not int or pid <= 0 for pid in pids):
        raise ValueError("Profile targets must be positive process IDs")
    targets = sorted(set(pids))
    directory.mkdir(parents=True, exist_ok=True)
    if (directory / "perf.data").exists() or (directory / "analysis.json").exists():
        raise FileExistsError(f"Refusing to overwrite a perf capture in {directory}")
    images = (
        sorted({image for pid in targets for image in legacy.mapped_images(pid)})
        if kind == "gil"
        else []
    )
    # One group probes the union of mapped images. Registering the same libc
    # once per worker would otherwise multiply its events in the capture.
    probes = legacy.Probes(images) if kind == "gil" else None
    metadata = {
        "kind": kind,
        "pids": targets,
        "images": [str(image) for image in images],
        "clock": "CLOCK_MONOTONIC",
        "profiled_numbers_are_not_final_benchmarks": True,
    }
    (directory / "capture.json").write_text(json.dumps(metadata, indent=2))
    with legacy.recording(",".join(str(pid) for pid in targets), directory, probes):
        load = workload()
    (directory / "load.json").write_text(json.dumps(load, indent=2))
    window = _window(load)
    result = dict(
        metadata,
        load=load,
        measurement_started_ns=window.start,
        measurement_drained_ns=window.end,
    )
    if probes is not None:
        _run(
            [
                "perf",
                "script",
                "--ns",
                "--show-lost-events",
                "-i",
                str(directory / "perf.data"),
                "-F",
                "pid,tid,time,event",
            ],
            directory / "events.txt",
        )
        result.update(_analyze(directory, probes.events, targets, window))
    else:
        warnings = _run(
            [
                "perf",
                "report",
                "--stdio",
                "--no-children",
                "-i",
                str(directory / "perf.data"),
                "--sort",
                "comm,tgid,pid,dso,symbol",
                "--time",
                f"{window.start / 1e9:.9f},{window.end / 1e9:.9f}",
            ],
            directory / "cpu-report.txt",
        )
        warnings += (directory / "perf.log").read_text()
        result.update(
            valid=True,
            warnings=warnings.strip(),
            cpu_report="cpu-report.txt",
            interpretation=(
                "CPU sample shares are on-CPU time, not elapsed request time. "
                "The report separates TGID (process) and PID (thread)."
            ),
        )
    (directory / "analysis.json").write_text(json.dumps(result, indent=2))
    if not result["valid"]:
        raise RuntimeError(f"Invalid GIL trace; inspect {directory / 'analysis.json'}")
    return result


def self_test(python: Path, directory: Path, env: dict[str, str]) -> None:
    """Verify quiet and known-contention controls once before serving captures."""
    legacy.python_info(python)
    directory.mkdir(parents=True, exist_ok=True)
    legacy.self_test(argparse.Namespace(python=python, env=env), directory)
