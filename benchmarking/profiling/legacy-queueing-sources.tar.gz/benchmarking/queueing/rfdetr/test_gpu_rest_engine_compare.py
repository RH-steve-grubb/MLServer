"""REST comparison planning tests use mocked children and synthetic receipts."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import gpu_rest_engine_compare as driver


def values(command: list[str]) -> dict[str, str]:
    return dict(zip(command[::2], command[1::2]))


def production() -> dict[str, str]:
    return {f"mlserver/fixture-{i}.py": f"hash-{i}" for i in range(102)}


class RestEngineTests(unittest.TestCase):
    def setUp(self) -> None:
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        args = argparse.Namespace(
            bundle=self.root,
            user="codex",
            screen=False,
            seconds=10.0,
            repeat_seconds=20.0,
            repeats=3,
            without_cuda=False,
            concurrency=16,
        )
        self.plan = driver.baseline.Plan(args, self.root, Path(sys.executable))
        self.reference = {
            "prior_reference": {"fixed": {"rest": {"workers": 8, "threads": 2}}}
        }

    def receipts(self, case: Path, configuration: dict) -> None:
        folder = case / "receipts"
        folder.mkdir()
        common = {
            key: configuration[key]
            for key in (
                "adapter",
                "transport",
                "engine",
                "metadata_only",
                "buffer_inject",
            )
        }
        common.update(
            zmq_installed=True, adapter_installed={"buffers": True, "worker_json": True}
        )
        (folder / "frontend.json").write_text(json.dumps({**common, "pid": 100}))
        graph = configuration["engine"] == "cuda-graph-blocking"
        for pid in range(101, 109):
            record = {
                **common,
                "pid": pid,
                "intra_op_threads": 2,
                "provider_options": {
                    "CUDAExecutionProvider": {"enable_cuda_graph": "1", "use_tf32": "1"}
                },
                "engine_receipt": {
                    "variant": configuration["engine"],
                    "installed": graph,
                    "bound_device_buffers": graph,
                    "input_shape": [1, 3, 512, 512],
                    "wait_policy": {
                        "requested_flags": 4,
                        "before_session_flags": 12,
                        "after_session_flags": 12,
                    },
                },
            }
            (folder / f"worker-{pid}.json").write_text(json.dumps(record))

    def child(self, label: str, command: list[str]) -> tuple[dict, Path]:
        parsed = values(command)
        configuration = {
            **driver.FIXED,
            "engine": parsed["--engine"],
            "concurrency": int(parsed["--concurrency"]),
        }
        phase = parsed["--phase"]
        roles = (
            [("smoke", False)]
            if phase == "smoke"
            else [("control-before", False), (phase, True), ("control-after", False)]
        )
        run = self.root / label
        run.mkdir()
        rows = []
        for index, (role, profiled) in enumerate(roles):
            row = {
                **configuration,
                "profiled": profiled,
                "rps": 30.0,
                "clients": [{}]
                * min(int(parsed["--clients"]), configuration["concurrency"]),
            }
            case = run / f"case-{index:03}-rest"
            case.mkdir()
            (case / "result.json").write_text(json.dumps(row))
            self.receipts(case, configuration)
            rows.append({**row, "role": role})
        return {
            "results": rows,
            "resource_limits_enforced": not self.plan.args.screen,
        }, run / "SUMMARY.json"

    def test_screen_has_eight_alternating_unprofiled_rest_cases(self) -> None:
        self.plan.args.screen = True
        self.plan.args.repeats, self.plan.args.repeat_seconds = 4, 5.0
        with patch.object(self.plan, "run", side_effect=self.child) as run:
            result = driver.execute(self.plan, self.reference)
        self.assertEqual(run.call_count, 8)
        self.assertEqual(
            [row["variant"] for row in result["repeats"]],
            ["run", "cuda-graph-blocking", "cuda-graph-blocking", "run"] * 2,
        )
        self.assertTrue(result["screening_only"])
        self.assertFalse(result["resource_budget_verified"])
        self.assertEqual(result["expected_child_calls"], 8)
        self.assertEqual(result["expected_server_cases"], 8)
        self.assertEqual(result["captures"], {})
        self.assertEqual(result["client_controls"], {})
        for call in run.call_args_list:
            parsed = values(call.args[1])
            self.assertEqual(
                tuple(parsed[key] for key in ("--phase", "--concurrency", "--seconds")),
                ("smoke", "16", "5.0"),
            )

    def test_formal_has_twelve_trials_two_controls_eight_bracketed_captures(
        self,
    ) -> None:
        with patch.object(self.plan, "run", side_effect=self.child) as run:
            result = driver.execute(self.plan, self.reference)
        self.assertEqual(run.call_count, 22)
        self.assertEqual(result["expected_child_calls"], 22)
        self.assertEqual(result["expected_server_cases"], 38)
        self.assertTrue(result["resource_budget_verified"])
        self.assertEqual(len(result["repeats"]), 12)
        counts = Counter(
            (row["variant"], row["concurrency"]) for row in result["repeats"]
        )
        self.assertEqual(set(counts.values()), {3})
        self.assertEqual(
            [row["concurrency"] for row in result["repeats"]],
            [1, 1, 16, 16, 16, 16, 1, 1, 1, 1, 16, 16],
        )
        self.assertEqual(set(result["client_controls"]), {"run", "cuda-graph-blocking"})
        self.assertEqual(set(result["captures"]), {"run", "cuda-graph-blocking"})
        for capture in result["captures"].values():
            self.assertEqual(set(capture["passes"]), {"cpu", "gil", "stages", "cuda"})
        cases = 0
        for call in run.call_args_list:
            command = call.args[1]
            parsed = values(command)
            self.assertEqual(
                tuple(
                    parsed[key]
                    for key in (
                        "--protocol",
                        "--workers",
                        "--threads",
                        "--adapter",
                        "--transport",
                    )
                ),
                ("rest", "8", "2", "compact", "zmq"),
            )
            self.assertNotIn("--metadata-only", command)
            self.assertNotIn("--buffer-inject", command)
            cases += 1 if parsed["--phase"] == "smoke" else 3
        self.assertEqual(cases, 38)
        serial = [row for row in result["repeats"] if row["concurrency"] == 1]
        self.assertEqual({row["active_clients"] for row in serial}, {1})
        self.assertEqual(
            {row["active_clients"] for row in result["client_controls"].values()}, {4}
        )

    def test_wrong_reference_rest_settings_rejected_before_children(self) -> None:
        self.reference["prior_reference"]["fixed"]["rest"]["workers"] = 2
        with patch.object(self.plan, "run") as run:
            with self.assertRaisesRegex(RuntimeError, "eight workers"):
                driver.execute(self.plan, self.reference)
        run.assert_not_called()

    def test_wrong_actual_engine_or_enabled_buffer_flag_stops_trial(self) -> None:
        for key, value in (("engine", "run"), ("buffer_inject", True)):
            with self.subTest(key=key):
                directory = self.root / key
                directory.mkdir()
                original = self.root
                self.root = directory

                def child(label: str, command: list[str]) -> tuple[dict, Path]:
                    summary, path = self.child(label, command)
                    if label == "r0-c1-cuda-graph-blocking":
                        receipt = path.parent / "case-000-rest/receipts/worker-101.json"
                        record = json.loads(receipt.read_text())
                        record[key] = value
                        receipt.write_text(json.dumps(record))
                    return summary, path

                with patch.object(self.plan, "run", side_effect=child):
                    with self.assertRaisesRegex(RuntimeError, "receipt mismatch"):
                        driver.execute(self.plan, self.reference)
                self.root = original

    def test_formal_rejects_unverified_resource_budget(self) -> None:
        def child(label: str, command: list[str]) -> tuple[dict, Path]:
            summary, path = self.child(label, command)
            summary["resource_limits_enforced"] = False
            return summary, path

        with patch.object(self.plan, "run", side_effect=child):
            with self.assertRaisesRegex(RuntimeError, "root resource limits"):
                driver.execute(self.plan, self.reference)

    def test_screen_main_uses_reference_once_and_no_profile_tool_requirement(
        self,
    ) -> None:
        self.main_check(source_match=True)

    def test_source_mismatch_publishes_failure_without_children(self) -> None:
        self.main_check(source_match=False)

    def main_check(self, source_match: bool) -> None:
        (self.root / "model").mkdir()
        (self.root / "model/model.onnx").write_bytes(b"model")
        digest = hashlib.sha256(b"model").hexdigest()
        (self.root / "manifest.json").write_text(
            json.dumps({"onnx": {"sha256": digest}})
        )
        reference = {
            "python": sys.executable,
            "prior_reference": {"model_sha256": digest},
            "production_hashes": production(),
        }

        def freeze(directory: Path) -> None:
            hashes = production()
            if not source_match:
                hashes["mlserver/fixture-0.py"] = "changed"
            (directory / "source-hashes.json").write_text(json.dumps(hashes))

        argv = [
            "rest-engine",
            "--screen",
            "--bundle",
            str(self.root),
            "--store",
            str(self.root / "runs"),
        ]
        with patch.object(sys, "argv", argv), patch.object(
            driver.os, "geteuid", return_value=4337
        ), patch.object(
            driver.injection, "load_reference", return_value=reference
        ) as loader, patch.object(
            driver.transport, "environment_inventory", return_value={"verified": True}
        ) as inventory, patch.object(
            driver.study.gpu_tools,
            "capabilities",
            return_value={"perf": {"available": False}, "nsys": {"available": False}},
        ), patch.object(
            driver.study, "freeze", side_effect=freeze
        ) as frozen, patch.object(
            driver, "execute", return_value={"done": True}
        ) as execute:
            if source_match:
                driver.main()
            else:
                with self.assertRaisesRegex(RuntimeError, "Production source differs"):
                    driver.main()
        loader.assert_called_once()
        frozen.assert_called_once()
        inventory.assert_called_once_with(reference["prior_reference"])
        if source_match:
            plan = execute.call_args.args[0]
            self.assertEqual(
                (plan.args.screen, plan.args.repeats, plan.args.repeat_seconds),
                (True, 4, 5),
            )
            self.assertTrue((plan.directory / "SOURCE.json").exists())
            self.assertTrue((plan.directory / "SUMMARY.json").exists())
        else:
            execute.assert_not_called()
            failed = list((self.root / "runs").glob("rest-engine-*/FAILED.json"))
            self.assertEqual(len(failed), 1)
            self.assertIn("Production source differs", failed[0].read_text())

    def test_nonroot_formal_and_invalid_durations_rejected(self) -> None:
        for extra in ([], ["--screen", "--repeat-seconds", "nan"]):
            with patch.object(sys, "argv", ["rest-engine", *extra]), patch.object(
                driver.os, "geteuid", return_value=4337
            ):
                with self.assertRaises(SystemExit):
                    driver.main()


if __name__ == "__main__":
    unittest.main()
