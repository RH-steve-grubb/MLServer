"""Qualify fresh REST inputs on every worker; this is not a capacity benchmark.

Send original, mirrored, then original normalized FP32 tensors through each of
eight workers for ordinary Run and CUDA Graph/blocking. No warmup, load generator,
profiler, or additional prediction request is used. Root is not required.
"""

import argparse
from dataclasses import replace
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
from typing import Any
import urllib.request

import numpy as np

import gpu_stage_summary as stages
import gpu_study as study
import gpu_transport_compare as transport
import gpu_winner_profile as winner

DEFAULT_ORACLE = Path(
    "/home/codex/mlserver-durable-store/rfdetr-gpu-engine-screen-20261026/"
    "screen-20261026T204923044536Z-368378/oracle"
)
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-rest-fresh-inputs-20261026"
ENGINES = ("run", "cuda-graph-blocking")
SHAPES = {"dets": (1, 300, 4), "labels": (1, 300, 91)}


def fixtures(bundle: Path, oracle: Path) -> dict[str, Any]:
    """Bind both immutable numerical oracles to the original model and input."""
    spec = json.loads((oracle / "spec.json").read_text())
    receipt = json.loads((oracle / "result.json").read_text())
    if (
        spec["oracle"] is not True
        or spec["variant"] != "run"
        or receipt["status"] != "ok"
        or receipt["phase"] != "oracle_complete"
        or study.digest(bundle / "model/model.onnx") != spec["model_sha256"]
        or study.digest(bundle / "sample/input.npy") != spec["input_sha256"]
    ):
        raise RuntimeError("Oracle/model/input identity mismatch")
    original = np.load(bundle / "sample/input.npy", allow_pickle=False)
    if (
        original.dtype != np.float32
        or original.shape != (1, 3, 512, 512)
        or not np.isfinite(original).all()
    ):
        raise ValueError("Expected the prepared normalized finite FP32/B1 input")
    tensors = {
        "original": original,
        "mirrored": np.ascontiguousarray(original[..., ::-1]),
    }
    expected = {}
    for name in tensors:
        with np.load(oracle / f"{name}.npz", allow_pickle=False) as archive:
            expected[name] = {key: archive[key] for key in archive.files}
        values = expected[name]
        if set(values) != set(SHAPES) or any(
            values[key].dtype != np.float32
            or values[key].shape != shape
            or not np.isfinite(values[key]).all()
            for key, shape in SHAPES.items()
        ):
            raise ValueError(f"Invalid immutable oracle: {name}")
    if np.array_equal(original, tensors["mirrored"]) or all(
        np.allclose(
            expected["original"][key], expected["mirrored"][key], rtol=1e-3, atol=1e-3
        )
        for key in SHAPES
    ):
        raise ValueError("Mirrored input/oracle cannot distinguish stale inputs")
    return {
        "tensors": tensors,
        "expected": expected,
        "hashes": {
            "model_sha256": spec["model_sha256"],
            "input_sha256": spec["input_sha256"],
            "oracle": {
                name: study.digest(oracle / name)
                for name in ("spec.json", "result.json", "original.npz", "mirrored.npz")
            },
        },
    }


def check_response(value: dict, expected: dict, request_id: str) -> dict[str, float]:
    """Require both exact FP32 shapes and strict raw numerical agreement."""
    outputs = value.get("outputs", [])
    if value.get("id") != request_id or (
        len(outputs) != 2 or {item["name"] for item in outputs} != set(SHAPES)
    ):
        raise ValueError("Response request ID or output set mismatch")
    errors = {}
    for item in outputs:
        name = item["name"]
        if item["datatype"] != "FP32" or tuple(item["shape"]) != SHAPES[name]:
            raise ValueError(f"Invalid output datatype/shape: {name}")
        actual = np.asarray(item["data"], dtype=np.float32).reshape(SHAPES[name])
        if not np.isfinite(actual).all():
            raise ValueError(f"Nonfinite output: {name}")
        np.testing.assert_allclose(
            actual, expected[name], rtol=1e-3, atol=1e-3, equal_nan=False
        )
        errors[name] = float(np.max(np.abs(actual - expected[name])))
    return errors


def request(port: int, tensor: np.ndarray, request_id: str) -> dict[str, Any]:
    body = json.dumps(
        {
            "id": request_id,
            "inputs": [
                {
                    "name": "input",
                    "datatype": "FP32",
                    "shape": list(tensor.shape),
                    "data": tensor.reshape(-1).tolist(),
                }
            ],
            "outputs": [{"name": name} for name in SHAPES],
        },
        allow_nan=False,
        separators=(",", ":"),
    ).encode()
    call = urllib.request.Request(
        f"http://127.0.0.1:{port}/v2/models/rfdetr-small/infer",
        data=body,
        headers={"Content-Type": "application/json", "Accept-Encoding": "identity"},
    )
    with urllib.request.urlopen(call, timeout=120) as response:
        return json.load(response)


def worker_proof(case: Path, server: dict, phases: list[dict]) -> dict[str, Any]:
    """After teardown, prove exactly one request per phase on every worker."""
    result = {
        "protocol": "rest",
        "adapter": "compact",
        "total_drained": 24,
        "requested_start_ns": phases[0]["start_ns"],
        "drained_ns": phases[-1]["end_ns"],
    }
    capture = stages.collect(case, result, server)
    workers = server["workers"]
    if len(workers) != 8 or len({row["pid"] for row in workers}) != 8:
        raise RuntimeError("Qualification requires eight distinct worker receipts")
    proof = {}
    for worker in workers:
        pid = worker["pid"]
        raw = json.loads((case / "stages" / f"stages-{pid}.json").read_text())
        records = [
            row for row in raw["records"] if row["stage"] == "worker.request.inclusive"
        ]
        counts = [
            sum(
                phase["start_ns"] <= row["start_ns"]
                and row["end_ns"] <= phase["end_ns"]
                for row in records
            )
            for phase in phases
        ]
        if len(records) != 3 or counts != [1, 1, 1]:
            raise RuntimeError(f"Fresh-input worker coverage failed for PID {pid}")
        proof[str(pid)] = {"requests": 3, "phase_counts": counts}
    return {"workers": proof, "matched_requests": capture["matched_message_ids"]}


def execute(base: study.Study, fixture: dict) -> list[dict]:
    results = []
    for engine in ENGINES:
        # Keep each server's environment/receipt expectations bound to its mode.
        args = argparse.Namespace(**{**vars(base.args), "engine": engine})
        selected = replace(base, args=args)
        variant = study.Variant(8, 2, "compact", "zmq", engine)
        case = base.run / engine
        study.owned_directory(case, args.user)
        phases = []
        with study.serving(selected, case, variant) as server:
            for index, name in enumerate(("original", "mirrored", "original")):
                phase: dict[str, Any] = {
                    "input": name,
                    "start_ns": time.monotonic_ns(),
                    "responses": [],
                }
                for number in range(8):
                    identifier = f"fresh-{engine}-{index}-{number}"
                    value = request(
                        server["http_port"], fixture["tensors"][name], identifier
                    )
                    error = check_response(value, fixture["expected"][name], identifier)
                    phase["responses"].append(
                        {"id": identifier, "max_abs_error": error}
                    )
                phase["end_ns"] = time.monotonic_ns()
                phases.append(phase)
                study.publish(case / "PHASES.json", phases)
        proof = worker_proof(case, server, phases)
        result = {
            "engine": engine,
            "case": str(case),
            "requests": 24,
            "phases": phases,
            "worker_proof": proof,
            "status": "passed",
        }
        results.append(result)
        study.publish(base.run / "RESULTS.json", results)
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=winner.DEFAULT_REFERENCE)
    parser.add_argument("--oracle", type=Path, default=DEFAULT_ORACLE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    args.reference, args.oracle, args.bundle, args.store = (
        path.expanduser().resolve()
        for path in (args.reference, args.oracle, args.bundle, args.store)
    )
    args.python = args.python.expanduser().absolute()
    if args.python != Path(sys.executable).absolute():
        parser.error("Invoke this script with the selected pinned serving Python")
    args.protocol, args.phase, args.capture = "rest", "stages", "cpu"
    args.adapter, args.transport, args.engine = "compact", "zmq", "run"
    args.metadata_only = args.buffer_inject = False
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    run = args.store / f"qualification-{stamp}-{os.getpid()}"
    study.owned_directory(run, args.user)
    print(f"Qualification output: {run}", flush=True)
    try:
        reference = winner.load_reference(args.reference)
        environment = transport.environment_inventory(reference["prior_reference"])
        fixture = fixtures(args.bundle, args.oracle)
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if (
            fixture["hashes"]["model_sha256"]
            != reference["prior_reference"]["model_sha256"]
            or manifest["onnx"]["sha256"] != fixture["hashes"]["model_sha256"]
        ):
            raise RuntimeError("Model differs from verified serving reference")
        study.freeze(run)
        frozen = json.loads((run / "source-hashes.json").read_text())
        if winner.production(frozen) != reference["production_hashes"]:
            raise RuntimeError(
                "Production source differs from verified serving reference"
            )
        gpu = study.gpu_tools.gpu_snapshot()
        device = gpu["gpus"][0]
        if (
            "4070" not in device["name"]
            or device["memory_total_mib"] is None
            or device["memory_used_mib"] is None
            or device["memory_total_mib"] - device["memory_used_mib"] < 8192
        ):
            raise RuntimeError(
                "Eight-worker qualification requires RTX4070 with 8 GiB free"
            )
        budget = study.automatic_budget()
        study.previous.validate_budget(budget)
        study.publish(
            run / "SETUP.json",
            {
                "qualification_only": True,
                "capacity_measurement": False,
                "resource_limits_enforced": os.geteuid() == 0,
                "arguments": {key: str(value) for key, value in vars(args).items()},
                "environment": environment,
                "gpu": gpu,
                "budget": budget.__dict__,
                "reference": reference,
                "hashes": fixture["hashes"],
                "source_manifest_sha256": study.digest(run / "source-hashes.json"),
            },
        )
        selected = study.Study(args, run, budget, device["uuid"])
        results = execute(selected, fixture)
        study.publish(
            run / "SUMMARY.json",
            {
                "qualification_only": True,
                "capacity_measurement": False,
                "status": "passed",
                "results": results,
            },
        )
        print(f"Complete: {run / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            run / "FAILED.json", {"type": type(error).__name__, "message": str(error)}
        )
        raise


if __name__ == "__main__":
    main()
