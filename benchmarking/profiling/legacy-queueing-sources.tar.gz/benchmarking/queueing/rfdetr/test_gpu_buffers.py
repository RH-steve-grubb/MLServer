"""Real-protobuf buffer adapter tests; no server, model, GPU or network work."""

import copy
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from functools import wraps
from multiprocessing.reduction import ForkingPickler
import os
import struct
from threading import Barrier
from types import SimpleNamespace
from typing import Any, cast
import unittest
from unittest.mock import Mock, patch

import numpy as np

from mlserver.codecs.numpy import NumpyCodec
from mlserver.grpc import converters
from mlserver.grpc import dataplane_pb2 as pb
from mlserver.grpc.converters import ModelInferRequestConverter
from mlserver.parallel.messages import ModelRequestMessage
from mlserver.types import InferenceRequest

import gpu_buffers as buffers

MODES = ((False, False), (True, False), (False, True))


class BufferTests(unittest.TestCase):
    def setUp(self) -> None:
        self.original_descriptor = ModelInferRequestConverter.__dict__["to_types"]
        self.original = ModelInferRequestConverter.to_types
        self.addCleanup(
            setattr, ModelInferRequestConverter, "to_types", self.original_descriptor
        )
        self.addCleanup(setattr, converters, "inject_raw", converters.inject_raw)

    @staticmethod
    def request() -> pb.ModelInferRequest:
        return pb.ModelInferRequest(
            model_name="rfdetr-small",
            model_version="1",
            id="sample-request",
            inputs=[
                pb.ModelInferRequest.InferInputTensor(
                    name="images", datatype="FP32", shape=[1, 2]
                )
            ],
            raw_input_contents=[struct.pack("<2f", 1.25, -2.5)],
        )

    def test_supported_input_uses_readonly_flat_fp32_view(self) -> None:
        request = self.request()
        original = Mock(wraps=self.original)
        converted = buffers.convert(request, original)
        data = converted.inputs[0].data.root
        self.assertIsInstance(data, np.ndarray)
        self.assertEqual(data.dtype, np.dtype("<f4"))
        self.assertEqual(data.shape, (2,))
        self.assertFalse(data.flags.writeable)
        self.assertFalse(data.flags.owndata)
        np.testing.assert_array_equal(data, [1.25, -2.5])
        delegated = original.call_args.args[0]
        self.assertIsNot(delegated, request)
        self.assertEqual(len(delegated.raw_input_contents), 0)

    def test_injection_passes_same_protobuf_without_unpacking_or_mutating(self) -> None:
        request = self.request()
        before = request.SerializeToString()
        original = Mock(wraps=self.original)
        with patch("mlserver.raw._unpack_tensor", side_effect=AssertionError("unpack")):
            converted = buffers.convert(request, original, buffer_inject=True)
        original.assert_called_once_with(request)
        self.assertIs(original.call_args.args[0], request)
        self.assertEqual(request.SerializeToString(), before)
        self.assertEqual(len(request.raw_input_contents), 1)
        data = converted.inputs[0].data.root
        self.assertFalse(data.flags.writeable)
        self.assertFalse(data.flags.owndata)
        del request
        np.testing.assert_array_equal(data, [1.25, -2.5])
        # The installed seam delegates normally outside its request context.
        restored = self.original(self.request())
        self.assertIsInstance(restored.inputs[0].data.root, list)

    def test_injection_scopes_nested_fallback_and_exception_paths(self) -> None:
        request = self.request()
        inner = self.request()
        inner.raw_input_contents[0] = struct.pack("<2f", 9.0, 10.0)
        fallback = self.request()
        fallback.model_name = "another-model"

        def nested(value: pb.ModelInferRequest) -> InferenceRequest:
            converted = buffers.convert(inner, self.original, buffer_inject=True)
            np.testing.assert_array_equal(converted.inputs[0].data.root, [9.0, 10.0])
            normal = buffers.convert(fallback, self.original, buffer_inject=True)
            self.assertIsInstance(normal.inputs[0].data.root, list)
            self.assertEqual(normal.inputs[0].data.root, [1.25, -2.5])
            with self.assertRaisesRegex(RuntimeError, "conversion failed"):
                buffers.convert(
                    inner,
                    Mock(side_effect=RuntimeError("conversion failed")),
                    buffer_inject=True,
                )
            return self.original(value)

        converted = buffers.convert(request, nested, buffer_inject=True)
        np.testing.assert_array_equal(converted.inputs[0].data.root, [1.25, -2.5])
        with self.assertRaisesRegex(RuntimeError, "outer failed"):
            buffers.convert(
                request,
                Mock(side_effect=RuntimeError("outer failed")),
                buffer_inject=True,
            )
        self.assertIsInstance(self.original(request).inputs[0].data.root, list)

    def test_injection_context_is_isolated_between_threads(self) -> None:
        # Both converters reach the seam concurrently with different buffers.
        buffers._install_inject()
        barrier = Barrier(2)

        def convert(value: float) -> np.ndarray:
            request = self.request()
            request.raw_input_contents[0] = struct.pack("<2f", value, -value)

            def original(message: pb.ModelInferRequest) -> InferenceRequest:
                barrier.wait(timeout=5)
                return self.original(message)

            result = buffers.convert(request, original, buffer_inject=True)
            return result.inputs[0].data.root

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(convert, [3.0, 7.0]))
        np.testing.assert_array_equal(results[0], [3.0, -3.0])
        np.testing.assert_array_equal(results[1], [7.0, -7.0])
        self.assertIsInstance(self.original(self.request()).inputs[0].data.root, list)

    def test_special_fp32_bits_survive_conversion_and_worker_decode(self) -> None:
        bits = np.array(
            [0, 0x80000000, 0x7FC00001, 0x7F800001, 0x7F800000, 0xFF800000, 1],
            dtype="<u4",
        )
        request = self.request()
        request.inputs[0].shape[:] = [1, len(bits)]
        request.raw_input_contents[0] = bits.tobytes()
        for mode in MODES:
            with self.subTest(mode=mode):
                converted = buffers.convert(request, self.original, *mode)
                np.testing.assert_array_equal(
                    converted.inputs[0].data.root.view("<u4"), bits
                )
                message = ModelRequestMessage(
                    model_name="rfdetr-small",
                    method_name="predict",
                    method_args=[converted],
                )
                received = ForkingPickler.loads(ForkingPickler.dumps(message))
                restored = received.method_args[0]
                worker_array = NumpyCodec.decode_input(restored.inputs[0])
                self.assertEqual(worker_array.shape, (1, len(bits)))
                np.testing.assert_array_equal(
                    worker_array.reshape(-1).view("<u4"), bits
                )
                self.assertTrue(worker_array.flags.writeable)

    def test_metadata_and_caller_bytes_are_preserved(self) -> None:
        request = self.request()
        request.parameters["sequence"].int64_param = 42
        request.parameters["mode"].string_param = "detection"
        request.parameters["disabled"].bool_param = False
        request.inputs[0].parameters["content_type"].string_param = "np"
        request.outputs.add(name="dets").parameters["option"].bool_param = True
        request.outputs.add(name="labels").parameters["count"].int64_param = 0
        before = request.SerializeToString()
        expected = self.original(request)
        for mode in MODES:
            with self.subTest(mode=mode):
                converted = buffers.convert(request, self.original, *mode)
                self.assertEqual(converted.id, expected.id)
                self.assertEqual(converted.parameters, expected.parameters)
                self.assertEqual(converted.outputs, expected.outputs)
                actual_input, expected_input = converted.inputs[0], expected.inputs[0]
                self.assertEqual(actual_input.name, expected_input.name)
                self.assertEqual(actual_input.datatype, expected_input.datatype)
                self.assertEqual(actual_input.shape, expected_input.shape)
                self.assertEqual(actual_input.parameters, expected_input.parameters)
                self.assertEqual(request.SerializeToString(), before)

    def test_zero_length_and_scalar_shapes_are_supported(self) -> None:
        for shape, values in (([0, 3], []), ([], [1.25])):
            for mode in MODES:
                with self.subTest(shape=shape, mode=mode):
                    request = self.request()
                    request.inputs[0].shape[:] = shape
                    request.raw_input_contents[0] = struct.pack(
                        f"<{len(values)}f", *values
                    )
                    converted = buffers.convert(request, self.original, *mode)
                    np.testing.assert_array_equal(converted.inputs[0].data.root, values)
                    self.assertEqual(
                        NumpyCodec.decode_input(converted.inputs[0]).shape, tuple(shape)
                    )

    def test_multiple_raw_inputs_keep_individual_shapes_and_values(self) -> None:
        request = self.request()
        request.inputs.add(name="second", datatype="FP32", shape=[1])
        request.raw_input_contents.append(struct.pack("<f", 4.5))
        for mode in MODES:
            with self.subTest(mode=mode):
                converted = buffers.convert(request, self.original, *mode)
                self.assertEqual(
                    [tensor.name for tensor in converted.inputs], ["images", "second"]
                )
                np.testing.assert_array_equal(
                    NumpyCodec.decode_input(converted.inputs[0]), [[1.25, -2.5]]
                )
                np.testing.assert_array_equal(
                    NumpyCodec.decode_input(converted.inputs[1]), [4.5]
                )

    def check_fallback(self, request: pb.ModelInferRequest) -> None:
        before = request.SerializeToString()
        for mode in MODES:
            with self.subTest(mode=mode):
                original = Mock(wraps=self.original)
                try:
                    expected = self.original(copy.deepcopy(request))
                except Exception as error:
                    with self.assertRaises(type(error)) as raised:
                        buffers.convert(request, original, *mode)
                    self.assertEqual(str(raised.exception), str(error))
                else:
                    actual = buffers.convert(request, original, *mode)
                    self.assertEqual(actual.model_dump(), expected.model_dump())
                original.assert_called_once_with(request)
                self.assertIs(original.call_args.args[0], request)
                self.assertEqual(request.SerializeToString(), before)

    def test_unsupported_models_datatypes_and_typed_contents_fall_back(self) -> None:
        request = self.request()
        request.model_name = "another-model"
        self.check_fallback(request)
        request = self.request()
        request.inputs[0].datatype = "FP64"
        request.raw_input_contents[0] = struct.pack("<2d", 1.25, -2.5)
        self.check_fallback(request)
        request = self.request()
        request.inputs[0].contents.fp32_contents.extend([1.25, -2.5])
        self.check_fallback(request)
        request = self.request()
        request.inputs[0].contents.fp32_contents.extend([1.25, -2.5])
        request.inputs.add(name="second", datatype="FP32", shape=[2])
        self.check_fallback(request)

    def test_malformed_shapes_and_buffer_counts_preserve_original_behavior(
        self,
    ) -> None:
        for shape in ([-1], [3], [0], [2**62, 2**62]):
            with self.subTest(shape=shape):
                request = self.request()
                request.inputs[0].shape[:] = shape
                self.check_fallback(request)
        for buffers_value in ([], [b"bad"], [struct.pack("<2f", 1.25, -2.5), b"extra"]):
            with self.subTest(buffers=buffers_value):
                request = self.request()
                request.raw_input_contents[:] = buffers_value
                self.check_fallback(request)
        request = self.request()
        request.ClearField("inputs")
        self.check_fallback(request)

    def test_install_is_explicit_idempotent_and_exposes_receipt_marker(self) -> None:
        for adapter in (None, "stock", "worker-json"):
            with self.subTest(adapter=adapter):
                with patch.dict(os.environ, {}, clear=True):
                    if adapter is not None:
                        os.environ["MLSERVER_GPU_ADAPTER"] = adapter
                    buffers.install()
                self.assertIs(
                    ModelInferRequestConverter.__dict__["to_types"],
                    self.original_descriptor,
                )
        for adapter in ("buffers", "compact"):
            with self.subTest(adapter=adapter):
                setattr(
                    ModelInferRequestConverter, "to_types", self.original_descriptor
                )
                with patch.dict(
                    os.environ,
                    {
                        "MLSERVER_GPU_ADAPTER": adapter,
                        "MLSERVER_GPU_METADATA_ONLY": "0",
                        "MLSERVER_GPU_BUFFER_INJECT": "0",
                    },
                ):
                    buffers.install()
                    installed: Any = ModelInferRequestConverter.__dict__["to_types"]
                    buffers.install()
                self.assertIs(
                    ModelInferRequestConverter.__dict__["to_types"], installed
                )
                self.assertTrue(
                    getattr(ModelInferRequestConverter.to_types, "_gpu_buffers", False)
                )
                self.assertIs(
                    getattr(ModelInferRequestConverter.to_types, "_gpu_metadata_only"),
                    False,
                )
                self.assertIs(
                    getattr(ModelInferRequestConverter.to_types, "_gpu_buffer_inject"),
                    False,
                )
                converted = ModelInferRequestConverter.to_types(
                    pb_object=self.request()
                )
                self.assertIsInstance(converted.inputs[0].data.root, np.ndarray)

    def test_metadata_only_reads_raw_buffers_once_and_keeps_them_alive(self) -> None:
        class RawBuffers(list[bytes]):
            iterations = 0

            def __iter__(self) -> Iterator[bytes]:
                self.iterations += 1
                return super().__iter__()

        request = self.request()
        raw = RawBuffers(request.raw_input_contents)
        # Count native-container reads without patching generated protobuf code.
        # The real protobuf still supplies every metadata field and value.
        view = SimpleNamespace(
            model_name=request.model_name,
            inputs=request.inputs,
            raw_input_contents=raw,
            ListFields=request.ListFields,
        )
        original = Mock(wraps=self.original)
        converted = buffers.convert(cast(pb.ModelInferRequest, view), original, True)
        self.assertEqual(raw.iterations, 1)
        delegated = original.call_args.args[0]
        expected = pb.ModelInferRequest()
        expected.CopyFrom(request)
        expected.ClearField("raw_input_contents")
        self.assertEqual(delegated, expected)
        del view, raw, request
        np.testing.assert_array_equal(converted.inputs[0].data.root, [1.25, -2.5])

    def test_injection_reads_raw_buffers_once(self) -> None:
        class RawBuffers(list[bytes]):
            iterations = 0

            def __iter__(self) -> Iterator[bytes]:
                self.iterations += 1
                return super().__iter__()

        request = self.request()
        raw = RawBuffers(request.raw_input_contents)

        class RequestView:
            raw_input_contents = raw

            def __getattr__(self, name: str) -> Any:
                return getattr(request, name)

        view = cast(pb.ModelInferRequest, RequestView())
        original = Mock(wraps=self.original)
        converted = buffers.convert(view, original, buffer_inject=True)
        self.assertEqual(raw.iterations, 1)
        self.assertIs(original.call_args.args[0], view)
        np.testing.assert_array_equal(converted.inputs[0].data.root, [1.25, -2.5])

    def test_metadata_mode_is_idempotent_through_stage_wrapper_and_cannot_change(
        self,
    ) -> None:
        for enabled in (False, True):
            with self.subTest(metadata_only=enabled):
                setattr(
                    ModelInferRequestConverter, "to_types", self.original_descriptor
                )
                with patch.dict(
                    os.environ,
                    {
                        "MLSERVER_GPU_ADAPTER": "compact",
                        "MLSERVER_GPU_METADATA_ONLY": str(int(enabled)),
                        "MLSERVER_GPU_BUFFER_INJECT": "0",
                    },
                ):
                    buffers.install()
                    original = ModelInferRequestConverter.__dict__["to_types"].__func__
                    calls = []

                    @wraps(original)
                    def staged(
                        cls: type[ModelInferRequestConverter],
                        pb_object: pb.ModelInferRequest,
                    ) -> InferenceRequest:
                        calls.append("stage")
                        return original(cls, pb_object)

                    decorated = classmethod(staged)
                    setattr(ModelInferRequestConverter, "to_types", decorated)
                    buffers.install()
                    self.assertIs(
                        ModelInferRequestConverter.__dict__["to_types"], decorated
                    )
                    self.assertIs(
                        getattr(
                            ModelInferRequestConverter.to_types, "_gpu_metadata_only"
                        ),
                        enabled,
                    )
                    converted = ModelInferRequestConverter.to_types(self.request())
                    np.testing.assert_array_equal(
                        converted.inputs[0].data.root, [1.25, -2.5]
                    )
                    self.assertEqual(calls, ["stage"])
                    os.environ["MLSERVER_GPU_METADATA_ONLY"] = str(int(not enabled))
                    with self.assertRaisesRegex(
                        RuntimeError, "Cannot change metadata-copy mode"
                    ):
                        buffers.install()
                    self.assertIs(
                        ModelInferRequestConverter.__dict__["to_types"], decorated
                    )

    def test_invalid_metadata_mode_is_rejected_before_installation(self) -> None:
        with patch.dict(
            os.environ,
            {"MLSERVER_GPU_ADAPTER": "buffers", "MLSERVER_GPU_METADATA_ONLY": "true"},
        ):
            with self.assertRaisesRegex(ValueError, "must be 0 or 1"):
                buffers.install()
        self.assertIs(
            ModelInferRequestConverter.__dict__["to_types"], self.original_descriptor
        )

    def test_injection_mode_is_idempotent_through_stages_and_cannot_change(
        self,
    ) -> None:
        with patch.dict(
            os.environ,
            {
                "MLSERVER_GPU_ADAPTER": "compact",
                "MLSERVER_GPU_METADATA_ONLY": "0",
                "MLSERVER_GPU_BUFFER_INJECT": "1",
            },
        ):
            buffers.install()
            original = ModelInferRequestConverter.__dict__["to_types"].__func__
            inject = converters.inject_raw
            calls = []

            @wraps(original)
            def staged(
                cls: type[ModelInferRequestConverter],
                pb_object: pb.ModelInferRequest,
            ) -> InferenceRequest:
                calls.append("stage")
                return original(cls, pb_object)

            decorated = classmethod(staged)
            setattr(ModelInferRequestConverter, "to_types", decorated)
            buffers.install()
            self.assertIs(ModelInferRequestConverter.__dict__["to_types"], decorated)
            self.assertIs(converters.inject_raw, inject)
            self.assertTrue(getattr(staged, "_gpu_buffers"))
            self.assertTrue(getattr(staged, "_gpu_buffer_inject"))
            self.assertFalse(getattr(staged, "_gpu_metadata_only"))
            converted = ModelInferRequestConverter.to_types(pb_object=self.request())
            np.testing.assert_array_equal(converted.inputs[0].data.root, [1.25, -2.5])
            self.assertEqual(calls, ["stage"])
            os.environ["MLSERVER_GPU_BUFFER_INJECT"] = "0"
            with self.assertRaisesRegex(RuntimeError, "Cannot change buffer-injection"):
                buffers.install()
            self.assertIs(ModelInferRequestConverter.__dict__["to_types"], decorated)
            self.assertIs(converters.inject_raw, inject)

    def test_enabling_injection_after_control_installation_is_rejected(self) -> None:
        with patch.dict(
            os.environ,
            {
                "MLSERVER_GPU_ADAPTER": "compact",
                "MLSERVER_GPU_METADATA_ONLY": "0",
                "MLSERVER_GPU_BUFFER_INJECT": "0",
            },
        ):
            buffers.install()
            original = ModelInferRequestConverter.__dict__["to_types"]
            os.environ["MLSERVER_GPU_BUFFER_INJECT"] = "1"
            with self.assertRaisesRegex(RuntimeError, "Cannot change buffer-injection"):
                buffers.install()
            self.assertIs(ModelInferRequestConverter.__dict__["to_types"], original)

    def test_invalid_or_conflicting_injection_mode_cannot_install(self) -> None:
        for metadata, inject in (("0", "true"), ("1", "1")):
            with self.subTest(metadata=metadata, inject=inject):
                original = converters.inject_raw
                with patch.dict(
                    os.environ,
                    {
                        "MLSERVER_GPU_ADAPTER": "compact",
                        "MLSERVER_GPU_METADATA_ONLY": metadata,
                        "MLSERVER_GPU_BUFFER_INJECT": inject,
                    },
                ):
                    with self.assertRaises(ValueError):
                        buffers.install()
                self.assertIs(converters.inject_raw, original)
                self.assertIs(
                    ModelInferRequestConverter.__dict__["to_types"],
                    self.original_descriptor,
                )
        with self.assertRaisesRegex(ValueError, "mutually exclusive"):
            buffers.convert(self.request(), self.original, True, True)


if __name__ == "__main__":
    unittest.main()
