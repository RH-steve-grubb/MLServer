"""Mocked confirmation-plan tests: no sockets, profiling, root or GPU actions."""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

import gpu_grpc_confirm as driver


def reference() -> dict:
    return {
        "python": "/old/bin/python",
        "model_sha256": "fixed-model",
        "fixed": {
            "grpc": {"workers": 2, "threads": 2},
            "rest": {"workers": 8, "threads": 2},
        },
    }


def plan(directory: Path) -> driver.baseline.Plan:
    args = argparse.Namespace(
        bundle=directory,
        user="codex",
        seconds=10.0,
        repeat_seconds=20.0,
        repeats=3,
        concurrency=16,
        without_cuda=False,
    )
    return driver.baseline.Plan(args, directory, Path("/transport/bin/python"))


class ConfirmationTests(unittest.TestCase):
    def child(self, label, options):
        selected = dict(zip(options[::2], options[1::2]))
        configuration = {
            name: selected[f"--{name}"] for name in ("protocol", "adapter", "transport")
        }
        configuration.update(
            {
                name: int(selected[f"--{name}"])
                for name in ("workers", "threads", "concurrency")
            }
        )
        clients = min(int(selected["--clients"]), configuration["concurrency"])
        row = {**configuration, "clients": [{} for _ in range(clients)], "rps": 100.0}
        phase = selected["--phase"]
        if phase == "smoke":
            rows = [{**row, "profiled": False, "role": "smoke"}]
        else:
            rows = [
                {**row, "role": role, "profiled": profiled}
                for role, profiled in (
                    ("control-before", False),
                    (phase, True),
                    ("control-after", False),
                )
            ]
        return {"results": rows}, Path("/results") / label / "SUMMARY.json"

    def test_rotates_variants_and_topology_without_retuning(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            current = plan(Path(folder))
            with mock.patch.object(current, "run", side_effect=self.child) as run:
                result = driver.execute(current, reference())
            self.assertEqual(run.call_count, 26)
            self.assertEqual(len(result["repeats"]), 18)
            topology_order = [result["repeats"][i]["clients"] for i in range(0, 18, 3)]
            self.assertEqual(topology_order, [2, 4, 4, 2, 2, 4])
            for clients in (2, 4):
                positions = defaultdict(list)
                selected = [
                    row for row in result["repeats"] if row["clients"] == clients
                ]
                for index, row in enumerate(selected):
                    positions[row["variant"]].append(index % 3)
                    value = row["result"]
                    self.assertEqual(
                        (
                            value["protocol"],
                            value["workers"],
                            value["threads"],
                            value["concurrency"],
                        ),
                        ("grpc", 2, 2, 16),
                    )
                    self.assertEqual(len(value["clients"]), clients)
                self.assertEqual(set(positions), {item[0] for item in driver.VARIANTS})
                self.assertTrue(
                    all(set(order) == {0, 1, 2} for order in positions.values())
                )
            selectors = Counter(
                (row["result"]["adapter"], row["result"]["transport"])
                for row in result["repeats"]
            )
            self.assertEqual(
                selectors,
                {("stock", "queue"): 6, ("compact", "queue"): 6, ("compact", "zmq"): 6},
            )
            captures = result["captures"]
            grpc = captures["grpc-clients4-compact-zmq"]
            self.assertEqual(grpc["requested_clients"], 4)
            self.assertEqual(set(grpc["passes"]), {"cpu", "gil", "stages", "cuda"})
            for transport in ("queue", "zmq"):
                rest = captures[f"rest-c1-compact-{transport}"]
                self.assertEqual(set(rest["passes"]), {"cpu", "stages"})
                self.assertEqual(rest["configuration"]["concurrency"], 1)
                self.assertEqual(rest["configuration"]["workers"], 8)
                self.assertEqual(rest["active_clients"], 1)
            for call in run.call_args_list[:18]:
                option_values = dict(zip(call.args[1][::2], call.args[1][1::2]))
                self.assertEqual(option_values["--seconds"], "20.0")
            self.assertEqual(
                len(json.loads((current.directory / "REPEATS.json").read_text())), 18
            )
            self.assertTrue((current.directory / "CAPTURES.json").exists())

    def test_rejects_mismatched_client_count(self) -> None:
        configuration = {
            "protocol": "grpc",
            "adapter": "compact",
            "transport": "zmq",
            "workers": 2,
            "threads": 2,
            "concurrency": 16,
        }
        with self.assertRaisesRegex(RuntimeError, "client count"):
            driver._check(
                {**configuration, "rps": 100.0, "clients": [{}]}, configuration, 4
            )

    def test_profiled_trial_cannot_become_unprofiled_repeat(self) -> None:
        def child(label, options):
            summary, path = self.child(label, options)
            summary["results"][0]["profiled"] = True
            return summary, path

        with tempfile.TemporaryDirectory() as folder:
            current = plan(Path(folder))
            with mock.patch.object(current, "run", side_effect=child):
                with self.assertRaisesRegex(RuntimeError, "unprofiled trial"):
                    driver.execute(current, reference())

    def test_capture_controls_are_required_and_progress_survives_failure(self) -> None:
        def child(label, options):
            summary, path = self.child(label, options)
            if label == "grpc-clients4-compact-zmq-stages":
                summary["results"] = summary["results"][1:]
            return summary, path

        with tempfile.TemporaryDirectory() as folder:
            current = plan(Path(folder))
            with mock.patch.object(current, "run", side_effect=child):
                with self.assertRaisesRegex(RuntimeError, "before/after controls"):
                    driver.execute(current, reference())
            repeats = json.loads((current.directory / "REPEATS.json").read_text())
            self.assertEqual(len(repeats), 18)
            captures = json.loads((current.directory / "CAPTURES.json").read_text())
            self.assertEqual(
                set(captures["grpc-clients4-compact-zmq"]["passes"]), {"cpu", "gil"}
            )


class EntryPointTests(unittest.TestCase):
    @mock.patch.object(driver, "execute", return_value={"complete": True})
    @mock.patch.object(
        driver.transport, "environment_inventory", return_value={"checked": True}
    )
    @mock.patch.object(
        driver.transport, "load_reference", side_effect=lambda path: reference()
    )
    @mock.patch.object(driver.study, "freeze")
    @mock.patch.object(
        driver.study.gpu_tools,
        "capabilities",
        return_value={"perf": {"available": True}, "nsys": {"available": True}},
    )
    @mock.patch.object(driver.os, "geteuid", return_value=0)
    def test_main_uses_new_environment_and_one_frozen_source(
        self, uid, tools, freeze, load_reference, inventory, execute
    ) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "manifest.json").write_text(
                json.dumps({"onnx": {"sha256": "fixed-model"}})
            )
            arguments = ["confirm", "--store", folder, "--bundle", folder]
            with mock.patch.object(sys, "argv", arguments), mock.patch.object(
                sys, "executable", "/transport/bin/python"
            ):
                driver.main()
            freeze.assert_called_once()
            inventory.assert_called_once_with(reference())
            current, selected = execute.call_args.args
            self.assertEqual(current.python, Path("/transport/bin/python"))
            self.assertEqual(selected["python"], "/old/bin/python")
            directory = next(root.glob("confirm-*"))
            self.assertTrue((directory / "SUMMARY.json").exists())
            self.assertTrue((directory / "ENVIRONMENT.json").exists())

    @mock.patch.object(
        driver.transport,
        "environment_inventory",
        side_effect=RuntimeError("dependency drift"),
    )
    @mock.patch.object(
        driver.transport, "load_reference", side_effect=lambda path: reference()
    )
    @mock.patch.object(driver.study, "freeze")
    @mock.patch.object(driver.os, "geteuid", return_value=0)
    def test_dependency_failure_is_preserved_before_any_collection(
        self, uid, freeze, load_reference, inventory
    ) -> None:
        with tempfile.TemporaryDirectory() as folder:
            with mock.patch.object(sys, "argv", ["confirm", "--store", folder]):
                with self.assertRaisesRegex(RuntimeError, "dependency drift"):
                    driver.main()
            freeze.assert_not_called()
            directory = next(Path(folder).glob("confirm-*"))
            failure = json.loads((directory / "FAILED.json").read_text())
            self.assertEqual(failure["message"], "dependency drift")


if __name__ == "__main__":
    unittest.main()
