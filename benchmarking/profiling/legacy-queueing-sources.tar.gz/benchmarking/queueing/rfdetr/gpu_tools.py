"""Read-only profiler preflight and low-frequency GPU telemetry.

This module never changes clocks, power limits, drivers, or profiler packages.
NVML utilization/power readings are rolling device-wide measurements, not
per-request GPU timings or SM occupancy. Use a CUDA timeline for those questions.
"""

from collections.abc import Iterator
from contextlib import contextmanager
import csv
import io
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
from typing import Any

_QUERY_TIMEOUT = 5
_GPU_FIELDS = (
    "index,uuid,name,memory.total,memory.used,utilization.gpu,temperature.gpu,"
    "power.draw,clocks.current.sm"
)
_PROCESS_FIELDS = "gpu_uuid,pid,process_name,used_gpu_memory"
_UNAVAILABLE_VALUES = {"N/A", "[N/A]", "Not Supported", "[Not Supported]"}
_VERSION_PATTERNS = {
    "perf": r"\bperf version\s+(\d[^\s]*)",
    "nsys": r"\bNsight Systems(?:\s+version)?\s+(\d[^\s]*)",
    "ncu": r"\bVersion\s+(\d[^\s]*)",
    "nvidia-smi": r"\bNVIDIA-SMI version\s*:\s*(\d[^\s]*)",
}
_NSYS_REPAIR = (
    "On this Fedora 44 host, the RPM database records Nsight Systems 2026.1.3 "
    "but its /opt/nvidia payload was missing. An administrator can preview "
    "`dnf --assumeno --repo=cuda-fedora44-x86_64 reinstall "
    "nsight-systems-2026.1.3-2026.1.3.425_261338342291v0-0.x86_64`, then "
    "repair only that package after reviewing the transaction. Do not update "
    "the driver/toolkit for this study. This collector never runs dnf."
)


def _tool(name: str, fallbacks: tuple[str, ...]) -> dict[str, Any]:
    found = shutil.which(name)
    paths = list(dict.fromkeys(([found] if found else []) + list(fallbacks)))
    attempts: list[dict[str, Any]] = []
    for path in paths:
        attempt: dict[str, Any] = {"path": path}
        try:
            result = subprocess.run(
                [path, "--version"], capture_output=True, text=True, timeout=10
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            attempt["error"] = str(error)
        else:
            attempt.update(
                returncode=result.returncode,
                stdout=result.stdout.strip()[:4000],
                stderr=result.stderr.strip()[:4000],
            )
            version = re.search(
                _VERSION_PATTERNS[name],
                result.stdout + "\n" + result.stderr,
                re.IGNORECASE,
            )
            # CUDA installs launcher stubs even when the actual profiler payload
            # is missing. Existence/which(), or a version embedded in an error,
            # does not establish that the profiler is usable.
            if result.returncode == 0 and version:
                if name != "ncu" or "Nsight Compute" in result.stdout + result.stderr:
                    attempts.append(attempt)
                    return {
                        "available": True,
                        "path": path,
                        "version": version.group(1),
                        "attempts": attempts,
                    }
        attempts.append(attempt)
    return {
        "available": False,
        "path": paths[0] if paths else None,
        "version": None,
        "attempts": attempts,
    }


def capabilities() -> dict[str, Any]:
    """Probe actual tool behavior without collecting or changing system state."""
    result: dict[str, Any] = {
        "monotonic_ns": time.monotonic_ns(),
        "perf": _tool("perf", ("/usr/bin/perf",)),
        # The repaired standalone CLI lives here on the profiling host; a
        # different root PATH must not select the old broken toolkit launcher.
        "nsys": _tool(
            "nsys", ("/usr/local/sbin/nsys", "/usr/local/cuda-13.3/bin/nsys")
        ),
        "ncu": _tool("ncu", ("/usr/local/cuda-13.3/bin/ncu",)),
        "nvidia_smi": _tool("nvidia-smi", ("/usr/bin/nvidia-smi",)),
        # No capture command is emitted until the real installed CLI's help has
        # been checked. In particular, a broken launcher cannot verify options.
        "nsight_capture_options_verified": False,
    }
    result["cuda_timeline_available"] = result["nsys"]["available"]
    result["nsight_repair_recommendation"] = (
        None if result["nsys"]["available"] else _NSYS_REPAIR
    )
    return result


def _query(argument: str) -> str:
    executable = shutil.which("nvidia-smi") or "/usr/bin/nvidia-smi"
    try:
        result = subprocess.run(
            [executable, argument, "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=_QUERY_TIMEOUT,
        )
    except (OSError, subprocess.TimeoutExpired) as error:
        raise RuntimeError(
            "Cannot read NVIDIA telemetry. Run the collector on the GPU host "
            "outside a device-restricted sandbox and verify nvidia-smi works: "
            f"{error}"
        ) from error
    if result.returncode:
        detail = (result.stderr.strip() or result.stdout.strip())[:2000]
        raise RuntimeError(
            f"nvidia-smi failed for {argument}: {detail}. Verify GPU/driver access "
            "and supported query fields; no driver settings were changed."
        )
    return result.stdout


def _rows(output: str, width: int, kind: str) -> list[list[str]]:
    try:
        rows = list(csv.reader(io.StringIO(output), skipinitialspace=True, strict=True))
    except csv.Error as error:
        raise RuntimeError(f"Malformed nvidia-smi {kind} CSV: {error}") from error
    result: list[list[str]] = []
    for row in rows:
        if not row or not any(value.strip() for value in row):
            continue
        if len(row) != width:
            raise RuntimeError(
                f"Unexpected nvidia-smi {kind} CSV: expected {width} columns, "
                f"received {len(row)}. "
                "Check supported query fields and driver output."
            )
        result.append([value.strip() for value in row])
    return result


def _number(value: str, field: str) -> float | None:
    if value in _UNAVAILABLE_VALUES:
        return None
    try:
        result = float(value)
    except ValueError as error:
        raise RuntimeError(
            f"Invalid nvidia-smi {field} value {value!r}; "
            "check query support/permissions"
        ) from error
    if not math.isfinite(result):
        raise RuntimeError(f"Non-finite nvidia-smi {field} value {value!r}")
    return result


def _identifier(value: str, field: str) -> int:
    try:
        return int(value)
    except ValueError as error:
        raise RuntimeError(
            f"Invalid nvidia-smi {field} identifier {value!r}"
        ) from error


def gpu_snapshot() -> dict[str, Any]:
    """Read GPU statistics and all compute clients; the caller identifies its PIDs."""
    stamp = time.monotonic_ns()
    gpu_rows = _rows(_query(f"--query-gpu={_GPU_FIELDS}"), 9, "GPU")
    if not gpu_rows:
        raise RuntimeError("nvidia-smi returned no GPUs; verify GPU/driver access")
    process_rows = _rows(
        _query(f"--query-compute-apps={_PROCESS_FIELDS}"), 4, "process"
    )
    gpus: list[dict[str, Any]] = []
    numeric_fields = (
        "memory_total_mib",
        "memory_used_mib",
        "utilization_gpu_percent",
        "temperature_gpu_c",
        "power_draw_w",
        "sm_clock_mhz",
    )
    for row in gpu_rows:
        record: dict[str, Any] = {
            "index": _identifier(row[0], "GPU index"),
            "uuid": row[1],
            "name": row[2],
        }
        record.update(
            (name, _number(value, name)) for name, value in zip(numeric_fields, row[3:])
        )
        gpus.append(record)
    processes = [
        {
            "gpu_uuid": row[0],
            "pid": _identifier(row[1], "PID"),
            "process_name": row[2],
            "used_gpu_memory_mib": _number(row[3], "process memory"),
        }
        for row in process_rows
    ]
    return {
        "monotonic_ns": stamp,
        "collection_duration_ns": time.monotonic_ns() - stamp,
        "gpus": gpus,
        "compute_processes": processes,
    }


@contextmanager
def sampling(directory: Path, interval: float = 0.5) -> Iterator[Path]:
    """Buffer telemetry until exit; stop only this context's sampler thread.

    The half-second default limits nvidia-smi process overhead. Each sample also
    records collection duration, so it is not confused with a zero-cost monitor.
    """
    if not math.isfinite(interval) or interval <= 0:
        raise ValueError("GPU sampling interval must be finite and greater than zero")
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "gpu-telemetry.jsonl"
    with path.open("x") as destination:
        # Fail before the workload starts if the GPU/driver is inaccessible.
        records = [gpu_snapshot()]
        errors: list[str] = []
        stop = threading.Event()

        def collect() -> None:
            # Wait after each read: slow commands never overlap or create a
            # catch-up storm. Consumers use actual monotonic timestamps.
            while not stop.wait(interval):
                try:
                    records.append(gpu_snapshot())
                except Exception as error:
                    errors.append(str(error))
                    records.append(
                        {"monotonic_ns": time.monotonic_ns(), "error": str(error)}
                    )
                    return

        thread = threading.Thread(
            target=collect, name="rfdetr-gpu-telemetry", daemon=True
        )
        thread.start()
        try:
            yield path
        finally:
            stop.set()
            # Two read-only nvidia-smi queries, each with a fixed timeout, bound
            # an in-progress sample. No broad kill/pkill touches other clients.
            thread.join(timeout=2 * _QUERY_TIMEOUT + 1)
            if thread.is_alive():
                errors.append("GPU sampler did not stop within its command timeout")
            for record in records:
                destination.write(json.dumps(record, allow_nan=False) + "\n")
        if errors:
            raise RuntimeError(f"GPU telemetry failed; inspect {path}: {errors[0]}")
