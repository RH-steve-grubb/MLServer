"""Profile the selected CUDA Graph/blocking engine and confirm serial serving.

Selection comes from completed engine trials, not a fresh throughput ranking.
Capture brackets diagnose the winner; they are not new C16 baseline comparisons.
"""

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

import gpu_baseline as baseline
import gpu_engine_compare as engine
import gpu_transport_compare as transport

study = baseline.study
DEFAULT_REFERENCE = Path(
    "/home/codex/mlserver-durable-store/rfdetr-gpu-engine-serving-20261026/"
    "engine-20261026T211545669721Z-393417/SUMMARY.json"
)
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-winner-profile-20261026"
SELECTED = {
    "protocol": "grpc",
    "adapter": "compact",
    "transport": "zmq",
    "workers": 2,
    "threads": 2,
    "concurrency": 16,
    "engine": "cuda-graph-blocking",
    "metadata_only": False,
}


def production(manifest: dict[str, str]) -> dict[str, str]:
    return {
        name: value
        for name, value in manifest.items()
        if name.startswith(("mlserver/", "runtimes/onnx/mlserver_onnx/"))
    }


def load_reference(path: Path) -> dict[str, Any]:
    summary = json.loads(path.read_text())
    configurations = {
        "run": {**SELECTED, "engine": "run"},
        "cuda-graph-blocking": SELECTED,
    }
    records = {}
    for name, configuration in configurations.items():
        if summary["configurations"].get(name) != configuration:
            raise RuntimeError(
                "Reference does not contain the fixed no-metadata winner"
            )
        trials = [
            r
            for r in summary["repeats"]
            if r["block"] == "increments" and r["variant"] == name
        ]
        if len(trials) != 3 or {r["round"] for r in trials} != {0, 1, 2}:
            raise RuntimeError(
                "Reference requires three complete baseline/winner trials"
            )
        for trial in trials:
            if trial["requested_clients"] != 2:
                raise RuntimeError("Reference trial client topology mismatch")
            engine.check({"results": [trial["result"]]}, configuration, 2)
        records[name] = [r["summary"] for r in trials]
    source_manifest = Path(summary["source_snapshot"]).parent / "source-hashes.json"
    hashes = production(json.loads(source_manifest.read_text()))
    if len(hashes) != 102:
        raise RuntimeError("Reference production source manifest is incomplete")
    return {
        "source_summary": str(path),
        "prior_reference": summary["reference"],
        "production_hashes": hashes,
        "verified_repeat_summaries": records,
    }


def execute(plan: baseline.Plan, reference: dict) -> dict[str, Any]:
    repeats = []
    variants = (
        ("run", {**SELECTED, "engine": "run", "concurrency": 1}),
        ("cuda-graph-blocking", {**SELECTED, "concurrency": 1}),
    )
    for repeat in range(plan.args.repeats):
        ordered = variants if repeat % 2 == 0 else tuple(reversed(variants))
        for name, configuration in ordered:
            summary, path = plan.run(
                f"serial-r{repeat}-{name}",
                [
                    "--phase",
                    "smoke",
                    *engine.options(configuration, 2, plan.args.repeat_seconds),
                ],
            )
            (row,) = engine.check(summary, configuration, 2)
            repeats.append(
                {
                    "round": repeat,
                    "variant": name,
                    "requested_clients": 2,
                    "active_clients": 1,
                    "summary": str(path),
                    "result": row,
                }
            )
            study.publish(plan.directory / "REPEATS.json", repeats)
    captures = {}
    for name in ("cpu", "gil", "stages", "cuda"):
        command = (
            ["--phase", "profile", "--capture", name]
            if name in ("cpu", "gil")
            else ["--phase", name]
        )
        summary, path = plan.run(
            name, [*command, *engine.options(SELECTED, 2, plan.args.seconds)]
        )
        engine.check(summary, SELECTED, 2, command[1])
        captures[name] = str(path)
        study.publish(plan.directory / "CAPTURES.json", captures)
    return {
        "purpose": "Selected no-metadata engine profiling and matched C1 confirmation",
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "reference": reference,
        "selected_configuration": SELECTED,
        "serial_repeats": repeats,
        "captures": captures,
        "interpretation": (
            "CUDA Graph/blocking without metadata-only was selected for lower CPU "
            "at overlapping graph throughput, not by selecting the highest RPS. "
            "No fresh stock/representation or C16 baseline comparison is performed. "
            "Use the verified preceding engine repeats for that comparison. "
            "Serial trials compare run with the winner at W2/T2/C1, requested "
            "two clients and one active client. All capture brackets use the winner "
            "at W2/T2/C16/two clients; their throughput is diagnostic."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=DEFAULT_REFERENCE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float, default=15)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    if (
        os.geteuid() != 0
        or args.repeats < 1
        or any(
            not math.isfinite(s) or s <= 0 for s in (args.seconds, args.repeat_seconds)
        )
    ):
        parser.error("Run as root with positive repeats and finite positive durations")
    args.without_cuda, args.concurrency = False, 16
    args.reference, args.bundle, args.store = (
        p.resolve() for p in (args.reference, args.bundle, args.store)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"profile-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"Winner profile output: {directory}", flush=True)
    try:
        reference = load_reference(args.reference)
        study.publish(directory / "REFERENCE.json", reference)
        prior = reference["prior_reference"]
        study.publish(
            directory / "ENVIRONMENT.json", transport.environment_inventory(prior)
        )
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if (
            manifest["onnx"]["sha256"] != prior["model_sha256"]
            or study.digest(args.bundle / "model/model.onnx") != prior["model_sha256"]
        ):
            raise RuntimeError(
                "Winner profile model differs from the verified reference"
            )
        tools = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", tools)
        if not tools["perf"]["available"] or not tools["nsys"]["available"]:
            raise RuntimeError("Working perf and Nsight Systems are required")
        study.freeze(directory)
        frozen = production(json.loads((directory / "source-hashes.json").read_text()))
        if frozen != reference["production_hashes"]:
            raise RuntimeError(
                "Production source differs from the verified engine study"
            )
        result = execute(plan, reference)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
