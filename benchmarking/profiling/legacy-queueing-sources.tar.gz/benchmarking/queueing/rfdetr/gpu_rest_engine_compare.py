"""Compare the fixed compact REST path with and without CUDA Graph/blocking.

Screening uses short unprofiled trials. Formal root execution repeats both
engines at C1/C16, checks client headroom and captures each engine separately.
"""

import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import sys
from typing import Any

import gpu_baseline as baseline
import gpu_inject_compare as injection

engine = injection.engine
transport = injection.transport
study = injection.study
DEFAULT_STORE = study.DEFAULT_STORE.parent / "rfdetr-gpu-rest-engine-20261026"
FIXED = {
    **injection.FIXED,
    "protocol": "rest",
    "workers": 8,
    "engine": "run",
}


def execute(plan: baseline.Plan, reference: dict) -> dict[str, Any]:
    prior = reference["prior_reference"]
    if prior.get("fixed", {}).get("rest") != {"workers": 8, "threads": 2}:
        raise RuntimeError("Reference REST selection must be eight workers/two threads")
    variants = (
        ("run", FIXED),
        ("cuda-graph-blocking", {**FIXED, "engine": "cuda-graph-blocking"}),
    )
    repeats = []
    concurrencies = (16,) if plan.args.screen else (1, 16)
    for repeat in range(plan.args.repeats):
        ordered = variants if repeat % 2 == 0 else tuple(reversed(variants))
        blocks = concurrencies if repeat % 2 == 0 else tuple(reversed(concurrencies))
        for concurrency in blocks:
            for label, selected in ordered:
                configuration = {**selected, "concurrency": concurrency}
                rows, path = injection.run(
                    plan,
                    f"r{repeat}-c{concurrency}-{label}",
                    configuration,
                    [
                        "--phase",
                        "smoke",
                        *engine.options(configuration, 2, plan.args.repeat_seconds),
                    ],
                )
                repeats.append(
                    {
                        "round": repeat,
                        "variant": label,
                        "concurrency": concurrency,
                        "requested_clients": 2,
                        "active_clients": min(2, concurrency),
                        "summary": str(path),
                        "result": rows[0],
                    }
                )
                study.publish(plan.directory / "REPEATS.json", repeats)
    controls: dict[str, dict] = {}
    captures: dict[str, dict] = {}
    if not plan.args.screen:
        for label, configuration in variants:
            rows, path = injection.run(
                plan,
                f"clients4-{label}",
                configuration,
                [
                    "--phase",
                    "smoke",
                    *engine.options(configuration, 4, plan.args.repeat_seconds),
                ],
            )
            controls[label] = {
                "requested_clients": 4,
                "active_clients": 4,
                "summary": str(path),
                "result": rows[0],
            }
            study.publish(plan.directory / "CLIENT_CONTROLS.json", controls)
        for label, configuration in variants:
            captures[label] = {"configuration": configuration, "passes": {}}
            for name in ("cpu", "gil", "stages", "cuda"):
                command = (
                    ["--phase", "profile", "--capture", name]
                    if name in ("cpu", "gil")
                    else ["--phase", name]
                )
                _, path = injection.run(
                    plan,
                    f"{label}-{name}",
                    configuration,
                    [*command, *engine.options(configuration, 2, plan.args.seconds)],
                )
                captures[label]["passes"][name] = str(path)
                study.publish(plan.directory / "CAPTURES.json", captures)
    return {
        "purpose": "Fixed compact REST run versus CUDA Graph/blocking",
        "python": str(plan.python),
        "source_snapshot": str(plan.directory / "source"),
        "reference": reference,
        "configurations": dict(variants),
        "screening_only": plan.args.screen,
        "resource_budget_verified": not plan.args.screen,
        "resource_scope": (
            "Screening only; nonroot execution has no verified cgroup budget; "
            "no formal capacity claim"
            if plan.args.screen
            else "Root-enforced common server/client CPU and memory budget"
        ),
        "expected_child_calls": (
            2 * plan.args.repeats if plan.args.screen else 4 * plan.args.repeats + 10
        ),
        "expected_server_cases": (
            2 * plan.args.repeats if plan.args.screen else 4 * plan.args.repeats + 26
        ),
        "repeats": repeats,
        "client_controls": controls,
        "captures": captures,
        "interpretation": (
            "This study tests REST, not gRPC. Only the inference engine changes "
            "from ordinary run to CUDA Graph with blocking synchronization. "
            "Both retain compact worker JSON/NumPy, ZeroMQ, FP32/B1, eight "
            "workers/two threads, metadata-only and buffer injection disabled. "
            "C1 has one active client; C16 has two, or four in controls. "
            "Compare unprofiled repeats at the same concurrency/client topology. "
            "Bracketed CPU/GIL/stage/CUDA captures diagnose costs; their "
            "throughput is not final speedup evidence."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--screen", action="store_true")
    parser.add_argument("--reference", type=Path, default=injection.DEFAULT_REFERENCE)
    parser.add_argument("--bundle", type=Path, default=study.DEFAULT_BUNDLE)
    parser.add_argument("--store", type=Path, default=DEFAULT_STORE)
    parser.add_argument("--seconds", type=float, default=10)
    parser.add_argument("--repeat-seconds", type=float)
    parser.add_argument("--repeats", type=int)
    parser.add_argument("--user", default="codex")
    args = parser.parse_args()
    args.repeats = (
        args.repeats if args.repeats is not None else (4 if args.screen else 3)
    )
    args.repeat_seconds = (
        args.repeat_seconds
        if args.repeat_seconds is not None
        else (5 if args.screen else 20)
    )
    if (
        not args.screen
        and os.geteuid() != 0
        or args.repeats < 1
        or any(
            not math.isfinite(value) or value <= 0
            for value in (args.seconds, args.repeat_seconds)
        )
    ):
        parser.error(
            "Formal mode requires root; use positive repeats and finite "
            "positive durations"
        )
    args.without_cuda, args.concurrency = False, 16
    args.reference, args.bundle, args.store = (
        path.resolve() for path in (args.reference, args.bundle, args.store)
    )
    os.umask(0o022)
    args.store.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = args.store / f"rest-engine-{stamp}-{os.getpid()}"
    directory.mkdir(mode=0o755)
    plan = baseline.Plan(args, directory, Path(sys.executable))
    plan.record()
    print(f"REST engine comparison output: {directory}", flush=True)
    try:
        reference = injection.load_reference(args.reference)
        study.publish(directory / "REFERENCE.json", reference)
        if Path(reference["python"]).resolve() != Path(sys.executable).resolve():
            raise RuntimeError("Use the exact verified winner Python environment")
        prior = reference["prior_reference"]
        study.publish(
            directory / "ENVIRONMENT.json", transport.environment_inventory(prior)
        )
        manifest = json.loads((args.bundle / "manifest.json").read_text())
        if (
            manifest["onnx"]["sha256"] != prior["model_sha256"]
            or study.digest(args.bundle / "model/model.onnx") != prior["model_sha256"]
        ):
            raise RuntimeError("REST comparison model differs from reference")
        tools = study.gpu_tools.capabilities()
        study.publish(directory / "CAPABILITIES.json", tools)
        if not args.screen and (
            not tools["perf"]["available"] or not tools["nsys"]["available"]
        ):
            raise RuntimeError("Formal mode requires working perf and Nsight Systems")
        study.freeze(directory)
        hashes = injection.winner.production(
            json.loads((directory / "source-hashes.json").read_text())
        )
        if hashes != reference["production_hashes"]:
            raise RuntimeError("Production source differs from the verified winner")
        study.publish(
            directory / "SOURCE.json",
            {
                "source_snapshot": str(directory / "source"),
                "production_file_count": len(hashes),
                "reference_production_matched": True,
            },
        )
        study.publish(
            directory / "SCOPE.json",
            {
                "screening_only": args.screen,
                "resource_budget_verified": not args.screen,
                "profiles_per_engine": (
                    [] if args.screen else ["cpu", "gil", "stages", "cuda"]
                ),
            },
        )
        result = execute(plan, reference)
        study.publish(directory / "SUMMARY.json", result)
        print(f"Complete: {directory / 'SUMMARY.json'}", flush=True)
    except BaseException as error:
        study.publish(
            directory / "FAILED.json",
            {"type": type(error).__name__, "message": str(error)},
        )
        raise


if __name__ == "__main__":
    main()
