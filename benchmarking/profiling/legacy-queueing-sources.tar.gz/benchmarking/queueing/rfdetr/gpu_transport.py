"""Select the existing pickle/ZeroMQ IPC diagnostic for the GPU study.

Install before representation adapters and gpu_stages. The helper replaces
inference transport only; model control messages retain their stock queues.
"""

import atexit
import json
from multiprocessing.util import Finalize
import os
from pathlib import Path
import sys
from typing import Any

_INSTALLED = False
_FINALIZER: Any = None
_SETTINGS = {
    "MLSERVER_QUEUE_CODEC": "pickle",
    "MLSERVER_QUEUE_TENSORS": "list",
}
_COUNTERS = {
    "sent",
    "received",
    "sent_bytes",
    "received_bytes",
    "encode_ns",
    "decode_ns",
}
_SCOPE = "Full process lifetime including warmup/pilot; not steady-state timing"


def _publish(path: Path, value: dict) -> None:
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def _flush() -> Path | None:
    location = os.environ.get("MLSERVER_GPU_RECEIPTS")
    if not _INSTALLED or not location:
        return None
    helper = sys.modules["zmq_transport"]
    pid = os.getpid()
    path = Path(location) / f"transport-{pid}.json"
    _publish(
        path,
        {
            "format_version": 1,
            "pid": pid,
            "transport": "zmq",
            "pyzmq_version": helper.zmq.pyzmq_version(),
            "libzmq_version": helper.zmq.zmq_version(),
            "scope": _SCOPE,
            "counts": dict(helper.COUNTS),
        },
    )
    return path


def _safe_flush() -> None:
    try:
        _flush()
    except Exception as exc:
        # Exit-time diagnostics must not mask inference/shutdown errors.
        # collect() rejects missing or incomplete process receipts afterwards.
        try:
            print(f"GPU transport receipt flush failed: {exc}", file=sys.stderr)
        except Exception:
            pass


def installed() -> bool:
    """Report successful process-local installation, not an environment request."""
    return _INSTALLED


def _directory() -> None:
    location = os.environ.get("MLSERVER_QUEUE_ZMQ_DIR")
    if not location:
        raise ValueError("ZeroMQ requires MLSERVER_QUEUE_ZMQ_DIR")
    directory = Path(location)
    if not directory.is_absolute() or not directory.is_dir():
        raise ValueError("ZeroMQ IPC directory must already exist and be absolute")
    # Match zmq_transport.endpoint() without creating a socket or choosing IDs.
    if len(os.fsencode(directory / "q-000000000000.sock")) > 100:
        raise ValueError("ZeroMQ IPC pathname exceeds the diagnostic's safe limit")


def _check_order() -> None:
    for name in ("gpu_worker_json", "gpu_stages"):
        if getattr(sys.modules.get(name), "_INSTALLED", False):
            raise RuntimeError(f"Install GPU transport before {name}")
    buffers = sys.modules.get("gpu_buffers")
    converter = getattr(buffers, "ModelInferRequestConverter", None)
    if getattr(getattr(converter, "to_types", None), "_gpu_buffers", False):
        raise RuntimeError("Install GPU transport before gpu_buffers")


def install() -> bool:
    """Install ZeroMQ once when explicitly selected; Queue needs no adapter."""
    global _INSTALLED, _FINALIZER
    transport = os.environ.get("MLSERVER_GPU_TRANSPORT", "queue")
    if transport not in ("queue", "zmq"):
        raise ValueError(f"Unknown GPU transport: {transport}")
    settings = {**_SETTINGS, "MLSERVER_QUEUE_TRANSPORT": transport}
    for key, expected in settings.items():
        if os.environ.get(key, expected) != expected:
            raise ValueError(f"GPU transport requires {key}={expected}")
    if transport == "queue":
        if _INSTALLED:
            raise RuntimeError("An installed ZeroMQ transport cannot switch to Queue")
        return False
    _directory()
    if _INSTALLED:
        return True
    _check_order()
    queueing = str(Path(__file__).resolve().parent.parent)
    if queueing not in sys.path:
        sys.path.insert(0, queueing)
    import zmq_transport

    os.environ.update(settings)
    zmq_transport.install()
    _INSTALLED = True
    atexit.register(_safe_flush)
    # multiprocessing workers do not reliably run ordinary atexit callbacks.
    _FINALIZER = Finalize(None, _safe_flush, exitpriority=10)
    return True


def _read(path: Path, pid: int) -> dict:
    receipt = json.loads(path.read_text())
    if (
        receipt.get("format_version") != 1
        or receipt.get("pid") != pid
        or receipt.get("transport") != "zmq"
        or receipt.get("scope") != _SCOPE
        or not isinstance(receipt.get("pyzmq_version"), str)
        or not receipt["pyzmq_version"]
        or not isinstance(receipt.get("libzmq_version"), str)
        or not receipt["libzmq_version"]
    ):
        raise RuntimeError(f"Invalid ZeroMQ transport receipt identity: {path}")
    counts = receipt.get("counts", {})
    if (
        not isinstance(counts, dict)
        or set(counts) != _COUNTERS
        or any(type(value) is not int or value < 0 for value in counts.values())
    ):
        raise RuntimeError(f"Invalid ZeroMQ transport counters: {path}")
    return receipt


def collect(case: Path, server: dict) -> dict:
    """Validate completed-process IPC traffic, including warmup/pilot traffic."""
    frontend = server["frontend"]["pid"]
    workers = {worker["pid"] for worker in server["workers"]}
    expected = {frontend, *workers}
    paths = {case / "receipts" / f"transport-{pid}.json" for pid in expected}
    if set((case / "receipts").glob("transport-*")) != paths:
        raise RuntimeError("ZeroMQ transport files do not match frontend/worker PIDs")
    receipts = {
        pid: _read(case / "receipts" / f"transport-{pid}.json", pid) for pid in expected
    }
    front = receipts[frontend]["counts"]
    worker_counts = [receipts[pid]["counts"] for pid in workers]
    if not worker_counts or any(
        counts["received"] <= 0 or counts["received"] != counts["sent"]
        for counts in worker_counts
    ):
        raise RuntimeError("ZeroMQ worker requests did not all receive replies")
    if not (front["sent"] == front["received"] > 0):
        raise RuntimeError("ZeroMQ frontend requests did not all receive replies")
    if front["sent_bytes"] <= 0 or front["received_bytes"] <= 0:
        raise RuntimeError("ZeroMQ transport did not account for payload bytes")
    for outgoing, incoming in (
        ("sent", "received"),
        ("received", "sent"),
        ("sent_bytes", "received_bytes"),
        ("received_bytes", "sent_bytes"),
    ):
        if front[outgoing] != sum(counts[incoming] for counts in worker_counts):
            raise RuntimeError(
                f"ZeroMQ transport counter conservation failed: {outgoing}"
            )
    summary = {
        "valid": True,
        "transport": "zmq",
        "scope": _SCOPE,
        "requests": front["sent"],
        "request_bytes": front["sent_bytes"],
        "response_bytes": front["received_bytes"],
        "processes": {str(pid): receipt for pid, receipt in receipts.items()},
    }
    _publish(case / "transport-summary.json", summary)
    return summary
