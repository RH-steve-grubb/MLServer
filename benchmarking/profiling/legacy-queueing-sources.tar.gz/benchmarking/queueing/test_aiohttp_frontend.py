"""Compare thin aiohttp and raw FastAPI routes before measuring capacity."""

import json
import os
from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
from httpx import AsyncClient

from mlserver.handlers import DataPlane
from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.model import ParallelModel
from mlserver.rest import RESTServer
from mlserver.settings import Settings

from . import raw_worker, test_raw_worker
from .aiohttp_frontend import AiohttpFrontend

worker = test_raw_worker.worker


@pytest.fixture
def frontends(worker: Any, monkeypatch: Any) -> tuple[Any, AiohttpFrontend]:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "full")

    async def dispatch(request: ModelRequestMessage) -> ModelResponseMessage:
        response = await raw_worker.process_request(worker, request)
        if response.exception:
            raise response.exception
        assert isinstance(response.return_value, raw_worker.RawReply)
        response.return_value.worker_pid = os.getpid() + 10000
        return response

    async def get_model(name: str, version: str | None = None) -> Any:
        selected = await worker._model_registry.get_model(name, version)
        proxy = Mock(spec=ParallelModel)
        proxy.name, proxy.version, proxy.ready = (
            selected.name,
            selected.version,
            selected.ready,
        )
        proxy._dispatcher = SimpleNamespace(dispatch_request=dispatch)
        return proxy

    registry: Any = SimpleNamespace(get_model=get_model)
    plane = Mock(spec=DataPlane)
    plane.ready, plane.live = AsyncMock(return_value=True), AsyncMock(return_value=True)
    settings = Settings(gzip_enabled=False, metrics_endpoint=None)
    server = RESTServer(settings, plane, Mock())
    raw_worker.install_routes(server, registry)
    frontend = AiohttpFrontend(settings, registry, plane)
    return server._app, frontend


@pytest.mark.parametrize("encoded", [test_raw_worker.body(), b"{", b"{}", b"", b"[]"])
@pytest.mark.parametrize("versioned", [False, True])
async def test_body_status_and_headers_match_fastapi(
    encoded: bytes, versioned: bool, frontends: Any, monkeypatch: Any
) -> None:
    app, frontend = frontends
    parser = AsyncMock(side_effect=AssertionError("frontend must not parse JSON"))
    monkeypatch.setattr(web.Request, "json", parser)
    path = "/v2/models/sum-model"
    if versioned:
        path += "/versions/v1"
    path += "/infer"
    headers = {"content-type": "application/json", "X-Test": "retained"}
    async with AsyncClient(app=app, base_url="http://test") as client:
        expected = await client.post(path, content=encoded, headers=headers)
    async with TestClient(TestServer(frontend.app)) as client:
        response = await client.post(path, data=encoded, headers=headers)
        assert response.status == expected.status_code
        assert await response.json() == expected.json()
        assert response.headers["content-type"].startswith("application/json")
        if response.status == 200:
            assert response.headers["x-test"] == expected.headers["x-test"]
            assert response.headers["ce-requestid"] == "client-id"
    parser.assert_not_awaited()


@pytest.mark.parametrize(
    "path",
    [
        "/v2/models/other-model/infer",
        "/v2/models/absent/infer",
        "/v2/models/sum-model/versions/absent/infer",
    ],
)
async def test_model_selection_and_errors_match_fastapi(
    path: str, frontends: Any
) -> None:
    app, frontend = frontends
    async with AsyncClient(app=app, base_url="http://test") as client:
        expected = await client.post(path, content=test_raw_worker.body())
    async with TestClient(TestServer(frontend.app)) as client:
        response = await client.post(path, data=test_raw_worker.body())
        assert response.status == expected.status_code
        assert await response.json() == expected.json()


async def test_large_body_is_not_rejected_by_aiohttp_default_cap(
    frontends: Any,
) -> None:
    app, frontend = frontends
    payload = json.loads(test_raw_worker.body())
    payload["inputs"][0].update(shape=[1, 100000], data=[0.123456789] * 100000)
    encoded = json.dumps(payload).encode()
    assert len(encoded) > 1024**2
    path = "/v2/models/sum-model/infer"
    async with AsyncClient(app=app, base_url="http://test") as client:
        expected = await client.post(path, content=encoded)
    async with TestClient(TestServer(frontend.app)) as client:
        response = await client.post(path, data=encoded)
        assert response.status == expected.status_code == 200
        assert await response.json() == expected.json()


async def test_not_ready_model_matches_fastapi(frontends: Any, worker: Any) -> None:
    app, frontend = frontends
    model = await worker._model_registry.get_model("sum-model")
    model.ready = False
    path = "/v2/models/sum-model/infer"
    async with AsyncClient(app=app, base_url="http://test") as client:
        expected = await client.post(path, content=test_raw_worker.body())
    async with TestClient(TestServer(frontend.app)) as client:
        response = await client.post(path, data=test_raw_worker.body())
        assert response.status == expected.status_code == 400
        assert await response.json() == expected.json()


async def test_health_stats_and_stop(frontends: Any) -> None:
    _, frontend = frontends
    stats = AsyncMock(return_value={"cpu_seconds": 1.0})
    frontend.add_stats(stats)
    frontend.add_balance(lambda: {"events": []})
    async with TestClient(TestServer(frontend.app)) as client:
        assert (await client.get("/v2/health/ready")).status == 200
        frontend.data_plane.ready.return_value = False
        assert (await client.get("/v2/health/ready")).status == 503
        assert (await client.get("/v2/health/live")).status == 200
        await client.post("/v2/models/sum-model/infer", data=test_raw_worker.body())
        response = await client.get("/queue-probe/stats")
        assert await response.json() == {
            "cpu_seconds": 1.0,
            "http_aiohttp_replies": 1.0,
        }
        response = await client.get("/queue-probe/balance")
        assert await response.json() == {"events": []}
        response = await client.post("/queue-probe/stop")
        assert await response.json() == {"stopping": True}
        assert frontend.stopped.is_set()
    stats.assert_awaited_once()


async def test_aiohttp_requires_full_worker_json(monkeypatch: Any) -> None:
    monkeypatch.setenv("MLSERVER_QUEUE_JSON", "input")
    with pytest.raises(ValueError, match="full worker JSON"):
        AiohttpFrontend(Settings(), Mock(), Mock())
