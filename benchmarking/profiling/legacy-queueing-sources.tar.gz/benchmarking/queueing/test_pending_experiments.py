"""Reject confounded worker-JSON and fixed-worker-count replica comparisons."""

from typing import Any

import pytest

from .run_pending_experiments import VARIANTS, validate


def document(variant: str) -> dict[str, Any]:
    mode, config, frontends = VARIANTS[variant]
    return {
        "metadata": {"queue_json": mode, "queue_transport": "queue", "probed": False},
        "results": [
            {
                "config": config,
                "frontends": frontends,
                "total_workers": 6,
                "threads": 1,
                "queue_json": mode,
                "queue_transport": "queue",
                "queue_codec": "pickle",
                "queue_tensors": "list",
                "errors": [],
                "total_drained": 10,
                "rps": 100,
                "request_bytes": 200,
                "codec_counts": {},
                "tensor_counts": {},
                "transport_counts": {},
                "raw_counts": (
                    {
                        "raw_requests": 10,
                        "raw_worker_replies": 10,
                        "raw_input_bytes": 2000,
                        "raw_byte_replies": 10 if mode == "full" else 0,
                    }
                    if mode != "frontend"
                    else {}
                ),
            }
        ],
    }


@pytest.mark.parametrize("variant", list(VARIANTS))
async def test_expected_variant(variant: str) -> None:
    validate(document(variant), variant)


@pytest.mark.parametrize(
    "key,value",
    [
        ("errors", ["prediction failed"]),
        ("total_drained", 0),
        ("rps", float("nan")),
        ("config", "replica6-pool1"),
        ("frontends", 6),
        ("total_workers", 12),
        ("threads", 4),
        ("queue_codec", "msgpack"),
        ("queue_transport", "zmq"),
        ("queue_tensors", "numpy"),
        ("queue_json", "input"),
        ("transport_counts", {"transport_sent": 10}),
    ],
)
async def test_rejects_confounded_variant(key: str, value: Any) -> None:
    doc = document("worker-json-1x6")
    doc["results"][0][key] = value
    with pytest.raises(ValueError):
        validate(doc, "worker-json-1x6")


@pytest.mark.parametrize(
    "key", ["raw_requests", "raw_worker_replies", "raw_input_bytes", "raw_byte_replies"]
)
async def test_rejects_unexercised_raw_work(key: str) -> None:
    doc = document("worker-json-1x6")
    doc["results"][0]["raw_counts"][key] -= 1
    with pytest.raises(ValueError, match="validation failed"):
        validate(doc, "worker-json-1x6")


async def test_rejects_raw_adapter_on_stock_control() -> None:
    doc = document("stock-1x6")
    doc["results"][0]["raw_counts"] = {"raw_requests": 10}
    with pytest.raises(ValueError, match="unexpectedly"):
        validate(doc, "stock-1x6")
