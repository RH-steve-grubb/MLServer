"""Unprivileged tests for native-trace interpretation and probe resolution."""

from pathlib import Path
from typing import Any

import pytest

from . import gil_profile


async def test_condition_wait_requires_an_active_gil_acquisition() -> None:
    analysis = gil_profile.TraceAnalysis(gil_profile.Window(0, 1_000_000_000))
    # This could be a queue/other lock wait. It must not become a GIL wait.
    analysis.feed(10, 10, "cond_in")
    analysis.feed(10, 100, "cond_out")
    analysis.feed(10, 200, "take_in")
    analysis.feed(10, 300, "take_out")
    analysis.feed(10, 600, "drop_in")
    row = analysis.finish()
    assert row["acquisition"]["count"] == 1
    assert row["acquisition"]["mean_us"] == 0.1
    assert row["acquisitions_with_condition_wait"] == 0
    assert row["condition_wait_thread_ms"] == 0
    assert row["unmatched_events"] == 0
    assert "approximate_held_percent" not in row


async def test_multiple_condition_waits_count_one_contended_acquisition() -> None:
    analysis = gil_profile.TraceAnalysis(gil_profile.Window(0, 1_000_000_000))
    for stamp, role in [
        (100, "take_in"),
        (200, "cond_in"),
        (500, "cond_out"),
        (600, "cond_in"),
        (1000, "cond_out"),
        (1200, "take_out"),
        (1400, "drop_in"),
    ]:
        analysis.feed(10, stamp, role)
    result = analysis.finish()
    assert result["acquisitions_with_condition_wait"] == 1
    assert result["condition_wait_thread_ms"] == 0.0007
    assert result["acquisition"]["mean_us"] == 1.1


async def test_warmup_is_excluded_and_boundary_intervals_are_clipped() -> None:
    analysis = gil_profile.TraceAnalysis(gil_profile.Window(100, 1000))
    for stamp, role in [
        (0, "take_in"),
        (10, "take_out"),
        (200, "drop_in"),
        (300, "take_in"),
        (400, "cond_in"),
        (1100, "cond_out"),
        (1200, "take_out"),
        (1300, "drop_in"),
    ]:
        analysis.feed(10, stamp, role)
    result = analysis.finish()
    assert result["acquisition"]["count"] == 0
    assert result["condition_wait_thread_ms"] == 0.0006
    assert result["unmatched_events"] == 0


async def test_wait_is_thread_time_not_an_elapsed_time_fraction() -> None:
    analysis = gil_profile.TraceAnalysis(gil_profile.Window(0, 1000))
    for tid in (10, 11):
        analysis.feed(tid, 0, "take_in")
        analysis.feed(tid, 100, "cond_in")
        analysis.feed(tid, 900, "cond_out")
        analysis.feed(tid, 950, "take_out")
        analysis.feed(tid, 1000, "drop_in")
    result = analysis.finish()
    assert result["condition_wait_thread_ms"] == 0.0016
    assert result["acquisitions_with_condition_wait"] == 2


async def test_incomplete_acquisition_is_not_a_completed_slow_call() -> None:
    analysis = gil_profile.TraceAnalysis(gil_profile.Window(0, 1000))
    analysis.feed(10, 100, "take_in")
    analysis.feed(10, 200, "cond_in")
    result = analysis.finish()
    assert result["acquisition"]["count"] == 0
    assert result["condition_wait_thread_ms"] == 0.0008
    assert result["open_acquisitions"] == 1


async def test_missing_and_duplicate_acquisitions_are_flagged() -> None:
    analysis = gil_profile.TraceAnalysis(gil_profile.Window(0, 1000))
    analysis.feed(10, 100, "take_out")
    analysis.feed(10, 200, "take_in")
    analysis.feed(10, 300, "take_in")
    assert analysis.finish()["unmatched_events"] == 2


async def test_perf_parser_handles_names_and_nanoseconds(tmp_path: Path) -> None:
    trace = tmp_path / "events.txt"
    trace.write_text(
        "# perf header\n"
        "  10 12.000000100: mlsgil_x:take_in_0:\n"
        "  10 12.000000200: mlsgil_x:cond_in_1:\n"
        "  10 12.000000900: mlsgil_x:cond_out_1__return:\n"
        "  10 12.000001000: mlsgil_x:take_out_0__return:\n"
        "  10 12.000003000: irrelevant:event:\n"
    )
    events = dict(
        zip(
            [
                "mlsgil_x:take_in_0",
                "mlsgil_x:cond_in_1",
                "mlsgil_x:cond_out_1__return",
                "mlsgil_x:take_out_0__return",
            ],
            ["take_in", "cond_in", "cond_out", "take_out"],
        )
    )
    result = gil_profile.analyze_trace(
        trace, events, gil_profile.Window(12_000_000_000, 13_000_000_000)
    )
    assert result["parsed_events"] == 4
    assert result["acquisition"]["mean_us"] == 0.9
    assert result["condition_wait_thread_ms"] == 0.0007
    assert result["lost_events_reported"] is False
    assert result["valid"] is True


async def test_zero_acquisitions_is_not_reported_as_zero_contention(
    tmp_path: Path,
) -> None:
    trace = tmp_path / "events.txt"
    trace.write_text("unrecognized output\n")
    with pytest.raises(RuntimeError, match="No complete GIL acquisitions"):
        gil_profile.analyze_trace(trace, {}, gil_profile.Window(0, 1000))


async def test_lost_events_are_flagged(tmp_path: Path) -> None:
    trace = tmp_path / "events.txt"
    trace.write_text(
        "LOST 17 events!\n 10 0.000000001: g:in:\n" " 10 0.000000002: g:out:\n"
    )
    result = gil_profile.analyze_trace(
        trace, {"g:in": "take_in", "g:out": "take_out"}, gil_profile.Window(0, 1000)
    )
    assert result["lost_events_reported"] is True
    assert result["valid"] is False
    assert result["condition_wait_thread_ms"] is None


async def test_symbol_discovery_excludes_bolt_fragments(monkeypatch: Any) -> None:
    symbols = (
        "0001 t take_gil.llvm.123\n0002 t take_gil.llvm.123.warm\n"
        "0003 t take_gil.llvm.123.org.0\n0004 t drop_gil.llvm.123\n"
        "0005 t drop_gil.llvm.123.cold\n0006 r __func__.take_gil.llvm.123\n"
    )
    monkeypatch.setattr(gil_profile, "command", lambda args: symbols)
    assert gil_profile.gil_symbols(Path("python")) == {
        "take_gil": "take_gil.llvm.123",
        "drop_gil": "drop_gil.llvm.123",
    }


async def test_probe_definition_aliases_and_return_names(monkeypatch: Any) -> None:
    monkeypatch.setattr(
        gil_profile,
        "gil_symbols",
        lambda path: {"take_gil": "take_gil", "drop_gil": "drop_gil"},
    )
    monkeypatch.setattr(
        gil_profile,
        "symbol_offsets",
        lambda path, function: [0x100, 0x200] if "libc.so" in path.name else [0x300],
    )

    def definitions(args: list[str]) -> str:
        spec = args[-1]
        event, function = spec.split("=", 1)
        prefix = "r" if function.endswith("%return") else "p"
        if prefix == "r":
            event += "__return"
        line = f"{prefix}:{event.replace(':', '/')} /image:0x100\n"
        return line

    monkeypatch.setattr(gil_profile, "command", definitions)
    probes = gil_profile.Probes([Path("python"), Path("libc.so.6")])
    assert len(probes.events) == 6
    assert list(probes.events.values()).count("cond_out") == 2
    assert any(name.endswith("__return") for name in probes.events)
    assert all("=0x" in spec for _, spec in probes.specs)
    assert "drop_in" not in probes.events.values()


async def test_cleanup_deletes_only_owned_registered_probes(
    monkeypatch: Any, tmp_path: Path
) -> None:
    probes = gil_profile.Probes.__new__(gil_profile.Probes)
    probes.group = "mlsgil_owned"
    probes.installed = ["mlsgil_owned:take_in", "mlsgil_owned:take_out"]
    registry = tmp_path / "uprobe_events"
    registry.write_text(
        "p:mlsgil_owned/take_in /image:0x100\n" "p:unrelated/take_out /image:0x200\n"
    )
    original_read = Path.read_text
    monkeypatch.setattr(Path, "is_file", lambda path: True)
    monkeypatch.setattr(Path, "read_text", lambda path: original_read(registry))
    deleted = []

    def delete(args: list[str], **kwargs: Any) -> Any:
        deleted.append(args[-1])
        return gil_profile.subprocess.CompletedProcess(args, 0, "", "")

    monkeypatch.setattr(gil_profile.subprocess, "run", delete)
    probes.close()
    assert deleted == ["mlsgil_owned:take_in"]
    assert probes.installed == []


@pytest.mark.parametrize("start,end", [(0, 0), (10, 0)])
async def test_invalid_measurement_window(start: int, end: int) -> None:
    with pytest.raises(ValueError, match="positive duration"):
        gil_profile.Window(start, end)


async def test_elf_offsets_account_for_bolt_layout(monkeypatch: Any) -> None:
    def output(args: list[str]) -> str:
        if args[0] == "nm":
            return "01874700 t take_gil.llvm.123\n"
        return (
            "Sections:\n"
            "28 .text 00274a1a 01800000 01800000 013a6000 2**21\n"
            " CONTENTS, ALLOC, LOAD, READONLY, CODE\n"
        )

    monkeypatch.setattr(gil_profile, "command", output)
    assert gil_profile.symbol_offsets(Path("python"), "take_gil.llvm.123") == [
        0x141A700
    ]


async def test_libc_versions_are_deduplicated_by_address(monkeypatch: Any) -> None:
    def output(args: list[str]) -> str:
        if args[0] == "nm":
            assert args[1] == "-D"
            return (
                "00000110 T pthread_cond_timedwait@GLIBC_2.2.5\n"
                "00000220 T pthread_cond_timedwait@@GLIBC_2.3.2\n"
                "00000220 T pthread_cond_timedwait@ANOTHER_ALIAS\n"
            )
        return (
            "0 .text 00001000 00000100 00000100 00000080 2**4\n"
            " CONTENTS, ALLOC, LOAD, READONLY, CODE\n"
        )

    monkeypatch.setattr(gil_profile, "command", output)
    assert gil_profile.symbol_offsets(Path("libc.so.6"), "pthread_cond_timedwait") == [
        0x90,
        0x1A0,
    ]


@pytest.mark.parametrize("symbol", ["", "00005000 t take_gil\n"])
async def test_unresolvable_symbol_offset_fails(monkeypatch: Any, symbol: str) -> None:
    monkeypatch.setattr(
        gil_profile,
        "command",
        lambda args: (
            symbol
            if args[0] == "nm"
            else (
                "0 .text 00001000 00000100 00000100 00000080 2**4\n"
                " CONTENTS, ALLOC, LOAD, READONLY, CODE\n"
            )
        ),
    )
    with pytest.raises(RuntimeError, match="Cannot resolve ELF entries"):
        gil_profile.symbol_offsets(Path("python"), "take_gil")


@pytest.mark.parametrize("missing_role", ["cond_in", "cond_out"])
async def test_missing_wait_probe_invalidates_elapsed_wait(
    tmp_path: Path, missing_role: str
) -> None:
    roles = ["take_in", "cond_in", "cond_out", "take_out"]
    trace = tmp_path / "events.txt"
    trace.write_text(
        "".join(
            f" 10 0.00000000{stamp}: g:{role}:\n"
            for stamp, role in enumerate(roles, 1)
            if role != missing_role
        )
    )
    result = gil_profile.analyze_trace(
        trace, {f"g:{role}": role for role in roles}, gil_profile.Window(0, 100)
    )
    assert result["acquisitions_with_condition_wait"] == 1
    assert result["valid"] is False
    assert result["condition_wait_thread_ms"] is None
    with pytest.raises(RuntimeError, match="Invalid GIL trace"):
        gil_profile.require_valid_trace(result)


async def test_attachment_boundary_is_not_a_missing_probe(tmp_path: Path) -> None:
    trace = tmp_path / "events.txt"
    trace.write_text(
        "10 0.000000001: g:take_out:\n"
        "10 0.000000100: g:take_in:\n"
        "10 0.000000200: g:take_out:\n"
    )
    result = gil_profile.analyze_trace(
        trace,
        {"g:take_in": "take_in", "g:take_out": "take_out"},
        gil_profile.Window(50, 1000),
    )
    assert result["valid"] is True
    assert result["acquisition"]["count"] == 1


async def test_missing_wait_return_across_window_end_is_invalid(tmp_path: Path) -> None:
    trace = tmp_path / "events.txt"
    trace.write_text(
        "10 0.000000100: g:take_in:\n"
        "10 0.000000200: g:take_out:\n"
        "10 0.000000300: g:take_in:\n"
        "10 0.000000400: g:cond_in:\n"
        "10 0.000001100: g:take_out:\n"
    )
    roles = ("take_in", "take_out", "cond_in")
    result = gil_profile.analyze_trace(
        trace, {f"g:{role}": role for role in roles}, gil_profile.Window(0, 1000)
    )
    assert result["valid"] is False
    assert result["condition_wait_thread_ms"] is None


async def test_unfinished_call_after_window_does_not_invalidate_it(
    tmp_path: Path,
) -> None:
    trace = tmp_path / "events.txt"
    trace.write_text(
        "10 0.000000100: g:take_in:\n"
        "10 0.000000200: g:take_out:\n"
        "10 0.000001100: g:take_in:\n"
        "10 0.000001200: g:cond_in:\n"
    )
    roles = ("take_in", "take_out", "cond_in")
    result = gil_profile.analyze_trace(
        trace, {f"g:{role}": role for role in roles}, gil_profile.Window(0, 1000)
    )
    assert result["valid"] is True
    assert result["condition_wait_thread_ms"] == 0


async def test_self_test_requires_positive_and_negative_controls() -> None:
    quiet = {"valid": True, "acquisitions_with_condition_wait": 0}
    busy = {
        "valid": True,
        "acquisitions_with_condition_wait": 10,
        "condition_wait_thread_ms": 50.0,
    }
    gil_profile.validate_self_test(quiet, busy)
    with pytest.raises(RuntimeError, match="did not detect paired"):
        gil_profile.validate_self_test(quiet, dict(busy, condition_wait_thread_ms=0))
    with pytest.raises(RuntimeError, match="unexpectedly detected"):
        gil_profile.validate_self_test(
            dict(quiet, acquisitions_with_condition_wait=1), busy
        )


async def test_summary_suppresses_invalid_metrics(tmp_path: Path) -> None:
    row = {
        "batch": 1,
        "concurrency": 2,
        "phase": "gil",
        "rps": 100,
        "timings": {"client_ms": {"mean": 1}},
        "gil": {"valid": False, "invalid_reasons": ["missing wait entry"]},
    }
    gil_profile.write_summary(tmp_path, [row])
    summary = (tmp_path / "SUMMARY.txt").read_text()
    assert "INVALID GIL TRACE: missing wait entry" in summary
    assert "summed condition wait:" not in summary
    assert "Approximate GIL-held" not in summary


async def test_contention_worker_protocol() -> None:
    result = gil_profile.subprocess.run(
        [
            gil_profile.sys.executable,
            str(Path(gil_profile.__file__)),
            "--self-test-worker",
        ],
        input="quiet\ncontended\n\n",
        capture_output=True,
        text=True,
        timeout=15,
    )
    assert result.returncode == 0, result.stderr
    ready, quiet, contended = [
        gil_profile.json.loads(line) for line in result.stdout.splitlines()
    ]
    assert ready == {"ready": True}
    assert quiet["start"] < quiet["end"] < contended["start"] < contended["end"]
    assert quiet["end"] - quiet["start"] >= 800_000_000
    assert contended["end"] - contended["start"] >= 1_800_000_000


@pytest.mark.parametrize(
    "reply,valid",
    [
        ([b"ack\n"], True),
        ([b"ack\n\x00"], True),
        ([b"a", b"ck\n\x00"], True),
        ([b"nack\n"], False),
        ([b"ack\nBAD"], False),
        ([b"ack\n\x00BAD"], False),
    ],
)
async def test_recording_waits_for_perf_enable_ack(
    monkeypatch: Any, tmp_path: Path, reply: list[bytes], valid: bool
) -> None:
    original = gil_profile.subprocess.Popen

    def fake_perf(args: list[str], **kwargs: Any) -> Any:
        assert "--delay=-1" in args
        control, ack = (
            int(fd)
            for fd in args[args.index("--control") + 1].removeprefix("fd:").split(",")
        )
        code = (
            "import os,signal,sys,time; "
            "signal.signal(signal.SIGINT,lambda *args: sys.exit(0)); "
            f"assert os.read({control},64)==b'enable\\n'; "
            "print('enabled',flush=True); "
            + "".join(
                f"os.write({ack},{chunk!r}); time.sleep(0.01); " for chunk in reply
            )
            + "signal.pause()"
        )
        return original([gil_profile.sys.executable, "-c", code], **kwargs)

    monkeypatch.setattr(gil_profile.subprocess, "Popen", fake_perf)
    if valid:
        with gil_profile.recording(123, tmp_path, None) as process:
            assert (tmp_path / "perf.log").read_text().splitlines()[-1] == "enabled"
            assert process.poll() is None
        assert process.returncode == 0
    else:
        with pytest.raises(RuntimeError, match="handshake failed.*reply="):
            with gil_profile.recording(123, tmp_path, None):
                pytest.fail("Malformed acknowledgement enabled the workload")


@pytest.mark.skipif(gil_profile.shutil.which("perf") is None, reason="perf unavailable")
async def test_real_perf_enable_handshake(monkeypatch: Any, tmp_path: Path) -> None:
    original = gil_profile.subprocess.Popen
    # CPU-only user-space sampling exercises perf's actual control protocol
    # without requiring root, uprobes or the privileged collector's mmap quota.
    target = original([gil_profile.sys.executable, "-c", "import time; time.sleep(30)"])

    def user_perf(args: list[str], **kwargs: Any) -> Any:
        args = list(args)
        args[args.index("-e") + 1] = "cpu-clock:u"
        args[args.index("-m") + 1] = "8"
        return original(args, **kwargs)

    monkeypatch.setattr(gil_profile.subprocess, "Popen", user_perf)
    try:
        try:
            with gil_profile.recording(target.pid, tmp_path, None) as process:
                assert process.poll() is None
        except RuntimeError:
            log = (tmp_path / "perf.log").read_text()
            if any(
                marker in log
                for marker in (
                    "Permission",
                    "permission",
                    "Operation not permitted",
                    "Access",
                    "perf_event_paranoid",
                    "not supported",
                )
            ):
                pytest.skip("Host policy does not permit unprivileged perf recording")
            raise
        assert process.returncode in (0, -gil_profile.signal.SIGINT, 130)
        assert (tmp_path / "perf.data").stat().st_size > 0
    finally:
        gil_profile.stop_process(target)
