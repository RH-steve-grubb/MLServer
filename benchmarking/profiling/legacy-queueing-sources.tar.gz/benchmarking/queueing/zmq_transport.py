"""Opt-in pickle/ZeroMQ data-plane diagnostic, not a production transport.

Keep stock model loading, shutdown queues, response futures and round-robin
selection. Replace only inference-message transport. Spawned workers receive
endpoint strings, never a live ZeroMQ socket or context. Serialization now runs
on the sending/receiving event loops rather than Queue feeder/executor threads;
this is a comparison of IPC designs, not just pipe versus socket bandwidth.
"""

import asyncio
import os
import time
import uuid
from dataclasses import dataclass, field
from multiprocessing.reduction import ForkingPickler
from pathlib import Path
from typing import Any, Callable

import zmq
import zmq.asyncio

from mlserver.parallel.dispatcher import Dispatcher
from mlserver.parallel.messages import ModelRequestMessage, ModelResponseMessage
from mlserver.parallel.worker import Worker

COUNTS = {
    "sent": 0,
    "received": 0,
    "sent_bytes": 0,
    "received_bytes": 0,
    "encode_ns": 0,
    "decode_ns": 0,
}
_ORIGINALS: dict[str, Callable[..., Any]] = {
    "worker_init": Worker.__init__,
    "worker_run": Worker.coro_run,
    "dispatcher_init": Dispatcher.__init__,
    "dispatcher_stop": Dispatcher.stop,
}


def endpoint(kind: str) -> str:
    directory = Path(os.environ["MLSERVER_QUEUE_ZMQ_DIR"])
    if not directory.is_dir():
        raise ValueError("ZeroMQ IPC directory must already exist")
    path = directory / f"{kind}-{uuid.uuid4().hex[:12]}.sock"
    if len(os.fsencode(path)) > 100:
        raise ValueError("ZeroMQ IPC pathname exceeds the diagnostic's safe limit")
    return f"ipc://{path}"


def make_socket(context: zmq.asyncio.Context, kind: int) -> Any:
    sock = context.socket(kind)
    # Match the stock unbounded multiprocessing queues, not a new admission
    # policy. Only fixed-concurrency trusted local diagnostics may use this.
    sock.setsockopt(zmq.SNDHWM, 0)
    sock.setsockopt(zmq.RCVHWM, 0)
    sock.setsockopt(zmq.LINGER, 0)
    if kind == zmq.PUSH:
        sock.setsockopt(zmq.IMMEDIATE, 1)
    return sock


def pack(value: Any) -> memoryview:
    started = time.perf_counter_ns()
    # Use Queue's exact serializer and default protocol, including Pydantic's
    # original pickle reducers. No model_dump(), MessagePack or tensor changes.
    data = ForkingPickler.dumps(value)
    COUNTS["encode_ns"] += time.perf_counter_ns() - started
    COUNTS["sent"] += 1
    COUNTS["sent_bytes"] += len(data)
    return data


def unpack(data: bytes) -> Any:
    started = time.perf_counter_ns()
    value = ForkingPickler.loads(data)
    COUNTS["decode_ns"] += time.perf_counter_ns() - started
    COUNTS["received"] += 1
    COUNTS["received_bytes"] += len(data)
    return value


def init_worker(self: Worker, *args: Any, **kwargs: Any) -> None:
    _ORIGINALS["worker_init"](self, *args, **kwargs)
    responses = self._responses
    reply = getattr(responses, "_queue_zmq_reply", None)
    if reply is None:
        reply = endpoint("r")
        setattr(responses, "_queue_zmq_reply", reply)
    # Queue.__getstate__ omits arbitrary attributes, so also store the strings
    # on Worker itself where multiprocessing spawn will preserve them.
    setattr(self, "_queue_zmq_reply", reply)
    setattr(self, "_queue_zmq_request", endpoint("q"))


async def worker_requests(worker: Worker) -> None:
    context = zmq.asyncio.Context(io_threads=1)
    requests = make_socket(context, zmq.PULL)
    replies = make_socket(context, zmq.PUSH)
    try:
        requests.bind(getattr(worker, "_queue_zmq_request"))
        replies.connect(getattr(worker, "_queue_zmq_reply"))
        while True:
            request = unpack(await requests.recv(copy=True))
            if not isinstance(request, ModelRequestMessage):
                raise TypeError("Unexpected ZeroMQ diagnostic request")
            # Exercise the original registry lookup, model-context handling,
            # method invocation and error envelope. ONNX remains synchronous.
            response = await worker._process_request(request)
            await replies.send(pack(response), copy=True)
            # A ready socket need not suspend. Preserve an opportunity for the
            # unchanged control-plane loop to handle unload/stop messages.
            await asyncio.sleep(0)
    finally:
        requests.close()
        replies.close()
        context.term()


async def run_worker(self: Worker) -> None:
    # The original coroutine initializes the registry before its first await.
    # Create it first so the data-plane coroutine never sees a missing registry.
    control = asyncio.create_task(_ORIGINALS["worker_run"](self))
    data = asyncio.create_task(worker_requests(self))
    try:
        done, _ = await asyncio.wait(
            (control, data), return_when=asyncio.FIRST_COMPLETED
        )
        if control in done:
            await control
        else:
            await data
            raise RuntimeError("ZeroMQ diagnostic request loop stopped unexpectedly")
    finally:
        control.cancel()
        data.cancel()
        await asyncio.gather(control, data, return_exceptions=True)


@dataclass
class ParentTransport:
    context: zmq.asyncio.Context
    replies: Any
    requests: dict[int, Any] = field(default_factory=dict)
    receiver: asyncio.Task | None = None

    async def close(self) -> None:
        if self.receiver:
            self.receiver.cancel()
            await asyncio.gather(self.receiver, return_exceptions=True)
        for sock in self.requests.values():
            sock.close()
        self.replies.close()
        self.context.term()


async def receive_responses(dispatcher: Dispatcher, sock: Any) -> None:
    while True:
        response = unpack(await sock.recv(copy=True))
        if not isinstance(response, ModelResponseMessage):
            raise TypeError("Unexpected ZeroMQ diagnostic response")
        dispatcher._async_responses.resolve(response)
        await asyncio.sleep(0)


def init_dispatcher(self: Dispatcher, *args: Any, **kwargs: Any) -> None:
    _ORIGINALS["dispatcher_init"](self, *args, **kwargs)
    context = zmq.asyncio.Context(io_threads=1)
    replies = make_socket(context, zmq.PULL)
    state = ParentTransport(context, replies)
    try:
        replies.bind(getattr(self._responses, "_queue_zmq_reply"))
        setattr(self, "_queue_zmq", state)
        state.receiver = asyncio.create_task(receive_responses(self, replies))
    except BaseException:
        replies.close()
        context.term()
        raise


async def dispatch_request(
    self: Dispatcher, message: ModelRequestMessage
) -> ModelResponseMessage:
    state: ParentTransport = getattr(self, "_queue_zmq")
    if state.receiver is None or state.receiver.done():
        raise RuntimeError("ZeroMQ diagnostic response loop is unavailable")
    worker, pid = self._get_worker()
    if pid not in state.requests:
        sock = make_socket(state.context, zmq.PUSH)
        sock.connect(getattr(worker, "_queue_zmq_request"))
        state.requests[pid] = sock
    # Register before the async send: unlike Queue.put(), send can suspend and
    # a fast worker could return before a future registered afterwards existed.
    future = self._async_responses._schedule(message, worker)
    try:
        await state.requests[pid].send(pack(message), copy=True)
    except BaseException:
        future.cancel()
        self._async_responses._clear_message(message.id)
        raise
    return await self._async_responses._wait(message.id)


async def stop_dispatcher(self: Dispatcher) -> None:
    try:
        await getattr(self, "_queue_zmq").close()
    finally:
        await _ORIGINALS["dispatcher_stop"](self)


def install() -> None:
    """Install process-local diagnostic hooks, including in spawned workers."""
    if Worker.coro_run is run_worker:
        return
    if os.environ.get("MLSERVER_QUEUE_CODEC", "pickle") != "pickle":
        raise ValueError("ZeroMQ transport comparison requires the stock pickle codec")
    if os.environ.get("MLSERVER_QUEUE_TENSORS", "list") != "list":
        raise ValueError("ZeroMQ transport comparison requires the stock list inputs")
    setattr(Worker, "__init__", init_worker)
    setattr(Worker, "coro_run", run_worker)
    setattr(Dispatcher, "__init__", init_dispatcher)
    setattr(Dispatcher, "dispatch_request", dispatch_request)
    setattr(Dispatcher, "stop", stop_dispatcher)
