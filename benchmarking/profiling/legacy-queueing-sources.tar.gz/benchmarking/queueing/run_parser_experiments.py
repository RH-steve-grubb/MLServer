"""Control Uvicorn's h11/httptools parser before attributing gains to aiohttp.

Expose the isolated httptools and PyZMQ libraries to the existing Python-3.12
MLServer environment. No production dependency changes or automatic installs.
Fresh typed Queue and raw ZeroMQ controls; all workers/model work stay fixed.
"""

import argparse
import importlib
import json
import math
import os
import shutil
import sys
from pathlib import Path
from typing import Any

_http = importlib.import_module(
    f"{__package__}.run_http_experiments" if __package__ else "run_http_experiments"
)
PARSERS = {
    "stock-fastapi-queue": "h11",
    "stock-fastapi-queue-httptools": "httptools",
    "raw-fastapi-zmq": "h11",
    "raw-fastapi-zmq-httptools": "httptools",
    "raw-aiohttp-zmq": "auto",
}


def validate_parser(document: dict[str, Any], variant: str) -> None:
    _http.validate(document, variant)
    selected = document["metadata"]["http_engine"]
    expected = (
        "aiohttp._http_parser.HttpRequestParser"
        if variant == "raw-aiohttp-zmq"
        else (
            "uvicorn.protocols.http.h11_impl.H11Protocol"
            if PARSERS[variant] == "h11"
            else "uvicorn.protocols.http.httptools_impl.HttpToolsProtocol"
        )
    )
    if selected != expected:
        raise ValueError(f"Wrong actual HTTP parser: {selected}; expected {expected}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=float, default=6)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--batches", type=int, nargs="+", default=[1, 100, 1000])
    parser.add_argument("--concurrencies", type=int, nargs="+", default=[64])
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 12):
        parser.error("Use the study's MLServer Python-3.12 Poetry environment")
    if (
        not math.isfinite(args.seconds)
        or args.seconds <= 0
        or args.repeats <= 0
        or min(args.batches + args.concurrencies) <= 0
    ):
        parser.error("Duration, repeats and workload values must be positive/finite")
    args.output, args.model = args.output.absolute(), args.model.absolute()
    args.balance, args.variants = False, list(PARSERS)
    _http.VARIANTS.update(
        {
            "stock-fastapi-queue-httptools": ("fastapi", "queue", "frontend"),
            "raw-fastapi-zmq-httptools": ("fastapi", "zmq", "full"),
        }
    )
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    source = args.output / "source"
    source.mkdir()
    for name in (
        "bench.py",
        "probe.py",
        "raw_worker.py",
        "aiohttp_frontend.py",
        "worker_balance.py",
        "zmq_transport.py",
        "http_parser.py",
        "run_http_experiments.py",
        "run_zmq_experiment.py",
        "run_parser_experiments.py",
        "test_http_parser.py",
    ):
        shutil.copy2(_http.BENCH.with_name(name), source / name)
    for project in ("http-parser-env", "zeromq-env"):
        shutil.copytree(_http.BENCH.parent / project, source / project)
    for name in ("pyproject.toml", "poetry.lock"):
        shutil.copy2(_http.BENCH.parents[2] / name, source / name)
    docs: list[dict[str, Any]] = []
    previous = os.environ.get("MLSERVER_QUEUE_HTTP_PARSER")
    try:
        for trial in range(args.repeats):
            order = args.variants[::-1] if trial % 2 else args.variants
            for variant in order:
                os.environ["MLSERVER_QUEUE_HTTP_PARSER"] = PARSERS[variant]
                document = _http.run_block(args, variant, len(docs))
                validate_parser(document, variant)
                docs.append(document)
                (args.output / "results.json").write_text(json.dumps(docs, indent=2))
                _http.summarize(args.output, docs, False)
    finally:
        if previous is None:
            os.environ.pop("MLSERVER_QUEUE_HTTP_PARSER", None)
        else:
            os.environ["MLSERVER_QUEUE_HTTP_PARSER"] = previous
        _http.summarize(args.output, docs, False)
    print(f"Finished. Read {args.output / 'SUMMARY.txt'}", flush=True)


if __name__ == "__main__":
    main()
