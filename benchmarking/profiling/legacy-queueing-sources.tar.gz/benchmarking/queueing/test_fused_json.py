"""Fused-input correctness, exceptional fallback and unchanged output path."""

import asyncio
import json
import threading
from copy import deepcopy
from typing import Any
from unittest.mock import Mock

import pytest
from httpx import ASGITransport, AsyncClient

from . import frontend_offload, run_fused_json
from .test_frontend_offload import body, make_server
from .test_frontend_transport import measurement


def encoded_bodies() -> list[bytes]:
    document = json.loads(body())
    cases = [document]
    for data in ([True, False], [2**100, -(2**100)], [None, 1.5], [1e-300, 1e300]):
        value = deepcopy(document)
        value["inputs"][0]["data"] = data
        cases.append(value)
    value = deepcopy(document)
    value["parameters"] = {"custom": {"items": [1, "é", None]}}
    cases.append(value)
    return [json.dumps(value).encode() for value in cases] + [
        b"",
        b"{}",
        b"[]",
        b"null",
        b"{",
        b" ",
        b"\xff",
        body().decode().encode("utf-16"),
    ]


@pytest.mark.parametrize("workers", [0, 4])
@pytest.mark.parametrize("versioned", [False, True])
@pytest.mark.parametrize("encoded", encoded_bodies())
async def test_fused_routes_preserve_json_contract(
    workers: int, versioned: bool, encoded: bytes, monkeypatch: Any
) -> None:
    # Match the serving experiment's stdlib JSON control, not the different
    # orjson dependency path in the production Python 3.12 environment.
    from mlserver.codecs import json as codec
    from mlserver.rest import requests

    monkeypatch.setattr(codec, "orjson", None)
    monkeypatch.setattr(requests, "orjson", None)
    owners: list[int] = []
    control, fused = make_server(owners), make_server(owners)
    pool = frontend_offload.install_routes(fused, workers, "fused-input")
    path = "/v2/models/chosen-model"
    if versioned:
        path += "/versions/v2"
    try:
        replies = []
        for server in (control, fused):
            async with AsyncClient(
                transport=ASGITransport(app=server._app), base_url="http://test"
            ) as client:
                replies.append(
                    await client.post(
                        path + "/infer",
                        content=encoded,
                        headers={
                            "content-type": "application/json",
                            "x-input": "retained",
                        },
                    )
                )
        expected, actual = replies
        assert actual.status_code == expected.status_code
        assert actual.json() == expected.json()
        if actual.status_code == 200:
            # Input fusion must not accidentally optimize/change the response
            # formatter too; compare bytes and protocol headers, not just JSON.
            assert actual.content == expected.content
            assert actual.headers["x-output"] == expected.headers["x-output"]
            assert actual.headers["content-length"] == str(len(actual.content))
        assert all(owner == threading.get_native_id() for owner in owners)
        assert pool.inflight == 0
    finally:
        await pool.close()


async def test_successful_fused_input_does_not_use_old_parser(monkeypatch: Any) -> None:
    server = make_server([])
    pool = frontend_offload.install_routes(server, 4, "fused-input")
    parser = Mock(side_effect=AssertionError("Old parser used for valid UTF8 JSON"))
    monkeypatch.setattr(frontend_offload, "decode_from_bytelike_json_to_dict", parser)
    try:
        async with AsyncClient(
            transport=ASGITransport(app=server._app), base_url="http://test"
        ) as client:

            async def predict(index: int) -> None:
                document = json.loads(body())
                document["id"] = str(index)
                document["inputs"][0]["data"] = [index, index + 0.25]
                response = await client.post(
                    f"/v2/models/model-{index % 8}/versions/v2/infer",
                    json=document,
                    headers={"x-input": "retained"},
                )
                assert response.status_code == 200
                result = response.json()
                assert result["id"] == str(index)
                assert result["model_name"] == f"model-{index % 8}"
                assert result["model_version"] == "v2"
                assert result["outputs"][0]["data"] == [index, index + 0.25]

            await asyncio.gather(*(predict(index) for index in range(64)))
        assert pool.completed == 128 and pool.inflight == 0
        assert pool.peak_inflight <= 4
        assert all(
            stage.snapshot() == {"mode": "fused-input", "validation_fallbacks": 0}
            for stage in server._app.state.frontend_json_stages
        )
        parser.assert_not_called()
        assert (
            frontend_offload.FusedInputStages.encode
            is frontend_offload.JsonStages.encode
        )
    finally:
        await pool.close()


async def test_fallback_is_visible_and_other_routes_remain_unchanged() -> None:
    server = make_server([])
    untouched = [
        route
        for route in server._app.routes
        if getattr(route, "path", None) not in frontend_offload.PATHS
    ]
    pool = frontend_offload.install_routes(server, 0, "fused-input")
    try:
        assert all(route in server._app.routes for route in untouched)
        async with AsyncClient(
            transport=ASGITransport(app=server._app), base_url="http://test"
        ) as client:
            response = await client.post(
                "/v2/models/chosen-model/infer",
                content=b"{",
                headers={"content-type": "application/json", "x-input": "retained"},
            )
        assert response.status_code == 422
        assert (
            sum(
                stage.snapshot()["validation_fallbacks"]
                for stage in server._app.state.frontend_json_stages
            )
            == 1
        )
    finally:
        await pool.close()


def fused_measurement(mode: str = "off", threads: int = 8) -> dict:
    row = measurement("queue", threads)
    row.update(mode=mode, json_mode="fused-input", scheduler="round-robin")
    for phase in ("before", "after"):
        row["checks"][phase].update(
            gil_enabled=mode == "on",
            scheduler="round-robin",
            least_outstanding_installed=False,
            frontend_json_stages=[
                dict(mode="fused-input", validation_fallbacks=0) for _ in range(2)
            ],
        )
    row["checks"]["after"]["frontend_json_pool"]["thread_gil_states"] = (
        {"123": mode == "on"} if threads else {}
    )
    return row


@pytest.mark.parametrize("mode", ["on", "off"])
@pytest.mark.parametrize("threads", [0, 8])
def test_valid_fused_controls(mode: str, threads: int) -> None:
    run_fused_json.validate(fused_measurement(mode, threads))


@pytest.mark.parametrize("phase", ["before", "after"])
@pytest.mark.parametrize("defect", ["fallback", "mode", "gil", "scheduler", "workers"])
def test_rejects_confounded_fused_controls(phase: str, defect: str) -> None:
    row = fused_measurement()
    state = row["checks"][phase]
    if defect == "fallback":
        state["frontend_json_stages"][0]["validation_fallbacks"] = 1
    elif defect == "mode":
        state["frontend_json_stages"][0]["mode"] = "separate"
    elif defect == "gil":
        state["gil_enabled"] = True
    elif defect == "scheduler":
        state["least_outstanding_installed"] = True
    else:
        row["checks"]["startup"][0]["gil_enabled"] = False
    with pytest.raises(ValueError):
        run_fused_json.validate(row)


def test_summary_compares_fusion_with_same_threads_and_gil() -> None:
    rows = []
    for mode in ("on", "off"):
        for threads in (0, 8):
            for codec in ("separate", "fused-input"):
                row = fused_measurement(mode, threads)
                row["json_mode"] = codec
                row["rps"] *= 1.5 if codec == "fused-input" else 1
                rows.append(row)
    text = run_fused_json.summarize(rows)
    assert text.count("1.500") == 4
    assert "response formatting unchanged" in text
    assert "not a Python 3.12 performance comparison" in text


def test_unknown_mode_rejected_before_routes_change() -> None:
    server = make_server([])
    original = list(server._app.routes)
    with pytest.raises(ValueError, match="Unknown frontend JSON"):
        frontend_offload.install_routes(server, 4, "unknown")
    assert server._app.routes == original
