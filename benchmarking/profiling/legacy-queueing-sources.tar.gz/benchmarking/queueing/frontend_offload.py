"""Diagnostic frontend JSON stages, inline or in a bounded thread pool.

Only the two JSON infer routes are replaced. The original FastAPI fields and
MLServer endpoint retain validation, model selection, headers and DataPlane
dispatch. No coroutine, registry, asyncio Future or worker queue moves threads.
This is not a general REST replacement (forms, dependencies and streaming are
outside the experiment).
"""

import asyncio
import json
import os
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from typing import Any, Callable

from fastapi import HTTPException, Request, Response
from fastapi.dependencies.utils import _validate_value_with_model_field
from fastapi.exceptions import RequestValidationError, ResponseValidationError
from pydantic import ValidationError

from mlserver.codecs.json import decode_from_bytelike_json_to_dict, encode_to_json_bytes
from mlserver.rest.app import APIRoute

PATHS = (
    "/v2/models/{model_name}/infer",
    "/v2/models/{model_name}/versions/{model_version}/infer",
)


class JsonPool:
    def __init__(self, workers: int):
        if workers < 0:
            raise ValueError("JSON thread count cannot be negative")
        self.workers = workers
        self.executor = (
            ThreadPoolExecutor(
                max_workers=workers,
                thread_name_prefix="frontend-json",
                initializer=self._initialise_thread,
            )
            if workers
            else None
        )
        # Bound submitted work, not just the number of running threads: the
        # executor's own queue is otherwise unbounded. Cancellation must keep
        # the slot until the CPU job actually finishes, not until await exits.
        self.slots = asyncio.Semaphore(workers) if workers else None
        self.inflight = 0
        self.peak_inflight = 0
        self.completed = 0
        self.thread_states: dict[int, bool] = {}
        self.thread_lock = threading.Lock()

    def _initialise_thread(self) -> None:
        enabled = getattr(sys, "_is_gil_enabled", lambda: True)()
        expected = os.environ.get("MLSERVER_FT_EXPECT")
        if expected is not None and enabled != (expected == "on"):
            raise RuntimeError("Unexpected GIL state in frontend JSON thread")
        with self.thread_lock:
            self.thread_states[threading.get_native_id()] = enabled

    def _finished(self, future: asyncio.Future) -> None:
        # This callback runs on the owning event loop, including when the
        # caller was cancelled. Retrieve exceptions for abandoned CPU jobs.
        future.exception()
        self.inflight -= 1
        self.completed += 1
        assert self.slots is not None
        self.slots.release()

    async def run(self, operation: Callable, *args: Any) -> Any:
        if self.executor is None:
            self.completed += 1
            return operation(*args)
        assert self.slots is not None
        await self.slots.acquire()
        try:
            future = asyncio.get_running_loop().run_in_executor(
                self.executor, operation, *args
            )
        except BaseException:
            self.slots.release()
            raise
        self.inflight += 1
        self.peak_inflight = max(self.peak_inflight, self.inflight)
        future.add_done_callback(self._finished)
        # Cancelling an await cannot stop Python/native CPU work already
        # running. Shield the job so its permit is not released prematurely.
        return await asyncio.shield(future)

    def snapshot(self) -> dict[str, Any]:
        with self.thread_lock:
            states = dict(self.thread_states)
        return {
            "workers": self.workers,
            "completed": self.completed,
            "inflight": self.inflight,
            "peak_inflight": self.peak_inflight,
            "thread_gil_states": states,
        }

    async def close(self) -> None:
        if self.executor is not None:
            # Wait for all submitted CPU work, even abandoned jobs, without
            # blocking the event loop which owns their completion callbacks.
            await asyncio.to_thread(self.executor.shutdown, wait=True)
            await asyncio.sleep(0)


class JsonStages:
    def __init__(self, route: APIRoute, pool: JsonPool):
        self.route = route
        self.pool = pool

    def snapshot(self) -> dict[str, Any]:
        return {"mode": "separate", "validation_fallbacks": 0}

    def parse(self, body: bytes) -> Any:
        decoded = None
        if body:
            try:
                decoded = decode_from_bytelike_json_to_dict(body)
            except json.JSONDecodeError as error:
                raise RequestValidationError(
                    [
                        {
                            "type": "json_invalid",
                            "loc": ("body", error.pos),
                            "msg": "JSON decode error",
                            "input": {},
                            "ctx": {"error": error.msg},
                        }
                    ],
                    body=error.doc,
                ) from error
            except UnicodeDecodeError as error:
                raise HTTPException(
                    status_code=400, detail="There was an error parsing the body"
                ) from error
        # Reuse the original route's pre-built field rather than fused
        # model_validate_json(): changing parser would confound thread placement.
        field = self.route.body_field
        assert field is not None
        value, errors = _validate_value_with_model_field(
            field=field, value=decoded, values={}, loc=("body",)
        )
        if errors:
            raise RequestValidationError(errors, body=decoded)
        return value

    def encode(self, response: Any) -> bytes:
        field = self.route.response_field
        assert field is not None
        value, errors = field.validate(response, {}, loc=("response",))
        if errors:
            raise ResponseValidationError(errors=errors, body=response)
        content = field.serialize(
            value,
            include=self.route.response_model_include,
            exclude=self.route.response_model_exclude,
            by_alias=self.route.response_model_by_alias,
            exclude_unset=self.route.response_model_exclude_unset,
            exclude_defaults=self.route.response_model_exclude_defaults,
            exclude_none=self.route.response_model_exclude_none,
        )
        return encode_to_json_bytes(content)

    async def infer(self, request: Request) -> Response:
        content_type = request.headers.get("content-type", "application/json")
        if "json" not in content_type.lower():
            # This experiment intentionally handles JSON only; do not present
            # it as production parity for arbitrary request content types.
            return Response(status_code=415)
        payload = await self.pool.run(self.parse, await request.body())
        headers = Response()
        # Run the unmodified MLServer endpoint on its owning event loop.
        # This retains request IDs, model/version lookup and header propagation.
        result = await self.route.endpoint(
            request, headers, payload, **request.path_params
        )
        encoded = await self.pool.run(self.encode, result)
        response = Response(encoded, media_type="application/json")
        response.headers.raw.extend(
            (key, value)
            for key, value in headers.headers.raw
            if key not in (b"content-length", b"content-type")
        )
        return response


class FusedInputStages(JsonStages):
    """Reuse the route's schema to parse and validate JSON in one operation."""

    def __init__(self, route: APIRoute, pool: JsonPool):
        super().__init__(route, pool)
        self._fallbacks = 0
        self._fallback_lock = threading.Lock()

    def snapshot(self) -> dict[str, Any]:
        with self._fallback_lock:
            return {"mode": "fused-input", "validation_fallbacks": self._fallbacks}

    def _fallback(self, body: bytes) -> Any:
        # Retain original malformed/schema-error behavior, including JSON
        # error locations and non-UTF8 encodings accepted by json.loads().
        # This extra parse is ONLY on the exceptional path; serving controls
        # must verify zero fallbacks instead of silently timing the old parser.
        with self._fallback_lock:
            self._fallbacks += 1
        return super().parse(body)

    def parse(self, body: bytes) -> Any:
        if not body:
            return self._fallback(body)
        field = self.route.body_field
        assert field is not None
        try:
            # Reuse the pre-built adapter: per-request schema construction
            # would confound fusion with a substantial unrelated cost.
            return field._type_adapter.validate_json(body)
        except ValidationError:
            return self._fallback(body)


def install_routes(server: Any, workers: int, json_mode: str = "separate") -> JsonPool:
    """Install only the diagnostic JSON infer pair; zero threads means inline."""
    if json_mode not in ("separate", "fused-input"):
        raise ValueError("Unknown frontend JSON mode")
    pool = JsonPool(workers)
    checks = []
    replaced = 0
    for index, route in enumerate(server._app.router.routes):
        if getattr(route, "path", None) in PATHS:
            if not isinstance(route, APIRoute):
                raise TypeError("Expected the original MLServer infer route")
            stages = (
                FusedInputStages(route, pool)
                if json_mode == "fused-input"
                else JsonStages(route, pool)
            )
            checks.append(stages)
            server._app.router.routes[index] = APIRoute(
                route.path, stages.infer, methods=["POST"], response_model=None
            )
            replaced += 1
    if replaced != len(PATHS):
        raise ValueError("Expected both original infer routes")
    original_lifespan = server._app.router.lifespan_context

    @asynccontextmanager
    async def lifespan(app: Any) -> Any:
        try:
            async with original_lifespan(app) as state:
                yield state
        finally:
            await pool.close()

    server._app.router.lifespan_context = lifespan
    server._app.state.frontend_json_pool = pool
    server._app.state.frontend_json_stages = checks
    return pool
